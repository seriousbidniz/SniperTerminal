import test from "node:test";
import assert from "node:assert/strict";
import { makeDb } from "./mockdb.mjs";
import { runPipeline } from "../base44/shared/pipeline.js";
import { computeSeries } from "../base44/shared/indicators.js";
import { analyzeAt, enrichSeries } from "../base44/shared/signalEngine.js";

const H = 3600_000;
function klines(n, endMs, seed = 3, drift = 0.002) {
  let s = seed; const r = () => (s = (s * 16807) % 2147483647) / 2147483647;
  const start = Math.floor(endMs / H) * H - (n - 1) * H; let p = 100; const rows = [];
  for (let i = 0; i < n; i++) {
    const d = typeof drift === "function" ? drift(i, n) : drift;
    const o = p, c = o * (1 + d + (r() - 0.5) * 0.02);
    rows.push([start + i * H, o, Math.max(o, c) * 1.003, Math.min(o, c) * 0.997, c, 1, start + (i + 1) * H - 1, 1000 + r() * 800]);
    p = c;
  }
  return rows;
}

test("pipeline end-to-end on mocked providers: signals have levels, ids are stable, lifecycle advances", async () => {
  const { svc, tables } = makeDb();
  await svc.entities.Assets.bulkCreate([
    { symbol: "AAA", name: "Alpha", market_type: "crypto", active: true, liquidity_score: 80 },
    { symbol: "BBB", name: "Beta", market_type: "crypto", active: true, liquidity_score: 70 },
    { symbol: "EUR/USD", name: "Euro", market_type: "fx", active: true, liquidity_score: 99 },
  ]);
  await svc.entities.PushSubscriptions.create({ user_email: "u@x", endpoint: "https://push/1", p256dh: "k", auth: "a", active: true });
  await svc.entities.UserSettings.create({ user_email: "u@x", push_enabled: true, push_new_signals_min_score: 0, push_lifecycle: "all" });

  // Pick a deterministic seed whose last CLOSED bar produces a qualifying setup.
  const now0 = Date.now();
  let goodSeed = null;
  for (let seed = 1; seed < 200 && !goodSeed; seed++) {
    const rows = klines(300, now0, seed);
    const c = rows.slice(0, -1).map((k) => ({ t: k[0], o: k[1], h: k[2], l: k[3], c: k[4], v: k[7] }));
    const a = analyzeAt(enrichSeries(computeSeries(c)), c.length - 1, { symbol: "AAA", market_type: "crypto", liquidity_score: 80 });
    if (a && a.opportunity_score >= 52) goodSeed = seed;
  }
  assert.ok(goodSeed, "found a seed");
  const calls = [];
  globalThis.fetch = async (url) => {
    calls.push(String(url));
    if (String(url).includes("binance")) {
      const sym = new URL(url).searchParams.get("symbol");
      if (sym === "BBBUSDT") return new Response("restricted", { status: 451 });
      return Response.json(klines(300, now0, sym === "AAAUSDT" ? goodSeed : 5));
    }
    // Yahoo fallback
    const rows = klines(300, Date.now(), 9, -0.002);
    return Response.json({ chart: { result: [{ timestamp: rows.map((k) => k[0] / 1000), indicators: { quote: [{ open: rows.map((k) => k[1]), high: rows.map((k) => k[2]), low: rows.map((k) => k[3]), close: rows.map((k) => k[4]), volume: rows.map(() => 0) }] } }] } });
  };

  const s1 = await runPipeline(svc, { deadlineMs: 60_000 });
  assert.equal(s1.assets, 3);
  assert.equal(s1.failed.length, 0);
  assert.ok(calls.some((u) => u.includes("BBB-USD")), "451 from Binance falls back to Yahoo");
  const assets = tables.Assets;
  assert.equal(assets.find((a) => a.symbol === "BBB").candle_source, "yahoo");
  assert.equal(assets.find((a) => a.symbol === "AAA").candle_source, "binance");
  for (const snap of tables.MarketSnapshots) assert.ok(snap.rsi == null || (snap.rsi >= 0 && snap.rsi <= 100));

  const rec = tables.RecommendedTradeSignals || [];
  for (const s of rec) {
    assert.ok(s.entry_low != null && s.invalidation != null && s.target_1 != null && s.expires_at, "every signal has levels + expiry");
  }
  const viral = tables.ViralTradeSignals || [];
  for (const v of viral) assert.ok(v.invalidation != null && v.expires_at);

  const idsBefore = rec.filter((s) => s.status === "active").map((s) => s.id).sort();
  const s2 = await runPipeline(svc, { deadlineMs: 60_000 });
  const live = (tables.RecommendedTradeSignals || []).filter((s) => ["active", "triggered", "target_hit"].includes(s.status));
  for (const id of idsBefore) {
    const sig = tables.RecommendedTradeSignals.find((s) => s.id === id);
    assert.ok(sig.status !== "superseded" || s2.rec.superseded > 0, "no churn without a direction flip");
  }
  assert.ok(live.length <= 3, "at most one live signal per asset");

  // Force a signal through its lifecycle: put an active signal's entry zone + invalidation above price.
  assert.ok(live.length > 0, "fixture should yield at least one live signal");
  {
    const sig = live[0];
    const last = tables.MarketSnapshots.filter((x) => x.asset === sig.asset).at(-1).price;
    Object.assign(sig, { status: "active", direction: "bullish", entry_low: last * 0.5, entry_high: last * 2, invalidation: last * 0.4, target_1: last * 3, target_2: last * 4, last_eval_bar_time: new Date(Date.now() - 3 * H).toISOString(), entry_triggered_at: null, entry_price: null, outcome: null });
    await runPipeline(svc, { deadlineMs: 60_000 });
    assert.equal(sig.status, "triggered");
    assert.ok(sig.entry_price > 0);
    const lifeAlerts = tables.Alerts.filter((a) => a.alert_type === "signal_lifecycle" && a.signal_id === sig.id);
    assert.equal(lifeAlerts.length, 1, JSON.stringify(lifeAlerts.map((a) => [a.trigger_reason, a.dedupe_key])));
    assert.ok(tables.PushOutbox.some((p) => p.signal_id === sig.id && p.title.includes("entry zone")), "push queued for lifecycle event");
  }
  assert.ok(tables.SystemState.some((r) => r.key === "pipeline:last_run"));
});
