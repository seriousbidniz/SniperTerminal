import test from "node:test";
import assert from "node:assert/strict";
import { ema, sma, rsi, atr, donchian, computeSeries } from "../base44/shared/indicators.js";
import { analyzeAt, enrichSeries, snapshotAt, analyzeViral } from "../base44/shared/signalEngine.js";
import { evaluateBar, evaluateBars, expireIfDue, rMultiple } from "../base44/shared/lifecycle.js";
import { backtestAsset, aggregateTrades, blendCalibration } from "../base44/shared/backtest.js";
import { attributeFills, performanceStats, parseBinanceSymbol } from "../base44/shared/attribution.js";
import { signBody, verifyBody } from "../base44/shared/signing.js";
import { encryptSecret, decryptSecret } from "../base44/shared/cryptoBox.js";
import { yahooSymbol, binancePair, roundPrice } from "../base44/shared/symbols.js";
import { buildAlerts } from "../base44/shared/alerts.js";

const H = 3600_000;
function rng(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }
function candles(n, { start = 100, drift = 0, vol = 0.01, seed = 7 } = {}) {
  const r = rng(seed); const out = []; let p = start; const t0 = Date.UTC(2026, 0, 1);
  for (let i = 0; i < n; i++) {
    const o = p; const c = o * (1 + drift + (r() - 0.5) * 2 * vol);
    const h = Math.max(o, c) * (1 + r() * vol * 0.5); const l = Math.min(o, c) * (1 - r() * vol * 0.5);
    out.push({ t: t0 + i * H, o, h, l, c, v: 1000 + r() * 500 }); p = c;
  }
  return out;
}

test("SMA/EMA known values", () => {
  assert.deepEqual(sma([1, 2, 3, 4, 5], 3), [null, null, 2, 3, 4]);
  const e = ema([1, 2, 3, 4, 5], 3);
  assert.equal(e[2], 2); assert.equal(e[3], 3); assert.equal(e[4], 4);
});

test("RSI matches Wilder reference (classic 14-period example)", () => {
  // Reference series from Wilder / StockCharts RSI worked example; first RSI ≈ 70.53
  const closes = [44.34,44.09,44.15,43.61,44.33,44.83,45.10,45.42,45.84,46.08,45.89,46.03,45.61,46.28,46.28,46.00,46.03,46.41,46.22,45.64];
  const r = rsi(closes, 14);
  assert.ok(Math.abs(r[14] - 70.53) < 0.1, `got ${r[14]}`);
  assert.ok(Math.abs(r[15] - 66.32) < 0.2, `got ${r[15]}`);
});

test("ATR and Donchian are causal (no look-ahead)", () => {
  const c = candles(300);
  const a1 = atr(c.map(x=>x.h), c.map(x=>x.l), c.map(x=>x.c), 14);
  const c2 = c.slice(0, 200);
  const a2 = atr(c2.map(x=>x.h), c2.map(x=>x.l), c2.map(x=>x.c), 14);
  assert.equal(a1[199], a2[199]);
  const d = donchian(c.map(x=>x.h), c.map(x=>x.l), 20);
  assert.equal(d.upper[50], Math.max(...c.slice(30, 50).map(x=>x.h)));
});

test("engine output is causal: analysing bar i ignores later bars", () => {
  const c = candles(400, { drift: 0.0015, seed: 3 });
  const asset = { symbol: "TST", market_type: "crypto", liquidity_score: 80 };
  for (let i = 250; i < 399; i += 7) {
    const full = analyzeAt(enrichSeries(computeSeries(c)), i, asset);
    const cut = analyzeAt(enrichSeries(computeSeries(c.slice(0, i + 1))), i, asset);
    // atrPctRank uses a trailing window, so identical inputs → identical output
    assert.deepEqual(full && { ...full }, cut && { ...cut });
  }
});

test("engine produces coherent levels whenever it fires", () => {
  let fired = 0;
  for (const seed of [1, 2, 3, 4, 5, 6]) {
    const c = candles(600, { drift: seed % 2 ? 0.001 : -0.001, seed, vol: 0.012 });
    const S = enrichSeries(computeSeries(c));
    for (let i = 210; i < c.length; i++) {
      const s = analyzeAt(S, i, { symbol: "X", market_type: "crypto", liquidity_score: 70 });
      if (!s) continue; fired++;
      assert.ok(s.entry_low <= s.entry_high);
      if (s.direction === "bullish") { assert.ok(s.invalidation < s.entry_low); assert.ok(s.target_1 > s.entry_high); assert.ok(s.target_2 >= s.target_1); }
      else { assert.ok(s.invalidation > s.entry_high); assert.ok(s.target_1 < s.entry_low); assert.ok(s.target_2 <= s.target_1); }
      assert.ok(new Date(s.expires_at).getTime() > c[i].t);
      assert.ok(s.opportunity_score >= 0 && s.opportunity_score <= 100);
      assert.equal(s.calibration_source, "uncalibrated");
    }
  }
  assert.ok(fired > 20, `engine fired ${fired} times`);
});

test("uncalibrated setups carry zero assumed edge; calibration moves the score", () => {
  const c = candles(500, { drift: 0.002, seed: 11 });
  const S = enrichSeries(computeSeries(c));
  const asset = { symbol: "X", market_type: "crypto", liquidity_score: 70 };
  let i = c.length - 1, base = null;
  for (; i > 300 && !base; i--) base = analyzeAt(S, i, asset);
  i++;
  assert.ok(base, "need a signal");
  const key = base.setup_type === "reversal" ? `reversal_${base.direction}|crypto` : `${base.setup_type}|crypto`;
  const good = analyzeAt(S, i, asset, { [key]: { n_effective: 200, win_rate: 0.7, expectancy_r: 0.6, median_bars_to_resolution: 10, source: "blended" } });
  const bad = analyzeAt(S, i, asset, { [key]: { n_effective: 200, win_rate: 0.2, expectancy_r: -0.6, median_bars_to_resolution: 10, source: "blended" } });
  assert.ok(good.opportunity_score > base.opportunity_score);
  assert.ok(bad.opportunity_score < base.opportunity_score);
  assert.equal(good.horizon_hours, 15);
});

const sigBull = { id: "s1", direction: "bullish", status: "active", entry_low: 99, entry_high: 100, invalidation: 97, target_1: 103, target_2: 106, timestamp: new Date(0).toISOString(), entry_window_hours: 4, expires_at: new Date(24 * H).toISOString() };

test("lifecycle: entry then target", () => {
  const r = evaluateBars(sigBull, [
    { t: 0, o: 101, h: 101.5, l: 99.5, c: 100.2 },
    { t: H, o: 100.2, h: 103.5, l: 100, c: 103 },
  ], "recommended", 10 * H);
  assert.deepEqual(r.events.map(e => e.type), ["entry_triggered", "target_1_hit"]);
  assert.equal(r.state.entry_price, 100);
  assert.equal(r.state.outcome, "win");
  assert.equal(r.state.outcome_r, 1);
});

test("lifecycle: same-bar target+stop counts as loss (conservative)", () => {
  const s = { ...sigBull, status: "triggered", entry_price: 100, entry_triggered_at: "x" };
  const r = evaluateBar(s, { t: H, o: 100, h: 104, l: 96, c: 100 }, "recommended", 10 * H);
  assert.equal(r.patch.status, "invalidated"); assert.equal(r.patch.outcome, "loss"); assert.equal(r.patch.outcome_r, -1);
});

test("lifecycle: invalidated before entry, expiry untriggered, bearish mirror", () => {
  assert.equal(evaluateBar(sigBull, { t: 0, o: 101, h: 101.5, l: 96.5, c: 97 }).patch.status, "invalidated"); // gap through zone & stop: in-zone → triggered then stopped
  const far = evaluateBar(sigBull, { t: 5 * H, o: 110, h: 111, l: 109, c: 110 }, "recommended", 10 * H);
  assert.equal(far.patch.outcome, "expired_untriggered");
  const bear = { ...sigBull, direction: "bearish", entry_low: 100, entry_high: 101, invalidation: 103, target_1: 97, target_2: 94 };
  const r = evaluateBars(bear, [{ t: 0, o: 99, h: 100.5, l: 98.8, c: 100 }, { t: H, o: 100, h: 100.5, l: 96.5, c: 97 }], "recommended", 10 * H);
  assert.deepEqual(r.events.map(e => e.type), ["entry_triggered", "target_1_hit"]);
  assert.equal(r.state.entry_price, 100); assert.equal(r.state.outcome_r, 1); // conservative fill at zone low for shorts
  assert.equal(rMultiple("bearish", 100, 103, 106), -2);
});

test("lifecycle: time-based expiry", () => {
  const e = expireIfDue({ ...sigBull, status: "triggered", entry_price: 100 }, "recommended", 25 * H);
  assert.equal(e.patch.status, "expired");
  assert.equal(expireIfDue(sigBull, "recommended", 1 * H), null);
});

test("backtest + blend", () => {
  const c = candles(1000, { drift: 0.0008, seed: 21, vol: 0.01 });
  const trades = backtestAsset(c, { symbol: "X", market_type: "crypto", liquidity_score: 70 });
  assert.ok(trades.length > 5, `trades ${trades.length}`);
  for (const t of trades) if (t.triggered) assert.ok(Number.isFinite(t.r));
  const agg = aggregateTrades(trades);
  const k = Object.keys(agg)[0];
  const b = blendCalibration(agg[k], { n: 10, wins: 10, sum_r: 15, bars: [5] }, { maxPrior: 5 });
  assert.ok(b.n_effective <= 15 && b.n_effective > 10);
  assert.equal(blendCalibration(null, null).n_effective, 0);
});

test("attribution: entry in zone, exit closes with R and win", () => {
  const sig = { id: "sig1", kind: "recommended", asset: "a1", direction: "bullish", setup_type: "bullish_breakout", timestamp: "2026-01-01T00:00:00Z", expires_at: "2026-01-02T00:00:00Z", entry_low: 99, entry_high: 100, invalidation: 97, atr: 1 };
  const base = { base_asset: "BTC", quote_asset: "USDT", commission_asset: "USDT" };
  const res = attributeFills([
    { ...base, external_trade_id: "1", side: "buy", price: 100, qty: 1, commission: 0.1, executed_at: "2026-01-01T02:00:00Z" },
    { ...base, external_trade_id: "2", side: "buy", price: 150, qty: 1, commission: 0, executed_at: "2026-03-01T02:00:00Z" },
  ], [], { BTC: [sig] }, "u@x");
  assert.equal(res.executionCreates.length, 1);
  assert.equal(res.fillPatches[1].match_type, "unmatched");
  const ex = { ...res.executionCreates[0], id: "e1" };
  const res2 = attributeFills([{ ...base, external_trade_id: "3", side: "sell", price: 103, qty: 1, commission: 0.1, executed_at: "2026-01-01T05:00:00Z" }], [ex], { BTC: [sig] }, "u@x");
  const done = res2.executionUpdates[0];
  assert.equal(done.status, "closed"); assert.equal(done.outcome, "win");
  assert.ok(Math.abs(done.realised_pnl - 2.8) < 1e-9);
  assert.ok(Math.abs(done.r_multiple - 0.93) < 0.01);
  const st = performanceStats([done]);
  assert.equal(st.win_rate, 1);
  assert.deepEqual(parseBinanceSymbol("ETHUSDT"), { base: "ETH", quote: "USDT" });
});

test("attribution: out-of-zone fill is low confidence and excluded from headline", () => {
  const sig = { id: "s", kind: "recommended", direction: "bullish", timestamp: "2026-01-01T00:00:00Z", expires_at: "2026-01-02T00:00:00Z", entry_low: 99, entry_high: 100, invalidation: 97, atr: 1 };
  const r = attributeFills([{ base_asset: "SOL", quote_asset: "USDT", external_trade_id: "1", side: "buy", price: 120, qty: 1, executed_at: "2026-01-01T03:00:00Z" }], [], { SOL: [sig] }, "u");
  assert.equal(r.executionCreates[0].match_confidence, "low");
  assert.equal(performanceStats([{ ...r.executionCreates[0], status: "closed", outcome: "win" }]).win_rate, null);
});

test("HMAC sign/verify incl. replay window", async () => {
  const { timestamp, signature } = await signBody("s3cret", '{"a":1}');
  assert.equal(await verifyBody("s3cret", '{"a":1}', timestamp, signature), true);
  assert.equal(await verifyBody("s3cret", '{"a":2}', timestamp, signature), false);
  assert.equal(await verifyBody("wrong", '{"a":1}', timestamp, signature), false);
  assert.equal(await verifyBody("s3cret", '{"a":1}', timestamp, signature, Date.now() + 120_000), false);
});

test("AES-GCM secret box round-trip and tamper detection", async () => {
  const key = Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString("base64");
  const env = await encryptSecret(key, "abc123");
  assert.equal(await decryptSecret(key, env), "abc123");
  const bad = env.slice(0, -4) + (env.endsWith("AAAA") ? "BBBB" : "AAAA");
  await assert.rejects(() => decryptSecret(key, bad));
});

test("symbol mapping", () => {
  assert.equal(yahooSymbol({ market_type: "commodity", symbol: "WTIUSD", provider_symbol: "WTI/USD" }), "CL=F");
  assert.equal(yahooSymbol({ market_type: "fx", symbol: "EUR/USD" }), "EURUSD=X");
  assert.equal(yahooSymbol({ market_type: "crypto", symbol: "BTC" }), "BTC-USD");
  assert.equal(binancePair({ market_type: "crypto", symbol: "MATIC" }), "POLUSDT");
  assert.equal(binancePair({ market_type: "fx", symbol: "EUR/USD" }), null);
  assert.equal(roundPrice(1.0845678, "fx"), 1.08457);
});

test("alerts: holdings alerts are private to their owner", () => {
  const out = buildAlerts({ recSignals: [], viralSignals: [], existingAlerts: [], assets: [{ id: "a", symbol: "BTC", market_type: "crypto" }],
    latestSnap: { a: { price: 70, timestamp: new Date().toISOString() } },
    holdings: [{ id: "h", asset: "btc", average_entry: 100, quantity: 1, created_by: "me@x" }, { id: "h2", asset: "BTC", average_entry: 100, quantity: -1, created_by: "you@x" }] });
  assert.equal(out.length, 2);
  assert.equal(out[0].user_email, "me@x"); assert.equal(out[0].audience, "user"); assert.equal(out[0].alert_type, "stop_loss");
  assert.equal(out[1].alert_type, "take_profit"); // short from 100 → 70 is +30%
});

test("snapshot + viral on real-shaped data", () => {
  const c = candles(300, { seed: 9, vol: 0.02 });
  const S = enrichSeries(computeSeries(c));
  const snap = snapshotAt(S, 299);
  assert.ok(snap.rsi >= 0 && snap.rsi <= 100);
  assert.equal(snap.sentiment_score_input, null);
  const v = analyzeViral({ ...snap, change_1h: 3, change_4h: 6, volume_change_percent: 250, attention_score_input: 85 }, S, 299, { symbol: "X", market_type: "crypto", liquidity_score: 80 });
  assert.ok(v && v.direction === "bullish" && v.invalidation < c[299].c);
});

test("attribution: buy and sell inside one sync batch closes the new execution", () => {
  const sig = { id: "s", kind: "recommended", direction: "bullish", setup_type: "bullish_pullback", timestamp: "2026-01-01T00:00:00Z", expires_at: "2026-01-02T00:00:00Z", entry_low: 99, entry_high: 100, invalidation: 98, atr: 1 };
  const b = { base_asset: "ETH", quote_asset: "USDT", commission_asset: "USDT", commission: 0 };
  const r = attributeFills([
    { ...b, external_trade_id: "2", side: "sell", price: 98, qty: 2, executed_at: "2026-01-01T04:00:00Z" },
    { ...b, external_trade_id: "1", side: "buy", price: 100, qty: 2, executed_at: "2026-01-01T03:00:00Z" },
  ], [], { ETH: [sig] }, "u");
  assert.equal(r.executionCreates.length, 1);
  assert.equal(r.executionCreates[0].status, "closed");
  assert.equal(r.executionCreates[0].outcome, "loss");
  assert.equal(r.executionCreates[0].r_multiple, -1);
});
