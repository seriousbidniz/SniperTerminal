// Minimal in-memory imitation of the Base44 entities API for integration tests.
let seq = 0;
function match(row, q) {
  return Object.entries(q).every(([k, v]) => {
    const val = row[k];
    if (v && typeof v === "object" && !Array.isArray(v)) {
      if ("$in" in v && !v.$in.includes(val)) return false;
      if ("$gte" in v && !(val >= v.$gte)) return false;
      if ("$lt" in v && !(val < v.$lt)) return false;
      return true;
    }
    return val === v;
  });
}
function sorter(sort) {
  if (!sort) return () => 0;
  const desc = sort.startsWith("-"); const f = sort.replace(/^-/, "");
  return (a, b) => ((a[f] ?? "") < (b[f] ?? "") ? -1 : (a[f] ?? "") > (b[f] ?? "") ? 1 : 0) * (desc ? -1 : 1);
}
export function makeDb() {
  const tables = {};
  const handler = (name) => {
    const t = (tables[name] ||= []);
    const stamp = (r) => ({ id: `${name}_${++seq}`, created_date: new Date().toISOString(), updated_date: new Date().toISOString(), ...r });
    return {
      list: async (sort, limit = 50) => [...t].sort(sorter(sort)).slice(0, limit),
      filter: async (q, sort, limit = 50) => t.filter((r) => match(r, q)).sort(sorter(sort)).slice(0, limit),
      get: async (id) => t.find((r) => r.id === id) || null,
      create: async (r) => { const x = stamp(r); t.push(x); return x; },
      bulkCreate: async (rs) => rs.map((r) => { const x = stamp(r); t.push(x); return x; }),
      update: async (id, p) => { const x = t.find((r) => r.id === id); Object.assign(x, p, { updated_date: new Date().toISOString() }); return x; },
      bulkUpdate: async (rs) => rs.map(({ id, ...p }) => { const x = t.find((r) => r.id === id); if (x) Object.assign(x, p); return x; }),
      delete: async (id) => { const i = t.findIndex((r) => r.id === id); if (i >= 0) t.splice(i, 1); return { success: true }; },
    };
  };
  const entities = new Proxy({}, { get: (_, name) => handler(name) });
  return { svc: { entities }, tables };
}
