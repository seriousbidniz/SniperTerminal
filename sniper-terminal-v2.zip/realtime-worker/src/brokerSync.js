// Read-only Binance account sync.
// - Verifies each key with GET /sapi/v1/account/apiRestrictions and REJECTS any
//   key that can trade, withdraw or transfer. Rejected keys are wiped server-side.
// - Pulls fills with GET /api/v3/myTrades per symbol, paging by trade id.
//   (Binance requires a symbol; time windows can't exceed 24h, so we page by
//   fromId instead, which also makes the sync resumable.)
// Signed endpoints are geo-restricted by Binance: run this worker in a region
// Binance serves (check with: curl https://api.binance.com/api/v3/ping).
import crypto from "node:crypto";
import { decryptSecret } from "../../base44/shared/cryptoBox.js";
import { parseBinanceSymbol } from "../../base44/shared/attribution.js";
import { config } from "./config.js";
import { ingest } from "./gateway.js";
import { log, warn } from "./log.js";

const UNSAFE_PERMISSIONS = [
  "enableSpotAndMarginTrading", "enableWithdrawals", "enableInternalTransfer", "permitsUniversalTransfer",
  "enableMargin", "enableFutures", "enableVanillaOptions", "enablePortfolioMarginTrading", "enableFixApiTrade",
];

async function signedGet(path, params, apiKey, apiSecret) {
  const qs = new URLSearchParams({ ...params, recvWindow: "10000", timestamp: String(Date.now()) });
  const sig = crypto.createHmac("sha256", apiSecret).update(qs.toString()).digest("hex");
  const res = await fetch(`${config.binanceRestUrl}${path}?${qs}&signature=${sig}`, {
    headers: { "X-MBX-APIKEY": apiKey },
    signal: AbortSignal.timeout(20_000),
  });
  const text = await res.text();
  if (!res.ok) {
    const err = new Error(`Binance ${path} HTTP ${res.status}: ${text.slice(0, 200)}`);
    err.status = res.status;
    throw err;
  }
  return JSON.parse(text);
}

async function credentials(conn) {
  return {
    apiKey: await decryptSecret(config.brokerEncryptionKey, conn.api_key_encrypted),
    apiSecret: await decryptSecret(config.brokerEncryptionKey, conn.api_secret_encrypted),
  };
}

export async function verifyConnection(conn) {
  try {
    const { apiKey, apiSecret } = await credentials(conn);
    const perms = await signedGet("/sapi/v1/account/apiRestrictions", {}, apiKey, apiSecret);
    const unsafe = UNSAFE_PERMISSIONS.filter((p) => perms[p] === true);
    if (unsafe.length) {
      return { id: conn.id, status: "rejected", permissions: perms, status_message: `Rejected: this key has ${unsafe.join(", ")} enabled. Create a new key with ONLY "Enable Reading" ticked. The key has been deleted from our systems.` };
    }
    if (perms.enableReading !== true) {
      return { id: conn.id, status: "rejected", permissions: perms, status_message: "Rejected: \"Enable Reading\" is not ticked on this key." };
    }
    return { id: conn.id, status: "verified", permissions: perms, status_message: perms.ipRestrict ? null : "Tip: restrict this key to the sync server's IP address in Binance for extra safety." };
  } catch (e) {
    if (e.status === 451) return { id: conn.id, status: "error", status_message: "Binance refused the sync server's location (HTTP 451). The worker must run in a region Binance serves." };
    if (e.status === 401 || e.status === 400) return { id: conn.id, status: "rejected", status_message: `Binance rejected the key: ${e.message.slice(0, 160)}` };
    return { id: conn.id, status: "error", status_message: e.message.slice(0, 300) };
  }
}

export async function syncConnection(conn, pairs) {
  const { apiKey, apiSecret } = await credentials(conn);
  let cursor = {};
  try { cursor = conn.sync_cursor ? JSON.parse(conn.sync_cursor) : {}; } catch { cursor = {}; }
  const since = conn.track_since ? new Date(conn.track_since).getTime() : 0;
  const fills = [];
  for (const pair of pairs) {
    let fromId = cursor[pair] != null ? cursor[pair] + 1 : 0;
    for (let page = 0; page < 5; page++) {
      let rows;
      try {
        rows = await signedGet("/api/v3/myTrades", { symbol: pair, fromId: String(fromId), limit: "1000" }, apiKey, apiSecret);
      } catch (e) {
        if (String(e.message).includes("-1121")) break; // invalid symbol on this account's region
        throw e;
      }
      if (!rows.length) break;
      for (const t of rows) {
        cursor[pair] = Math.max(cursor[pair] ?? -1, t.id);
        if (t.time < since) continue;
        const { base, quote } = parseBinanceSymbol(t.symbol);
        fills.push({
          external_trade_id: `binance:${conn.id}:${t.symbol}:${t.id}`,
          order_id: String(t.orderId), symbol: t.symbol, base_asset: base, quote_asset: quote,
          side: t.isBuyer ? "buy" : "sell", price: Number(t.price), qty: Number(t.qty), quote_qty: Number(t.quoteQty),
          commission: Number(t.commission), commission_asset: t.commissionAsset, is_maker: !!t.isMaker,
          executed_at: new Date(t.time).toISOString(),
        });
      }
      if (rows.length < 1000) break;
      fromId = cursor[pair] + 1;
    }
    await new Promise((r) => setTimeout(r, 150)); // be gentle with request weight
  }
  const res = await ingest("broker_fills", { connection_id: conn.id, user_email: conn.user_email, fills, sync_cursor: cursor });
  if (fills.length) log(`broker ${conn.id}: ${fills.length} fills → ${JSON.stringify(res)}`);
  return res;
}

export async function runBrokerCycle(connections, pairs) {
  if (!config.brokerEncryptionKey) return;
  const pending = connections.filter((c) => c.status === "pending_verification");
  if (pending.length) {
    const updates = [];
    for (const c of pending) updates.push(await verifyConnection(c));
    await ingest("broker_status", { updates });
    log(`verified ${updates.length} broker connection(s): ${updates.map((u) => u.status).join(", ")}`);
  }
  for (const c of connections.filter((x) => x.status === "verified")) {
    try {
      await syncConnection(c, pairs);
    } catch (e) {
      warn(`broker sync ${c.id} failed: ${e.message}`);
      if (e.status === 401 || e.status === 451) {
        await ingest("broker_status", { updates: [{ id: c.id, status: "error", status_message: e.message.slice(0, 300) }] });
      }
    }
  }
}
