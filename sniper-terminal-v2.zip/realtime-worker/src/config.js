function req(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var ${name}`);
  return v;
}
export const config = {
  ingestUrl: req("BASE44_INGEST_URL"), // https://<your-app>.base44.app/functions/realtimeIngest
  sharedSecret: req("WORKER_SHARED_SECRET"),
  vapid: {
    publicKey: process.env.VAPID_PUBLIC_KEY || "",
    privateKey: process.env.VAPID_PRIVATE_KEY || "",
    subject: process.env.VAPID_SUBJECT || "mailto:hello@example.com",
  },
  brokerEncryptionKey: process.env.BROKER_ENCRYPTION_KEY || "",
  binanceWsUrl: process.env.BINANCE_WS_URL || "wss://data-stream.binance.vision/ws",
  binanceRestUrl: process.env.BINANCE_REST_URL || "https://api.binance.com",
  twelveDataKey: process.env.TWELVE_DATA_API_KEY || "", // WebSocket requires a Twelve Data Pro plan
  statePollMs: Number(process.env.STATE_POLL_MS || 15000),
  brokerSyncMs: Number(process.env.BROKER_SYNC_MS || 120000),
  port: Number(process.env.PORT || 8080),
};
