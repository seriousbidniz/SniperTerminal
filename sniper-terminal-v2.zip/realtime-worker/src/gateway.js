// Signed calls to the Base44 realtimeIngest function.
import { signBody, SIGNATURE_HEADER, TIMESTAMP_HEADER } from "../../base44/shared/signing.js";
import { config } from "./config.js";

export async function ingest(op, payload = {}) {
  const body = JSON.stringify({ op, ...payload });
  const { timestamp, signature } = await signBody(config.sharedSecret, body);
  const res = await fetch(config.ingestUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json", [TIMESTAMP_HEADER]: timestamp, [SIGNATURE_HEADER]: signature },
    body,
    signal: AbortSignal.timeout(60_000),
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok) throw new Error(`ingest ${op} → HTTP ${res.status}: ${text.slice(0, 300)}`);
  return data;
}
