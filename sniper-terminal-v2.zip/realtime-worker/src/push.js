// Web Push delivery (VAPID). Works for desktop/Android browsers and for iOS/iPadOS
// 16.4+ when the app has been added to the Home Screen.
import webpush from "web-push";
import { config } from "./config.js";
import { ingest } from "./gateway.js";
import { warn } from "./log.js";

let ready = false;
export function initPush() {
  if (!config.vapid.publicKey || !config.vapid.privateKey) {
    warn("VAPID keys not set — push notifications disabled");
    return false;
  }
  webpush.setVapidDetails(config.vapid.subject, config.vapid.publicKey, config.vapid.privateKey);
  ready = true;
  return true;
}

export async function deliver(jobs) {
  if (!ready || !jobs?.length) return;
  const results = await Promise.all(jobs.map(async (j) => {
    try {
      await webpush.sendNotification(j.subscription, JSON.stringify(j.payload), {
        TTL: 3600,
        urgency: j.payload.severity === "critical" ? "high" : "normal",
        topic: String(j.payload.tag || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 32) || undefined,
      });
      return { outbox_id: j.outbox_id, subscription_id: j.subscription_id, ok: true };
    } catch (e) {
      return { outbox_id: j.outbox_id, subscription_id: j.subscription_id, ok: false, status_code: e.statusCode || null, error: String(e.body || e.message).slice(0, 200) };
    }
  }));
  try {
    await ingest("push_results", { results });
  } catch (e) {
    warn("push_results failed", e.message);
  }
}
