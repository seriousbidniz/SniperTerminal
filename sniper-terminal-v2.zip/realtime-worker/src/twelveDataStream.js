// Optional real-time FX / commodity / index prices from Twelve Data.
// Twelve Data's WebSocket requires a Pro plan or higher; without a key this
// module stays idle and those markets are handled by the 5-minute refresh.
import WebSocket from "ws";
import { log, warn } from "./log.js";

export class TwelveDataStream {
  constructor(apiKey, onPrice) {
    this.apiKey = apiKey;
    this.onPrice = onPrice;
    this.symbols = new Set();
    this.ws = null;
    this.backoff = 2000;
    this.lastMessageAt = 0;
  }
  setSymbols(symbols) {
    if (!this.apiKey) return;
    const next = new Set(symbols);
    const changed = next.size !== this.symbols.size || [...next].some((s) => !this.symbols.has(s));
    this.symbols = next;
    if (!this.ws) this.connect();
    else if (changed) this.subscribe();
  }
  connect() {
    if (!this.apiKey || !this.symbols.size) return;
    const ws = new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(this.apiKey)}`);
    this.ws = ws;
    ws.on("open", () => { log(`twelvedata ws connected (${this.symbols.size} symbols)`); this.backoff = 2000; this.subscribe(); });
    ws.on("message", (buf) => {
      this.lastMessageAt = Date.now();
      let m; try { m = JSON.parse(buf.toString()); } catch { return; }
      if (m.event === "price" && m.symbol && Number.isFinite(Number(m.price))) this.onPrice(m.symbol, Number(m.price), (m.timestamp || Date.now() / 1000) * 1000);
      if (m.event === "subscribe-status" && m.fails?.length) warn("twelvedata subscribe failures", JSON.stringify(m.fails).slice(0, 300));
    });
    ws.on("close", () => { this.ws = null; setTimeout(() => this.connect(), this.backoff); this.backoff = Math.min(this.backoff * 2, 120_000); });
    ws.on("error", (e) => warn("twelvedata ws error", e.message));
    this.heartbeat = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ action: "heartbeat" })); }, 10_000);
    ws.on("close", () => clearInterval(this.heartbeat));
  }
  subscribe() {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({ action: "reset" }));
    this.ws.send(JSON.stringify({ action: "subscribe", params: { symbols: [...this.symbols].join(",") } }));
  }
  status() {
    return { enabled: !!this.apiKey, connected: !!this.ws && this.ws.readyState === WebSocket.OPEN, symbols: this.symbols.size, last_message_at: this.lastMessageAt || null };
  }
}
