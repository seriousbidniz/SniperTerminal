// ─────────────────────────────────────────────────────────────────────────────
// Sniper Terminal realtime worker
//   • streams 1m klines for every crypto asset with a live signal (Binance)
//   • optional FX/commodity/index ticks (Twelve Data Pro)
//   • runs the SAME lifecycle rules as the backend on every tick and posts
//     transitions (entry / T1 / T2 / invalidation / expiry) to Base44
//   • delivers Web Push immediately
//   • verifies + syncs read-only broker accounts
// ─────────────────────────────────────────────────────────────────────────────
import http from "node:http";
import { evaluateBar, expireIfDue, LIVE_STATUSES } from "../../base44/shared/lifecycle.js";
import { config } from "./config.js";
import { ingest } from "./gateway.js";
import { BinanceKlineStream } from "./binanceStream.js";
import { TwelveDataStream } from "./twelveDataStream.js";
import { runBrokerCycle } from "./brokerSync.js";
import { initPush, deliver } from "./push.js";
import { log, warn } from "./log.js";

const state = {
  signals: new Map(), // id → signal (with kind)
  assets: new Map(),  // id → asset
  byPair: new Map(),  // BINANCE PAIR → [signal ids]
  byTdSymbol: new Map(),
  pending: [],        // lifecycle items awaiting flush
  connections: [],
  stats: { events_posted: 0, pushes_delivered: 0, last_state_at: null, started_at: Date.now() },
};

const binance = new BinanceKlineStream(config.binanceWsUrl, (pair, bar) => onBar(state.byPair.get(pair) || [], bar));
const twelve = new TwelveDataStream(config.twelveDataKey, (symbol, price, ts) => {
  onBar(state.byTdSymbol.get(symbol) || [], { t: ts, o: price, h: price, l: price, c: price, closeTime: ts });
});

function onBar(ids, bar) {
  const now = Date.now();
  for (const id of ids) {
    const sig = state.signals.get(id);
    if (!sig || !LIVE_STATUSES.includes(sig.status)) continue;
    const { events, patch } = evaluateBar(sig, bar, sig.kind, now);
    if (!events.length) continue;
    queue(sig, events, patch);
  }
}

function queue(sig, events, patch) {
  state.pending.push({ kind: sig.kind, id: sig.id, expect_status: sig.status, patch, events });
  Object.assign(sig, patch); // optimistic: don't re-fire while the post is in flight
}

async function flush() {
  if (!state.pending.length) return;
  const items = state.pending.splice(0);
  try {
    const res = await ingest("signal_events", { items });
    state.stats.events_posted += res.events || 0;
    if (res.push_jobs?.length) {
      await deliver(res.push_jobs);
      state.stats.pushes_delivered += res.push_jobs.length;
    }
    log(`posted ${items.length} lifecycle item(s): ${items.map((i) => `${i.id}:${i.events.map((e) => e.type).join("+")}`).join(", ")}`);
  } catch (e) {
    warn("signal_events failed; will retry", e.message);
    state.pending.unshift(...items);
  }
}

async function refreshState() {
  const s = await ingest("state", {
    include_brokers: !!config.brokerEncryptionKey,
    stats: { ...state.stats, binance: binance.status(), twelve: twelve.status(), pending: state.pending.length },
  });
  state.stats.last_state_at = Date.now();
  state.assets = new Map(s.assets.map((a) => [a.id, a]));
  const pendingIds = new Set(state.pending.map((p) => p.id));
  const next = new Map();
  for (const sig of s.signals) {
    // Keep our optimistic local copy while a post for it is still pending.
    next.set(sig.id, pendingIds.has(sig.id) && state.signals.has(sig.id) ? state.signals.get(sig.id) : sig);
  }
  state.signals = next;

  state.byPair = new Map();
  state.byTdSymbol = new Map();
  for (const sig of next.values()) {
    const a = state.assets.get(sig.asset);
    if (!a) continue;
    if (a.binance_pair) (state.byPair.get(a.binance_pair) || state.byPair.set(a.binance_pair, []).get(a.binance_pair)).push(sig.id);
    else if (a.market_type !== "crypto" && a.provider_symbol) (state.byTdSymbol.get(a.provider_symbol) || state.byTdSymbol.set(a.provider_symbol, []).get(a.provider_symbol)).push(sig.id);
  }
  binance.setPairs([...state.byPair.keys()]);
  twelve.setSymbols([...state.byTdSymbol.keys()]);
  state.connections = s.broker_connections || [];
  if (s.push_jobs?.length) {
    await deliver(s.push_jobs);
    state.stats.pushes_delivered += s.push_jobs.length;
  }
}

function expirySweep() {
  const now = Date.now();
  for (const sig of state.signals.values()) {
    if (!LIVE_STATUSES.includes(sig.status)) continue;
    const r = expireIfDue(sig, sig.kind, now);
    if (r && (r.events.length || Object.keys(r.patch).length)) queue(sig, r.events, r.patch);
  }
}

function every(ms, fn, name) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try { await fn(); } catch (e) { warn(`${name} failed:`, e.message); } finally { running = false; }
  };
  tick();
  return setInterval(tick, ms);
}

function brokerPairs() {
  return [...new Set([...state.assets.values()].map((a) => a.binance_pair).filter(Boolean))];
}

initPush();
every(config.statePollMs, refreshState, "state");
every(500, flush, "flush");
every(10_000, expirySweep, "expiry");
every(30_000, async () => binance.maintain(), "ws-maintain");
every(config.brokerSyncMs, () => runBrokerCycle(state.connections, brokerPairs()), "broker");

http.createServer((req, res) => {
  const body = JSON.stringify({
    ok: Date.now() - (state.stats.last_state_at || 0) < config.statePollMs * 4,
    signals: state.signals.size, ...state.stats, binance: binance.status(), twelve: twelve.status(),
  });
  res.writeHead(req.url === "/healthz" ? 200 : 404, { "Content-Type": "application/json" });
  res.end(req.url === "/healthz" ? body : "{}");
}).listen(config.port, () => log(`worker up on :${config.port}`));

process.on("SIGTERM", async () => { await flush(); process.exit(0); });
