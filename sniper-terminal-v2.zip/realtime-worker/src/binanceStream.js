// One WebSocket to Binance's market-data-only stream host, with live
// SUBSCRIBE/UNSUBSCRIBE of <pair>@kline_1m streams, auto-reconnect with
// backoff, and proactive reconnect before Binance's 24h connection limit.
import WebSocket from "ws";
import { log, warn } from "./log.js";

export class BinanceKlineStream {
  constructor(url, onBar) {
    this.url = url;
    this.onBar = onBar;
    this.wanted = new Set();
    this.subscribed = new Set();
    this.ws = null;
    this.reqId = 1;
    this.backoff = 1000;
    this.lastMessageAt = 0;
    this.connectedAt = 0;
  }

  setPairs(pairs) {
    this.wanted = new Set(pairs.map((p) => p.toLowerCase()));
    if (!this.ws) this.connect();
    else this.sync();
  }

  connect() {
    if (this.wanted.size === 0) return;
    const ws = new WebSocket(this.url);
    this.ws = ws;
    ws.on("open", () => {
      log(`binance ws connected (${this.wanted.size} pairs)`);
      this.connectedAt = Date.now();
      this.backoff = 1000;
      this.subscribed = new Set();
      this.sync();
    });
    ws.on("message", (buf) => {
      this.lastMessageAt = Date.now();
      let msg;
      try { msg = JSON.parse(buf.toString()); } catch { return; }
      const k = msg?.k;
      if (msg?.e !== "kline" || !k) return;
      this.onBar(msg.s, {
        t: k.t, o: Number(k.o), h: Number(k.h), l: Number(k.l), c: Number(k.c),
        closeTime: Math.min(Date.now(), k.T), closed: !!k.x,
      });
    });
    ws.on("close", () => {
      warn(`binance ws closed — reconnecting in ${this.backoff}ms`);
      this.ws = null;
      setTimeout(() => this.connect(), this.backoff);
      this.backoff = Math.min(this.backoff * 2, 60_000);
    });
    ws.on("error", (e) => warn("binance ws error", e.message));
  }

  sync() {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const add = [...this.wanted].filter((p) => !this.subscribed.has(p)).map((p) => `${p}@kline_1m`);
    const remove = [...this.subscribed].filter((p) => !this.wanted.has(p)).map((p) => `${p}@kline_1m`);
    // Batch params; stay well under Binance's per-connection message rate.
    const send = (method, params) => {
      for (let i = 0; i < params.length; i += 100) {
        this.ws.send(JSON.stringify({ method, params: params.slice(i, i + 100), id: this.reqId++ }));
      }
    };
    if (add.length) send("SUBSCRIBE", add);
    if (remove.length) send("UNSUBSCRIBE", remove);
    add.forEach((s) => this.subscribed.add(s.split("@")[0]));
    remove.forEach((s) => this.subscribed.delete(s.split("@")[0]));
  }

  /** Called periodically: recycle stale or near-24h connections. */
  maintain() {
    if (!this.ws) return;
    const age = Date.now() - this.connectedAt;
    const silent = this.lastMessageAt && Date.now() - this.lastMessageAt > 90_000;
    if (age > 23 * 3600_000 || silent) {
      log(`recycling binance ws (age ${Math.round(age / 60000)}m, silent=${silent})`);
      this.ws.terminate();
    }
  }

  status() {
    return { connected: !!this.ws && this.ws.readyState === WebSocket.OPEN, pairs: this.subscribed.size, last_message_at: this.lastMessageAt || null };
  }
}
