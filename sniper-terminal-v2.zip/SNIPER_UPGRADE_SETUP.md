# Sniper Terminal v2 — setup and remaining work

## What changed

- **One signal engine** in `base44/shared/`, replacing four drifting copies. It uses real indicators (Wilder RSI, ATR, EMA, Donchian, MACD) on closed 1h candles. Every signal gets an entry zone, invalidation, two targets and a hard expiry.
- **Stable signals.** A signal keeps its id, levels and expiry until it resolves: `active` → `triggered` → `target_hit` → `closed`, or `invalidated` / `expired`. Outcomes are recorded in R multiples.
- **Learning loop.** `calibrateSetups` back-tests the live engine hourly with no look-ahead and blends the results with live outcomes. A setup is treated as having no edge until it has 30 or more samples.
- **Real-time data:**
  - The browser streams crypto prices from Binance.
  - Base44 entity subscriptions refresh screens instantly.
  - The `realtime-worker/` service watches 1m candles and sends Web Push.
- **Order ticket.** `ExternalTradeLinks` shows pre-filled side, limit, stop, targets and a risk-sized quantity, all copyable. Uniswap links are genuinely pre-filled. Binance opens the pair and copies the order.
- **Signal countdown.** A live expiry and invalidation countdown appears on every signal card and drawer.
- **Read-only broker sync (Binance).** It matches your fills to signals and shows your verified win rate on the new **Performance** page.
- **Security.** Row-level security on all user data, plus private holding alerts. Broker keys are encrypted with AES-GCM, and keys with trade or withdraw permissions are auto-rejected.
- **PWA.** Manifest, icons and a push service worker.

## Status of the work

**Built and verified:**
- 20 automated tests pass (`node --test tests/*.test.mjs`).
- All new and rewritten functions pass `deno check`.
- The front end builds (`npm run build`) and lint is clean.

**Not yet tested against your live Base44 app.** I had no access to it, so do the steps below in order.

---

## Step 1 — Generate keys (on your computer)

```bash
cd realtime-worker && npm install
npm run keygen   # prints BROKER_ENCRYPTION_KEY and WORKER_SHARED_SECRET
npm run vapid    # prints VAPID_PUBLIC_KEY and VAPID_PRIVATE_KEY
```

## Step 2 — Set Base44 secrets

In the Base44 dashboard, set these secrets:
- `WORKER_SHARED_SECRET`
- `BROKER_ENCRYPTION_KEY`
- `VAPID_PUBLIC_KEY`

Keep `TWELVE_DATA_API_KEY` if you already have it set.

## Step 3 — Push the code to Base44

Push this repo through your GitHub sync, or run `base44 deploy` from the project root.

This deploys:
- the entities, including 8 new ones and RLS on the existing ones;
- the functions;
- the workflows (refresh every 5 minutes, calibration hourly).

## Step 4 — Deploy the realtime worker

Any always-on host that can run Docker works. The host must be in a region Binance serves. Check first with:

```bash
curl https://api.binance.com/api/v3/ping
```

A `{}` response is good. An HTTP 451 response means Binance blocks that region.

Build and run from the repo root:

```bash
docker build -f realtime-worker/Dockerfile -t sniper-worker .
```

Set the environment variables listed in `realtime-worker/.env.example`. Set `BASE44_INGEST_URL` to `https://<your-app-domain>/functions/realtimeIngest`.

The health check is at `/healthz`. In the app, **Settings → Live data** turns green when the worker is connected.

## Step 5 — Smoke test

1. As an admin, open **Asset Universe → Refresh All**. Signals should now show entry, invalidation and T1 values instead of "—".
2. Open a signal. You should see the countdown and the order ticket.
3. On a phone, add the app to the Home Screen (iOS 16.4 or later), then go to **Settings → Notifications → Push on this device** and send a test.
4. Go to **Settings → Broker accounts → Connect Binance** with a key that has *Enable Reading* only. Within about 2 minutes it should show "Connected, read-only".
5. Wait for the hourly calibration run, then open the **Performance** page.

---

## Prompts for the Base44 AI builder (remaining items)

Paste these one at a time. Each one is scoped so it doesn't touch the new engine.

**1. Mobile navigation (pre-existing gap)**
> On mobile, Settings, Performance, Watchlists and Asset Universe can't be reached because BottomNav only has 5 tabs. Replace the "Alerts" tab with a "More" tab that opens a sheet listing Alerts, Performance, Watchlists, Asset Universe, Settings and Documentation. Keep the existing BottomNav styling. Don't change any other component.

**2. Clear legacy data after first deploy**
> Create a one-off admin-only backend function `cleanupLegacyData`. Using `asServiceRole`, it should:
> - set status `superseded` on every RecommendedTradeSignals and ViralTradeSignals record that has no `expires_at` field;
> - set status `dismissed` on every Alerts record that has no `audience` field.
>
> Process in batches of 200 and return the counts. Add a button for it in Asset Universe, visible only to admins.

**3. Per-user alert dismissal (pre-existing issue)**
> Global alerts are shared records, so when one user dismisses or snoozes an alert it disappears for everyone. Add an entity AlertStates with fields alert_id, user_email, status (read/dismissed/snoozed) and snoozed_until, with RLS so each user sees only their own rows. Change Alerts.jsx so that Dismiss and Snooze write an AlertStates row instead of updating the alert. When listing alerts, merge in the user's AlertStates. Leave alerts with audience "user" behaving as they do now.

**4. Update the Documentation page**
> Update src/pages/Documentation.jsx to describe the v2 engine, using SNIPER_UPGRADE_SETUP.md as the source. Cover:
> - the four setup types and their origins (shown in each signal's `pattern_origin`);
> - ATR-based entry, invalidation and targets;
> - hard expiry;
> - the lifecycle statuses;
> - calibration (back-test capped at 50 samples, blended with live outcomes; under 30 samples = no edge assumed);
> - the order ticket;
> - read-only broker sync.
>
> Remove any text that says attention or sentiment scores are social or search data. They are market-activity proxies.

**5. Code splitting (performance)**
> The main JS bundle is about 1.6 MB. Lazy-load the Documentation, TermsOfService, PrivacyPolicy, RiskDisclaimer, StrategyBuilder and Performance pages with React.lazy and Suspense in App.jsx, using the existing loading spinner as the fallback.

**6. Optional: real-time FX, gold, oil and indices**
> No code change is needed. Buy a Twelve Data Pro plan and set `TWELVE_DATA_API_KEY` on the realtime worker. Without it, those markets update every 5 minutes.

## Known limits (deliberate)

- **No social or sentiment data feed.** "Attention" is a volume and price-speed proxy, and catalyst/sentiment fields are left null.
- **Calibration is not proof of an edge.** It is about 1,000 hourly bars per asset with assumed costs (0.1% per side on crypto), and past results don't guarantee future ones.
- **The broker can't be pre-filled by link.** Binance's website doesn't accept order values in a URL. Placing orders automatically would need trade-enabled keys, which this app refuses by design.
- **Native APNs needs a native app.** iPhone push works through Web Push, but only once the app is installed to the Home Screen.
