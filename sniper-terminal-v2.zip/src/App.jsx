import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { SessionModeProvider } from '@/components/shared/SessionMode';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import CookieConsent from '@/components/shared/CookieConsent';
import OnboardingAcknowledgment from '@/components/shared/OnboardingAcknowledgment';

import AppLayout from './components/layout/AppLayout';
import Dashboard from './pages/Dashboard';
import ViralTrades from './pages/ViralTrades';
import Portfolio from './pages/Portfolio';
import Alerts from './pages/Alerts';
import Watchlists from './pages/Watchlists';
import Settings from './pages/Settings';
import Documentation from './pages/Documentation';
import Assets from './pages/Assets';
import RecommendedTradesPage from './pages/RecommendedTrades';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import RiskDisclaimer from './pages/RiskDisclaimer';
import Performance from './pages/Performance';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
          <span className="text-xs text-muted-foreground font-mono">Loading terminal...</span>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -100 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        <Routes location={location}>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/recommended" element={<RecommendedTradesPage />} />
            <Route path="/viral" element={<ViralTrades />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/watchlists" element={<Watchlists />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/documentation" element={<Documentation />} />
            <Route path="/assets" element={<Assets />} />
            <Route path="/performance" element={<Performance />} />
          </Route>
          <Route path="/terms" element={<TermsOfService />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/risk-disclaimer" element={<RiskDisclaimer />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};

function App() {
  return (
    <AuthProvider>
      <SessionModeProvider>
        <QueryClientProvider client={queryClientInstance}>
          <OnboardingAcknowledgment />
          <Router>
            <AuthenticatedApp />
            <CookieConsent />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </SessionModeProvider>
    </AuthProvider>
  )
}

export default App