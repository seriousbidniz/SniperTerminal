import React from "react";
import { Newspaper } from "lucide-react";
import EmptyState from "../shared/EmptyState";

const categoryColors = {
  bullish: "text-profit bg-profit/10 border-profit/30",
  bearish: "text-loss bg-loss/10 border-loss/30",
  mixed: "text-warning bg-warning/10 border-warning/30",
  macro: "text-primary bg-primary/10 border-primary/30",
  regulation: "text-viral bg-viral/10 border-viral/30",
  protocol: "text-primary bg-primary/10 border-primary/30",
  exchange: "text-muted-foreground bg-secondary border-border",
  exploit: "text-loss bg-loss/10 border-loss/30",
  narrative: "text-viral bg-viral/10 border-viral/30",
};

export default function CatalystFeed({ events }) {
  const sorted = [...(events || [])].sort((a, b) => {
    const da = a.published_at ? new Date(a.published_at) : new Date(a.created_date || 0);
    const db = b.published_at ? new Date(b.published_at) : new Date(b.created_date || 0);
    return db - da;
  });

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Newspaper className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold">Catalyst Feed</h2>
        <span className="text-xs text-muted-foreground font-mono">({sorted.length})</span>
      </div>

      {sorted.length === 0 ? (
        <EmptyState icon={Newspaper} title="No catalysts tracked yet" description="Add news events to monitor market-moving catalysts." />
      ) : (
        <div className="divide-y divide-border max-h-80 overflow-y-auto">
          {sorted.slice(0, 10).map((event) => (
            <div key={event.id} className="px-4 py-2.5 hover:bg-accent/50 transition-colors">
              <div className="flex items-start gap-2">
                <span className={`text-[10px] font-medium uppercase px-1.5 py-0.5 rounded border flex-shrink-0 mt-0.5 ${categoryColors[event.category] || categoryColors.mixed}`}>
                  {event.category}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground line-clamp-1">{event.title}</p>
                  {event.summary && <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{event.summary}</p>}
                  <div className="flex items-center gap-2 mt-1">
                    {event.impact_level && (
                      <span className={`text-[9px] uppercase tracking-wider ${event.impact_level === "critical" || event.impact_level === "high" ? "text-loss" : "text-muted-foreground"}`}>
                        {event.impact_level} impact
                      </span>
                    )}
                    {event.source && <span className="text-[9px] text-muted-foreground/50">{event.source}</span>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}