import SignalCountdown from "@/components/shared/SignalCountdown";
import { formatPrice } from "@/lib/format";
import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Crosshair } from "lucide-react";
import { TradeReasonPill } from "@/components/shared/TradeReasonIndicator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import RecommendedDetailDrawer from "@/components/drilldown/RecommendedDetailDrawer.jsx";
import { isStale } from "@/lib/freshness";
import StaleBanner from "@/components/shared/StaleBanner";
import DecisionBadge from "@/components/shared/DecisionBadge";
import UrgencyTag from "@/components/shared/UrgencyTag";
import ConfidenceTier from "@/components/shared/ConfidenceTier";

const STALE_MS = 4 * 60 * 60 * 1000;
const MIN_COVERAGE = 20;

const directionColors = {
  bullish: "text-profit bg-profit/10 border-profit/30",
  bearish: "text-loss bg-loss/10 border-loss/30",
};

function ScoreCell({ value, invert = false, label }) {
  if (value == null) return <span className="text-muted-foreground/30 font-mono text-xs">—</span>;
  const score = Math.round(value);
  const s = invert ? 100 - score : score;
  const color = s >= 70 ? "text-profit" : s >= 45 ? "text-warning" : "text-loss";
  const ring = s >= 70 ? "ring-profit/20" : s >= 45 ? "ring-warning/20" : "ring-loss/20";
  return (
    <div className="flex flex-col items-center gap-0.5">
      {label && <span className="text-[9px] text-muted-foreground/60 uppercase tracking-widest">{label}</span>}
      <span className={`font-mono font-bold text-sm ${color} ring-1 ${ring} rounded px-1.5 py-0.5 bg-card`}>{score}</span>
    </div>
  );
}

function fmt(val, prefix = "") {
  if (val == null || val === "") return <span className="text-muted-foreground/30">—</span>;
  if (typeof val === "number") return `${prefix}${val.toLocaleString()}`;
  return val;
}

function FilterSelect({ value, onChange, width, children }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={`h-7 text-xs ${width} bg-background/60 border-border/60 hover:border-border transition-colors font-medium`}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="text-xs">
        {children}
      </SelectContent>
    </Select>
  );
}

const TABLE_HEADERS = [
  { key: "decision",   label: "Decision" },
  { key: "urgency",    label: "Urgency" },
  { key: "grade",      label: "Grade" },
  { key: "asset",      label: "Asset" },
  { key: "direction",  label: "Dir." },
  { key: "setup_type", label: "Setup" },
  { key: "entry",      label: "Entry Zone" },
  { key: "inv",        label: "Inv." },
  { key: "t1",         label: "T1" },
  { key: "opp",        label: "OPP" },
  { key: "risk",       label: "RISK" },
  { key: "reason",     label: "Reason" },
  { key: "time",       label: "Time" },
];

export default function DashboardRecommended({ signals = [] }) {
  const [selected, setSelected] = useState(null);
  const [dirFilter, setDirFilter] = useState("all");
  const [setupFilter, setSetupFilter] = useState("all");
  const [minScore, setMinScore] = useState("0");
  const [sortBy, setSortBy] = useState("opportunity_score");

  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    assets.forEach(a => { m[a.id] = a; });
    return m;
  }, [assets]);

  // Enrich signals with asset symbol/name and stale flag
  const enriched = useMemo(() => signals.map(sig => {
    const asset = assetMap[sig.asset];
    return {
      ...sig,
      asset_symbol: asset?.symbol || sig.asset || "—",
      asset_name: asset?.name || "",
      market_type: asset?.market_type || "crypto",
      is_stale: isStale(sig.timestamp, STALE_MS),
    };
  }), [signals, assetMap]);

  const setupTypes = useMemo(() => {
    const s = new Set(enriched.map(s => s.setup_type).filter(Boolean));
    return Array.from(s);
  }, [enriched]);

  const filtered = useMemo(() => {
    let r = enriched;
    if (dirFilter !== "all") r = r.filter(s => s.direction === dirFilter);
    if (setupFilter !== "all") r = r.filter(s => s.setup_type === setupFilter);
    const min = parseFloat(minScore) || 0;
    if (min > 0) r = r.filter(s => (s.opportunity_score || 0) >= min);
    return [...r].sort((a, b) => (b[sortBy] || 0) - (a[sortBy] || 0));
  }, [enriched, dirFilter, setupFilter, minScore, sortBy]);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">

      {/* ── Header ── */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-border bg-secondary/10">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
            <Crosshair className="w-3.5 h-3.5 text-primary" />
          </div>
          <div>
            <span className="text-sm font-semibold tracking-tight">Daily Recommended Trades</span>
            <span className="ml-2 text-xs text-muted-foreground font-mono">
              {filtered.length} signal{filtered.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-1.5">
          <FilterSelect value={dirFilter} onChange={setDirFilter} width="w-[100px]">
            <SelectItem value="all">All dirs.</SelectItem>
            <SelectItem value="bullish">↑ Bullish</SelectItem>
            <SelectItem value="bearish">↓ Bearish</SelectItem>
          </FilterSelect>

          <FilterSelect value={setupFilter} onChange={setSetupFilter} width="w-[110px]">
            <SelectItem value="all">All setups</SelectItem>
            {setupTypes.map(t => (
              <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>
            ))}
          </FilterSelect>

          <FilterSelect value={minScore} onChange={setMinScore} width="w-[96px]">
            <SelectItem value="0">Any score</SelectItem>
            <SelectItem value="50">≥ 50</SelectItem>
            <SelectItem value="60">≥ 60</SelectItem>
            <SelectItem value="70">≥ 70</SelectItem>
            <SelectItem value="80">≥ 80</SelectItem>
          </FilterSelect>

          <FilterSelect value={sortBy} onChange={setSortBy} width="w-[130px]">
            <SelectItem value="opportunity_score">Sort: Opp. ↓</SelectItem>
            <SelectItem value="conviction_score">Sort: Conv. ↓</SelectItem>
          </FilterSelect>
        </div>
      </div>

      {/* ── Coverage fallback ── */}
      {enriched.length > 0 && enriched.length < MIN_COVERAGE && (
        <div className="mx-4 mt-3 flex items-start gap-2 bg-secondary/30 border border-border rounded-lg px-3 py-2 text-[11px] text-muted-foreground">
          <span className="text-warning/60 mt-0.5">⚠</span>
          <span>
            {enriched.length} of {MIN_COVERAGE}+ target signals. Add more tracked assets and run Recompute to increase coverage. Signal quality is not lowered to fill quotas.
          </span>
        </div>
      )}

      {/* ── Table (desktop) / Cards (mobile) ── */}
      {filtered.length === 0 ? (
        <div className="py-14 text-center space-y-1.5">
          <p className="text-xs text-muted-foreground/60">No active signals match your filters.</p>
          {enriched.length === 0 && (
            <p className="text-[11px] text-muted-foreground/40">Add tracked assets in Asset Universe and run Recompute to generate signals.</p>
          )}
        </div>
      ) : (
        <>
          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-border">
            {filtered.map(s => (
              <button
                key={s.id}
                onClick={() => setSelected(s)}
                className={`w-full text-left px-4 py-3.5 hover:bg-primary/5 transition-colors ${s.is_stale ? "opacity-60" : ""}`}
              >
                {/* Row 1: Decision badge dominant */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0 space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-sm">{s.asset_symbol}</span>
                      {s.is_stale && <StaleBanner variant="row" />}
                    </div>
                    <DecisionBadge signal={s} size="md" />
                    <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                      <UrgencyTag signal={s} />
                      <SignalCountdown signal={s} asset={assetMap[s.asset]} />
                      <ConfidenceTier signal={s} showLabel={false} />
                      {s.direction && (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${directionColors[s.direction] || ""}`}>
                          {s.direction === "bullish" ? "▲" : "▼"} {s.direction}
                        </span>
                      )}
                    </div>
                    {s.setup_type && <div className="text-[10px] text-muted-foreground/70 capitalize">{s.setup_type.replace(/_/g, " ")}</div>}
                    <TradeReasonPill signal={s} />
                  </div>
                  <div className="flex-shrink-0 text-center">
                    <div className="text-[9px] text-muted-foreground/50 uppercase">OPP</div>
                    <ScoreCell value={s.opportunity_score} />
                  </div>
                </div>
                {/* Row 2: scores */}
                <div className="grid grid-cols-3 gap-x-3 gap-y-1 text-[11px] mb-2">
                  <div className="flex justify-between gap-1"><span className="text-muted-foreground">Conv</span><span className="font-mono">{s.conviction_score != null ? Math.round(s.conviction_score) : "—"}</span></div>
                  <div className="flex justify-between gap-1"><span className="text-muted-foreground">Risk</span><span className="font-mono text-warning">{s.risk_score != null ? Math.round(s.risk_score) : "—"}</span></div>
                  <div className="flex justify-between gap-1"><span className="text-muted-foreground">Mkt</span><span className="capitalize">{s.market_type || "—"}</span></div>
                </div>
                {/* Row 3: levels */}
                <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-[11px] font-mono">
                  {(s.entry_low != null || s.entry_high != null) && (
                    <span className="text-muted-foreground/70">
                      Entry: {formatPrice(s.entry_low, s.market_type)} – {formatPrice(s.entry_high, s.market_type)}
                    </span>
                  )}
                  {s.invalidation != null && <span className="text-loss/80">Inv: {formatPrice(s.invalidation, s.market_type)}</span>}
                  {s.target_1 != null && <span className="text-profit/80">T1: {formatPrice(s.target_1, s.market_type)}</span>}
                </div>
                {s.why_now && <p className="text-[11px] text-muted-foreground/60 mt-1.5 line-clamp-2 leading-relaxed">{s.why_now}</p>}
              </button>
            ))}
          </div>

          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border/60">
                  {TABLE_HEADERS.map(h => (
                    <th key={h.key} className="px-4 py-2.5 text-left text-[9px] font-semibold text-muted-foreground/70 uppercase tracking-widest whitespace-nowrap bg-secondary/5">
                      {h.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => {
                  const rowStale = s.is_stale;
                  return (
                    <tr
                      key={s.id}
                      onClick={() => setSelected(s)}
                      className={[
                        "group border-b border-border/40 cursor-pointer transition-all duration-100",
                        rowStale ? "opacity-55 hover:opacity-75 bg-warning/[0.03]" : "hover:bg-primary/[0.04]",
                      ].join(" ")}
                    >
                      <td className="px-4 py-3 whitespace-nowrap">
                        <DecisionBadge signal={s} size="md" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <UrgencyTag signal={s} />
                      <SignalCountdown signal={s} asset={assetMap[s.asset]} />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <ConfidenceTier signal={s} showLabel={false} />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-foreground text-[13px] group-hover:text-primary transition-colors">{s.asset_symbol || "—"}</span>
                          {rowStale && <StaleBanner variant="row" />}
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {s.direction ? (
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide ${directionColors[s.direction] || "text-muted-foreground border-border"}`}>
                            {s.direction === "bullish" ? "▲ Long" : "▼ Short"}
                          </span>
                        ) : "—"}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="text-muted-foreground/80 capitalize">{s.setup_type ? s.setup_type.replace(/_/g, " ") : "—"}</span>
                      </td>
                      <td className="px-4 py-3 font-mono whitespace-nowrap">
                        {s.entry_low != null || s.entry_high != null ? (
                          <span className="text-muted-foreground/70 text-[11px]">
                            {s.entry_low != null ? `${formatPrice(s.entry_low, s.market_type)}` : "—"}{" – "}{s.entry_high != null ? `${formatPrice(s.entry_high, s.market_type)}` : "—"}
                          </span>
                        ) : <span className="text-muted-foreground/30">—</span>}
                      </td>
                      <td className="px-4 py-3 font-mono whitespace-nowrap text-loss/80 text-[11px]">
                        {s.invalidation != null ? `${formatPrice(s.invalidation, s.market_type)}` : <span className="text-muted-foreground/30">—</span>}
                      </td>
                      <td className="px-4 py-3 font-mono whitespace-nowrap text-profit/80 text-[11px]">
                        {s.target_1 != null ? `${formatPrice(s.target_1, s.market_type)}` : <span className="text-muted-foreground/30">—</span>}
                      </td>
                      <td className="px-4 py-3 text-center"><ScoreCell value={s.opportunity_score} /></td>
                      <td className="px-4 py-3 text-center"><ScoreCell value={s.risk_score} invert /></td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <TradeReasonPill signal={s} />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="font-mono text-[10px] text-muted-foreground/40">
                          {s.timestamp ? new Date(s.timestamp).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      <RecommendedDetailDrawer signal={selected} onClose={() => setSelected(null)} />
    </div>
  );
}