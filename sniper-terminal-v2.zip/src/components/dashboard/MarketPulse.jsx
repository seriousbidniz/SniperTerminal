import React from "react";
import { Activity, TrendingUp, TrendingDown, Shield, AlertTriangle, Zap, BarChart3 } from "lucide-react";
import StaleDataBanner from "../shared/StaleDataBanner";

const moodColors = {
  extreme_fear: "text-loss",
  fear: "text-loss/80",
  neutral: "text-muted-foreground",
  greed: "text-profit/80",
  extreme_greed: "text-profit",
};

const regimeColors = {
  risk_on: "text-profit",
  risk_off: "text-loss",
  neutral: "text-muted-foreground",
  transitioning: "text-warning",
};

export default function MarketPulse({ snapshot }) {
  const data = snapshot || {};
  const isStale = data.is_stale;

  const pills = [
    { label: "Crypto Mood", value: (data.crypto_mood || "—").replace(/_/g, " "), color: moodColors[data.crypto_mood] || "text-muted-foreground", icon: Activity },
    { label: "FX Regime", value: (data.fx_regime || "—").replace(/_/g, " "), color: regimeColors[data.fx_regime] || "text-muted-foreground", icon: BarChart3 },
    { label: "BTC", value: data.btc_state || "—", color: "text-foreground", icon: TrendingUp },
    { label: "ETH", value: data.eth_state || "—", color: "text-foreground", icon: TrendingUp },
    { label: "DXY", value: (data.dxy_trend || "—").replace(/_/g, " "), color: data.dxy_trend === "strengthening" ? "text-loss" : data.dxy_trend === "weakening" ? "text-profit" : "text-muted-foreground", icon: TrendingDown },
    { label: "Volatility", value: data.volatility_regime || "—", color: data.volatility_regime === "extreme" ? "text-loss" : data.volatility_regime === "high" ? "text-warning" : "text-muted-foreground", icon: Zap },
    { label: "High Conviction", value: data.high_conviction_count ?? "—", color: "text-primary", icon: Shield },
    { label: "Risk Alerts", value: data.urgent_risk_alerts ?? "—", color: data.urgent_risk_alerts > 0 ? "text-loss" : "text-muted-foreground", icon: AlertTriangle },
  ];

  return (
    <div className="space-y-2">
      {isStale && <StaleDataBanner message="Market pulse data may be delayed. Treat readings with reduced confidence." />}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
        {pills.map((pill) => (
          <div key={pill.label} className="bg-card border border-border rounded-lg px-3 py-2.5 flex flex-col gap-1">
            <div className="flex items-center gap-1.5">
              <pill.icon className="w-3 h-3 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{pill.label}</span>
            </div>
            <span className={`text-sm font-semibold capitalize ${pill.color}`}>{pill.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}