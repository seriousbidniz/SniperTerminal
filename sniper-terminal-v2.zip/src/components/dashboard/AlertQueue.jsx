import React from "react";
import { Bell, Eye, Clock, Zap, ShieldAlert, LogOut } from "lucide-react";
import EmptyState from "../shared/EmptyState";

const queueConfig = {
  exit_hedge: { icon: LogOut, label: "Exit / Hedge", color: "text-loss border-loss/30 bg-loss/5" },
  reduce_risk: { icon: ShieldAlert, label: "Reduce Risk", color: "text-warning border-warning/30 bg-warning/5" },
  act_now: { icon: Zap, label: "Act Now", color: "text-primary border-primary/30 bg-primary/5" },
  prepare: { icon: Clock, label: "Prepare", color: "text-muted-foreground border-border bg-card" },
  watch: { icon: Eye, label: "Watch", color: "text-muted-foreground/60 border-border bg-card" },
};

const priorityOrder = ["exit_hedge", "reduce_risk", "act_now", "prepare", "watch"];

export default function AlertQueue({ alerts, onSelectAlert }) {
  const grouped = {};
  priorityOrder.forEach(key => { grouped[key] = []; });
  
  (alerts || []).forEach(alert => {
    if (!alert.is_dismissed && grouped[alert.action_class]) {
      grouped[alert.action_class].push(alert);
    }
  });

  const totalActive = Object.values(grouped).flat().length;

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Bell className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold">Alert Action Queue</h2>
        <span className="text-xs text-muted-foreground font-mono">({totalActive})</span>
      </div>

      {totalActive === 0 ? (
        <EmptyState icon={Bell} title="No active alerts" description="All clear — no alerts require your attention right now." />
      ) : (
        <div className="divide-y divide-border">
          {priorityOrder.map(key => {
            const items = grouped[key];
            if (items.length === 0) return null;
            const config = queueConfig[key];
            return (
              <div key={key} className="px-4 py-2.5">
                <div className={`flex items-center gap-1.5 mb-2 text-xs font-medium ${config.color.split(" ")[0]}`}>
                  <config.icon className="w-3 h-3" />
                  <span>{config.label}</span>
                  <span className="text-muted-foreground font-mono">({items.length})</span>
                </div>
                <div className="space-y-1">
                  {items.slice(0, 3).map(alert => (
                    <div
                      key={alert.id}
                      onClick={() => onSelectAlert?.(alert)}
                      className={`text-xs px-2.5 py-1.5 rounded border cursor-pointer hover:bg-accent/50 transition-colors ${config.color}`}
                    >
                      <span className="font-medium">{alert.title}</span>
                      {alert.asset_symbol && <span className="text-muted-foreground ml-2 font-mono">{alert.asset_symbol}</span>}
                    </div>
                  ))}
                  {items.length > 3 && (
                    <p className="text-[10px] text-muted-foreground pl-2">+{items.length - 3} more</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}