import React from "react";
import { useNavigate } from "react-router-dom";
import { Crosshair, Flame, Bell, Briefcase, Clock } from "lucide-react";

export default function DashboardMarketPulse({ recommendedCount, viralCount, alertCount, holdingsCount, latestTimestamp }) {
  const navigate = useNavigate();

  const stats = [
    { label: "Recommended Trades", value: recommendedCount ?? 0, icon: Crosshair, color: "text-primary", href: "/recommended" },
    { label: "Viral Signals", value: viralCount ?? 0, icon: Flame, color: "text-viral", href: "/viral" },
    { label: "Active Alerts", value: alertCount ?? 0, icon: Bell, color: "text-warning", href: "/alerts" },
    { label: "Holdings", value: holdingsCount ?? 0, icon: Briefcase, color: "text-muted-foreground", href: "/portfolio" },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {stats.map((s) => (
        <button
          key={s.label}
          onClick={() => navigate(s.href)}
          className="bg-card border border-border rounded-lg px-4 py-3 flex items-center gap-3 hover:border-primary/40 hover:bg-accent/30 transition-all text-left group"
        >
          <s.icon className={`w-5 h-5 flex-shrink-0 ${s.color} group-hover:scale-110 transition-transform`} />
          <div>
            <div className="text-2xl font-bold font-mono leading-none">{s.value}</div>
            <div className="text-[11px] text-muted-foreground mt-0.5 group-hover:text-foreground/80 transition-colors">{s.label}</div>
          </div>
        </button>
      ))}
      <div className="col-span-2 lg:col-span-4 flex items-center gap-2 text-[11px] text-muted-foreground bg-secondary/30 border border-border rounded-lg px-4 py-2">
        <Clock className="w-3.5 h-3.5 flex-shrink-0" />
        <span>
          Latest data:{" "}
          <span className="font-mono text-foreground">
            {latestTimestamp
              ? new Date(latestTimestamp).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })
              : "No signals loaded yet"}
          </span>
        </span>
      </div>
    </div>
  );
}