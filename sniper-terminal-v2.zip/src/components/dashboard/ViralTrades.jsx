import React, { useState, useMemo } from "react";
import { Flame, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import ScoreBadge from "../shared/ScoreBadge";
import MoveStateBadge from "../shared/MoveStateBadge";
import AILabelBadge from "../shared/AILabelBadge";
import StaleDataBanner from "../shared/StaleDataBanner";
import EmptyState from "../shared/EmptyState";

export default function ViralTrades({ signals, onRefresh, isRefreshing, onSelectViral }) {
  const [filterJunk, setFilterJunk] = useState(true);
  const [sortBy, setSortBy] = useState("viral_score");

  const filtered = useMemo(() => {
    let result = (signals || []).filter(s => s.status === "active" || !s.status);
    if (filterJunk) result = result.filter(s => (s.liquidity_quality || 0) >= 30);
    result.sort((a, b) => (b[sortBy] || 0) - (a[sortBy] || 0));
    return result;
  }, [signals, filterJunk, sortBy]);

  const hasStale = filtered.some(s => s.is_stale);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-viral" />
          <h2 className="text-sm font-semibold">Viral Trades</h2>
          <span className="text-xs text-muted-foreground font-mono">({filtered.length})</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Switch checked={filterJunk} onCheckedChange={setFilterJunk} className="h-4 w-7" />
            <span className="text-[10px] text-muted-foreground">Filter junk</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1.5"
            onClick={onRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      {hasStale && (
        <div className="px-4 pt-2">
          <StaleDataBanner message="Some viral data may be delayed. Labels shown with reduced certainty." />
        </div>
      )}

      {filtered.length === 0 ? (
        <EmptyState icon={Flame} title="No viral moves detected" description="Markets may be quiet, or all moves were filtered as low-quality." />
      ) : (
        <div className="divide-y divide-border">
          {filtered.map((signal) => (
            <div
              key={signal.id}
              onClick={() => onSelectViral?.(signal)}
              className="px-4 py-3 hover:bg-accent/50 cursor-pointer transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span className="text-sm font-semibold font-mono">{signal.asset_symbol}</span>
                    <MoveStateBadge state={signal.move_state} />
                    <AILabelBadge label={signal.ai_label} />
                    {signal.is_stale && <span className="text-[10px] text-warning">⚠ STALE</span>}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span>1h: <span className={`font-mono ${(signal.price_change_1h || 0) >= 0 ? "text-profit" : "text-loss"}`}>{signal.price_change_1h != null ? `${signal.price_change_1h > 0 ? "+" : ""}${signal.price_change_1h.toFixed(1)}%` : "—"}</span></span>
                    <span>4h: <span className={`font-mono ${(signal.price_change_4h || 0) >= 0 ? "text-profit" : "text-loss"}`}>{signal.price_change_4h != null ? `${signal.price_change_4h > 0 ? "+" : ""}${signal.price_change_4h.toFixed(1)}%` : "—"}</span></span>
                    <span>24h: <span className={`font-mono ${(signal.price_change_24h || 0) >= 0 ? "text-profit" : "text-loss"}`}>{signal.price_change_24h != null ? `${signal.price_change_24h > 0 ? "+" : ""}${signal.price_change_24h.toFixed(1)}%` : "—"}</span></span>
                    <span>Vol Spike: <span className="text-foreground font-mono">{signal.volume_spike != null ? `${signal.volume_spike.toFixed(1)}x` : "—"}</span></span>
                  </div>
                  {signal.last_refreshed && (
                    <p className="text-[10px] text-muted-foreground/50 mt-1 font-mono">
                      Updated {new Date(signal.last_refreshed).toLocaleTimeString()}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <ScoreBadge label="VIRAL" score={signal.viral_score} explanation="Virality score based on attention, volume anomaly, sentiment surge, and narrative velocity." />
                  <ScoreBadge label="LIQ" score={signal.liquidity_quality} explanation="Liquidity quality indicates whether this move can be traded safely at size." />
                  <ScoreBadge label="CROWD" score={signal.crowding_score} invert explanation="Crowding score. Higher values indicate dangerous overcrowding." />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}