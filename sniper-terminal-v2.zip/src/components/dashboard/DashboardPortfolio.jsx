import React from "react";
import { Briefcase, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";

function PnlValue({ value, label }) {
  const isPos = value > 0;
  const isNeg = value < 0;
  const formatted = value == null
    ? "—"
    : `${isPos ? "+" : ""}$${Math.abs(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const color = isPos ? "text-profit" : isNeg ? "text-loss" : "text-foreground";
  return (
    <div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">{label}</div>
      <div className={`text-base font-bold font-mono ${color}`}>{formatted}</div>
    </div>
  );
}

export default function DashboardPortfolio({ portfolios = [] }) {
  const navigate = useNavigate();
  const totals = portfolios.reduce(
    (acc, p) => ({
      total_value: acc.total_value + (p.total_value || 0),
      cash_balance: acc.cash_balance + (p.cash_balance || 0),
      unrealised_pnl: acc.unrealised_pnl + (p.unrealised_pnl || 0),
      realised_pnl: acc.realised_pnl + (p.realised_pnl || 0),
    }),
    { total_value: 0, cash_balance: 0, unrealised_pnl: 0, realised_pnl: 0 }
  );

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <button
        onClick={() => navigate("/portfolio")}
        className="w-full flex items-center justify-between gap-2 px-4 py-3 border-b border-border hover:bg-accent/20 transition-colors text-left"
      >
        <div className="flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">Portfolio Summary</span>
          {portfolios.length > 1 && (
            <span className="text-xs text-muted-foreground font-mono">({portfolios.length} portfolios)</span>
          )}
        </div>
        <ExternalLink className="w-3.5 h-3.5 text-muted-foreground/40" />
      </button>

      {portfolios.length === 0 ? (
        <button
          onClick={() => navigate("/portfolio")}
          className="w-full py-8 text-center text-xs text-muted-foreground hover:text-primary transition-colors"
        >
          No portfolios found — click to create one
        </button>
      ) : (
        <button
          onClick={() => navigate("/portfolio")}
          className="w-full p-4 grid grid-cols-2 gap-4 text-left hover:bg-accent/10 transition-colors"
        >
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Total Value</div>
            <div className="text-2xl font-bold font-mono">
              ${totals.total_value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Cash Balance</div>
            <div className="text-2xl font-bold font-mono text-muted-foreground">
              ${totals.cash_balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <PnlValue value={totals.unrealised_pnl} label="Unrealised P&L" />
          <PnlValue value={totals.realised_pnl} label="Realised P&L" />
        </button>
      )}
    </div>
  );
}