import SignalCountdown from "@/components/shared/SignalCountdown";
import React, { useState, useMemo } from "react";
import { Flame, RefreshCw, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import ViralDetailDrawer from "@/components/drilldown/ViralDetailDrawer";
import { isStale } from "@/lib/freshness";
import StaleBanner from "@/components/shared/StaleBanner";

const moveStateConfig = {
  early:     { label: "Early",     classes: "text-profit bg-profit/10 border-profit/25" },
  building:  { label: "Building",  classes: "text-primary bg-primary/10 border-primary/25" },
  crowded:   { label: "Crowded",   classes: "text-warning bg-warning/10 border-warning/25" },
  exhausted: { label: "Exhausted", classes: "text-loss bg-loss/10 border-loss/25" },
};

const aiLabelConfig = {
  tradable: { dot: "bg-profit",   text: "text-profit",  label: "Tradable" },
  caution:  { dot: "bg-warning",  text: "text-warning", label: "Caution" },
  avoid:    { dot: "bg-loss",     text: "text-loss",    label: "Avoid" },
};

function MiniBar({ value, inverted = false }) {
  if (value == null) return <span className="text-muted-foreground/30 font-mono text-xs">—</span>;
  const pct = Math.min(Math.max(Math.round(value), 0), 100);
  const display = inverted ? 100 - pct : pct;
  const color = display >= 70 ? "bg-profit" : display >= 45 ? "bg-warning" : "bg-loss";
  return (
    <div className="flex items-center gap-2 min-w-[80px]">
      <div className="flex-1 h-1 bg-secondary/60 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${pct}%` }} />
      </div>
      <span className="font-mono text-[11px] text-foreground/70 w-6 text-right tabular-nums">{pct}</span>
    </div>
  );
}

const TABLE_HEADERS = ["Asset", "Viral", "Attn.", "Vol.", "Sent.", "Liq.", "State", "Label", "Summary", "Time"];

const MIN_COVERAGE = 20;

export default function DashboardViral({ signals = [], refetchViral }) {
  const [selected, setSelected] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState(null);

  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    assets.forEach(a => { m[a.id] = a; });
    return m;
  }, [assets]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetchViral();
    setLastRefreshed(new Date());
    setIsRefreshing(false);
  };

  const sorted = useMemo(() =>
    [...signals]
      .map(s => {
        const asset = assetMap[s.asset];
        return { ...s, asset_symbol: asset?.symbol || s.asset || "—", asset_name: asset?.name || "" };
      })
      .sort((a, b) => (b.viral_score || 0) - (a.viral_score || 0)),
  [signals, assetMap]);

  return (
    <div className="bg-card border border-viral/15 rounded-xl overflow-hidden shadow-sm">

      {/* ── Header ── */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-viral/15 bg-viral/[0.04]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-viral/15 flex items-center justify-center">
            <Flame className="w-3.5 h-3.5 text-viral" />
          </div>
          <div>
            <span className="text-sm font-semibold tracking-tight text-viral/90">Viral Trades</span>
            <span className="ml-2 text-xs text-muted-foreground font-mono">
              {sorted.length} signal{sorted.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {lastRefreshed && (
            <span className="text-[10px] text-muted-foreground/50 font-mono hidden sm:block">
              Updated {lastRefreshed.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
            </span>
          )}
          <Button
            variant="outline"
            size="sm"
            className="h-7 text-xs gap-1.5 border-viral/25 hover:border-viral/50 hover:bg-viral/5 text-viral/70 hover:text-viral transition-colors"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing…" : "Refresh"}
          </Button>
        </div>
      </div>

      {/* ── Disclaimer ── */}
      <div className="flex items-start gap-2.5 mx-5 mt-3.5 bg-viral/[0.04] border border-viral/10 rounded-lg px-3.5 py-2.5 text-[11px] text-viral/70 leading-relaxed">
        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-viral/60" />
        <span>Virality reflects market attention, not setup quality. High viral scores may indicate late-stage or overcrowded moves — not buying opportunities.</span>
      </div>

      {/* ── Coverage fallback ── */}
      {sorted.length > 0 && sorted.length < MIN_COVERAGE && (
        <div className="mx-5 mt-3 flex items-start gap-2 bg-secondary/30 border border-border rounded-lg px-3 py-2 text-[11px] text-muted-foreground">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-warning/60" />
          <span>
            {sorted.length} of {MIN_COVERAGE}+ target signals available. Add more tracked assets and run Refresh to increase coverage.
          </span>
        </div>
      )}

      {/* ── Table ── */}
      {sorted.length === 0 ? (
        <div className="py-14 text-center space-y-1.5">
          <p className="text-xs text-muted-foreground/60">No active viral signals.</p>
          <p className="text-[11px] text-muted-foreground/40">Add tracked assets and run Refresh to generate signals.</p>
        </div>
      ) : (
        <>
          {/* Mobile cards */}
          <div className="md:hidden mt-3.5 divide-y divide-border">
            {sorted.map(s => {
              const labelCfg = aiLabelConfig[s.ai_label];
              const stateCfg = moveStateConfig[s.move_state];
              const staleRow = isStale(s.timestamp);
              return (
                <button
                  key={s.id}
                  onClick={() => setSelected(s)}
                  className={`w-full text-left px-4 py-3.5 hover:bg-viral/5 transition-colors ${staleRow ? "opacity-60" : ""}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-mono font-bold text-sm">{s.asset_symbol || "—"}</span>
                        <SignalCountdown signal={s} asset={assetMap[s.asset]} />
                        {staleRow && <StaleBanner variant="row" />}
                      </div>
                      {s.asset_name && <div className="text-[10px] text-muted-foreground/60 mt-0.5">{s.asset_name}</div>}
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {stateCfg && <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${stateCfg.classes}`}>{stateCfg.label}</span>}
                      {labelCfg && <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${labelCfg.text}`}>{labelCfg.label}</span>}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-x-3 gap-y-1 text-[11px]">
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Viral</span><span className="font-mono text-viral font-bold">{s.viral_score != null ? Math.round(s.viral_score) : "—"}</span></div>
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Attn</span><span className="font-mono">{s.attention_score != null ? Math.round(s.attention_score) : "—"}</span></div>
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Liq</span><span className="font-mono">{s.liquidity_quality_score != null ? Math.round(s.liquidity_quality_score) : "—"}</span></div>
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Vol</span><span className="font-mono">{s.volume_spike_score != null ? Math.round(s.volume_spike_score) : "—"}</span></div>
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Crowd</span><span className="font-mono text-warning">{s.crowding_score != null ? Math.round(s.crowding_score) : "—"}</span></div>
                    <div className="flex justify-between gap-1"><span className="text-muted-foreground">Exhaust</span><span className="font-mono text-warning">{s.exhaustion_score != null ? Math.round(s.exhaustion_score) : "—"}</span></div>
                  </div>
                  {s.summary && <p className="text-[11px] text-muted-foreground/60 mt-2 line-clamp-2 leading-relaxed">{s.summary}</p>}
                </button>
              );
            })}
          </div>

          {/* Desktop table */}
        <div className="hidden md:block overflow-x-auto mt-3.5">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-viral/10 border-t border-t-viral/10">
                {TABLE_HEADERS.map(h => (
                  <th key={h} className="px-4 py-2.5 text-left text-[9px] font-semibold text-muted-foreground/60 uppercase tracking-widest whitespace-nowrap bg-viral/[0.03]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map((s) => {
                const rowStale = isStale(s.timestamp);
                const labelCfg = aiLabelConfig[s.ai_label];
                const stateCfg = moveStateConfig[s.move_state];

                return (
                  <tr
                    key={s.id}
                    onClick={() => setSelected(s)}
                    className={[
                      "group border-b border-border/30 cursor-pointer transition-all duration-100",
                      rowStale
                        ? "opacity-55 hover:opacity-75 bg-warning/[0.03]"
                        : "hover:bg-viral/[0.04]",
                    ].join(" ")}
                  >
                    {/* Asset */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[13px] text-foreground group-hover:text-viral transition-colors">
                          {s.asset_symbol || "—"}
                        </span>
                        {rowStale && <StaleBanner variant="row" />}
                      </div>
                      <div className="mt-1"><SignalCountdown signal={s} asset={assetMap[s.asset]} /></div>
                    </td>

                    <td className="px-4 py-3"><MiniBar value={s.viral_score} /></td>
                    <td className="px-4 py-3"><MiniBar value={s.attention_score} /></td>
                    <td className="px-4 py-3"><MiniBar value={s.volume_spike_score} /></td>
                    <td className="px-4 py-3"><MiniBar value={s.sentiment_spike_score} /></td>
                    <td className="px-4 py-3"><MiniBar value={s.liquidity_quality_score} /></td>

                    {/* Move state */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      {stateCfg ? (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide ${stateCfg.classes}`}>
                          {stateCfg.label}
                        </span>
                      ) : "—"}
                    </td>

                    {/* AI Label */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      {labelCfg ? (
                        <div className={`flex items-center gap-1.5 ${labelCfg.text}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${labelCfg.dot} flex-shrink-0`} />
                          <span className="font-semibold text-[11px]">{labelCfg.label}</span>
                        </div>
                      ) : <span className="text-muted-foreground/40">—</span>}
                    </td>

                    {/* Summary */}
                    <td className="px-4 py-3 max-w-[220px]">
                      <span className="line-clamp-2 text-muted-foreground/70 leading-relaxed text-[11px]">
                        {s.summary || "—"}
                      </span>
                    </td>

                    {/* Timestamp */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-[10px] text-muted-foreground/40">
                        {s.timestamp
                          ? new Date(s.timestamp).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
                          : "—"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        </>
      )}

      <ViralDetailDrawer signal={selected} onClose={() => setSelected(null)} />
    </div>
  );
}