import React, { useState, useMemo } from "react";
import { Crosshair, ArrowUpDown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ScoreBadge from "../shared/ScoreBadge";
import DirectionBadge from "../shared/DirectionBadge";
import StaleDataBanner from "../shared/StaleDataBanner";
import EmptyState from "../shared/EmptyState";

export default function RecommendedTrades({ signals, onSelectTrade }) {
  const [marketFilter, setMarketFilter] = useState("all");
  const [directionFilter, setDirectionFilter] = useState("all");
  const [sortBy, setSortBy] = useState("opportunity_score");

  const filtered = useMemo(() => {
    let result = (signals || []).filter(s => s.status === "active" || !s.status);
    if (marketFilter !== "all") result = result.filter(s => s.market_type === marketFilter);
    if (directionFilter !== "all") result = result.filter(s => s.direction === directionFilter);
    result.sort((a, b) => (b[sortBy] || 0) - (a[sortBy] || 0));
    return result;
  }, [signals, marketFilter, directionFilter, sortBy]);

  const hasStale = filtered.some(s => s.is_stale);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Crosshair className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold">Daily Recommended Trades</h2>
          <span className="text-xs text-muted-foreground font-mono">({filtered.length})</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={marketFilter} onValueChange={setMarketFilter}>
            <SelectTrigger className="h-7 text-xs w-24 bg-secondary/50 border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Markets</SelectItem>
              <SelectItem value="crypto">Crypto</SelectItem>
              <SelectItem value="fx">FX</SelectItem>
            </SelectContent>
          </Select>
          <Select value={directionFilter} onValueChange={setDirectionFilter}>
            <SelectTrigger className="h-7 text-xs w-24 bg-secondary/50 border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="bullish">Bullish</SelectItem>
              <SelectItem value="bearish">Bearish</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="h-7 text-xs w-32 bg-secondary/50 border-border">
              <ArrowUpDown className="w-3 h-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="opportunity_score">Opportunity</SelectItem>
              <SelectItem value="conviction_score">Conviction</SelectItem>
              <SelectItem value="risk_reward_ratio">Risk-Adjusted</SelectItem>
              <SelectItem value="momentum_score">Momentum</SelectItem>
              <SelectItem value="catalyst_quality">Catalyst</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {hasStale && (
        <div className="px-4 pt-2">
          <StaleDataBanner message="Some signals may be stale. Scores shown with reduced confidence." />
        </div>
      )}

      {filtered.length === 0 ? (
        <EmptyState icon={Crosshair} title="No signals match your filters" description="Try adjusting your filters or check back later for new setups." />
      ) : (
        <div className="divide-y divide-border">
          {filtered.map((signal) => (
            <div
              key={signal.id}
              onClick={() => onSelectTrade?.(signal)}
              className="px-4 py-3 hover:bg-accent/50 cursor-pointer transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-sm font-semibold font-mono">{signal.asset_symbol}</span>
                    <DirectionBadge direction={signal.direction} />
                    <span className="text-[10px] text-muted-foreground uppercase bg-secondary px-1.5 py-0.5 rounded">{signal.setup_type || "setup"}</span>
                    <span className="text-[10px] text-muted-foreground">{signal.timeframe}</span>
                    {signal.is_stale && <span className="text-[10px] text-warning">⚠ STALE</span>}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span>Price: <span className="text-foreground font-mono">${signal.current_price?.toLocaleString() ?? "—"}</span></span>
                    <span>Entry: <span className="text-foreground font-mono">${signal.entry_zone_low?.toLocaleString() ?? "—"} – ${signal.entry_zone_high?.toLocaleString() ?? "—"}</span></span>
                    <span>Invalidation: <span className="text-loss font-mono">${signal.invalidation?.toLocaleString() ?? "—"}</span></span>
                    <span>T1: <span className="text-profit font-mono">${signal.target_1?.toLocaleString() ?? "—"}</span></span>
                    <span>T2: <span className="text-profit font-mono">${signal.target_2?.toLocaleString() ?? "—"}</span></span>
                  </div>
                  {signal.why_now && (
                    <p className="text-xs text-muted-foreground mt-1.5 line-clamp-1">{signal.why_now}</p>
                  )}
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <ScoreBadge label="OPP" score={signal.opportunity_score} explanation="Opportunity score reflects overall trade quality based on trend, momentum, volume, structure, and catalyst alignment." />
                  <ScoreBadge label="CONV" score={signal.conviction_score} explanation="Conviction score reflects strength of confirmation signals and data confidence." />
                  <ScoreBadge label="RISK" score={signal.risk_score} invert explanation="Risk score reflects potential downside. Higher = more risk." />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}