import React from "react";
import { Bell, Eye, Clock, Zap, ShieldAlert, LogOut, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";

const GROUPS = [
  { key: "exit_hedge", label: "Exit / Hedge", icon: LogOut, color: "text-loss", bg: "bg-loss/5 border-loss/20" },
  { key: "reduce_risk", label: "Reduce Risk", icon: ShieldAlert, color: "text-warning", bg: "bg-warning/5 border-warning/20" },
  { key: "act_now", label: "Act Now", icon: Zap, color: "text-primary", bg: "bg-primary/5 border-primary/20" },
  { key: "prepare", label: "Prepare", icon: Clock, color: "text-muted-foreground", bg: "bg-secondary/40 border-border" },
  { key: "watch", label: "Watch", icon: Eye, color: "text-muted-foreground/70", bg: "bg-secondary/20 border-border" },
];

const severityDot = {
  critical: "bg-loss",
  high: "bg-warning",
  medium: "bg-primary",
  low: "bg-muted-foreground",
};

export default function DashboardAlerts({ alerts = [] }) {
  const navigate = useNavigate();
  const grouped = {};
  GROUPS.forEach(g => { grouped[g.key] = []; });

  alerts.forEach(a => {
    const key = a.action_classification;
    if (grouped[key]) grouped[key].push(a);
    else if (grouped["watch"]) grouped["watch"].push(a);
  });

  const totalActive = alerts.length;

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <button
        onClick={() => navigate("/alerts")}
        className="w-full flex items-center justify-between gap-2 px-4 py-3 border-b border-border hover:bg-accent/20 transition-colors text-left"
      >
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">Alerts</span>
          <span className="text-xs text-muted-foreground font-mono">({totalActive})</span>
        </div>
        <ExternalLink className="w-3.5 h-3.5 text-muted-foreground/40" />
      </button>

      {totalActive === 0 ? (
        <div className="py-8 text-center text-xs text-muted-foreground">No active alerts.</div>
      ) : (
        <div className="divide-y divide-border">
          {GROUPS.map(g => {
            const items = grouped[g.key] || [];
            if (items.length === 0) return null;
            return (
              <div key={g.key} className="px-4 py-3">
                <div className={`flex items-center gap-1.5 text-xs font-medium mb-2 ${g.color}`}>
                  <g.icon className="w-3.5 h-3.5" />
                  <span>{g.label}</span>
                  <span className="text-muted-foreground font-mono ml-1">({items.length})</span>
                </div>
                <div className="space-y-1.5">
                  {items.slice(0, 4).map(a => {
                    const symbol = a.asset || "Unknown";
                    const marketType = a.market_type || "";
                    const alertType = (a.alert_type || "alert").replace(/_/g, " ");
                    const headline = [symbol, marketType, alertType].filter(Boolean).join(" • ");
                    const displayName = a.display_name && a.display_name !== symbol ? a.display_name : null;
                    const priceStr = a.current_price != null
                      ? (a.current_price < 1 ? `$${a.current_price.toFixed(4)}` : `$${a.current_price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`)
                      : null;
                    return (
                    <button
                      key={a.id}
                      onClick={() => navigate("/alerts")}
                      className={`w-full flex items-start gap-2 text-xs px-2.5 py-1.5 rounded border text-left hover:brightness-110 transition-all cursor-pointer ${g.bg}`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1 ${severityDot[a.severity] || "bg-muted-foreground"}`} />
                      <div className="min-w-0 flex-1">
                        <div className="font-mono font-semibold text-foreground text-[11px] truncate">{headline}</div>
                        {displayName && <div className="text-[10px] text-muted-foreground/60 truncate">{displayName}</div>}
                        <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                          {priceStr && <span className="font-mono text-[10px] text-foreground/70">{priceStr}</span>}
                          {a.pnl_pct != null && (
                            <span className={`text-[10px] font-mono ${a.pnl_pct >= 0 ? "text-profit" : "text-loss"}`}>
                              {a.pnl_pct >= 0 ? "+" : ""}{a.pnl_pct.toFixed(1)}%
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                    );
                  })}
                  {items.length > 4 && (
                    <button
                      onClick={() => navigate("/alerts")}
                      className="text-[11px] text-primary/70 hover:text-primary pl-2 transition-colors"
                    >
                      +{items.length - 4} more — view all alerts →
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}