import React, { useMemo } from "react";
import { Grid3x3 } from "lucide-react";
import EmptyState from "../shared/EmptyState";

export default function OpportunityHeatmap({ signals }) {
  const sectors = useMemo(() => {
    const map = {};
    (signals || []).forEach(s => {
      const key = s.market_type || "other";
      if (!map[key]) map[key] = { bullish: 0, bearish: 0, total: 0, avgScore: 0, scores: [] };
      map[key].total++;
      if (s.direction === "bullish") map[key].bullish++;
      else map[key].bearish++;
      map[key].scores.push(s.opportunity_score || 0);
    });
    Object.keys(map).forEach(k => {
      map[k].avgScore = map[k].scores.length > 0 ? map[k].scores.reduce((a, b) => a + b, 0) / map[k].scores.length : 0;
    });
    return map;
  }, [signals]);

  const keys = Object.keys(sectors);

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Grid3x3 className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold">Opportunity Heatmap</h2>
      </div>
      {keys.length === 0 ? (
        <EmptyState icon={Grid3x3} title="No opportunity data" />
      ) : (
        <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {keys.map(key => {
            const s = sectors[key];
            const intensity = Math.min(s.avgScore / 100, 1);
            return (
              <div
                key={key}
                className="rounded-lg border border-border p-3 text-center transition-colors"
                style={{ backgroundColor: `rgba(59, 130, 246, ${intensity * 0.3})` }}
              >
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{key}</p>
                <p className="text-lg font-bold font-mono text-foreground">{s.total}</p>
                <div className="flex justify-center gap-2 mt-1 text-[10px]">
                  <span className="text-profit">{s.bullish}↑</span>
                  <span className="text-loss">{s.bearish}↓</span>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">avg {Math.round(s.avgScore)}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}