import React, { useMemo } from "react";
import { TrendingUp, TrendingDown, ShieldAlert, Target, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

/**
 * Portfolio Risk Summary Strip — top of dashboard.
 * Shows: net long/short bias, % high-risk exposure, # positions near stop or TP.
 */

function Pill({ icon: Icon, label, value, color, bg, border, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors hover:opacity-80 ${bg} ${border}`}
    >
      <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${color}`} />
      <div className="text-left min-w-0">
        <div className={`text-xs font-bold font-mono ${color}`}>{value}</div>
        <div className="text-[9px] text-muted-foreground uppercase tracking-widest">{label}</div>
      </div>
    </button>
  );
}

export default function PortfolioRiskStrip({ holdings = [], portfolios = [] }) {
  const navigate = useNavigate();

  const stats = useMemo(() => {
    if (holdings.length === 0) return null;

    const open = holdings.filter(h => h.quantity != null && h.quantity !== 0);

    // Long/short bias
    let longVal = 0, shortVal = 0;
    open.forEach(h => {
      const val = Math.abs(h.current_value ?? (h.quantity ?? 0) * (h.live_price ?? h.average_entry ?? 0));
      if ((h.quantity ?? 0) > 0) longVal += val;
      else shortVal += val;
    });
    const totalExposure = longVal + shortVal;
    const netBias = totalExposure > 0 ? Math.round(((longVal - shortVal) / totalExposure) * 100) : 0;

    // High-risk positions (risk_score > 65 OR no stop loss)
    const highRisk = open.filter(h => !h.stop_loss);
    const highRiskPct = open.length > 0 ? Math.round((highRisk.length / open.length) * 100) : 0;

    // Near stop (within 5% of stop_loss)
    let nearStop = 0, nearTP = 0;
    open.forEach(h => {
      const price = h.live_price ?? h.average_entry;
      if (!price) return;
      if (h.stop_loss) {
        const distPct = Math.abs((price - h.stop_loss) / price) * 100;
        if (distPct < 5) nearStop++;
      }
      if (h.take_profit) {
        const distPct = Math.abs((price - h.take_profit) / price) * 100;
        if (distPct < 5) nearTP++;
      }
    });

    return { netBias, highRiskPct, nearStop, nearTP, totalPositions: open.length, longVal, shortVal };
  }, [holdings]);

  if (!stats || stats.totalPositions === 0) return null;

  const biasLabel = stats.netBias > 20 ? "NET LONG" : stats.netBias < -20 ? "NET SHORT" : "BALANCED";
  const biasColor = stats.netBias > 20 ? "text-profit" : stats.netBias < -20 ? "text-loss" : "text-muted-foreground";
  const biasBg    = stats.netBias > 20 ? "bg-profit/10" : stats.netBias < -20 ? "bg-loss/10" : "bg-secondary/30";
  const biasBorder = stats.netBias > 20 ? "border-profit/30" : stats.netBias < -20 ? "border-loss/30" : "border-border";
  const BiasIcon  = stats.netBias >= 0 ? TrendingUp : TrendingDown;

  const riskColor  = stats.highRiskPct >= 60 ? "text-loss" : stats.highRiskPct >= 30 ? "text-warning" : "text-profit";
  const riskBg     = stats.highRiskPct >= 60 ? "bg-loss/10" : stats.highRiskPct >= 30 ? "bg-warning/10" : "bg-profit/10";
  const riskBorder = stats.highRiskPct >= 60 ? "border-loss/30" : stats.highRiskPct >= 30 ? "border-warning/30" : "border-profit/30";

  const atRisk = stats.nearStop + stats.nearTP;
  const atRiskColor  = atRisk > 0 ? "text-warning" : "text-muted-foreground";
  const atRiskBg     = atRisk > 0 ? "bg-warning/10" : "bg-secondary/30";
  const atRiskBorder = atRisk > 0 ? "border-warning/30" : "border-border";

  return (
    <div className="bg-card border border-border rounded-xl px-4 py-3">
      <div className="flex items-center justify-between mb-2.5">
        <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground/50">Portfolio Risk Overview</span>
        <button
          onClick={() => navigate("/portfolio")}
          className="flex items-center gap-1 text-[9px] text-muted-foreground/50 hover:text-primary transition-colors uppercase tracking-widest"
        >
          View Portfolio <ArrowRight className="w-2.5 h-2.5" />
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        <Pill
          icon={BiasIcon}
          label={biasLabel}
          value={`${Math.abs(stats.netBias)}% ${stats.netBias >= 0 ? "Long" : "Short"}`}
          color={biasColor}
          bg={biasBg}
          border={biasBorder}
          onClick={() => navigate("/portfolio")}
        />
        <Pill
          icon={ShieldAlert}
          label="Unprotected Positions"
          value={`${stats.highRiskPct}% (${stats.totalPositions - Math.round((stats.highRiskPct / 100) * stats.totalPositions) + (stats.totalPositions - Math.round((100 - stats.highRiskPct) / 100 * stats.totalPositions))} no stop)`}
          color={riskColor}
          bg={riskBg}
          border={riskBorder}
          onClick={() => navigate("/portfolio")}
        />
        <Pill
          icon={Target}
          label="Near Stop / TP"
          value={atRisk > 0 ? `${stats.nearStop} near stop · ${stats.nearTP} near TP` : "None at limit"}
          color={atRiskColor}
          bg={atRiskBg}
          border={atRiskBorder}
          onClick={() => navigate("/portfolio")}
        />
      </div>
    </div>
  );
}