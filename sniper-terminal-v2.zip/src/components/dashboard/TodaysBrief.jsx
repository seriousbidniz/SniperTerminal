import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Zap, ShieldAlert, TrendingUp, TrendingDown, Minus, AlertTriangle, ChevronDown, ChevronUp, Target, Eye } from "lucide-react";
import { deriveDecision } from "@/components/shared/SignalDecisionOutput";
import RecommendedDetailDrawer from "@/components/drilldown/RecommendedDetailDrawer.jsx";
import ViralDetailDrawer from "@/components/drilldown/ViralDetailDrawer";

// ─── Market Bias ──────────────────────────────────────────────────────────────
function deriveMarketBias(recommended = [], viral = []) {
  const bullish = recommended.filter(s => s.direction === "bullish").length;
  const bearish  = recommended.filter(s => s.direction === "bearish").length;
  const total = bullish + bearish;
  if (total === 0) return null;
  const ratio = bullish / total;
  if (ratio >= 0.65) return { label: "Bullish", icon: TrendingUp, color: "text-profit", bg: "bg-profit/10 border-profit/30", ratio };
  if (ratio <= 0.35) return { label: "Bearish", icon: TrendingDown, color: "text-loss", bg: "bg-loss/10 border-loss/30", ratio };
  return { label: "Mixed", icon: Minus, color: "text-warning", bg: "bg-warning/10 border-warning/30", ratio };
}

// ─── Portfolio Warning ────────────────────────────────────────────────────────
function derivePortfolioWarning(alerts = []) {
  const critical = alerts.filter(a => a.action_classification === "exit_hedge" || a.action_classification === "reduce_risk");
  if (critical.length === 0) return null;
  return critical.length;
}

// ─── Action Card ──────────────────────────────────────────────────────────────
function ActionCard({ signal, rank, type, onClick }) {
  const decision = deriveDecision(signal);
  const symbol = signal.asset_symbol || signal.asset || "—";
  const isEnter = decision.id === "enter";
  const isAvoid = type === "risk";

  const accentColor = isAvoid
    ? "border-loss/25 bg-loss/[0.04] hover:bg-loss/[0.08]"
    : "border-profit/25 bg-profit/[0.04] hover:bg-profit/[0.08]";

  const rankColor = isAvoid ? "text-loss bg-loss/15" : "text-profit bg-profit/15";

  return (
    <button
      onClick={() => onClick(signal)}
      className={`w-full text-left rounded-xl border px-3.5 py-3 transition-all duration-150 group ${accentColor}`}
    >
      <div className="flex items-start gap-3">
        {/* Rank */}
        <span className={`text-[10px] font-black rounded-md px-1.5 py-0.5 flex-shrink-0 mt-0.5 ${rankColor}`}>
          #{rank}
        </span>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono font-black text-sm text-foreground group-hover:text-primary transition-colors">
              {symbol}
            </span>
            {signal.market_type && (
              <span className="text-[9px] uppercase tracking-wider text-muted-foreground/60 font-semibold">
                {signal.market_type}
              </span>
            )}
          </div>

          {/* Action statement */}
          <div className={`text-[11px] font-bold mb-1.5 ${isAvoid ? "text-loss/90" : "text-profit/90"}`}>
            {isAvoid
              ? (decision.id === "avoid" ? "⛔ Avoid — " : "⚠ Reduce — ") + (signal.what_kills_it?.split(".")[0] || decision.description?.split(".")[0] || "Risk elevated")
              : "✅ Enter — " + (signal.why_now?.split(".")[0] || decision.description?.split(".")[0] || "Setup confirmed")
            }
          </div>

          {/* Meta row */}
          <div className="flex items-center gap-2 flex-wrap">
            {signal.setup_type && (
              <span className="text-[9px] text-muted-foreground/60 capitalize">{signal.setup_type.replace(/_/g, " ")}</span>
            )}
            {signal.opportunity_score != null && !isAvoid && (
              <span className="text-[10px] font-mono text-profit/80">OPP {Math.round(signal.opportunity_score)}</span>
            )}
            {signal.risk_score != null && isAvoid && (
              <span className="text-[10px] font-mono text-loss/80">RISK {Math.round(signal.risk_score)}</span>
            )}
            {signal.viral_score != null && (
              <span className="text-[10px] font-mono text-viral/80">VIRAL {Math.round(signal.viral_score)}</span>
            )}
          </div>
        </div>

        <div className="flex-shrink-0 self-center opacity-40 group-hover:opacity-80 transition-opacity">
          <ChevronDown className="w-3.5 h-3.5 rotate-[-90deg]" />
        </div>
      </div>
    </button>
  );
}

// ─── Section Header ───────────────────────────────────────────────────────────
function SectionHead({ icon: Icon, label, color, count }) {
  return (
    <div className={`flex items-center gap-2 mb-2.5`}>
      <Icon className={`w-3.5 h-3.5 ${color}`} />
      <span className={`text-[11px] font-bold uppercase tracking-widest ${color}`}>{label}</span>
      {count != null && (
        <span className="text-[10px] text-muted-foreground font-mono">({count})</span>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function TodaysBrief({ recommended = [], viral = [], alerts = [], holdings = [], assetMap = {} }) {
  const navigate = useNavigate();
  const [selectedRec, setSelectedRec] = useState(null);
  const [selectedViral, setSelectedViral] = useState(null);
  const [collapsed, setCollapsed] = useState(false);

  // Enrich signals
  const enrichedRec = useMemo(() => recommended.map(s => {
    const asset = assetMap[s.asset];
    return { ...s, asset_symbol: asset?.symbol || s.asset || "—", asset_name: asset?.name || "", market_type: asset?.market_type || s.market_type || "crypto" };
  }), [recommended, assetMap]);

  const enrichedViral = useMemo(() => viral.map(s => {
    const asset = assetMap[s.asset];
    return { ...s, asset_symbol: asset?.symbol || s.asset || "—", asset_name: asset?.name || "", market_type: asset?.market_type || s.market_type || "crypto" };
  }), [viral, assetMap]);

  // Top 3 ENTER NOW trades
  const topTrades = useMemo(() => {
    return enrichedRec
      .filter(s => {
        const d = deriveDecision(s);
        return d.id === "enter";
      })
      .sort((a, b) => (b.opportunity_score || 0) - (a.opportunity_score || 0))
      .slice(0, 3);
  }, [enrichedRec]);

  // Top 3 risks — high risk recommended + avoid viral
  const topRisks = useMemo(() => {
    const highRiskRec = enrichedRec
      .filter(s => {
        const d = deriveDecision(s);
        return d.id === "avoid" || d.id === "reduce";
      })
      .map(s => ({ ...s, _type: "rec" }))
      .sort((a, b) => (b.risk_score || 0) - (a.risk_score || 0));

    const avoidViral = enrichedViral
      .filter(s => s.ai_label === "avoid" || (s.exhaustion_score > 65 && s.crowding_score > 60))
      .map(s => ({ ...s, _type: "viral" }))
      .sort((a, b) => (b.viral_score || 0) - (a.viral_score || 0));

    const combined = [...highRiskRec, ...avoidViral]
      .sort((a, b) => (b.risk_score || b.viral_score || 0) - (a.risk_score || a.viral_score || 0));

    return combined.slice(0, 3);
  }, [enrichedRec, enrichedViral]);

  const bias = useMemo(() => deriveMarketBias(enrichedRec, enrichedViral), [enrichedRec, enrichedViral]);
  const portfolioWarnings = derivePortfolioWarning(alerts);

  const hasContent = topTrades.length > 0 || topRisks.length > 0 || bias;

  if (!hasContent) return null;

  const now = new Date();
  const timeLabel = now.toLocaleString("en-GB", { weekday: "long", day: "numeric", month: "long" });

  const BiasIcon = bias?.icon || Minus;

  return (
    <div className="rounded-2xl border border-primary/20 bg-gradient-to-b from-primary/[0.06] to-transparent overflow-hidden shadow-lg shadow-primary/5">

      {/* ── Brief Header ── */}
      <button
        onClick={() => setCollapsed(c => !c)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-primary/5 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-primary/15 flex items-center justify-center">
            <Target className="w-4 h-4 text-primary" />
          </div>
          <div className="text-left">
            <div className="text-sm font-black tracking-tight text-foreground">Today's Trading Brief</div>
            <div className="text-[10px] text-muted-foreground/60 font-mono mt-0.5">{timeLabel}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Quick stats */}
          <div className="hidden sm:flex items-center gap-3">
            {bias && (
              <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-bold ${bias.color} ${bias.bg}`}>
                <BiasIcon className="w-3 h-3" />
                {bias.label}
              </div>
            )}
            {portfolioWarnings && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-loss/30 bg-loss/10 text-loss text-[10px] font-bold">
                <AlertTriangle className="w-3 h-3" />
                {portfolioWarnings} warning{portfolioWarnings !== 1 ? "s" : ""}
              </div>
            )}
          </div>
          {collapsed
            ? <ChevronDown className="w-4 h-4 text-muted-foreground/50" />
            : <ChevronUp className="w-4 h-4 text-muted-foreground/50" />
          }
        </div>
      </button>

      {!collapsed && (
        <div className="px-5 pb-5 space-y-5">

          {/* ── Market Bias + Portfolio Warning strip ── */}
          <div className="flex flex-wrap gap-2">
            {bias && (
              <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-semibold ${bias.color} ${bias.bg}`}>
                <BiasIcon className="w-3.5 h-3.5" />
                <span>Market bias: <strong>{bias.label}</strong></span>
                <span className="font-mono text-[10px] opacity-70">
                  {Math.round(bias.ratio * 100)}% bullish setups
                </span>
              </div>
            )}
            {portfolioWarnings && (
              <button
                onClick={() => navigate("/alerts")}
                className="flex items-center gap-2 px-3 py-2 rounded-xl border border-loss/30 bg-loss/10 text-loss text-xs font-semibold hover:bg-loss/15 transition-colors"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Portfolio: <strong>{portfolioWarnings} active warning{portfolioWarnings !== 1 ? "s" : ""}</strong></span>
                <span className="text-[10px] opacity-60">→ view</span>
              </button>
            )}
            {!portfolioWarnings && holdings.length > 0 && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl border border-profit/20 bg-profit/[0.04] text-profit text-xs font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-profit" />
                Portfolio: No active warnings
              </div>
            )}
          </div>

          {/* ── Two-column grid: enter + risks ── */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

            {/* LEFT — Top Trades */}
            <div>
              <SectionHead icon={Zap} label="Top Trades — Enter Now" color="text-profit" count={topTrades.length} />
              {topTrades.length === 0 ? (
                <div className="rounded-xl border border-border bg-secondary/20 px-4 py-6 text-center text-xs text-muted-foreground">
                  No high-conviction ENTER signals right now. Run Recompute to refresh.
                </div>
              ) : (
                <div className="space-y-2">
                  {topTrades.map((s, i) => (
                    <ActionCard
                      key={s.id}
                      signal={s}
                      rank={i + 1}
                      type="enter"
                      onClick={setSelectedRec}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* RIGHT — Top Risks */}
            <div>
              <SectionHead icon={ShieldAlert} label="Top Risks — Reduce / Avoid" color="text-loss" count={topRisks.length} />
              {topRisks.length === 0 ? (
                <div className="rounded-xl border border-border bg-secondary/20 px-4 py-6 text-center text-xs text-muted-foreground">
                  No high-risk signals detected. Stay alert.
                </div>
              ) : (
                <div className="space-y-2">
                  {topRisks.map((s, i) => (
                    <ActionCard
                      key={s.id}
                      signal={s}
                      rank={i + 1}
                      type="risk"
                      onClick={s._type === "viral" ? setSelectedViral : setSelectedRec}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* ── What to watch ── */}
          {enrichedViral.filter(s => s.ai_label === "tradable" && s.move_state === "early").length > 0 && (
            <div>
              <SectionHead icon={Eye} label="Watch — Early Movers" color="text-primary" />
              <div className="flex flex-wrap gap-2">
                {enrichedViral
                  .filter(s => s.ai_label === "tradable" && s.move_state === "early")
                  .slice(0, 5)
                  .map(s => (
                    <button
                      key={s.id}
                      onClick={() => setSelectedViral(s)}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors text-xs font-mono font-bold text-primary"
                    >
                      {s.asset_symbol}
                      <span className="text-[9px] font-normal text-muted-foreground/60">viral {Math.round(s.viral_score)}</span>
                    </button>
                  ))
                }
              </div>
            </div>
          )}

          {/* ── Disclaimer ── */}
          <p className="text-[9px] text-muted-foreground/30 leading-relaxed border-t border-border/30 pt-3">
            Analysis only. Not financial advice. All signals are derived from stored data. Conduct independent research before acting.
          </p>
        </div>
      )}

      <RecommendedDetailDrawer signal={selectedRec} onClose={() => setSelectedRec(null)} />
      <ViralDetailDrawer signal={selectedViral} onClose={() => setSelectedViral(null)} />
    </div>
  );
}