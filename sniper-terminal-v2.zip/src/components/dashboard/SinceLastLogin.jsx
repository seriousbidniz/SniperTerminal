import React, { useMemo, useEffect, useState } from "react";
import { Clock, TrendingUp, Bell, Flame } from "lucide-react";

const STORAGE_KEY = "sniper_last_login";
const PREV_COUNTS_KEY = "sniper_prev_counts";

function StatDelta({ icon: Icon, label, current, prev, color = "text-foreground" }) {
  const delta = prev != null ? current - prev : null;
  const increased = delta != null && delta > 0;
  const decreased = delta != null && delta < 0;
  return (
    <div className="flex items-center gap-2">
      <Icon className={`w-3 h-3 ${color} flex-shrink-0`} />
      <span className="text-[11px] text-muted-foreground">{label}</span>
      <span className={`text-[11px] font-mono font-bold ${color}`}>{current}</span>
      {delta != null && delta !== 0 && (
        <span className={`text-[10px] font-mono font-bold ${increased ? "text-profit" : "text-loss"}`}>
          {increased ? "+" : ""}{delta}
        </span>
      )}
    </div>
  );
}

export default function SinceLastLogin({ recommended = [], viral = [], alerts = [] }) {
  const [lastLogin, setLastLogin] = useState(null);
  const [prevCounts, setPrevCounts] = useState(null);

  useEffect(() => {
    // Read previous session data
    const stored = localStorage.getItem(STORAGE_KEY);
    const storedCounts = localStorage.getItem(PREV_COUNTS_KEY);

    if (stored) setLastLogin(new Date(stored));
    if (storedCounts) {
      try { setPrevCounts(JSON.parse(storedCounts)); } catch {}
    }

    // Save current session counts for next time
    localStorage.setItem(STORAGE_KEY, new Date().toISOString());
    localStorage.setItem(PREV_COUNTS_KEY, JSON.stringify({
      recommended: recommended.length,
      viral: viral.length,
      alerts: alerts.length,
    }));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // New signals since last login (by timestamp)
  const newSignals = useMemo(() => {
    if (!lastLogin) return { rec: 0, viral: 0, alerts: 0 };
    const rec = recommended.filter(s => s.timestamp && new Date(s.timestamp) > lastLogin).length;
    const v   = viral.filter(s => s.timestamp && new Date(s.timestamp) > lastLogin).length;
    const a   = alerts.filter(s => s.triggered_at && new Date(s.triggered_at) > lastLogin).length;
    return { rec, viral: v, alerts: a };
  }, [recommended, viral, alerts, lastLogin]);

  const hasAnyNew = newSignals.rec > 0 || newSignals.viral > 0 || newSignals.alerts > 0;

  if (!lastLogin) return null;

  const gap = Date.now() - lastLogin.getTime();
  const gapHours = Math.floor(gap / 3600000);
  const gapMins  = Math.floor((gap % 3600000) / 60000);
  const timeAgo = gapHours > 0
    ? `${gapHours}h ${gapMins}m ago`
    : `${gapMins}m ago`;

  if (!hasAnyNew) return null;

  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-2 px-4 py-2.5 rounded-xl border border-border bg-secondary/20 text-xs">
      <div className="flex items-center gap-1.5 text-muted-foreground/60">
        <Clock className="w-3 h-3" />
        <span className="text-[10px]">Since your last visit ({timeAgo}):</span>
      </div>
      {newSignals.rec > 0 && (
        <StatDelta icon={TrendingUp} label="new trades" current={newSignals.rec} color="text-profit" />
      )}
      {newSignals.viral > 0 && (
        <StatDelta icon={Flame} label="new viral" current={newSignals.viral} color="text-viral" />
      )}
      {newSignals.alerts > 0 && (
        <StatDelta icon={Bell} label="new alerts" current={newSignals.alerts} color="text-warning" />
      )}
    </div>
  );
}