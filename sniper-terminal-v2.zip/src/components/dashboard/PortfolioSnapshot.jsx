import React from "react";
import { Briefcase, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import EmptyState from "../shared/EmptyState";

function formatCurrency(val) {
  if (val == null) return "—";
  const abs = Math.abs(val);
  const prefix = val < 0 ? "-" : val > 0 ? "+" : "";
  return `${prefix}$${abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function PortfolioSnapshot({ portfolios, holdings }) {
  if (!portfolios || portfolios.length === 0) {
    return (
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold">Portfolio Snapshot</h2>
        </div>
        <EmptyState icon={Briefcase} title="No portfolios yet" description="Create a portfolio to track your positions and P&L." />
      </div>
    );
  }

  const totalValue = portfolios.reduce((sum, p) => sum + (p.total_value || 0), 0);
  const dailyPnl = portfolios.reduce((sum, p) => sum + (p.daily_pnl || 0), 0);
  const unrealisedPnl = portfolios.reduce((sum, p) => sum + (p.unrealised_pnl || 0), 0);
  const realisedPnl = portfolios.reduce((sum, p) => sum + (p.realised_pnl || 0), 0);

  const allHoldings = holdings || [];
  const sorted = [...allHoldings].sort((a, b) => (b.unrealised_pnl || 0) - (a.unrealised_pnl || 0));
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];

  // Concentration check
  const topAlloc = allHoldings.length > 0 ? Math.max(...allHoldings.map(h => h.allocation_pct || 0)) : 0;
  const hasConcentration = topAlloc > 30;

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center gap-2">
        <Briefcase className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold">Portfolio Snapshot</h2>
      </div>
      <div className="p-4 space-y-3">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Value</p>
            <p className="text-lg font-bold font-mono">${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Daily P&L</p>
            <p className={`text-lg font-bold font-mono ${dailyPnl >= 0 ? "text-profit" : "text-loss"}`}>
              {formatCurrency(dailyPnl)}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Unrealised</p>
            <p className={`text-sm font-semibold font-mono ${unrealisedPnl >= 0 ? "text-profit" : "text-loss"}`}>
              {formatCurrency(unrealisedPnl)}
            </p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Realised</p>
            <p className={`text-sm font-semibold font-mono ${realisedPnl >= 0 ? "text-profit" : "text-loss"}`}>
              {formatCurrency(realisedPnl)}
            </p>
          </div>
        </div>

        {hasConcentration && (
          <div className="flex items-center gap-2 text-xs text-warning bg-warning/10 border border-warning/20 rounded px-2.5 py-1.5">
            <AlertTriangle className="w-3 h-3 flex-shrink-0" />
            <span>High concentration detected ({topAlloc.toFixed(0)}% in single position). Consider diversifying.</span>
          </div>
        )}

        {(best || worst) && (
          <div className="flex gap-4 text-xs">
            {best && best.unrealised_pnl > 0 && (
              <div className="flex items-center gap-1.5">
                <TrendingUp className="w-3 h-3 text-profit" />
                <span className="text-muted-foreground">Best:</span>
                <span className="font-mono font-medium">{best.asset_symbol}</span>
                <span className="text-profit font-mono">{formatCurrency(best.unrealised_pnl)}</span>
              </div>
            )}
            {worst && worst.unrealised_pnl < 0 && (
              <div className="flex items-center gap-1.5">
                <TrendingDown className="w-3 h-3 text-loss" />
                <span className="text-muted-foreground">Worst:</span>
                <span className="font-mono font-medium">{worst.asset_symbol}</span>
                <span className="text-loss font-mono">{formatCurrency(worst.unrealised_pnl)}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}