import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Eye, Bell, Briefcase, BookOpen } from "lucide-react";
import ScoreBadge from "../shared/ScoreBadge";
import DirectionBadge from "../shared/DirectionBadge";
import StaleDataBanner from "../shared/StaleDataBanner";

export default function TradeDetailDrawer({ trade, onClose }) {
  if (!trade) return null;

  return (
    <Sheet open={!!trade} onOpenChange={() => onClose()}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-border">
        <SheetHeader className="pb-4 border-b border-border">
          <div className="flex items-center gap-3">
            <SheetTitle className="text-lg font-mono">{trade.asset_symbol}</SheetTitle>
            <DirectionBadge direction={trade.direction} />
          </div>
          <p className="text-xs text-muted-foreground">{trade.asset_name || trade.asset_symbol} · {trade.setup_type || "Setup"} · {trade.timeframe || "—"}</p>
        </SheetHeader>

        {trade.is_stale && (
          <div className="mt-3">
            <StaleDataBanner message="This signal's data may be outdated. Treat scores with reduced confidence." />
          </div>
        )}

        <div className="mt-4 space-y-5">
          {/* Scores */}
          <div className="flex justify-around">
            <ScoreBadge label="Opportunity" score={trade.opportunity_score} explanation="Trade quality based on trend, momentum, volume, structure, liquidity, and catalyst." />
            <ScoreBadge label="Conviction" score={trade.conviction_score} explanation="Strength of confirming signals. Higher = more aligned evidence." />
            <ScoreBadge label="Risk" score={trade.risk_score} invert explanation="Risk level. Higher score = more downside exposure and uncertainty." />
          </div>

          {/* Key Levels */}
          <div className="grid grid-cols-2 gap-3">
            <LevelRow label="Current Price" value={trade.current_price} />
            <LevelRow label="Entry Zone" value={`${trade.entry_zone_low ?? "—"} – ${trade.entry_zone_high ?? "—"}`} />
            <LevelRow label="Invalidation" value={trade.invalidation} className="text-loss" />
            <LevelRow label="R:R Ratio" value={trade.risk_reward_ratio ? `${trade.risk_reward_ratio.toFixed(1)}:1` : "—"} />
            <LevelRow label="Target 1" value={trade.target_1} className="text-profit" />
            <LevelRow label="Target 2" value={trade.target_2} className="text-profit" />
          </div>

          {/* Analysis */}
          {trade.why_now && <AnalysisBlock title="Why Now" content={trade.why_now} />}
          {trade.bull_case && <AnalysisBlock title="Bull Case" content={trade.bull_case} />}
          {trade.bear_case && <AnalysisBlock title="Bear Case" content={trade.bear_case} />}
          {trade.what_kills_it && <AnalysisBlock title="What Kills This Setup" content={trade.what_kills_it} />}
          {trade.catalyst_summary && <AnalysisBlock title="Catalyst" content={trade.catalyst_summary} />}

          {/* Disclaimer */}
          <p className="text-[10px] text-muted-foreground/50 leading-relaxed">
            This analysis reflects current conditions and may change. It does not constitute financial advice,
            does not guarantee any outcome, and should not be the sole basis for any trading decision.
            Always verify with your own research and consider your risk tolerance.
          </p>

          {/* Actions */}
          <div className="flex flex-wrap gap-2 pt-2">
            <Button variant="outline" size="sm" className="text-xs gap-1.5"><Eye className="w-3 h-3" /> Watchlist</Button>
            <Button variant="outline" size="sm" className="text-xs gap-1.5"><Bell className="w-3 h-3" /> Alert</Button>
            <Button variant="outline" size="sm" className="text-xs gap-1.5"><Briefcase className="w-3 h-3" /> Portfolio</Button>
            <Button variant="outline" size="sm" className="text-xs gap-1.5"><BookOpen className="w-3 h-3" /> Journal</Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function LevelRow({ label, value, className = "" }) {
  const display = typeof value === "number" ? `$${value.toLocaleString()}` : (value || "—");
  return (
    <div className="bg-secondary/50 rounded-lg px-3 py-2">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-mono font-semibold mt-0.5 ${className}`}>{display}</p>
    </div>
  );
}

function AnalysisBlock({ title, content }) {
  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground mb-1">{title}</p>
      <p className="text-sm text-foreground/90 leading-relaxed">{content}</p>
    </div>
  );
}