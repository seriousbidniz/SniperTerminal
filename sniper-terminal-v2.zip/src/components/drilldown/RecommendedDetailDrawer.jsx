// Re-export from the canonical drawer implementation
export { default } from "./RecommendedDrawer";