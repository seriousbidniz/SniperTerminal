import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Flame, ArrowUpRight, ArrowDownRight, AlertTriangle } from "lucide-react";

const moveStateColors = {
  early:    "text-profit bg-profit/10 border-profit/20",
  building: "text-primary bg-primary/10 border-primary/20",
  crowded:  "text-warning bg-warning/10 border-warning/20",
  exhausted:"text-loss bg-loss/10 border-loss/20",
};
const aiLabelColors = {
  tradable: "text-profit bg-profit/10 border-profit/20",
  caution:  "text-warning bg-warning/10 border-warning/20",
  avoid:    "text-loss bg-loss/10 border-loss/20",
};

function ScoreBar({ label, value, invert = false }) {
  if (value == null) return null;
  const pct = Math.min(Math.max(Math.round(value), 0), 100);
  const display = invert ? 100 - pct : pct;
  const color = display >= 70 ? "bg-profit" : display >= 45 ? "bg-warning" : "bg-loss";
  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] text-muted-foreground w-24 shrink-0">{label}</span>
      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-mono w-7 text-right text-foreground">{pct}</span>
    </div>
  );
}

function ExplainBlock({ icon: Icon, title, content, iconClass }) {
  if (!content) return null;
  return (
    <div className="rounded-lg border border-border px-3 py-2.5 space-y-1">
      <div className={`flex items-center gap-1.5 text-xs font-semibold ${iconClass}`}>
        <Icon className="w-3.5 h-3.5" />
        <span>{title}</span>
      </div>
      <p className="text-xs text-foreground/85 leading-relaxed">{content}</p>
    </div>
  );
}

export default function ViralDrawer({ signal, onClose }) {
  if (!signal) return null;

  return (
    <Sheet open={!!signal} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-viral/20">
        <SheetHeader className="pb-4 border-b border-viral/20">
          <div className="flex items-center gap-2.5 flex-wrap">
            <Flame className="w-5 h-5 text-viral" />
            <SheetTitle className="font-mono text-lg">{signal.asset || "Signal"}</SheetTitle>
            {signal.move_state && (
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase ${moveStateColors[signal.move_state] || ""}`}>
                {signal.move_state}
              </span>
            )}
            {signal.ai_label && (
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase ${aiLabelColors[signal.ai_label] || ""}`}>
                {signal.ai_label}
              </span>
            )}
          </div>
          {signal.timestamp && (
            <p className="text-[11px] text-muted-foreground">
              {new Date(signal.timestamp).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
            </p>
          )}
        </SheetHeader>

        <div className="mt-4 space-y-5">
          {/* Viral disclaimer */}
          <div className="flex items-start gap-2 bg-viral/5 border border-viral/15 rounded-lg px-3 py-2 text-[11px] text-viral/80">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>Virality measures market attention — not trade quality. This is not a trade recommendation.</span>
          </div>

          {/* Confidence note */}
          {signal.confidence_note && (
            <div className={`rounded-lg border px-3 py-2 text-xs leading-relaxed
              ${signal.ai_label === "tradable" ? "bg-profit/5 border-profit/20 text-profit/90"
                : signal.ai_label === "avoid" ? "bg-loss/5 border-loss/20 text-loss/90"
                : "bg-warning/5 border-warning/20 text-warning/90"}`}>
              {signal.confidence_note}
            </div>
          )}

          {/* Scores */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground">Signal Scores</p>
            <ScoreBar label="Viral Score" value={signal.viral_score} />
            <ScoreBar label="Attention" value={signal.attention_score} />
            <ScoreBar label="Volume Spike" value={signal.volume_spike_score} />
            <ScoreBar label="Sentiment" value={signal.sentiment_spike_score} />
            <ScoreBar label="Liquidity" value={signal.liquidity_quality_score} />
            <ScoreBar label="Crowding" value={signal.crowding_score} invert />
            <ScoreBar label="Exhaustion" value={signal.exhaustion_score} invert />
          </div>

          {/* Explainability */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground">Signal Explainability</p>
            <ExplainBlock
              icon={ArrowUpRight}
              title="What increased the viral score"
              content={signal.viral_boost_factors}
              iconClass="text-profit"
            />
            <ExplainBlock
              icon={ArrowDownRight}
              title="What reduced tradability"
              content={signal.viral_penalty_factors}
              iconClass="text-loss"
            />
          </div>

          {/* Summary */}
          {signal.summary && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-1">Move Summary</p>
              <p className="text-xs text-foreground/90 leading-relaxed">{signal.summary}</p>
            </div>
          )}

          <p className="text-[10px] text-muted-foreground/50 leading-relaxed">
            Viral signals reflect market attention, not fundamental or technical quality. Not financial advice.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}