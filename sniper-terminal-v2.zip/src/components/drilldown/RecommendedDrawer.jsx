import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, ShieldAlert, Clock, ExternalLink, Database, ChevronLeft } from "lucide-react";
import { RecommendedScenario } from "@/components/shared/HundredPoundScenario.jsx";
import { TradeReasonBlock } from "@/components/shared/TradeReasonIndicator";
import SignalDecisionOutput from "@/components/shared/SignalDecisionOutput";
import FailFastBlock from "@/components/shared/FailFastBlock";
import DecisionBadge from "@/components/shared/DecisionBadge";
import UrgencyTag from "@/components/shared/UrgencyTag";
import ConfidenceTier from "@/components/shared/ConfidenceTier";
import SignalCountdown from "@/components/shared/SignalCountdown";
import { useAssetMap } from "@/hooks/useAssetMap";
import { formatPrice } from "@/lib/format";
import MultiSignalAlignment from "@/components/shared/MultiSignalAlignment";
import SignalValidationPanel from "@/components/shared/SignalValidationPanel";
import ExternalTradeLinks from "@/components/shared/ExternalTradeLinks";
import { isStale, dataAge } from "@/lib/freshness";
import { Link } from "react-router-dom";

function Row({ label, value, className = "", marketType }) {
  const display = value == null ? "—" : typeof value === "number" ? formatPrice(value, marketType) : value;
  return (
    <div className="bg-secondary/40 rounded-lg px-3 py-2">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-mono font-semibold mt-0.5 ${className}`}>{display}</p>
    </div>
  );
}

function ScoreChip({ label, value, invert = false }) {
  if (value == null) return null;
  const s = invert ? 100 - value : value;
  const color = s >= 70 ? "text-profit bg-profit/10 border-profit/30"
    : s >= 45 ? "text-primary bg-primary/10 border-primary/30"
    : "text-loss bg-loss/10 border-loss/30";
  return (
    <div className="flex flex-col items-center gap-0.5">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded border ${color}`}>{Math.round(value)}</span>
    </div>
  );
}

function ExplainBlock({ icon: Icon, title, content, iconClass }) {
  if (!content) return null;
  return (
    <div className="rounded-lg border border-border px-3 py-2.5 space-y-1">
      <div className={`flex items-center gap-1.5 text-xs font-semibold ${iconClass}`}>
        <Icon className="w-3.5 h-3.5" />
        <span>{title}</span>
      </div>
      <p className="text-xs text-foreground/85 leading-relaxed">{content}</p>
    </div>
  );
}

export default function RecommendedDrawer({ signal, onClose }) {
  const assetMap = useAssetMap();
  if (!signal) return null;
  const asset = assetMap[signal.asset] || null;
  const mt = asset?.market_type || signal.market_type;
  const dir = signal.direction;
  const stale = isStale(signal.timestamp);
  const age = dataAge(signal.timestamp);

  // Use asset_symbol if enriched, else fall back to asset field
  const displaySymbol = signal.asset_symbol || signal.asset || "Signal";
  const displayName = signal.asset_name && signal.asset_name !== displaySymbol ? signal.asset_name : null;

  return (
    <Sheet open={!!signal} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-border">
        {/* ── Mobile back button ── */}
        <div className="md:hidden absolute top-4 left-4 z-20">
          <button
            onClick={onClose}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors select-none p-1"
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
        </div>

        <SheetHeader className="pb-4 border-b border-border">
          <div className="flex items-start gap-2.5 flex-wrap">
            {dir === "bullish"
              ? <TrendingUp className="w-5 h-5 text-profit mt-0.5 flex-shrink-0" />
              : <TrendingDown className="w-5 h-5 text-loss mt-0.5 flex-shrink-0" />}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <SheetTitle className="font-mono text-lg">{displaySymbol}</SheetTitle>
                {displayName && <span className="text-sm text-muted-foreground">{displayName}</span>}
              </div>
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                {signal.market_type && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase bg-secondary text-muted-foreground border-border">
                    {signal.market_type}
                  </span>
                )}
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border uppercase ${dir === "bullish" ? "text-profit bg-profit/10 border-profit/30" : "text-loss bg-loss/10 border-loss/30"}`}>
                  {dir}
                </span>
                {signal.setup_type && (
                  <span className="text-[10px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded uppercase">{signal.setup_type.replace(/_/g, " ")}</span>
                )}
                {stale && (
                  <span className="flex items-center gap-1 text-[10px] text-warning/80 bg-warning/10 border border-warning/25 px-1.5 py-0.5 rounded">
                    <Clock className="w-2.5 h-2.5" /> {age}
                  </span>
                )}
              </div>
            </div>
          </div>
          {signal.timestamp && (
            <p className="text-[11px] text-muted-foreground">
              {new Date(signal.timestamp).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
            </p>
          )}
        </SheetHeader>

        <div className="mt-4 space-y-5">
          {/* Dominant decision badge + urgency row */}
          <div className="flex items-center gap-2 flex-wrap">
            <DecisionBadge signal={signal} size="lg" />
            <UrgencyTag signal={signal} />
            <ConfidenceTier signal={signal} showLabel />
          </div>

          {/* Fail Fast — hard block if signal is invalid */}
          <FailFastBlock signal={signal}>
            {/* Decision Output — primary CTA */}
            <SignalDecisionOutput signal={signal} />

          {/* Live expiry + invalidation countdown */}
          <SignalCountdown signal={signal} asset={asset} variant="full" />

          {/* Multi-Signal Alignment */}
          <MultiSignalAlignment signal={signal} />

          {/* Scores */}
          <div className="flex justify-around">
            <ScoreChip label="Opportunity" value={signal.opportunity_score} />
            <ScoreChip label="Conviction" value={signal.conviction_score} />
            <ScoreChip label="Risk" value={signal.risk_score} invert />
          </div>

          {/* Confidence note */}
          {signal.confidence_note && (
            <div className="bg-primary/5 border border-primary/20 rounded-lg px-3 py-2 text-xs text-primary/90">
              {signal.confidence_note}
            </div>
          )}

          {/* Rule origin + evidence behind the score */}
          {(signal.pattern_origin || signal.calibration_source) && (
            <div className="rounded-lg border border-border px-3 py-2.5 space-y-1">
              {signal.pattern_origin && <p className="text-xs text-foreground/85"><span className="font-semibold">Setup rule:</span> {signal.pattern_origin}.</p>}
              <p className="text-[11px] text-muted-foreground">
                {signal.calibration_source && signal.calibration_source !== "uncalibrated" && signal.calibration_samples
                  ? <>Track record: {signal.calibrated_win_rate}% reached Target 1 first across {signal.calibration_samples} comparable signals ({signal.calibration_source}), expectancy {signal.expected_r}R. Past results don't guarantee future ones.</>
                  : <>Not enough resolved history for this setup yet, so the score assumes no edge.</>}
              </p>
            </div>
          )}

          {/* Why This Trade Exists */}
          <TradeReasonBlock signal={signal} />

          {/* Key Levels */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2">Key Levels</p>
            <div className="grid grid-cols-2 gap-2">
              <Row label="Entry Low" value={signal.entry_low} marketType={mt} />
              <Row label="Entry High" value={signal.entry_high} marketType={mt} />
              <Row label="Invalidation" value={signal.invalidation} marketType={mt} className="text-loss" />
              <Row label="Target 1" value={signal.target_1} marketType={mt} className="text-profit" />
              <Row label="Target 2" value={signal.target_2} marketType={mt} className="text-profit" />
            </div>
          </div>

          {/* £100 scenario */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2">Scenario Analysis</p>
            <RecommendedScenario signal={signal} />
          </div>

          {/* Explainability */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground">Score Explainability</p>
            <ExplainBlock
              icon={ArrowUpRight}
              title="What increased the score"
              content={signal.score_boost_factors}
              iconClass="text-profit"
            />
            <ExplainBlock
              icon={ArrowDownRight}
              title="What reduced the score"
              content={signal.score_penalty_factors}
              iconClass="text-loss"
            />
          </div>

          {/* Why Now / What Kills It */}
          {signal.why_now && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-1">Why Now</p>
              <p className="text-xs text-foreground/90 leading-relaxed">{signal.why_now}</p>
            </div>
          )}
          {signal.what_kills_it && (
            <ExplainBlock
              icon={ShieldAlert}
              title="What kills this setup"
              content={signal.what_kills_it}
              iconClass="text-warning"
            />
          )}

          {/* Signal Validation */}
          <SignalValidationPanel signal={signal} />

          {/* External Trade Links */}
          <ExternalTradeLinks signal={signal} asset={asset} />
          </FailFastBlock>

          {/* Navigate to */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2">Navigate To</p>
            <div className="flex flex-wrap gap-2">
              <Link
                to="/assets"
                onClick={onClose}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              >
                <Database className="w-3 h-3" /> Asset Universe
              </Link>
              <Link
                to="/recommended"
                onClick={onClose}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-primary/30 bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
              >
                <ExternalLink className="w-3 h-3" /> All Recommended Trades
              </Link>
            </div>
          </div>

          <p className="text-[10px] text-muted-foreground/50 leading-relaxed border-t border-border pt-3">
            Analytical output only. Not financial advice. Always conduct independent research.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}