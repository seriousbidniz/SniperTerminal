import React from "react";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Flame, ArrowUpRight, ArrowDownRight, AlertTriangle, ExternalLink, Database, ChevronLeft } from "lucide-react";
import { isStale, dataAge, staleDegradedNote } from "@/lib/freshness";
import StaleBanner from "@/components/shared/StaleBanner";
import SignalDisclaimer from "@/components/shared/SignalDisclaimer";
import { ViralScenario } from "@/components/shared/HundredPoundScenario.jsx";
import { TradeReasonBlock } from "@/components/shared/TradeReasonIndicator";
import SignalDecisionOutput from "@/components/shared/SignalDecisionOutput";
import FailFastBlock from "@/components/shared/FailFastBlock";
import DecisionBadge from "@/components/shared/DecisionBadge";
import UrgencyTag from "@/components/shared/UrgencyTag";
import ConfidenceTier from "@/components/shared/ConfidenceTier";
import SignalCountdown from "@/components/shared/SignalCountdown";
import { useAssetMap } from "@/hooks/useAssetMap";
import SignalValidationPanel from "@/components/shared/SignalValidationPanel";
import ExternalTradeLinks from "@/components/shared/ExternalTradeLinks";
import { Link } from "react-router-dom";

// ── Config ────────────────────────────────────────────────────────────────────
const moveStateConfig = {
  early:     { label: "Early",     classes: "text-profit bg-profit/10 border-profit/25" },
  building:  { label: "Building",  classes: "text-primary bg-primary/10 border-primary/25" },
  crowded:   { label: "Crowded",   classes: "text-warning bg-warning/10 border-warning/25" },
  exhausted: { label: "Exhausted", classes: "text-loss bg-loss/10 border-loss/25" },
};

const aiLabelConfig = {
  tradable: { color: "text-profit", bg: "bg-profit/5 border-profit/20",   label: "Tradable" },
  caution:  { color: "text-warning", bg: "bg-warning/5 border-warning/20", label: "Caution"  },
  avoid:    { color: "text-loss",    bg: "bg-loss/5 border-loss/20",       label: "Avoid"    },
};

// ── Score bar ─────────────────────────────────────────────────────────────────
function ScoreBar({ label, value, inverted = false }) {
  if (value == null) return null;
  const pct = Math.min(Math.max(Math.round(value), 0), 100);
  const display = inverted ? 100 - pct : pct;
  const color = display >= 70 ? "bg-profit" : display >= 45 ? "bg-primary" : "bg-loss";
  const textColor = display >= 70 ? "text-profit" : display >= 45 ? "text-primary" : "text-loss";
  return (
    <div className="flex items-center gap-3">
      <span className="text-[10px] text-muted-foreground/70 w-28 shrink-0 font-medium">{label}</span>
      <div className="flex-1 h-1 bg-secondary/60 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className={`text-xs font-mono font-bold w-7 text-right tabular-nums ${textColor}`}>{pct}</span>
    </div>
  );
}

// ── Explain block ─────────────────────────────────────────────────────────────
function ExplainBlock({ icon: Icon, label, text, color, bg }) {
  if (!text) return null;
  return (
    <div className={`rounded-xl border px-4 py-3 ${bg}`}>
      <div className={`flex items-center gap-2 text-xs font-semibold mb-2 ${color}`}>
        <Icon className="w-3.5 h-3.5" />
        <span>{label}</span>
      </div>
      <p className="text-xs text-foreground/85 leading-relaxed">{text}</p>
    </div>
  );
}

// ── Section heading ───────────────────────────────────────────────────────────
function SectionLabel({ children }) {
  return (
    <p className="text-[9px] font-bold text-muted-foreground/50 uppercase tracking-widest mb-2.5">
      {children}
    </p>
  );
}

// ── Main drawer ───────────────────────────────────────────────────────────────
export default function ViralDetailDrawer({ signal, onClose }) {
  const assetMap = useAssetMap();
  const asset = signal ? assetMap[signal.asset] || null : null;
  if (!signal) return null;

  const stale = isStale(signal.timestamp);
  const ageStr = dataAge(signal.timestamp);
  const displayedNote = stale
    ? staleDegradedNote(signal.confidence_note, ageStr)
    : signal.confidence_note;

  const stateCfg  = moveStateConfig[signal.move_state];
  const labelCfg  = aiLabelConfig[signal.ai_label];

  return (
    <Sheet open={!!signal} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-[480px] overflow-y-auto bg-card border-border p-0">

        {/* ── Mobile back button ── */}
        <div className="md:hidden absolute top-4 left-4 z-20">
          <button
            onClick={onClose}
            className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors select-none p-1"
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
        </div>

        {/* ── Drawer header ── */}
        <div className="px-6 pt-6 pb-5 border-b border-viral/15 bg-viral/[0.04]">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 rounded-xl bg-viral/15 flex items-center justify-center flex-shrink-0">
              <Flame className="w-4.5 h-4.5 text-viral" />
            </div>
            <div className="flex-1 min-w-0">
              <SheetTitle className="text-xl font-mono font-black tracking-tight text-foreground">
                {signal.asset_symbol || signal.asset || "Signal"}
              </SheetTitle>
              {signal.asset_name && signal.asset_name !== (signal.asset_symbol || signal.asset) && (
                <p className="text-xs text-muted-foreground/70 -mt-0.5">{signal.asset_name}</p>
              )}
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                {signal.market_type && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide bg-secondary text-muted-foreground border-border">
                    {signal.market_type}
                  </span>
                )}
                {stateCfg && (
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide ${stateCfg.classes}`}>
                    {stateCfg.label}
                  </span>
                )}
                {labelCfg && (
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide ${labelCfg.color} ${labelCfg.bg}`}>
                    {labelCfg.label}
                  </span>
                )}
              </div>
            </div>
            {signal.viral_score != null && (
              <div className="flex-shrink-0 text-center">
                <div className="text-[9px] font-semibold text-muted-foreground/50 uppercase tracking-widest mb-0.5">Viral</div>
                <div className="text-2xl font-mono font-black text-viral">{Math.round(signal.viral_score)}</div>
              </div>
            )}
          </div>
          {signal.timestamp && (
            <p className="text-[10px] text-muted-foreground/50 font-mono">
              Captured: {new Date(signal.timestamp).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
            </p>
          )}
        </div>

        {/* ── Body ── */}
        <div className="px-6 py-5 space-y-5">

          {stale && (
            <StaleBanner ageStr={ageStr} message="viral momentum may have shifted significantly since capture" />
          )}

          <SignalDisclaimer signalType="viral" />

          {/* Confidence note */}
          {displayedNote && (
            <div className={`rounded-xl border px-4 py-3 text-xs leading-relaxed ${
              stale
                ? "bg-warning/5 border-warning/20 text-warning/80"
                : labelCfg?.bg + " " + labelCfg?.color + "/90" || "bg-secondary/30 border-border text-foreground/80"
            }`}>
              {displayedNote}
            </div>
          )}

          {/* Score breakdown */}
          <div>
            <SectionLabel>Score Breakdown</SectionLabel>
            <div className="space-y-2.5 bg-secondary/10 border border-border/40 rounded-xl px-4 py-3">
              <ScoreBar label="Viral Score"    value={signal.viral_score} />
              <ScoreBar label="Attention"      value={signal.attention_score} />
              <ScoreBar label="Volume Spike"   value={signal.volume_spike_score} />
              <ScoreBar label="Sentiment"      value={signal.sentiment_spike_score} />
              <ScoreBar label="Liquidity"      value={signal.liquidity_quality_score} />
              {signal.crowding_score != null && <ScoreBar label="Crowding Risk"  value={signal.crowding_score}  inverted />}
              {signal.exhaustion_score != null && <ScoreBar label="Exhaustion Risk" value={signal.exhaustion_score} inverted />}
            </div>
          </div>

          {/* Explainability */}
          <div>
            <SectionLabel>Why This Score</SectionLabel>
            <div className="space-y-2">
              <ExplainBlock
                icon={ArrowUpRight}
                label="What increased the viral score"
                text={signal.viral_boost_factors}
                color="text-profit"
                bg="bg-profit/5 border-profit/15"
              />
              <ExplainBlock
                icon={ArrowDownRight}
                label="What reduced tradability"
                text={signal.viral_penalty_factors}
                color="text-loss"
                bg="bg-loss/5 border-loss/15"
              />
            </div>
          </div>

          {/* Data Quality Warning */}
          {signal.data_quality && signal.data_quality !== "live" && (
            <div className="flex items-start gap-2.5 bg-warning/5 border border-warning/25 rounded-xl px-4 py-3 text-[11px] text-warning/80 leading-relaxed">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold block mb-0.5">Data Quality Issue</span>
                {signal.data_quality === "full_fallback"
                  ? "This signal uses default fallback values — live market data is unavailable for this asset. Results may be unreliable."
                  : "This signal uses some default fallback values due to missing data inputs. Verify independently before trading."}
                {signal.data_confidence != null && (
                  <div className="mt-1 font-mono text-[10px]">Data confidence: {Math.round(signal.data_confidence)}%</div>
                )}
              </div>
            </div>
          )}

          {/* Raw Input Values + Debug Metadata */}
          {signal.raw_inputs && Object.keys(signal.raw_inputs).length > 0 && (
            <div>
              <SectionLabel>Source Data & Inputs</SectionLabel>
              <div className="bg-secondary/20 border border-border/40 rounded-xl px-4 py-3 space-y-1 text-[11px] font-mono">
                {[
                  { key: "change_1h", label: "1h Change (%)" },
                  { key: "change_4h", label: "4h Change (%)" },
                  { key: "volume_change_percent", label: "Vol Change (%)" },
                  { key: "attention_score_input", label: "Attention Score" },
                  { key: "sentiment_score_input", label: "Sentiment Score" },
                  { key: "liquidity_score", label: "Liquidity Score" },
                ].map(field => {
                  const val = signal.raw_inputs[field.key];
                  const isMissing = val == null;
                  return (
                    <div key={field.key} className="flex justify-between text-muted-foreground/80">
                      <span>{field.label}:</span>
                      <span className={isMissing ? "text-warning/70 italic" : "text-foreground font-semibold"}>
                        {isMissing ? "(missing)" : typeof val === "number" ? val.toFixed(2) : val}
                      </span>
                    </div>
                  );
                })}

                {/* Debug: Missing fields list */}
                {signal.raw_inputs.missing_fields && signal.raw_inputs.missing_fields.length > 0 && (
                  <div className="border-t border-border/30 pt-1 mt-1 text-[10px] text-warning">
                    <span className="font-bold">Missing from source:</span> {signal.raw_inputs.missing_fields.join(", ")}
                  </div>
                )}

                {signal.raw_inputs.snapshot_timestamp && (
                  <div className="border-t border-border/30 pt-1 mt-1 text-[10px] text-muted-foreground/60">
                    Snapshot fetched: {new Date(signal.raw_inputs.snapshot_timestamp).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Why This Trade Exists */}
          <div>
            <SectionLabel>Why This Trade Exists</SectionLabel>
            <TradeReasonBlock signal={signal} />
          </div>

          {/* Dominant decision badge row */}
          <div className="flex items-center gap-2 flex-wrap">
            <DecisionBadge signal={signal} size="lg" />
            <UrgencyTag signal={signal} />
            <ConfidenceTier signal={signal} showLabel />
          </div>

          {/* Fail Fast — hard block if signal is invalid */}
          <FailFastBlock signal={signal}>
            {/* Decision Output */}
            <div>
              <SectionLabel>Decision Output</SectionLabel>
              <SignalDecisionOutput signal={signal} />
            </div>

            {/* Time Expectation */}
            <SignalCountdown signal={signal} asset={asset} variant="full" />

            {/* Signal Validation */}
            <SignalValidationPanel signal={signal} />

            {/* External Trade Links */}
            <ExternalTradeLinks signal={signal} asset={asset} />
          </FailFastBlock>

          {/* Summary */}
          {signal.summary && (
            <div>
              <SectionLabel>Summary</SectionLabel>
              <p className="text-xs text-foreground/80 leading-relaxed bg-secondary/20 border border-border/40 rounded-xl px-4 py-3">
                {signal.summary}
              </p>
            </div>
          )}

          {/* £100 Scenario */}
          <div>
            <SectionLabel>Illustrative Move Example</SectionLabel>
            <ViralScenario signal={signal} />
          </div>

          {/* Navigate to */}
          <div>
            <SectionLabel>Navigate To</SectionLabel>
            <div className="flex flex-wrap gap-2">
              <Link
                to="/assets"
                onClick={onClose}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              >
                <Database className="w-3 h-3" /> Asset Universe
              </Link>
              <Link
                to="/viral"
                onClick={onClose}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-viral/30 bg-viral/10 hover:bg-viral/20 text-viral transition-colors"
              >
                <ExternalLink className="w-3 h-3" /> All Viral Trades
              </Link>
            </div>
          </div>


        </div>
      </SheetContent>
    </Sheet>
  );
}