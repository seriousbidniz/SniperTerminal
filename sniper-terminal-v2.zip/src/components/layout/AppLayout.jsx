import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import BottomNav from "./BottomNav";
import { useRealtimeSync } from "@/hooks/useRealtimeSync";

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  useRealtimeSync(); // server-pushed entity changes → instant UI refresh

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar — hidden on mobile */}
      <div className="hidden md:block">
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      </div>
      <div
        className="flex-1 min-h-screen flex flex-col transition-all duration-200"
        style={{ paddingLeft: collapsed ? "3.5rem" : "13rem" }}
        onClick={() => { if (!collapsed) setCollapsed(true); }}
      >
        <main
          className="flex-1 p-5 max-sm:p-3 overflow-auto"
          style={{
            paddingTop: "max(1.25rem, env(safe-area-inset-top))",
            paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 4rem)", // room for bottom nav on mobile
          }}
        >
          <Outlet />
        </main>
      </div>
      {/* Bottom nav — mobile only */}
      <BottomNav />
    </div>
  );
}