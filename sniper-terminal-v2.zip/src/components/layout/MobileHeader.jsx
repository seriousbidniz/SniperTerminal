import React from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

/**
 * Reusable mobile header with back button (visible on mobile only).
 * Shows a back button and title/icon for mobile users.
 */
export default function MobileHeader({ icon: Icon, title, subtitle }) {
  const navigate = useNavigate();

  return (
    <div className="flex items-start justify-between gap-3 md:hidden mb-4">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors select-none p-1 -ml-1"
      >
        <ChevronLeft className="w-4 h-4" />
        <span>Back</span>
      </button>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          {Icon && <Icon className="w-5 h-5 text-primary flex-shrink-0" />}
          <h1 className="text-lg font-bold tracking-tight">{title}</h1>
        </div>
        {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
      </div>
    </div>
  );
}