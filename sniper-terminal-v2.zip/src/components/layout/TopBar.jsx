import React from "react";
import { Bell, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function TopBar() {
  return (
    <header className="h-14 border-b border-border flex items-center justify-between px-6 max-sm:px-3 bg-card/50 backdrop-blur-sm sticky top-0 z-30">
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <Search className="w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search assets, signals, alerts..."
          className="h-8 bg-secondary/50 border-none text-sm placeholder:text-muted-foreground/50"
        />
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2 mr-4">
          <div className="w-2 h-2 rounded-full bg-profit animate-pulse-glow" />
          <span className="text-xs text-muted-foreground font-mono">LIVE</span>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <Bell className="w-4 h-4" />
        </Button>
      </div>
    </header>
  );
}