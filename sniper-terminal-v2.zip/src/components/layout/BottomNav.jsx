import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, Crosshair, Flame, Briefcase, Bell } from "lucide-react";

const navItems = [
  { path: "/",            icon: LayoutDashboard, label: "Dashboard" },
  { path: "/recommended", icon: Crosshair,        label: "Signals" },
  { path: "/viral",       icon: Flame,            label: "Viral" },
  { path: "/portfolio",   icon: Briefcase,        label: "Portfolio" },
  { path: "/alerts",      icon: Bell,             label: "Alerts" },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const [lastTab, setLastTab] = useState(null);

  const currentTab = navItems.find(item => 
    location.pathname === item.path || 
    (item.path !== "/" && location.pathname.startsWith(item.path))
  );

  const handleNavClick = (item) => {
    if (lastTab === item.path && location.pathname !== item.path) {
      // Tab is already active and we're on a sub-route — reset to root
      navigate(item.path);
    }
    setLastTab(item.path);
  };

  useEffect(() => {
    if (currentTab && lastTab !== currentTab.path) {
      setLastTab(currentTab.path);
    }
  }, [currentTab, lastTab]);

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t border-border bg-sidebar/90 backdrop-blur-md"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      {navItems.map((item) => {
        const isActive = location.pathname === item.path ||
          (item.path !== "/" && location.pathname.startsWith(item.path));
        return (
          <Link
            key={item.path}
            to={item.path}
            onClick={() => handleNavClick(item)}
            className={`flex flex-col items-center gap-0.5 px-3 py-2 min-w-0 flex-1 transition-colors select-none ${
              isActive ? "text-primary" : "text-muted-foreground"
            }`}
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            <span className="text-[9px] font-semibold uppercase tracking-wider truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}