import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Crosshair, Flame, Briefcase, Bell,
  Eye, Settings, ChevronLeft, ChevronRight, Zap, FileText, Database, Gauge
} from "lucide-react";

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/recommended", icon: Crosshair, label: "Recommended Trades" },
  { path: "/viral", icon: Flame, label: "Viral Trades" },
  { path: "/portfolio", icon: Briefcase, label: "Portfolio" },
  { path: "/alerts", icon: Bell, label: "Alerts" },
  { path: "/performance", icon: Gauge, label: "Performance" },
  { path: "/watchlists", icon: Eye, label: "Watchlists" },
  { path: "/assets", icon: Database, label: "Asset Universe" },
  { path: "/settings", icon: Settings, label: "Settings" },
  { path: "/documentation", icon: FileText, label: "Documentation" },
];

export default function Sidebar({ collapsed, setCollapsed }) {
  const location = useLocation();

  return (
    <aside className={`fixed left-0 top-0 h-full z-40 flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-200 ${collapsed ? "w-14" : "w-52"}`}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-3 h-13 border-b border-sidebar-border py-3.5">
        <div className="w-7 h-7 rounded bg-primary/20 flex items-center justify-center flex-shrink-0">
          <Zap className="w-3.5 h-3.5 text-primary" />
        </div>
        {!collapsed && (
          <div>
            <div className="text-[13px] font-semibold text-foreground tracking-tight leading-none">Sniper Terminal</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">Market Intelligence</div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path ||
            (item.path !== "/" && location.pathname.startsWith(item.path));
          return (
            <Link
              key={item.path}
              to={item.path}
              title={collapsed ? item.label : undefined}
              className={`flex items-center gap-3 px-2.5 py-2 rounded-md text-sm transition-all duration-100 group
                ${isActive
                  ? "bg-sidebar-accent text-primary font-medium"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`}
            >
              <item.icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} />
              {!collapsed && <span className="truncate text-[13px]">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Collapse Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex items-center justify-center h-9 border-t border-sidebar-border text-muted-foreground hover:text-foreground transition-colors text-xs"
      >
        {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
      </button>
    </aside>
  );
}