import React, { useState, useEffect } from "react";
import { User, Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUserProfile } from "@/hooks/useUserProfile";

const RISK_OPTIONS = [
  { value: "low",    label: "Low",    color: "text-profit border-profit/40 bg-profit/10" },
  { value: "medium", label: "Medium", color: "text-warning border-warning/40 bg-warning/10" },
  { value: "high",   label: "High",   color: "text-loss border-loss/40 bg-loss/10" },
];

const TIMELINE_OPTIONS = [
  { value: "4_weeks",   label: "4 Weeks" },
  { value: "3_months",  label: "3 Months" },
  { value: "6_months",  label: "6 Months" },
  { value: "1_year",    label: "1 Year" },
  { value: "long_term", label: "Long Term" },
];

export default function ProfileCard() {
  const { profile, isLoading, save, isSaving } = useUserProfile();
  const [form, setForm] = useState({
    alias: "",
    risk_appetite: "medium",
    invest_amount: "",
    goal_amount: "",
    timeline: "3_months",
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setForm({
        alias:         profile.alias        ?? "",
        risk_appetite: profile.risk_appetite ?? "medium",
        invest_amount: profile.invest_amount != null ? String(profile.invest_amount) : "",
        goal_amount:   profile.goal_amount   != null ? String(profile.goal_amount)   : "",
        timeline:      profile.timeline      ?? "3_months",
      });
    }
  }, [profile]);

  const handleSave = () => {
    save({
      alias:         form.alias || null,
      risk_appetite: form.risk_appetite,
      invest_amount: form.invest_amount !== "" ? parseFloat(form.invest_amount) : null,
      goal_amount:   form.goal_amount   !== "" ? parseFloat(form.goal_amount)   : null,
      timeline:      form.timeline,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  if (isLoading) return null;

  return (
    <Card className="bg-card border-primary/30">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2 text-primary">
          <User className="w-4 h-4" /> Trader Profile
        </CardTitle>
        <CardDescription className="text-xs">
          Anonymous profile used to personalise alerts and projections. No personal data is stored.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">

        {/* Alias */}
        <div className="space-y-1">
          <Label className="text-xs">Alias Name</Label>
          <Input
            className="h-8 text-xs bg-secondary/30 border-border"
            placeholder="e.g. SniperX, MoonTrader…"
            value={form.alias}
            onChange={e => setForm(f => ({ ...f, alias: e.target.value }))}
          />
          <p className="text-[10px] text-muted-foreground">Your alias — no real name required.</p>
        </div>

        {/* Risk Appetite */}
        <div className="space-y-1.5">
          <Label className="text-xs">Risk Appetite</Label>
          <div className="flex gap-2">
            {RISK_OPTIONS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setForm(f => ({ ...f, risk_appetite: opt.value }))}
                className={`flex-1 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                  form.risk_appetite === opt.value
                    ? opt.color
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Amounts */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Amount to Invest (£)</Label>
            <Input
              className="h-8 text-xs bg-secondary/30 border-border"
              type="number"
              min={0}
              placeholder="e.g. 500"
              value={form.invest_amount}
              onChange={e => setForm(f => ({ ...f, invest_amount: e.target.value }))}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Monetary Goal (£)</Label>
            <Input
              className="h-8 text-xs bg-secondary/30 border-border"
              type="number"
              min={0}
              placeholder="e.g. 1000"
              value={form.goal_amount}
              onChange={e => setForm(f => ({ ...f, goal_amount: e.target.value }))}
            />
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-1.5">
          <Label className="text-xs">Timeline</Label>
          <div className="flex flex-wrap gap-2">
            {TIMELINE_OPTIONS.map(opt => (
              <button
                key={opt.value}
                onClick={() => setForm(f => ({ ...f, timeline: opt.value }))}
                className={`px-3 py-1 rounded-lg border text-xs font-medium transition-colors ${
                  form.timeline === opt.value
                    ? "bg-primary/15 border-primary/50 text-primary"
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <Button
          size="sm"
          className="text-xs gap-1.5 w-full"
          onClick={handleSave}
          disabled={isSaving}
        >
          <Save className="w-3.5 h-3.5" />
          {saved ? "Saved ✓" : isSaving ? "Saving…" : "Save Profile"}
        </Button>
      </CardContent>
    </Card>
  );
}