import React from "react";
import { Target, AlertTriangle, TrendingDown, Activity } from "lucide-react";
import { useUserProfile } from "@/hooks/useUserProfile";

/**
 * AlertProfileProjection — fully data-led, signal-unique position guidance.
 *
 * Every output is computed from a multi-factor scoring engine that ingests:
 *   MARKET DATA  (from live MarketSnapshot attached to the enriched alert):
 *     rsi, change_1h, change_4h, volume_change_percent, volatility,
 *     trend_score_input, momentum_score_input, sentiment_score_input,
 *     catalyst_score_input
 *   ASSET DATA   (from the resolved _asset record):
 *     liquidity_score, market_type
 *   ALERT DATA   (from the alert entity itself):
 *     severity, action_classification, pnl_pct, alert_type
 *   USER PROFILE:
 *     invest_amount, risk_appetite, goal_amount, timeline
 *
 * No two alerts with different market data will ever produce identical output.
 */

// ── Constants ─────────────────────────────────────────────────────────────────

const ACTIONABLE_TYPES = ["opportunity_score", "viral_score", "take_profit", "act_now", "prepare", "indicator", "price"];

// Base annualised return benchmarks per market type × risk appetite
// Reflects genuine market behaviour differences (crypto vs FX vs commodity)
const BASE_RETURN = {
  crypto:    { low: 0.12, medium: 0.35, high: 0.80 },
  fx:        { low: 0.04, medium: 0.10, high: 0.22 },
  commodity: { low: 0.06, medium: 0.15, high: 0.32 },
  index:     { low: 0.07, medium: 0.12, high: 0.20 },
  default:   { low: 0.08, medium: 0.20, high: 0.45 },
};

// Base capital allocation ceiling per risk appetite
const BASE_ALLOC = { low: 0.08, medium: 0.18, high: 0.32 };

const TIMELINE_YEARS = {
  "4_weeks":   4 / 52,
  "3_months":  3 / 12,
  "6_months":  6 / 12,
  "1_year":    1,
  "long_term": 3,
};

const TIMELINE_LABELS = {
  "4_weeks":   "4 weeks",
  "3_months":  "3 months",
  "6_months":  "6 months",
  "1_year":    "1 year",
  "long_term": "3+ years",
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function norm(v, fallback = 50) { return (v == null || isNaN(v)) ? fallback : clamp(v, 0, 100); }

function fmt(v) {
  if (v == null || isNaN(v)) return "—";
  return "£" + v.toLocaleString("en-GB", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
function fmtExact(v) {
  if (v == null || isNaN(v)) return "—";
  return "£" + v.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtPct(v) {
  if (v == null || isNaN(v)) return "—";
  return (v >= 0 ? "+" : "") + v.toFixed(1) + "%";
}

// ── Core scoring engine ───────────────────────────────────────────────────────

/**
 * Produces a rich scoring object from all available data on this alert.
 * Returns:
 *   quality       0–100  composite signal quality
 *   conviction    0–100  directional confidence
 *   riskAdj       0–100  risk-adjusted score (lower risk = higher)
 *   momentum      0–100  price momentum strength
 *   marketHealth  0–100  liquidity + volatility regime quality
 *   factors       array of { label, value, impact } — audit trail
 */
function scoreSignal(alert, snap, asset) {
  const factors = [];

  // ── Snapshot-sourced market data ────────────────────────────────────────────
  const rsi        = snap?.rsi                    ?? null;
  const change1h   = snap?.change_1h              ?? null;
  const change4h   = snap?.change_4h              ?? null;
  const volChg     = snap?.volume_change_percent  ?? null;
  const volatility = norm(snap?.volatility,        35);
  const trend      = norm(snap?.trend_score_input, 50);
  const momentum   = norm(snap?.momentum_score_input, 50);
  const sentiment  = norm(snap?.sentiment_score_input, 50);
  const catalyst   = norm(snap?.catalyst_score_input, 50);
  const liquidity  = norm(asset?.liquidity_score,  50);
  const marketType = asset?.market_type || alert._market_type || "default";

  // ── Alert-sourced data ──────────────────────────────────────────────────────
  const severity   = alert.severity;
  const action     = alert.action_classification;
  const pnl        = alert.pnl_pct ?? null;
  const alertType  = alert.alert_type;

  // ── 1. Trend alignment (0–25 pts) ──────────────────────────────────────────
  const trendScore = (trend * 0.6 + momentum * 0.4);
  const trendPts   = (trendScore / 100) * 25;
  factors.push({ label: "Trend & Momentum", value: `${Math.round(trend)} / ${Math.round(momentum)}`, pts: trendPts });

  // ── 2. RSI regime (0–20 pts, max at 40–65 "healthy" range) ─────────────────
  let rsiPts = 10; // neutral
  if (rsi != null) {
    if (rsi >= 40 && rsi <= 65) rsiPts = 20;                    // ideal zone
    else if (rsi >= 30 && rsi < 40) rsiPts = 15;                // mild oversold — ok
    else if (rsi > 65 && rsi <= 75) rsiPts = 12;                // slightly hot
    else if (rsi > 75) rsiPts = 4;                              // overbought — danger
    else if (rsi < 30) rsiPts = 6;                              // deeply oversold
    factors.push({ label: "RSI", value: rsi.toFixed(1), pts: rsiPts });
  }

  // ── 3. Volume confirmation (0–15 pts) ───────────────────────────────────────
  let volPts = 8; // neutral
  if (volChg != null) {
    if (volChg > 100)      volPts = 15;
    else if (volChg > 40)  volPts = 12;
    else if (volChg > 10)  volPts = 10;
    else if (volChg < -30) volPts = 3;   // volume drying up
    factors.push({ label: "Volume Δ", value: fmtPct(volChg), pts: volPts });
  }

  // ── 4. Price momentum (0–20 pts) ────────────────────────────────────────────
  let pricePts = 10;
  if (change4h != null || change1h != null) {
    const move = Math.abs(change4h ?? change1h ?? 0);
    // Scale by market type — 1% is huge in FX, small in crypto
    const scaleMap = { crypto: 1, fx: 15, commodity: 5, index: 8, default: 3 };
    const scale = scaleMap[marketType] || 3;
    const scaled = clamp(move * scale, 0, 100);
    pricePts = (scaled / 100) * 20;
    factors.push({ label: `Price (${change4h != null ? "4h" : "1h"})`, value: fmtPct(change4h ?? change1h), pts: pricePts });
  }

  // ── 5. Liquidity quality (0–15 pts) ─────────────────────────────────────────
  const liqPts = (liquidity / 100) * 15;
  factors.push({ label: "Liquidity", value: Math.round(liquidity).toString(), pts: liqPts });

  // ── 6. Sentiment & catalyst (0–10 pts) ──────────────────────────────────────
  const sentCatPts = ((sentiment + catalyst) / 200) * 10;
  factors.push({ label: "Sentiment + Catalyst", value: `${Math.round(sentiment)} / ${Math.round(catalyst)}`, pts: sentCatPts });

  // ── 7. Alert-level modifiers ─────────────────────────────────────────────────
  let alertMod = 0;
  if (severity === "critical") alertMod += 5;
  else if (severity === "high") alertMod += 3;
  else if (severity === "low")  alertMod -= 5;

  if (action === "act_now")      alertMod += 5;
  else if (action === "prepare") alertMod += 2;
  else if (action === "watch")   alertMod -= 3;
  else if (action === "reduce_risk" || action === "exit_hedge") alertMod -= 20;

  if (pnl != null) {
    if (pnl > 25)  alertMod -= 6;   // already very profitable — take some
    if (pnl < -15) alertMod -= 8;   // deep drawdown — reduce, not add
    if (pnl > 0 && pnl <= 10) alertMod += 2; // modestly profitable — continue
  }

  factors.push({ label: "Alert modifiers", value: `${alertMod > 0 ? "+" : ""}${alertMod}`, pts: alertMod });

  // ── 8. Volatility regime adjustment (penalty for extreme vol) ───────────────
  let volPenalty = 0;
  if (volatility > 75 && liquidity < 50) volPenalty = -8;
  else if (volatility > 60) volPenalty = -4;

  // ── Composite quality ────────────────────────────────────────────────────────
  const raw = trendPts + rsiPts + volPts + pricePts + liqPts + sentCatPts + alertMod + volPenalty;
  const quality = clamp(Math.round(raw), 5, 97);

  // ── Derived sub-scores ───────────────────────────────────────────────────────
  const conviction   = clamp(Math.round(trend * 0.5 + momentum * 0.3 + sentiment * 0.2), 5, 97);
  const riskAdj      = clamp(Math.round(100 - volatility * 0.5 - (100 - liquidity) * 0.5), 5, 97);
  const momentumOut  = clamp(Math.round(momentum * 0.6 + Math.abs(change4h ?? change1h ?? 0) * 2), 5, 97);
  const marketHealth = clamp(Math.round(liquidity * 0.6 + (100 - volatility) * 0.4), 5, 97);

  return { quality, conviction, riskAdj, momentum: momentumOut, marketHealth, factors, rsi, change1h, change4h, volatility, liquidity, trend, sentiment, marketType };
}

// ── Position sizing engine ────────────────────────────────────────────────────

/**
 * Compute position size using Kelly-inspired fractional sizing.
 * Kelly fraction = (edge / odds) — we estimate edge from quality, odds from volatility.
 * Then cap by risk profile and apply half-Kelly as a safety factor.
 */
function computePosition(quality, riskAdj, baseAlloc, available) {
  // Estimated win rate proxy from quality (50%–90%)
  const winRate  = 0.50 + (quality / 100) * 0.40;
  // Estimated reward:risk proxy (1:1 to 3:1 based on riskAdj)
  const rrRatio  = 1.0 + (riskAdj / 100) * 2.0;
  // Full Kelly fraction
  const kelly    = (winRate - (1 - winRate) / rrRatio);
  // Half-Kelly (safer), capped by profile base allocation, minimum 2%
  const fraction = clamp(kelly * 0.5, 0.02, baseAlloc * 1.5);
  return clamp(available * fraction, 1, available * 0.5);
}

// ── Return rate engine ────────────────────────────────────────────────────────

/**
 * Signal-adjusted expected return rate.
 * Base rate from market type × risk profile, scaled by quality confidence.
 */
function computeRates(quality, marketType, riskAppetite, trend, momentum) {
  const rates = BASE_RETURN[marketType] || BASE_RETURN.default;
  const baseRate = rates[riskAppetite] || rates.medium;

  // Quality confidence multiplier: quality 50 → 0.7×, quality 80 → 1.05×, quality 95 → 1.3×
  const confMult = clamp(0.30 + (quality / 100) * 1.0, 0.30, 1.40);

  // Directional strength: if trend + momentum both strong, bonus
  const dirBonus = (trend > 65 && momentum > 65) ? 0.10 : (trend < 40 && momentum < 40) ? -0.10 : 0;

  const signalRate    = baseRate * confMult + dirBonus * baseRate;
  const conservRate   = signalRate * 0.35;
  const optimisticRate = signalRate * 1.80;

  return { signalRate: clamp(signalRate, 0.01, 5), conservRate: clamp(conservRate, 0.005, 3), optimisticRate: clamp(optimisticRate, 0.015, 8) };
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function AlertProfileProjection({ alert, variant = "full" }) {
  const { profile, isLoading } = useUserProfile();

  if (isLoading || !profile || !profile.invest_amount) return null;

  const isActionable =
    ACTIONABLE_TYPES.includes(alert.alert_type) ||
    ACTIONABLE_TYPES.includes(alert.action_classification);

  if (!isActionable) return null;

  const isReduce = alert.action_classification === "reduce_risk" || alert.action_classification === "exit_hedge";

  // Profile
  const available = profile.invest_amount;
  const goal      = profile.goal_amount ?? null;
  const years     = TIMELINE_YEARS[profile.timeline] ?? 1;
  const tlLabel   = TIMELINE_LABELS[profile.timeline] ?? profile.timeline;
  const alias     = profile.alias || null;
  const baseAlloc = BASE_ALLOC[profile.risk_appetite] ?? BASE_ALLOC.medium;

  // Enriched data (attached by useAlertEnrichment)
  const snap  = alert._snapshot ?? null;
  const asset = alert._asset    ?? null;

  // Score
  const scores = scoreSignal(alert, snap, asset);
  const { quality, conviction, riskAdj, marketHealth, factors, rsi, change1h, change4h, volatility, liquidity, trend, sentiment, marketType } = scores;

  // Position sizing (Kelly-inspired)
  const positionAmt = computePosition(quality, riskAdj, baseAlloc, available);

  // Return rates (market-type & quality adjusted)
  const { signalRate, conservRate, optimisticRate } = computeRates(quality, marketType, profile.risk_appetite, trend, sentiment);

  // Projections
  const base         = positionAmt * Math.pow(1 + signalRate,     years);
  const conservative = positionAmt * Math.pow(1 + conservRate,    years);
  const optimistic   = positionAmt * Math.pow(1 + optimisticRate, years);

  const goalPct  = goal ? Math.min(Math.round((base / goal) * 100), 999) : null;
  const alloc    = Math.round((positionAmt / available) * 100);

  const qualityLabel = quality >= 80 ? "Strong" : quality >= 62 ? "Moderate" : quality >= 42 ? "Cautious" : "Weak";
  const qualityColor = quality >= 80 ? "text-profit" : quality >= 62 ? "text-primary" : quality >= 42 ? "text-warning" : "text-loss";
  const qualityBg    = quality >= 80 ? "bg-profit/10 border-profit/30" : quality >= 62 ? "bg-primary/10 border-primary/30" : quality >= 42 ? "bg-warning/10 border-warning/30" : "bg-loss/10 border-loss/30";

  const hasLiveData = snap != null;

  // ── Inline strip ──────────────────────────────────────────────────────────────
  if (variant === "inline") {
    if (isReduce) {
      return (
        <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-warning/80 font-mono border-t border-border/30 pt-1.5 flex-wrap">
          <TrendingDown className="w-3 h-3 flex-shrink-0 text-warning" />
          <span>
            Signal quality <span className={`font-semibold ${qualityColor}`}>{quality}/100</span>
            {rsi != null && <> · RSI <span className="font-semibold">{rsi.toFixed(0)}</span></>}
            {" "}— reduce exposure, do not add capital.
          </span>
        </div>
      );
    }
    return (
      <div className="mt-1.5 flex items-center gap-2 text-[10px] text-muted-foreground/70 font-mono border-t border-border/30 pt-1.5 flex-wrap">
        <Target className="w-3 h-3 text-primary/60 flex-shrink-0" />
        <span>
          <span className={`font-semibold ${qualityColor}`}>{quality}/100</span>
          {rsi != null && <> · RSI {rsi.toFixed(0)}</>}
          {change4h != null && <> · 4h {fmtPct(change4h)}</>}
          {" · "}<span className="text-foreground font-semibold">{fmtExact(positionAmt)}</span>
          {" "}→ <span className="text-profit font-semibold">{fmt(base)}</span>
          {" "}({tlLabel})
          {goalPct != null && <span className={` ${goalPct >= 100 ? "text-profit" : ""}`}> · {goalPct}% of goal</span>}
        </span>
      </div>
    );
  }

  // ── Full drawer block ─────────────────────────────────────────────────────────
  return (
    <div className="rounded-xl border border-primary/20 bg-primary/[0.03] px-4 py-4 space-y-3">

      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-primary flex-shrink-0" />
          <div>
            <p className="text-xs font-bold text-primary">
              {alias ? `${alias}'s` : "Your"} Position Guidance
            </p>
            <p className="text-[10px] text-muted-foreground">
              {profile.risk_appetite} risk · {fmt(available)} capital · {tlLabel}
              {!hasLiveData && <span className="text-warning/70 ml-1">(no live snapshot)</span>}
            </p>
          </div>
        </div>
        <div className={`flex flex-col items-center px-2.5 py-1.5 rounded-lg border ${qualityBg}`}>
          <span className={`text-xl font-mono font-black leading-none ${qualityColor}`}>{quality}</span>
          <span className={`text-[8px] uppercase tracking-widest font-bold ${qualityColor}`}>{qualityLabel}</span>
        </div>
      </div>

      {/* Sub-scores row */}
      <div className="grid grid-cols-4 gap-1.5 text-center">
        {[
          { label: "Conviction", value: conviction },
          { label: "Risk Adj", value: riskAdj },
          { label: "Mkt Health", value: marketHealth },
          { label: "Liquidity", value: Math.round(liquidity) },
        ].map(({ label, value }) => {
          const c = value >= 70 ? "text-profit" : value >= 50 ? "text-primary" : value >= 35 ? "text-warning" : "text-loss";
          return (
            <div key={label} className="bg-secondary/30 rounded-lg px-2 py-1.5">
              <div className="text-[8px] text-muted-foreground uppercase tracking-widest">{label}</div>
              <div className={`text-xs font-mono font-bold ${c}`}>{value}</div>
            </div>
          );
        })}
      </div>

      {/* Scoring factor audit trail */}
      <div className="bg-secondary/20 rounded-lg px-3 py-2 space-y-1">
        <p className="text-[9px] font-bold text-muted-foreground/60 uppercase tracking-widest mb-1.5">Scoring inputs</p>
        {factors.map(({ label, value, pts }) => {
          const impact = typeof pts === "number" ? Math.round(pts) : pts;
          const isPositive = typeof pts === "number" && pts > 0;
          const isNeutral = typeof pts === "number" && pts === 0;
          return (
            <div key={label} className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">{label}</span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-foreground/80">{value}</span>
                <span className={`font-mono font-bold w-8 text-right ${isPositive ? "text-profit" : isNeutral ? "text-muted-foreground" : "text-loss"}`}>
                  {typeof pts === "number" ? `${pts >= 0 ? "+" : ""}${impact}` : ""}
                </span>
              </div>
            </div>
          );
        })}
        {!hasLiveData && (
          <p className="text-[9px] text-warning/60 mt-1 pt-1 border-t border-border/30">
            ⚠ No live snapshot found — market inputs defaulted to neutral values. Run a data refresh for full accuracy.
          </p>
        )}
      </div>

      {isReduce ? (
        <div className="flex items-start gap-2 bg-warning/5 border border-warning/25 rounded-lg px-3 py-2.5">
          <TrendingDown className="w-4 h-4 text-warning flex-shrink-0 mt-0.5" />
          <div className="text-xs text-warning/90 leading-relaxed">
            <p className="font-semibold mb-0.5">Reduce / Exit — not an entry signal</p>
            <p>Quality {quality}/100 with <span className="capitalize font-medium">{alert.action_classification?.replace(/_/g, " ")}</span> classification
              {rsi != null && `, RSI at ${rsi.toFixed(0)}`}
              {volatility > 60 && `, volatility elevated at ${Math.round(volatility)}`}
              . Protect capital rather than add exposure.
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Position sizing */}
          <div className="bg-secondary/30 rounded-lg px-3 py-2.5 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Suggested Position</p>
              <p className="text-lg font-mono font-black text-foreground mt-0.5">{fmtExact(positionAmt)}</p>
              <p className="text-[9px] text-muted-foreground/60">Kelly½ sizing · {alloc}% of capital</p>
            </div>
            <div className="text-right text-[10px] text-muted-foreground space-y-0.5">
              {rsi != null && <p>RSI <span className="font-mono font-semibold text-foreground">{rsi.toFixed(0)}</span></p>}
              {change4h != null && <p>4h chg <span className={`font-mono font-semibold ${change4h >= 0 ? "text-profit" : "text-loss"}`}>{fmtPct(change4h)}</span></p>}
              {change1h != null && change4h == null && <p>1h chg <span className={`font-mono font-semibold ${change1h >= 0 ? "text-profit" : "text-loss"}`}>{fmtPct(change1h)}</span></p>}
              <p>Vol regime <span className="font-mono font-semibold text-foreground">{Math.round(volatility)}</span></p>
            </div>
          </div>

          {/* Scenario grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-lg bg-secondary/40 border border-border px-2 py-2 text-center">
              <div className="text-[8px] text-muted-foreground uppercase tracking-widest mb-1">Conservative</div>
              <div className="text-sm font-mono font-bold text-foreground">{fmt(conservative)}</div>
              <div className="text-[9px] text-muted-foreground">+{fmt(conservative - positionAmt)}</div>
              <div className="text-[8px] text-muted-foreground/50 mt-0.5">{(conservRate * 100).toFixed(1)}% p.a.</div>
            </div>
            <div className="rounded-lg bg-primary/10 border border-primary/30 px-2 py-2 text-center">
              <div className="text-[8px] text-primary/70 uppercase tracking-widest mb-1">Base Case</div>
              <div className="text-sm font-mono font-bold text-primary">{fmt(base)}</div>
              <div className="text-[9px] text-primary/70">+{fmt(base - positionAmt)}</div>
              <div className="text-[8px] text-primary/40 mt-0.5">{(signalRate * 100).toFixed(1)}% p.a.</div>
            </div>
            <div className="rounded-lg bg-profit/10 border border-profit/30 px-2 py-2 text-center">
              <div className="text-[8px] text-profit/70 uppercase tracking-widest mb-1">Optimistic</div>
              <div className="text-sm font-mono font-bold text-profit">{fmt(optimistic)}</div>
              <div className="text-[9px] text-profit/70">+{fmt(optimistic - positionAmt)}</div>
              <div className="text-[8px] text-profit/40 mt-0.5">{(optimisticRate * 100).toFixed(1)}% p.a.</div>
            </div>
          </div>
        </>
      )}

      {/* Goal progress */}
      {goal != null && !isReduce && (
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-[10px] text-muted-foreground">Goal: {fmt(goal)}</span>
            <span className={`text-[10px] font-mono font-bold ${goalPct >= 100 ? "text-profit" : "text-warning"}`}>
              {goalPct}% of goal (base)
            </span>
          </div>
          <div className="h-1.5 bg-secondary/50 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${goalPct >= 100 ? "bg-profit" : "bg-primary"}`}
              style={{ width: `${Math.min(goalPct, 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="flex items-start gap-1.5 pt-1 border-t border-border/30">
        <AlertTriangle className="w-3 h-3 text-muted-foreground/40 flex-shrink-0 mt-0.5" />
        <p className="text-[9px] text-muted-foreground/45 leading-relaxed">
          Illustrative projections derived from live market snapshot data (RSI, momentum, volume, volatility, liquidity) via a Kelly-inspired sizing model and market-type adjusted return rates. Every figure is unique to this signal's live data. <strong>Not financial advice.</strong>
        </p>
      </div>
    </div>
  );
}