import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Bell, AlertTriangle, Clock, ShieldAlert, Zap, Eye, LogOut, Target, Flame, TrendingDown, TrendingUp, ExternalLink, Database } from "lucide-react";
import { dataAge, isStale } from "@/lib/freshness";
import { Link } from "react-router-dom";
import AlertProfileProjection from "./AlertProfileProjection";

const SEVERITY_COLORS = {
  critical: "text-loss bg-loss/10 border-loss/30",
  high:     "text-warning bg-warning/10 border-warning/30",
  medium:   "text-primary bg-primary/10 border-primary/30",
  low:      "text-muted-foreground bg-secondary border-border",
};

const ACTION_ICONS = {
  act_now:     Zap,
  prepare:     Clock,
  watch:       Eye,
  reduce_risk: ShieldAlert,
  exit_hedge:  LogOut,
  ignore:      Eye,
};

const ACTION_COLORS = {
  act_now:     "text-primary",
  prepare:     "text-foreground",
  watch:       "text-muted-foreground",
  reduce_risk: "text-warning",
  exit_hedge:  "text-loss",
};

const MARKET_TYPE_COLORS = {
  crypto:    "bg-violet-500/15 text-violet-400 border-violet-500/25",
  fx:        "bg-blue-500/15 text-blue-400 border-blue-500/25",
  commodity: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  index:     "bg-slate-500/15 text-slate-300 border-slate-500/25",
};

const ALERT_TYPE_CONFIG = {
  opportunity_score: { label: "Opportunity Score",   icon: Target },
  viral_score:       { label: "Viral Signal",         icon: Flame },
  indicator:         { label: "Risk Indicator",       icon: AlertTriangle },
  stop_loss:         { label: "Drawdown / Stop Loss", icon: TrendingDown },
  take_profit:       { label: "Profit Target",        icon: TrendingUp },
  price:             { label: "Price Alert",          icon: Zap },
  portfolio_risk:    { label: "Portfolio Risk",       icon: ShieldAlert },
  macro:             { label: "Macro Event",          icon: AlertTriangle },
};

function InfoRow({ label, value, className = "" }) {
  if (value == null || value === "") return null;
  return (
    <div className="bg-secondary/40 rounded-lg px-3 py-2">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-mono font-semibold mt-0.5 ${className}`}>{String(value)}</p>
    </div>
  );
}

function fmtPrice(price) {
  if (price == null) return null;
  if (price < 0.01) return `$${price.toFixed(6)}`;
  if (price < 1)    return `$${price.toFixed(4)}`;
  if (price < 1000) return `$${price.toFixed(2)}`;
  return `$${price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

export default function AlertDetailDrawer({ alert, onClose }) {
  if (!alert) return null;

  // Use enriched fields from useAlertEnrichment
  const symbol      = alert._symbol || null;
  const displayName = alert._name && alert._name !== symbol ? alert._name : null;
  const marketType  = alert._market_type;
  const livePrice   = alert._live_price;
  const priceStale  = alert._price_is_stale;
  const pnlPct      = alert.pnl_pct;
  const hasAsset    = !!alert._asset;

  const headline    = displayName || symbol || "Unknown Asset";
  const isUnknown   = !symbol && !displayName;

  const ActionIcon   = ACTION_ICONS[alert.action_classification] || Bell;
  const actionColor  = ACTION_COLORS[alert.action_classification] || "text-foreground";
  const stale        = isStale(alert.triggered_at, 12 * 60 * 60 * 1000);
  const age          = dataAge(alert.triggered_at);
  const marketColor  = MARKET_TYPE_COLORS[marketType] || "bg-secondary text-muted-foreground border-border";
  const typeConfig   = ALERT_TYPE_CONFIG[alert.alert_type] || { label: alert.alert_type, icon: AlertTriangle };
  const TypeIcon     = typeConfig.icon;

  const hasSignalLink  = alert.alert_type === "opportunity_score" || alert.alert_type === "indicator";
  const hasViralLink   = alert.alert_type === "viral_score";
  const hasHoldingLink = !!alert.holding_id;

  return (
    <Sheet open={!!alert} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-border">
        <SheetHeader className="pb-4 border-b border-border">
          <div className="flex items-start gap-2.5 flex-wrap">
            <TypeIcon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              {/* Asset identity */}
              <div className="flex items-center gap-2 flex-wrap">
                <SheetTitle className={`text-lg ${isUnknown ? "text-muted-foreground/60 italic" : ""}`}>
                  {headline}
                </SheetTitle>
                {symbol && symbol !== headline && (
                  <span className="text-sm font-mono text-muted-foreground">{symbol}</span>
                )}
              </div>
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                {marketType && (
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wide ${marketColor}`}>
                    {marketType}
                  </span>
                )}
                <span className="text-[10px] text-muted-foreground">{typeConfig.label}</span>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${SEVERITY_COLORS[alert.severity] || ""}`}>
                  {alert.severity}
                </span>
              </div>
            </div>
          </div>
          {alert.triggered_at && (
            <p className="text-[11px] text-muted-foreground font-mono mt-1">
              {new Date(alert.triggered_at).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" })}
              {stale && <span className="ml-2 text-warning/70">({age} ago)</span>}
            </p>
          )}
        </SheetHeader>

        <div className="mt-4 space-y-4">
          {/* Action required */}
          <div className={`flex items-center gap-2.5 rounded-lg border px-3 py-2.5 ${SEVERITY_COLORS[alert.severity] || "border-border"}`}>
            <ActionIcon className={`w-4 h-4 flex-shrink-0 ${actionColor}`} />
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Recommended Action</p>
              <p className={`text-sm font-semibold capitalize ${actionColor}`}>
                {alert.action_classification?.replace(/_/g, " ") || "—"}
              </p>
            </div>
          </div>

          {/* Price + P&L */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-secondary/40 rounded-lg px-3 py-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
                Current Price{priceStale ? " (stale)" : ""}
              </p>
              <p className={`text-sm font-mono font-semibold mt-0.5 ${priceStale ? "text-muted-foreground/60" : ""}`}>
                {livePrice != null
                  ? fmtPrice(livePrice)
                  : <span className="text-muted-foreground/50">Unavailable</span>}
              </p>
            </div>
            {pnlPct != null ? (
              <div className="bg-secondary/40 rounded-lg px-3 py-2">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">P&L %</p>
                <p className={`text-sm font-mono font-semibold mt-0.5 ${pnlPct >= 0 ? "text-profit" : "text-loss"}`}>
                  {pnlPct >= 0 ? "+" : ""}{pnlPct.toFixed(2)}%
                </p>
              </div>
            ) : (
              <InfoRow label="Alert Type" value={typeConfig.label} />
            )}
          </div>

          {/* Core fields */}
          <div className="grid grid-cols-2 gap-2">
            <InfoRow label="Severity" value={alert.severity} />
            <InfoRow label="Status"   value={alert.status} />
          </div>

          {/* Trigger reason */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-1.5">Trigger Reason</p>
            <div className="bg-secondary/40 rounded-lg px-3 py-2.5">
              <p className="text-xs text-foreground/90 leading-relaxed">{alert.trigger_reason || "—"}</p>
            </div>
          </div>

          {/* Summary */}
          {alert.summary && alert.summary !== alert.trigger_reason && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-1.5">Context & Recommended Action</p>
              <div className="bg-secondary/20 border border-border/50 rounded-lg px-3 py-2.5">
                <p className="text-xs text-foreground/85 leading-relaxed">{alert.summary}</p>
              </div>
            </div>
          )}

          {/* Drilldown navigation */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2">Navigate To</p>
            <div className="flex flex-wrap gap-2">
              {/* Always show View Asset — link to /assets, pass asset_id as search param if we have it */}
              <Link
                to={hasAsset ? `/assets?highlight=${alert.asset_id}` : "/assets"}
                onClick={onClose}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              >
                <Database className="w-3 h-3" /> View Asset
              </Link>

              {hasSignalLink && (
                <Link
                  to="/recommended"
                  onClick={onClose}
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-primary/30 bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
                >
                  <Target className="w-3 h-3" /> View Signal
                </Link>
              )}
              {hasViralLink && (
                <Link
                  to="/viral"
                  onClick={onClose}
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-viral/30 bg-viral/10 hover:bg-viral/20 text-viral transition-colors"
                >
                  <Flame className="w-3 h-3" /> View Viral Signal
                </Link>
              )}
              {hasHoldingLink && (
                <Link
                  to="/portfolio"
                  onClick={onClose}
                  className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-border bg-secondary/40 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ExternalLink className="w-3 h-3" /> View Holding
                </Link>
              )}
            </div>
          </div>

          {/* Stale warning */}
          {stale && (
            <div className="flex items-start gap-2 bg-warning/5 border border-warning/20 rounded-lg px-3 py-2 text-[11px] text-warning/80">
              <Clock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              <span>Alert triggered {age} ago. Market conditions may have changed — verify before acting.</span>
            </div>
          )}

          {/* Price stale warning */}
          {priceStale && livePrice != null && (
            <div className="flex items-start gap-2 bg-warning/5 border border-warning/20 rounded-lg px-3 py-2 text-[11px] text-warning/80">
              <Clock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              <span>Displayed price is from a stale market snapshot (&gt;4h old). Verify current price independently.</span>
            </div>
          )}

          {/* Profile-based position projection */}
          <AlertProfileProjection alert={alert} variant="full" />

          <p className="text-[10px] text-muted-foreground/50 leading-relaxed border-t border-border pt-3">
            Alerts are rule-based analytical signals only. Not financial advice. Always conduct independent research.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}