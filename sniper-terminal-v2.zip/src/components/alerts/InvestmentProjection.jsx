import React from "react";
import { Target, AlertTriangle } from "lucide-react";
import { useUserProfile } from "@/hooks/useUserProfile";

const TIMELINE_LABELS = {
  "4_weeks":   "4 weeks",
  "3_months":  "3 months",
  "6_months":  "6 months",
  "1_year":    "1 year",
  "long_term": "long term",
};

// Rough annualised return rate assumptions per risk appetite
// These are illustrative only — NOT financial advice
const ANNUAL_RATE = {
  low:    0.06,   // ~6% p.a. conservative
  medium: 0.18,   // ~18% p.a. moderate
  high:   0.45,   // ~45% p.a. aggressive / crypto-style
};

const TIMELINE_YEARS = {
  "4_weeks":   4 / 52,
  "3_months":  0.25,
  "6_months":  0.5,
  "1_year":    1,
  "long_term": 3,
};

function fmt(v) {
  if (v == null || isNaN(v)) return "—";
  return "£" + v.toLocaleString("en-GB", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function calcProjection(profile) {
  if (!profile || !profile.invest_amount) return null;
  const rate      = ANNUAL_RATE[profile.risk_appetite] ?? ANNUAL_RATE.medium;
  const years     = TIMELINE_YEARS[profile.timeline]   ?? 1;
  const principal = profile.invest_amount;

  // Compound growth
  const optimistic    = principal * Math.pow(1 + rate * 1.5, years);
  const conservative  = principal * Math.pow(1 + rate * 0.5, years);
  const base          = principal * Math.pow(1 + rate,       years);

  const goal = profile.goal_amount ?? null;
  const goalPct = goal ? Math.min(Math.round((base / goal) * 100), 999) : null;

  return { principal, optimistic, conservative, base, goal, goalPct, years, rate };
}

export default function InvestmentProjection() {
  const { profile, isLoading } = useUserProfile();

  if (isLoading || !profile || !profile.invest_amount) return null;

  const p = calcProjection(profile);
  if (!p) return null;

  const timelineLabel = TIMELINE_LABELS[profile.timeline] ?? profile.timeline;

  return (
    <div className="rounded-xl border border-primary/25 bg-primary/[0.04] px-4 py-4 space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Target className="w-4 h-4 text-primary flex-shrink-0" />
        <div>
          <p className="text-xs font-bold text-primary">
            {profile.alias ? `${profile.alias}'s` : "Your"} Investment Projection
          </p>
          <p className="text-[10px] text-muted-foreground">
            Starting with {fmt(p.principal)} · {timelineLabel} · {profile.risk_appetite} risk
          </p>
        </div>
      </div>

      {/* Scenario grid */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-lg bg-secondary/40 border border-border px-3 py-2 text-center">
          <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">Conservative</div>
          <div className="text-sm font-mono font-bold text-foreground">{fmt(p.conservative)}</div>
        </div>
        <div className="rounded-lg bg-primary/10 border border-primary/30 px-3 py-2 text-center">
          <div className="text-[9px] text-primary/70 uppercase tracking-widest mb-1">Base Case</div>
          <div className="text-sm font-mono font-bold text-primary">{fmt(p.base)}</div>
        </div>
        <div className="rounded-lg bg-profit/10 border border-profit/30 px-3 py-2 text-center">
          <div className="text-[9px] text-profit/70 uppercase tracking-widest mb-1">Optimistic</div>
          <div className="text-sm font-mono font-bold text-profit">{fmt(p.optimistic)}</div>
        </div>
      </div>

      {/* Goal progress */}
      {p.goal && (
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-muted-foreground">Goal: {fmt(p.goal)}</span>
            <span className={`text-[10px] font-mono font-bold ${p.goalPct >= 100 ? "text-profit" : "text-warning"}`}>
              {p.goalPct}% of goal (base case)
            </span>
          </div>
          <div className="h-1.5 bg-secondary/50 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${p.goalPct >= 100 ? "bg-profit" : "bg-primary"}`}
              style={{ width: `${Math.min(p.goalPct, 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="flex items-start gap-1.5 pt-1 border-t border-border/30">
        <AlertTriangle className="w-3 h-3 text-muted-foreground/50 flex-shrink-0 mt-0.5" />
        <p className="text-[9px] text-muted-foreground/50 leading-relaxed">
          Illustrative only. Projections use assumed annual return rates ({Math.round(ANNUAL_RATE[profile.risk_appetite] * 100)}% p.a. for {profile.risk_appetite} risk) and compound growth. Past performance is not indicative of future results. <strong>This is not financial advice.</strong>
        </p>
      </div>
    </div>
  );
}