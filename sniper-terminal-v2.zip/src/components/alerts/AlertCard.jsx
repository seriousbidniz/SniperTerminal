import React from "react";
import { Clock, X, Zap, ShieldAlert, Target, Flame, AlertTriangle, TrendingDown, TrendingUp } from "lucide-react";
import AlertProfileProjection from "./AlertProfileProjection";

const SEVERITY_DOT = {
  critical: "bg-loss",
  high:     "bg-warning",
  medium:   "bg-primary",
  low:      "bg-muted-foreground/50",
};

const MARKET_TYPE_COLORS = {
  crypto:    "bg-violet-500/15 text-violet-400 border-violet-500/25",
  fx:        "bg-blue-500/15 text-blue-400 border-blue-500/25",
  commodity: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  index:     "bg-slate-500/15 text-slate-300 border-slate-500/25",
};

const ALERT_TYPE_CONFIG = {
  opportunity_score: { label: "Opportunity",   icon: Target,        color: "text-primary bg-primary/10 border-primary/25" },
  viral_score:       { label: "Viral",          icon: Flame,         color: "text-viral bg-viral/10 border-viral/25" },
  indicator:         { label: "Risk Indicator", icon: AlertTriangle, color: "text-warning bg-warning/10 border-warning/25" },
  stop_loss:         { label: "Drawdown",       icon: TrendingDown,  color: "text-loss bg-loss/10 border-loss/25" },
  take_profit:       { label: "Profit Target",  icon: TrendingUp,    color: "text-profit bg-profit/10 border-profit/25" },
  price:             { label: "Price Alert",    icon: Zap,           color: "text-primary bg-primary/10 border-primary/25" },
  portfolio_risk:    { label: "Portfolio Risk", icon: ShieldAlert,   color: "text-warning bg-warning/10 border-warning/25" },
  macro:             { label: "Macro",          icon: AlertTriangle, color: "text-muted-foreground bg-secondary border-border" },
};

function fmtPrice(price) {
  if (price == null) return null;
  if (price < 0.01) return `$${price.toFixed(6)}`;
  if (price < 1)    return `$${price.toFixed(4)}`;
  if (price < 1000) return `$${price.toFixed(2)}`;
  return `$${price.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
}

/**
 * AlertCard — consumes an enriched alert (from useAlertEnrichment).
 * All identity fields are prefixed with _resolved_ to distinguish from raw stored values.
 */
export default function AlertCard({ alert, onDismiss, onSnooze, onSelect }) {
  // Use resolved enriched fields (set by useAlertEnrichment.enrich())
  const symbol      = alert._symbol || null;
  const displayName = alert._name && alert._name !== symbol ? alert._name : null;
  const marketType  = alert._market_type;
  const livePrice   = alert._live_price;
  const priceStale  = alert._price_is_stale;
  const pnlPct      = alert.pnl_pct;

  // If no valid identity at all, show a degraded card
  const headline    = displayName || symbol || "Unknown Asset";
  const isUnknown   = !symbol && !displayName;

  const typeConfig  = ALERT_TYPE_CONFIG[alert.alert_type] || { label: alert.alert_type, icon: AlertTriangle, color: "text-muted-foreground bg-secondary border-border" };
  const TypeIcon    = typeConfig.icon;
  const marketColor = MARKET_TYPE_COLORS[marketType] || "bg-secondary text-muted-foreground border-border";
  const priceStr    = livePrice != null ? fmtPrice(livePrice) : null;

  return (
    <div
      className="border border-border/60 rounded-lg bg-card hover:bg-accent/20 transition-colors cursor-pointer"
      onClick={() => onSelect(alert)}
    >
      <div className="px-3.5 py-3">
        <div className="flex items-start gap-2.5">
          <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-[5px] ${SEVERITY_DOT[alert.severity] || SEVERITY_DOT.low}`} />

          <div className="flex-1 min-w-0">
            {/* Asset identity line */}
            <div className="flex items-center gap-1.5 flex-wrap mb-1">
              {/* Primary: display name (bold) */}
              <span className={`text-sm font-semibold ${isUnknown ? "text-muted-foreground/60 italic" : "text-foreground"}`}>
                {headline}
              </span>
              {/* Secondary: symbol in mono if different from headline */}
              {symbol && symbol !== headline && (
                <span className="text-xs font-mono text-muted-foreground/70">{symbol}</span>
              )}
              {/* Only show raw ID in tiny muted text if truly unknown */}
              {isUnknown && alert.asset && (
                <span className="text-[9px] text-muted-foreground/40 font-mono">{String(alert.asset).slice(0, 12)}…</span>
              )}
              {/* Market type badge */}
              {marketType && (
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wide ${marketColor}`}>
                  {marketType}
                </span>
              )}
              {/* Alert type badge */}
              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase flex items-center gap-0.5 ${typeConfig.color}`}>
                <TypeIcon className="w-2.5 h-2.5" />
                {typeConfig.label}
              </span>

              {/* Price + PnL + time — pushed to right */}
              <div className="ml-auto flex items-center gap-2 flex-shrink-0">
                {priceStr ? (
                  <span className={`text-xs font-mono font-semibold ${priceStale ? "text-muted-foreground/60" : "text-foreground"}`}>
                    {priceStr}
                    {priceStale && <span className="text-[9px] text-warning/60 ml-0.5">~</span>}
                  </span>
                ) : (
                  <span className="text-[10px] font-mono text-muted-foreground/40">Price unavailable</span>
                )}
                {pnlPct != null && (
                  <span className={`text-[10px] font-mono font-bold ${pnlPct >= 0 ? "text-profit" : "text-loss"}`}>
                    {pnlPct >= 0 ? "+" : ""}{pnlPct.toFixed(1)}%
                  </span>
                )}
                <span className="text-[9px] text-muted-foreground/50 font-mono">
                  {alert.triggered_at
                    ? new Date(alert.triggered_at).toLocaleString("en-GB", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
                    : "—"}
                </span>
              </div>
            </div>

            {/* Trigger reason */}
            <p className="text-xs text-foreground/85 leading-snug line-clamp-2">{alert.trigger_reason}</p>

            {/* Summary if different */}
            {alert.summary && alert.summary !== alert.trigger_reason && (
              <p className="text-[11px] text-muted-foreground/60 mt-1 line-clamp-1 leading-relaxed">{alert.summary}</p>
            )}

            {/* Profile-based inline projection */}
            <AlertProfileProjection alert={alert} variant="inline" />
          </div>

          {/* Snooze / Dismiss buttons */}
          <div className="flex gap-1 flex-shrink-0 ml-1" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => onSnooze(alert.id)}
              className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              title="Snooze"
            >
              <Clock className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onDismiss(alert.id)}
              className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}