import React from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { AlertTriangle, Zap,
  Target, Clock, Pencil
} from "lucide-react";
import { Button } from "@/components/ui/button";

function fmtUsd(v) {
  if (v == null || isNaN(v)) return "—";
  return "$" + Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtPnl(v) {
  if (v == null || isNaN(v)) return "—";
  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
  return `${sign}$${Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
function fmtPct(v) {
  if (v == null || isNaN(v)) return "—";
  const sign = v > 0 ? "+" : "";
  return `${sign}${v.toFixed(2)}%`;
}
function pnlColor(v) {
  if (v == null || isNaN(v)) return "text-muted-foreground";
  return v > 0 ? "text-profit" : v < 0 ? "text-loss" : "text-foreground";
}

function InfoRow({ label, value, className = "" }) {
  return (
    <div className="bg-secondary/40 rounded-lg px-3 py-2">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-mono font-semibold mt-0.5 ${className}`}>{value || "—"}</p>
    </div>
  );
}

function ScoreChip({ label, value, invert = false }) {
  if (value == null) return null;
  const s = invert ? 100 - value : value;
  const color = s >= 70 ? "text-profit bg-profit/10 border-profit/30"
    : s >= 45 ? "text-primary bg-primary/10 border-primary/30"
    : "text-loss bg-loss/10 border-loss/30";
  return (
    <div className="flex flex-col items-center gap-0.5">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded border ${color}`}>{Math.round(value)}</span>
    </div>
  );
}

const SEVERITY_COLORS = {
  critical: "text-loss bg-loss/10 border-loss/30",
  high: "text-warning bg-warning/10 border-warning/30",
  medium: "text-primary bg-primary/10 border-primary/30",
  low: "text-muted-foreground bg-secondary border-border",
};

export default function HoldingDetailDrawer({ holding, recSignal, viralSignal, alerts = [], onClose, onEdit }) {
  if (!holding) return null;

  const { effectivePrice, priceStatus, pnlPercent, unrealised_pnl, current_value, allocation_percent } = holding;

  return (
    <Sheet open={!!holding} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-border">
        <SheetHeader className="pb-4 border-b border-border">
          <div className="flex items-center gap-2.5 flex-wrap">
            <SheetTitle className="font-mono text-lg">{holding.asset}</SheetTitle>
            {priceStatus === "stale" && (
              <span className="inline-flex items-center gap-1 text-[9px] font-semibold px-1.5 py-0.5 rounded border text-warning bg-warning/10 border-warning/30 uppercase">
                <Clock className="w-2.5 h-2.5" /> Stale
              </span>
            )}
            {priceStatus === "fallback" && (
              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded border text-muted-foreground bg-secondary border-border uppercase">
                Awaiting live data
              </span>
            )}
          </div>
          {holding.thesis_notes && (
            <p className="text-xs text-muted-foreground leading-relaxed mt-1">{holding.thesis_notes}</p>
          )}
          {onEdit && (
            <Button
              size="sm"
              variant="outline"
              className="mt-2 text-xs gap-1.5 h-7"
              onClick={() => onEdit(holding)}
            >
              <Pencil className="w-3 h-3" /> Edit Holding
            </Button>
          )}
        </SheetHeader>

        <div className="mt-4 space-y-5">

          {/* Price & P&L */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2">Position Summary</p>
            <div className="grid grid-cols-2 gap-2">
              <InfoRow label="Live Price" value={fmtUsd(effectivePrice)} className={priceStatus === "fallback" ? "text-muted-foreground/40" : ""} />
              <InfoRow label="Avg Entry" value={fmtUsd(holding.average_entry)} />
              <InfoRow label="Quantity" value={holding.quantity != null ? holding.quantity.toLocaleString() : "—"} />
              <InfoRow label="Current Value" value={fmtUsd(current_value)} />
              <InfoRow
                label="Unrealised P&L"
                value={priceStatus === "fallback" ? "No data" : fmtPnl(unrealised_pnl)}
                className={priceStatus === "fallback" ? "text-muted-foreground/40" : pnlColor(unrealised_pnl)}
              />
              <InfoRow
                label="P&L %"
                value={priceStatus === "fallback" ? "No data" : fmtPct(pnlPercent)}
                className={priceStatus === "fallback" ? "text-muted-foreground/40" : pnlColor(pnlPercent)}
              />
              <InfoRow label="Allocation" value={allocation_percent != null ? `${allocation_percent.toFixed(1)}%` : "—"} />
            </div>
          </div>

          {/* Risk Levels */}
          {(holding.stop_loss != null || holding.take_profit != null || holding.invalidation != null) && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">Risk Levels</p>
              <div className="grid grid-cols-3 gap-2">
                {holding.stop_loss != null && <InfoRow label="Stop Loss" value={fmtUsd(holding.stop_loss)} className="text-loss" />}
                {holding.take_profit != null && <InfoRow label="Take Profit" value={fmtUsd(holding.take_profit)} className="text-profit" />}
                {holding.invalidation != null && <InfoRow label="Invalidation" value={fmtUsd(holding.invalidation)} className="text-muted-foreground" />}
              </div>
            </div>
          )}

          {/* Recommended Signal */}
          {recSignal ? (
            <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-3 space-y-2">
              <div className="flex items-center gap-2">
                <Target className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-semibold text-primary">Recommended Signal Active</span>
                <span className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${recSignal.direction === "bullish" ? "text-profit bg-profit/10 border-profit/30" : "text-loss bg-loss/10 border-loss/30"}`}>
                  {recSignal.direction === "bullish" ? "▲" : "▼"} {recSignal.direction}
                </span>
              </div>
              <div className="flex justify-around pt-1">
                <ScoreChip label="Opp" value={recSignal.opportunity_score} />
                <ScoreChip label="Conv" value={recSignal.conviction_score} />
                <ScoreChip label="Risk" value={recSignal.risk_score} invert />
              </div>
              {recSignal.setup_type && (
                <p className="text-[10px] text-muted-foreground capitalize">{recSignal.setup_type.replace(/_/g, " ")} setup</p>
              )}
              {recSignal.why_now && (
                <p className="text-xs text-foreground/80 leading-relaxed">{recSignal.why_now}</p>
              )}
            </div>
          ) : (
            <div className="rounded-lg border border-border px-3 py-2 text-xs text-muted-foreground/60 flex items-center gap-2">
              <Target className="w-3.5 h-3.5" />
              No active recommended signal for this asset
            </div>
          )}

          {/* Viral Signal */}
          {viralSignal && (
            <div className={`rounded-lg border px-3 py-3 space-y-1.5 ${viralSignal.ai_label === "tradable" ? "border-profit/20 bg-profit/5" : viralSignal.ai_label === "avoid" ? "border-loss/20 bg-loss/5" : "border-warning/20 bg-warning/5"}`}>
              <div className="flex items-center gap-2">
                <Zap className={`w-3.5 h-3.5 ${viralSignal.ai_label === "tradable" ? "text-profit" : viralSignal.ai_label === "avoid" ? "text-loss" : "text-warning"}`} />
                <span className="text-xs font-semibold">Viral Signal</span>
                <span className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${viralSignal.ai_label === "tradable" ? "text-profit bg-profit/10 border-profit/30" : viralSignal.ai_label === "avoid" ? "text-loss bg-loss/10 border-loss/30" : "text-warning bg-warning/10 border-warning/30"}`}>
                  {viralSignal.ai_label}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground capitalize">{viralSignal.move_state} — viral score {Math.round(viralSignal.viral_score)}</p>
              {viralSignal.confidence_note && (
                <p className="text-xs text-foreground/80 leading-relaxed">{viralSignal.confidence_note}</p>
              )}
            </div>
          )}

          {/* Alerts */}
          {alerts.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-warning" /> Active Alerts ({alerts.length})
              </p>
              <div className="space-y-2">
                {alerts.map(a => (
                  <div key={a.id} className={`rounded-lg border px-3 py-2 text-xs ${SEVERITY_COLORS[a.severity] || SEVERITY_COLORS.low}`}>
                    <p className="font-semibold capitalize">{a.alert_type?.replace(/_/g, " ")} — {a.severity}</p>
                    <p className="mt-0.5 text-foreground/80 leading-relaxed">{a.summary || a.trigger_reason}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {priceStatus !== "live" && (
            <div className="flex items-start gap-2 bg-warning/5 border border-warning/20 rounded-lg px-3 py-2 text-[11px] text-warning/80">
              <Clock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              <span>
                {priceStatus === "fallback"
                  ? "No market data available for this asset. P&L calculations use average entry as price. Add this asset to enable live tracking."
                  : "Price data is stale. P&L values are approximate — refresh to get updated prices."}
              </span>
            </div>
          )}

          <p className="text-[10px] text-muted-foreground/50 leading-relaxed border-t border-border pt-3">
            Analytical output only. Not financial advice. Always conduct independent research before making trading decisions.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}