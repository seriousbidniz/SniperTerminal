import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function PortfolioEditDialog({ portfolio, open, onClose }) {
  const [name, setName] = useState("");
  const [cashBalance, setCashBalance] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    if (portfolio) {
      setName(portfolio.name || "");
      setCashBalance(portfolio.cash_balance != null ? String(portfolio.cash_balance) : "");
      setConfirmDelete(false);
    }
  }, [portfolio]);

  const updatePortfolio = useMutation({
    mutationFn: (data) => base44.entities.Portfolios.update(portfolio.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["portfolios"] });
      onClose();
    },
  });

  const deletePortfolio = useMutation({
    mutationFn: () => base44.entities.Portfolios.delete(portfolio.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["portfolios"] });
      onClose();
    },
  });

  const handleSave = () => {
    updatePortfolio.mutate({
      name: name.trim() || portfolio.name,
      cash_balance: parseFloat(cashBalance) || 0,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-card border-border max-w-sm">
        <DialogHeader>
          <DialogTitle>Edit Portfolio</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Portfolio Name</label>
            <Input
              value={name}
              onChange={e => setName(e.target.value)}
              className="bg-secondary/50"
              placeholder="Portfolio name"
            />
          </div>
          <div>
            <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Cash Balance (USD)</label>
            <Input
              type="number"
              value={cashBalance}
              onChange={e => setCashBalance(e.target.value)}
              className="bg-secondary/50"
              placeholder="0.00"
            />
          </div>

          {/* Danger zone */}
          <div className="border border-loss/20 rounded-lg px-3 py-2.5">
            <p className="text-[10px] text-loss/70 uppercase tracking-wider font-semibold mb-2">Danger Zone</p>
            {!confirmDelete ? (
              <button
                onClick={() => setConfirmDelete(true)}
                className="flex items-center gap-1.5 text-xs text-loss/70 hover:text-loss transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete portfolio
              </button>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-loss">Are you sure? This cannot be undone.</p>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => setConfirmDelete(false)}>Cancel</Button>
                  <Button
                    size="sm"
                    className="text-xs h-7 bg-loss/80 hover:bg-loss text-white border-0"
                    onClick={() => deletePortfolio.mutate()}
                    disabled={deletePortfolio.isPending}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={handleSave} disabled={updatePortfolio.isPending || !name.trim()}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}