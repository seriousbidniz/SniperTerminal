import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Trash2 } from "lucide-react";

export default function HoldingEditDialog({ holding, open, onClose }) {
  const [form, setForm] = useState({});
  const [confirmDelete, setConfirmDelete] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    if (holding) {
      setForm({
        asset: holding.asset || "",
        quantity: holding.quantity != null ? String(holding.quantity) : "",
        average_entry: holding.average_entry != null ? String(holding.average_entry) : "",
        live_price: holding.live_price != null ? String(holding.live_price) : "",
        stop_loss: holding.stop_loss != null ? String(holding.stop_loss) : "",
        take_profit: holding.take_profit != null ? String(holding.take_profit) : "",
        invalidation: holding.invalidation != null ? String(holding.invalidation) : "",
        thesis_notes: holding.thesis_notes || "",
      });
      setConfirmDelete(false);
    }
  }, [holding]);

  const updateHolding = useMutation({
    mutationFn: (data) => base44.entities.Holdings.update(holding.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["holdings"] });
      onClose();
    },
  });

  const deleteHolding = useMutation({
    mutationFn: () => base44.entities.Holdings.delete(holding.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["holdings"] });
      onClose();
    },
  });

  const f = (key) => form[key] || "";
  const set = (key) => (e) => setForm(prev => ({ ...prev, [key]: e.target.value }));

  const handleSave = () => {
    updateHolding.mutate({
      asset: form.asset.trim().toUpperCase(),
      quantity: parseFloat(form.quantity) || 0,
      average_entry: parseFloat(form.average_entry) || 0,
      live_price: form.live_price ? parseFloat(form.live_price) : null,
      stop_loss: form.stop_loss ? parseFloat(form.stop_loss) : null,
      take_profit: form.take_profit ? parseFloat(form.take_profit) : null,
      invalidation: form.invalidation ? parseFloat(form.invalidation) : null,
      thesis_notes: form.thesis_notes || null,
    });
  };

  if (!holding) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-card border-border max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Holding — {holding.asset}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="col-span-2">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Asset Symbol</label>
              <Input value={f("asset")} onChange={set("asset")} className="bg-secondary/50" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Quantity</label>
              <Input type="number" value={f("quantity")} onChange={set("quantity")} className="bg-secondary/50" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Avg Entry Price</label>
              <Input type="number" value={f("average_entry")} onChange={set("average_entry")} className="bg-secondary/50" />
            </div>
            <div className="col-span-2">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Manual Price Override (optional)</label>
              <Input type="number" value={f("live_price")} onChange={set("live_price")} className="bg-secondary/50" placeholder="Leave blank to use live snapshot" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Stop Loss</label>
              <Input type="number" value={f("stop_loss")} onChange={set("stop_loss")} className="bg-secondary/50" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Take Profit</label>
              <Input type="number" value={f("take_profit")} onChange={set("take_profit")} className="bg-secondary/50" />
            </div>
            <div className="col-span-2">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Invalidation Level</label>
              <Input type="number" value={f("invalidation")} onChange={set("invalidation")} className="bg-secondary/50" />
            </div>
            <div className="col-span-2">
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Thesis Notes</label>
              <Textarea value={f("thesis_notes")} onChange={set("thesis_notes")} className="bg-secondary/50 h-16" />
            </div>
          </div>

          <div className="border border-loss/20 rounded-lg px-3 py-2.5">
            <p className="text-[10px] text-loss/70 uppercase tracking-wider font-semibold mb-2">Danger Zone</p>
            {!confirmDelete ? (
              <button
                onClick={() => setConfirmDelete(true)}
                className="flex items-center gap-1.5 text-xs text-loss/70 hover:text-loss transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete this holding
              </button>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-loss">Delete {holding.asset} holding? Cannot be undone.</p>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => setConfirmDelete(false)}>Cancel</Button>
                  <Button
                    size="sm"
                    className="text-xs h-7 bg-loss/80 hover:bg-loss text-white border-0"
                    onClick={() => deleteHolding.mutate()}
                    disabled={deleteHolding.isPending}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={updateHolding.isPending || !form.asset?.trim() || !form.quantity || !form.average_entry}
          >
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}