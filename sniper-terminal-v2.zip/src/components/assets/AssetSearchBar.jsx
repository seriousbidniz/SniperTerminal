import React, { useState, useRef, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Search, Plus, Clock, CheckCircle2 } from "lucide-react";
import AddAssetDialog from "@/components/assets/AddAssetDialog";

const STATUS_COLOR = {
  active:       "text-profit",
  pending_data: "text-warning",
  inactive:     "text-muted-foreground",
};

/**
 * AssetSearchBar
 *
 * Props:
 *   placeholder  – string
 *   onSelect     – (asset) => void   called when user picks an existing asset
 *   onCreated    – (asset) => void   called after a brand-new asset is created
 */
export default function AssetSearchBar({ placeholder = "Search or add asset…", onSelect, onCreated }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const inputRef = useRef(null);
  const dropdownRef = useRef(null);

  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 30_000,
  });

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return assets.filter(
      a =>
        a.symbol?.toLowerCase().includes(q) ||
        a.name?.toLowerCase().includes(q)
    ).slice(0, 8);
  }, [assets, query]);

  // Close dropdown on outside click
  useEffect(() => {
    function handler(e) {
      if (
        dropdownRef.current && !dropdownRef.current.contains(e.target) &&
        inputRef.current && !inputRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  function handleInput(e) {
    setQuery(e.target.value);
    setOpen(true);
  }

  function handleSelect(asset) {
    setQuery("");
    setOpen(false);
    onSelect && onSelect(asset);
  }

  function handleCreateNew() {
    setOpen(false);
    setShowCreate(true);
  }

  function handleCreated(asset) {
    setQuery("");
    setShowCreate(false);
    onCreated && onCreated(asset);
  }

  const hasQuery = query.trim().length > 0;
  const exactMatch = assets.some(
    a => a.symbol?.toLowerCase() === query.trim().toLowerCase()
  );

  return (
    <div className="relative">
      {/* Input */}
      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInput}
          onFocus={() => hasQuery && setOpen(true)}
          placeholder={placeholder}
          className="w-full pl-8 pr-3 h-9 rounded-md border border-input bg-secondary/50 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring transition-colors"
        />
      </div>

      {/* Dropdown */}
      {open && hasQuery && (
        <div
          ref={dropdownRef}
          className="absolute z-50 top-full mt-1 left-0 right-0 bg-popover border border-border rounded-lg shadow-xl overflow-hidden"
        >
          {results.length > 0 && (
            <ul>
              {results.map(asset => {
                const status = asset.status || "active";
                const statusColor = STATUS_COLOR[status] || "text-muted-foreground";
                return (
                  <li key={asset.id}>
                    <button
                      onMouseDown={() => handleSelect(asset)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-accent transition-colors text-left"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-semibold text-sm">{asset.symbol}</span>
                          <span className="text-[10px] bg-secondary px-1.5 py-0.5 rounded text-muted-foreground uppercase font-medium">
                            {asset.market_type}
                          </span>
                          {asset.user_added && (
                            <span className="text-[9px] text-primary font-semibold">Custom</span>
                          )}
                        </div>
                        {asset.name && (
                          <span className="text-xs text-muted-foreground truncate">{asset.name}</span>
                        )}
                      </div>
                      {status === "pending_data" ? (
                        <Clock className={`w-3.5 h-3.5 flex-shrink-0 ${statusColor}`} />
                      ) : (
                        <CheckCircle2 className={`w-3.5 h-3.5 flex-shrink-0 ${statusColor}`} />
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}

          {/* Create new option */}
          {!exactMatch && (
            <button
              onMouseDown={handleCreateNew}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 hover:bg-accent transition-colors text-left border-t border-border/50"
            >
              <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center flex-shrink-0">
                <Plus className="w-3 h-3 text-primary" />
              </div>
              <span className="text-sm text-primary font-medium">
                Create "<span className="font-mono">{query.trim().toUpperCase()}</span>"
              </span>
            </button>
          )}

          {results.length === 0 && exactMatch && (
            <div className="px-3 py-3 text-xs text-muted-foreground">
              Asset already exists — select it above.
            </div>
          )}
        </div>
      )}

      {/* Full create dialog — pre-fills symbol */}
      <AddAssetDialog
        open={showCreate}
        initialSymbol={query.trim().toUpperCase()}
        onClose={() => setShowCreate(false)}
        onCreated={handleCreated}
      />
    </div>
  );
}