import React from "react";
import { ExternalLink, Globe, FileText, TrendingUp, Map, Twitter, MessageCircle, Code } from "lucide-react";

/**
 * Research & Trading Links section for assets.
 * Shows clickable links to external resources: website, docs, CoinGecko, exchanges, explorer, socials.
 * Only renders links that exist.
 */
export default function ResearchLinksSection({ asset }) {
  if (!asset) return null;

  // Define link groups: primary research links (always show) and social links (secondary)
  const primaryLinks = [
    {
      label: "CoinGecko Profile",
      url: asset.coingecko_profile_url,
      icon: TrendingUp,
      color: "text-purple-600 bg-purple-50 hover:bg-purple-100 border-purple-200",
      description: "Market data & price charts"
    },
    {
      label: "Official Website",
      url: asset.official_website_url,
      icon: Globe,
      color: "text-primary bg-primary/5 hover:bg-primary/10 border-primary/20",
      description: "Project homepage"
    },
    {
      label: "Documentation",
      url: asset.docs_url,
      icon: FileText,
      color: "text-blue-600 bg-blue-50 hover:bg-blue-100 border-blue-200",
      description: "Technical docs & guides"
    },
    {
      label: "Where to Buy / Trade",
      url: asset.where_to_buy_url,
      icon: Map,
      color: "text-green-600 bg-green-50 hover:bg-green-100 border-green-200",
      description: "Exchange listings & venues"
    },
    {
      label: "Explorer",
      url: asset.explorer_url,
      icon: Map,
      color: "text-orange-600 bg-orange-50 hover:bg-orange-100 border-orange-200",
      description: "Block explorer or contract page"
    },
  ];

  const socialLinks = [
    {
      label: "X / Twitter",
      url: asset.x_url,
      icon: Twitter,
      color: "text-slate-600 bg-slate-50 hover:bg-slate-100 border-slate-200",
    },
    {
      label: "Discord",
      url: asset.discord_url,
      icon: MessageCircle,
      color: "text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border-indigo-200",
    },
    {
      label: "GitHub",
      url: asset.github_url,
      icon: Code,
      color: "text-slate-800 bg-slate-50 hover:bg-slate-100 border-slate-200",
    },
  ];

  // Filter to only links that have URLs
  const availablePrimary = primaryLinks.filter(l => l.url);
  const availableSocial = socialLinks.filter(l => l.url);

  // Don't render section if no links available
  if (availablePrimary.length === 0 && availableSocial.length === 0) return null;

  return (
    <div className="space-y-4">
      {/* Primary Research Links */}
      {availablePrimary.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2.5">
            Research & Trading
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {availablePrimary.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center justify-between gap-2 px-3 py-2 rounded-lg border transition-colors ${link.color}`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                    <div className="min-w-0">
                      <div className="font-semibold text-sm">{link.label}</div>
                      <div className="text-[10px] opacity-70">{link.description}</div>
                    </div>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 flex-shrink-0 opacity-60" />
                </a>
              );
            })}
          </div>
        </div>
      )}

      {/* Social & Developer Links */}
      {availableSocial.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
            Community & Dev
          </h3>
          <div className="flex flex-wrap gap-1.5">
            {availableSocial.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  title={link.label}
                  className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md border text-xs font-semibold transition-colors ${link.color}`}
                >
                  <Icon className="w-3 h-3" />
                  {link.label}
                </a>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}