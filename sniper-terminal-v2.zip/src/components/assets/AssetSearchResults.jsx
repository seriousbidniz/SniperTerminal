import React from "react";
import { ExternalLink } from "lucide-react";

const PROVIDER_CONFIG = {
  coingecko: { label: "CoinGecko", color: "text-profit bg-profit/10 border-profit/25" },
  dex_screener: { label: "DEX Screener", color: "text-viral bg-viral/10 border-viral/25" },
  twelve_data: { label: "Twelve Data", color: "text-primary bg-primary/10 border-primary/25" },
  alpha_vantage: { label: "Alpha Vantage", color: "text-warning bg-warning/10 border-warning/25" },
};

function ProviderBadge({ provider }) {
  const cfg = PROVIDER_CONFIG[provider] || { label: provider, color: "text-muted-foreground bg-secondary border-border" };
  return (
    <span className={`inline-flex items-center text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wide ${cfg.color}`}>
      {cfg.label}
    </span>
  );
}

export default function AssetSearchResults({ results, marketType, onSelect }) {
  // Split by provider for clear display when both CoinGecko + DEX Screener are shown
  const coingecko = results.filter(r => r.provider === "coingecko");
  const dexScreener = results.filter(r => r.provider === "dex_screener");
  const other = results.filter(r => r.provider !== "coingecko" && r.provider !== "dex_screener");

  const renderRow = (result) => (
    <button
      key={`${result.provider}:${result.provider_asset_id}`}
      onClick={() => onSelect(result)}
      className="w-full text-left flex items-start gap-3 px-3 py-2.5 rounded-lg hover:bg-accent/40 border border-transparent hover:border-primary/25 transition-all group"
    >
      {/* Symbol + name */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
          <span className="font-mono font-bold text-sm">{result.symbol}</span>
          <ProviderBadge provider={result.provider} />
          {result.chain_id && (
            <span className="text-[9px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded border border-border uppercase">
              {result.chain_id}
            </span>
          )}
          {result.market_cap_rank && (
            <span className="text-[9px] text-muted-foreground font-mono">#{result.market_cap_rank}</span>
          )}
        </div>
        <p className="text-xs text-muted-foreground truncate">{result.name}</p>
        {/* Secondary info */}
        <div className="flex items-center gap-3 mt-1 flex-wrap">
          {result.exchange && (
            <span className="text-[10px] text-muted-foreground/70">{result.exchange}</span>
          )}
          {result.liquidity_usd != null && (
            <span className="text-[10px] text-muted-foreground/70">
              Liq: ${Number(result.liquidity_usd).toLocaleString(undefined, { notation: "compact" })}
            </span>
          )}
          {result.volume_24h != null && (
            <span className="text-[10px] text-muted-foreground/70">
              Vol: ${Number(result.volume_24h).toLocaleString(undefined, { notation: "compact" })}
            </span>
          )}
          {result.price_usd && (
            <span className="text-[10px] font-mono text-foreground/70">${Number(result.price_usd).toLocaleString()}</span>
          )}
          {result.token_address && (
            <span className="text-[10px] font-mono text-muted-foreground/50 truncate max-w-[120px]" title={result.token_address}>
              {result.token_address.slice(0, 8)}…
            </span>
          )}
        </div>
      </div>
      <ExternalLink className="w-3 h-3 text-muted-foreground/30 group-hover:text-primary/60 flex-shrink-0 mt-1 transition-colors" />
    </button>
  );

  // Combined render for single-provider results
  if (coingecko.length === 0 && dexScreener.length === 0) {
    return (
      <div className="space-y-1 rounded-xl border border-border bg-secondary/20 p-2 max-h-72 overflow-y-auto">
        {other.map(renderRow)}
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
      {coingecko.length > 0 && (
        <div>
          <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest px-1 mb-1">
            CoinGecko — Major / Listed Coins
          </p>
          <div className="rounded-xl border border-border bg-secondary/20 p-1 space-y-0.5">
            {coingecko.map(renderRow)}
          </div>
        </div>
      )}
      {dexScreener.length > 0 && (
        <div>
          <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest px-1 mb-1">
            DEX Screener — On-chain / Meme Pairs
          </p>
          <div className="rounded-xl border border-border bg-secondary/20 p-1 space-y-0.5">
            {dexScreener.map(renderRow)}
          </div>
        </div>
      )}
    </div>
  );
}