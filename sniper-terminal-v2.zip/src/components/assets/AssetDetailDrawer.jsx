import React from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Database, Target, Zap, Clock, AlertTriangle, Briefcase, Eye } from "lucide-react";
import { isStale, dataAge } from "@/lib/freshness";
import ResearchLinksSection from "./ResearchLinksSection";

const PROVIDER_LABELS = {
  coingecko: "CoinGecko", dex_screener: "DEX Screener",
  twelve_data: "Twelve Data", alpha_vantage: "Alpha Vantage", manual: "Manual",
};

function InfoRow({ label, value, className = "" }) {
  return (
    <div className="bg-secondary/40 rounded-lg px-3 py-2">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className={`text-sm font-mono font-semibold mt-0.5 ${className}`}>{value != null ? String(value) : "—"}</p>
    </div>
  );
}

function ScoreChip({ label, value, invert = false }) {
  if (value == null) return null;
  const s = invert ? 100 - value : value;
  const color = s >= 70 ? "text-profit bg-profit/10 border-profit/30"
    : s >= 45 ? "text-primary bg-primary/10 border-primary/30"
    : "text-loss bg-loss/10 border-loss/30";
  return (
    <div className="flex flex-col items-center gap-0.5">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded border ${color}`}>{Math.round(value)}</span>
    </div>
  );
}

export default function AssetDetailDrawer({ asset, onClose }) {
  const { data: snapshots = [] } = useQuery({
    queryKey: ["assetSnapshots", asset?.id],
    queryFn: () => asset ? base44.entities.MarketSnapshots.filter({ asset: asset.id }, "-timestamp", 5) : [],
    enabled: !!asset,
  });

  const { data: recSignals = [] } = useQuery({
    queryKey: ["assetRecSignals", asset?.id],
    queryFn: () => asset ? base44.entities.RecommendedTradeSignals.filter({ asset: asset.id, status: { $in: LIVE_SIGNAL_STATUSES } }, "-opportunity_score", 3) : [],
    enabled: !!asset,
  });

  const { data: viralSignals = [] } = useQuery({
    queryKey: ["assetViralSignals", asset?.id],
    queryFn: () => asset ? base44.entities.ViralTradeSignals.filter({ asset: asset.id, status: { $in: LIVE_SIGNAL_STATUSES } }, "-viral_score", 1) : [],
    enabled: !!asset,
  });

  const { data: holdings = [] } = useQuery({
    queryKey: ["assetHoldings", asset?.symbol],
    queryFn: () => asset ? base44.entities.Holdings.filter({ asset: asset.symbol }, "-created_date", 10) : [],
    enabled: !!asset,
  });

  const { data: watchlistItems = [] } = useQuery({
    queryKey: ["assetWatchlistItems", asset?.id],
    queryFn: () => asset ? base44.entities.WatchlistItems.filter({ asset: asset.id }, "-created_date", 5) : [],
    enabled: !!asset,
  });

  if (!asset) return null;

  const latestSnap = snapshots[0] || null;
  const snapStale = latestSnap ? isStale(latestSnap.timestamp) : true;
  const snapAge = latestSnap ? dataAge(latestSnap.timestamp) : null;
  const latestRec = recSignals[0] || null;
  const latestViral = viralSignals[0] || null;

  return (
    <Sheet open={!!asset} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-card border-border">
        <SheetHeader className="pb-4 border-b border-border">
          <div className="flex items-center gap-2.5 flex-wrap">
            <Database className="w-4 h-4 text-primary" />
            <SheetTitle className="font-mono text-lg">{asset.symbol}</SheetTitle>
            <span className="text-xs bg-secondary px-2 py-0.5 rounded font-medium capitalize">{asset.market_type}</span>
            {asset.data_provider && (
              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded border text-muted-foreground bg-secondary border-border uppercase">
                {PROVIDER_LABELS[asset.data_provider] || asset.data_provider}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground">{asset.name}</p>
        </SheetHeader>

        <div className="mt-4 space-y-5">
          {/* Core fields */}
          <div className="grid grid-cols-2 gap-2">
            <InfoRow label="Status" value={asset.status} />
            <InfoRow label="Liquidity Score" value={asset.liquidity_score} />
            {asset.sector && <InfoRow label="Sector" value={asset.sector} />}
            {asset.asset_class && <InfoRow label="Class" value={asset.asset_class?.replace(/_/g, " ")} />}
            {asset.last_refresh_at && (
              <InfoRow label="Last Refreshed" value={dataAge(asset.last_refresh_at)} />
            )}
          </div>

          {/* Data error */}
          {asset.data_error && (
            <div className="flex items-start gap-2 bg-loss/5 border border-loss/20 rounded-lg px-3 py-2 text-[11px] text-loss/80">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              {asset.data_error}
            </div>
          )}

          {/* Latest Snapshot */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" /> Latest Market Snapshot
              {snapStale && latestSnap && <span className="text-[10px] text-warning/70 font-normal">({snapAge})</span>}
            </p>
            {latestSnap ? (
              <div className="grid grid-cols-2 gap-2">
                <InfoRow label="Price" value={latestSnap.price != null ? `$${latestSnap.price.toLocaleString()}` : null} />
                <InfoRow label="24h Change" value={latestSnap.change_24h != null ? `${latestSnap.change_24h >= 0 ? "+" : ""}${latestSnap.change_24h.toFixed(2)}%` : null}
                  className={latestSnap.change_24h >= 0 ? "text-profit" : "text-loss"} />
                <InfoRow label="Volume (24h)" value={latestSnap.volume != null ? `$${latestSnap.volume.toLocaleString()}` : null} />
                <InfoRow label="RSI" value={latestSnap.rsi != null ? Math.round(latestSnap.rsi) : null} />
              </div>
            ) : (
              <div className="text-xs text-muted-foreground/50 bg-secondary/20 border border-border rounded-lg px-3 py-2">No snapshot available</div>
            )}
          </div>

          {/* Recommended Signal */}
          {latestRec && (
            <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-3 space-y-2">
              <div className="flex items-center gap-2">
                <Target className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-semibold text-primary">Active Recommended Signal</span>
                <span className={`ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${latestRec.direction === "bullish" ? "text-profit bg-profit/10 border-profit/30" : "text-loss bg-loss/10 border-loss/30"}`}>
                  {latestRec.direction}
                </span>
              </div>
              <div className="flex justify-around">
                <ScoreChip label="Opp" value={latestRec.opportunity_score} />
                <ScoreChip label="Conv" value={latestRec.opportunity_score} />
                <ScoreChip label="Risk" value={latestRec.risk_score} invert />
              </div>
              {latestRec.why_now && <p className="text-xs text-foreground/80 leading-relaxed">{latestRec.why_now}</p>}
            </div>
          )}

          {/* Viral Signal */}
          {latestViral && (
            <div className={`rounded-lg border px-3 py-2.5 space-y-1 ${latestViral.ai_label === "tradable" ? "border-profit/20 bg-profit/5" : latestViral.ai_label === "avoid" ? "border-loss/20 bg-loss/5" : "border-warning/20 bg-warning/5"}`}>
              <div className="flex items-center gap-2">
                <Zap className={`w-3.5 h-3.5 ${latestViral.ai_label === "tradable" ? "text-profit" : latestViral.ai_label === "avoid" ? "text-loss" : "text-warning"}`} />
                <span className="text-xs font-semibold">Viral Signal — {latestViral.ai_label}</span>
                <span className="ml-auto text-xs font-mono font-bold">{Math.round(latestViral.viral_score)}</span>
              </div>
              {latestViral.summary && <p className="text-xs text-foreground/80 leading-relaxed">{latestViral.summary}</p>}
            </div>
          )}

          {/* In Portfolio */}
          {holdings.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5" /> In Portfolio ({holdings.length})
              </p>
              {holdings.map(h => (
                <div key={h.id} className="bg-secondary/30 rounded-lg px-3 py-2 text-xs text-muted-foreground mb-1">
                  Qty: <span className="font-mono text-foreground">{h.quantity}</span> @ avg entry{" "}
                  <span className="font-mono text-foreground">${h.average_entry?.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}

          {/* In Watchlists */}
          {watchlistItems.length > 0 && (
            <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
              <Eye className="w-3.5 h-3.5" /> Tracked in {watchlistItems.length} watchlist{watchlistItems.length > 1 ? "s" : ""}
            </div>
          )}

          {/* Tags */}
          {asset.narrative_tags?.length > 0 && (
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">Narrative Tags</p>
              <div className="flex flex-wrap gap-1.5">
                {asset.narrative_tags.map(t => (
                  <span key={t} className="text-[10px] bg-secondary px-2 py-0.5 rounded text-muted-foreground">{t}</span>
                ))}
              </div>
            </div>
          )}

          {/* Research & Trading Links */}
          <div className="border-t border-border pt-4">
            <ResearchLinksSection asset={asset} />
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}