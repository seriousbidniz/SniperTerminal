import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search, Loader2, CheckCircle2, AlertTriangle, ChevronLeft, Coins, BarChart2, Layers
} from "lucide-react";
import AssetSearchResults from "./AssetSearchResults";

const STEPS = { MARKET_TYPE: 1, SEARCH: 2, CONFIRM: 3, FETCHING: 4, DONE: 5 };

const PROVIDER_LABELS = {
  coingecko: "CoinGecko",
  dex_screener: "DEX Screener",
  twelve_data: "Twelve Data",
  alpha_vantage: "Alpha Vantage",
};

const MARKET_ICON = {
  crypto: Coins,
  fx: BarChart2,
  commodity: BarChart2,
  index: Layers,
};

export default function AddAssetDialog({ open, initialSymbol, onClose, onCreated }) {
  const [step, setStep] = useState(STEPS.MARKET_TYPE);
  const [marketType, setMarketType] = useState("");
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  const [searchWarnings, setSearchWarnings] = useState([]);
  const [selectedResult, setSelectedResult] = useState(null);
  const [fetchResult, setFetchResult] = useState(null);
  const [fetchError, setFetchError] = useState(null);
  const [createdAsset, setCreatedAsset] = useState(null);
  const [duplicateError, setDuplicateError] = useState(null);

  const queryClient = useQueryClient();

  const { data: existingAssets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    enabled: open,
  });

  // Reset on open/close
  useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setStep(STEPS.MARKET_TYPE);
        setMarketType("");
        setQuery("");
        setSearchResults([]);
        setSearchWarnings([]);
        setSelectedResult(null);
        setFetchResult(null);
        setFetchError(null);
        setCreatedAsset(null);
        setDuplicateError(null);
      }, 200);
    } else if (initialSymbol) {
      setQuery(initialSymbol);
    }
  }, [open, initialSymbol]);

  const handleSearch = useCallback(async () => {
    if (!query.trim()) return;
    setSearching(true);
    setSearchResults([]);
    setSearchWarnings([]);
    try {
      const res = await base44.functions.invoke("searchAssetProviders", {
        query: query.trim(),
        market_type: marketType,
      });
      setSearchResults(res.data?.results || []);
      setSearchWarnings(res.data?.warnings || []);
    } catch (e) {
      setSearchWarnings([e.message || "Search failed"]);
    } finally {
      setSearching(false);
    }
  }, [query, marketType]);

  const handleSelectResult = (result) => {
    // Check duplicate by provider_asset_id
    const dup = existingAssets.find(
      a => a.provider_asset_id === result.provider_asset_id && a.data_provider === result.provider
    );
    if (dup) {
      setDuplicateError(`${result.name} (${result.symbol}) is already tracked via ${PROVIDER_LABELS[result.provider] || result.provider}.`);
      return;
    }
    setDuplicateError(null);
    setSelectedResult(result);
    setStep(STEPS.CONFIRM);
  };

  const handleConfirmAdd = async () => {
    if (!selectedResult) return;
    setStep(STEPS.FETCHING);
    setFetchError(null);

    try {
      // Create asset record
      const assetData = {
        symbol: selectedResult.symbol,
        name: selectedResult.name,
        market_type: selectedResult.market_type || marketType || "crypto",
        user_added: true,
        status: "pending_data",
        active: false,
        data_provider: selectedResult.provider,
        provider_asset_id: selectedResult.provider_asset_id,
        provider_symbol: selectedResult.provider_symbol,
        chain_id: selectedResult.chain_id || undefined,
        token_address: selectedResult.token_address || undefined,
        pair_address: selectedResult.pair_address || undefined,
        data_status: "pending",
      };

      const created = await base44.entities.Assets.create(assetData);
      setCreatedAsset(created);
      queryClient.invalidateQueries({ queryKey: ["allAssets"] });
      onCreated && onCreated(created);

      // Immediately fetch live market data
      try {
        const dataRes = await base44.functions.invoke("fetchAssetMarketData", { asset_id: created.id });
        setFetchResult(dataRes.data);
        queryClient.invalidateQueries({ queryKey: ["allAssets"] });
        queryClient.invalidateQueries({ queryKey: ["allSnapshots"] });
      } catch (dataErr) {
        setFetchError(dataErr.message || "Live data fetch failed. Asset saved as pending_data.");
      }

      setStep(STEPS.DONE);
    } catch (e) {
      setFetchError(e.message || "Failed to save asset");
      setStep(STEPS.DONE);
    }
  };

  const handleClose = () => {
    onClose();
  };

  const canSearch = query.trim().length >= 1 && !!marketType;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-card border-border max-w-lg max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center gap-2">
            {step > STEPS.MARKET_TYPE && step < STEPS.FETCHING && (
              <button
                onClick={() => setStep(s => s - 1)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
            <DialogTitle>
              {step === STEPS.MARKET_TYPE && "Add Asset — Select Market"}
              {step === STEPS.SEARCH && "Add Asset — Search Provider"}
              {step === STEPS.CONFIRM && "Add Asset — Confirm"}
              {step === STEPS.FETCHING && "Fetching Live Data…"}
              {step === STEPS.DONE && "Asset Added"}
            </DialogTitle>
          </div>
          {/* Step indicator */}
          {step < STEPS.FETCHING && (
            <div className="flex gap-1 mt-2">
              {[1, 2, 3].map(s => (
                <div key={s} className={`h-0.5 flex-1 rounded-full transition-colors ${step >= s ? "bg-primary" : "bg-border"}`} />
              ))}
            </div>
          )}
        </DialogHeader>

        <div className="flex-1 overflow-y-auto min-h-0 py-1">
          {/* ── STEP 1: Pick market type ── */}
          {step === STEPS.MARKET_TYPE && (
            <div className="space-y-3 px-1 py-2">
              <p className="text-xs text-muted-foreground">Choose the market type to route the search to the right provider.</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: "crypto", label: "Crypto", sub: "CoinGecko + DEX Screener", icon: Coins },
                  { value: "fx", label: "FX", sub: "Twelve Data", icon: BarChart2 },
                  { value: "commodity", label: "Commodity", sub: "Twelve Data", icon: BarChart2 },
                  { value: "index", label: "Index / ETF", sub: "Twelve Data", icon: Layers },
                ].map(opt => {
                  const Icon = opt.icon;
                  const selected = marketType === opt.value;
                  return (
                    <button
                      key={opt.value}
                      onClick={() => setMarketType(opt.value)}
                      className={`flex flex-col items-start gap-1 p-3 rounded-xl border text-left transition-all
                        ${selected
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-secondary/30 text-foreground hover:border-primary/40 hover:bg-accent/30"}`}
                    >
                      <Icon className={`w-4 h-4 ${selected ? "text-primary" : "text-muted-foreground"}`} />
                      <span className="text-sm font-semibold">{opt.label}</span>
                      <span className="text-[10px] text-muted-foreground">{opt.sub}</span>
                    </button>
                  );
                })}
              </div>
              <Button
                className="w-full mt-2"
                disabled={!marketType}
                onClick={() => setStep(STEPS.SEARCH)}
              >
                Continue
              </Button>
            </div>
          )}

          {/* ── STEP 2: Search ── */}
          {step === STEPS.SEARCH && (
            <div className="space-y-3 px-1 py-2">
              <p className="text-xs text-muted-foreground">
                Search by name or ticker.{" "}
                {marketType === "crypto"
                  ? "Results from CoinGecko and DEX Screener."
                  : "Results from Twelve Data."}
              </p>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <Input
                    autoFocus
                    placeholder={marketType === "crypto" ? "e.g. Bitcoin, PEPE, SHIB" : "e.g. EUR/USD, GLD, SPX"}
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && canSearch && handleSearch()}
                    className="pl-8 bg-secondary/50 text-sm"
                  />
                </div>
                <Button onClick={handleSearch} disabled={!canSearch || searching} className="shrink-0">
                  {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : "Search"}
                </Button>
              </div>

              {searchWarnings.length > 0 && (
                <div className="space-y-1">
                  {searchWarnings.map((w, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-warning/80 bg-warning/5 border border-warning/20 rounded-lg px-3 py-2">
                      <AlertTriangle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                      {w}
                    </div>
                  ))}
                </div>
              )}

              {duplicateError && (
                <div className="flex items-start gap-2 text-[11px] text-loss bg-loss/5 border border-loss/20 rounded-lg px-3 py-2">
                  <AlertTriangle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                  {duplicateError}
                </div>
              )}

              {searching && (
                <div className="flex items-center justify-center py-8 gap-2 text-xs text-muted-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" /> Searching providers…
                </div>
              )}

              {!searching && searchResults.length > 0 && (
                <AssetSearchResults
                  results={searchResults}
                  marketType={marketType}
                  onSelect={handleSelectResult}
                />
              )}

              {!searching && query && searchResults.length === 0 && !searchWarnings.length && (
                <div className="text-center py-6 text-xs text-muted-foreground">
                  No results found. Try a different name or ticker.
                </div>
              )}
            </div>
          )}

          {/* ── STEP 3: Confirm ── */}
          {step === STEPS.CONFIRM && selectedResult && (
            <div className="space-y-4 px-1 py-2">
              <div className="bg-secondary/30 border border-border rounded-xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono font-bold text-lg">{selectedResult.symbol}</span>
                      <span className="text-[10px] font-semibold px-1.5 py-0.5 bg-primary/10 border border-primary/25 text-primary rounded uppercase tracking-wide">
                        {PROVIDER_LABELS[selectedResult.provider] || selectedResult.provider}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{selectedResult.name}</p>
                  </div>
                  <span className="text-xs bg-secondary px-2 py-0.5 rounded font-medium capitalize">
                    {selectedResult.market_type || marketType}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <InfoRow label="Provider ID" value={selectedResult.provider_asset_id} mono />
                  {selectedResult.exchange && <InfoRow label="Exchange / DEX" value={selectedResult.exchange} />}
                  {selectedResult.chain_id && <InfoRow label="Chain" value={selectedResult.chain_id} />}
                  {selectedResult.token_address && <InfoRow label="Token" value={selectedResult.token_address} mono truncate />}
                  {selectedResult.pair_address && <InfoRow label="Pair" value={selectedResult.pair_address} mono truncate />}
                  {selectedResult.market_cap_rank && <InfoRow label="CMC Rank" value={`#${selectedResult.market_cap_rank}`} />}
                  {selectedResult.liquidity_usd != null && (
                    <InfoRow label="Liquidity" value={`$${Number(selectedResult.liquidity_usd).toLocaleString()}`} />
                  )}
                  {selectedResult.volume_24h != null && (
                    <InfoRow label="24h Vol" value={`$${Number(selectedResult.volume_24h).toLocaleString()}`} />
                  )}
                </div>
              </div>

              <div className="flex items-start gap-2 bg-primary/5 border border-primary/20 rounded-lg px-3 py-2.5 text-xs text-primary/80">
                <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <span>Live market data will be fetched immediately after saving. The asset will enter scoring flows once data is available.</span>
              </div>

              <div className="flex gap-2 pt-1">
                <Button variant="outline" className="flex-1" onClick={() => setStep(STEPS.SEARCH)}>Back</Button>
                <Button className="flex-1" onClick={handleConfirmAdd}>Confirm & Add</Button>
              </div>
            </div>
          )}

          {/* ── STEP 4: Fetching ── */}
          {step === STEPS.FETCHING && (
            <div className="flex flex-col items-center justify-center py-10 gap-3 text-center">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-sm font-medium">Fetching live market data…</p>
              <p className="text-xs text-muted-foreground">Creating first MarketSnapshot from {PROVIDER_LABELS[selectedResult?.provider]}</p>
            </div>
          )}

          {/* ── STEP 5: Done ── */}
          {step === STEPS.DONE && (
            <div className="flex flex-col items-center gap-4 py-8 text-center px-2">
              {fetchError && !fetchResult ? (
                <>
                  <AlertTriangle className="w-10 h-10 text-warning" />
                  <div>
                    <p className="text-sm font-semibold">Asset saved — data fetch failed</p>
                    <p className="text-xs text-muted-foreground mt-1 max-w-sm">{fetchError}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Status set to <span className="font-mono text-warning">pending_data</span>. You can trigger a refresh manually later.
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-10 h-10 text-profit" />
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {selectedResult?.symbol} added successfully
                    </p>
                    {fetchResult?.price != null && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Live price: <span className="font-mono text-foreground">${Number(fetchResult.price).toLocaleString()}</span>
                        {fetchResult.change_24h != null && (
                          <span className={`ml-2 ${fetchResult.change_24h >= 0 ? "text-profit" : "text-loss"}`}>
                            {fetchResult.change_24h >= 0 ? "+" : ""}{fetchResult.change_24h?.toFixed(2)}%
                          </span>
                        )}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      Status: <span className="font-mono text-profit">active</span> — MarketSnapshot created, scoring engines ready.
                    </p>
                  </div>
                </>
              )}
              <Button size="sm" onClick={handleClose}>Done</Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InfoRow({ label, value, mono, truncate }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold">{label}</span>
      <span className={`text-xs text-foreground/90 ${mono ? "font-mono" : ""} ${truncate ? "truncate" : ""}`}>
        {value || "—"}
      </span>
    </div>
  );
}