import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { useStreamStatus } from "@/hooks/useLivePrice";
import { dataAge } from "@/lib/freshness";

function readState(rows, key) {
  const r = rows.find((x) => x.key === key);
  if (!r) return null;
  try { return JSON.parse(r.value); } catch { return null; }
}

function Row({ ok, label, detail }) {
  const dot = ok === true ? "bg-profit" : ok === false ? "bg-loss" : "bg-muted-foreground/50";
  return (
    <div className="flex items-start gap-2.5">
      <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${dot}`} aria-hidden />
      <div className="min-w-0">
        <p className="text-xs font-medium">{label}</p>
        <p className="text-[11px] text-muted-foreground">{detail}</p>
      </div>
    </div>
  );
}

export default function LiveDataStatusCard() {
  const stream = useStreamStatus();
  const { data: rows = [] } = useQuery({
    queryKey: ["systemState"],
    queryFn: () => base44.entities.SystemState.filter({ key: { $in: ["pipeline:last_run", "worker:heartbeat"] } }, "-updated_date", 5),
    refetchInterval: 30_000,
  });
  const pipeline = readState(rows, "pipeline:last_run");
  const worker = readState(rows, "worker:heartbeat");
  const pipelineOk = pipeline?.at ? Date.now() - pipeline.at < 15 * 60_000 : null;
  const workerOk = worker?.at ? Date.now() - worker.at < 2 * 60_000 : null;

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2"><Activity className="w-4 h-4" /> Live data</CardTitle>
        <CardDescription className="text-xs">Where your prices and signal updates come from right now</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Row
          ok={stream === "live" ? true : stream === "idle" ? null : false}
          label="Crypto prices in this browser"
          detail={stream === "live" ? "Streaming from Binance in real time." : stream === "idle" ? "Starts when a crypto signal is on screen." : "Reconnecting to the price stream…"}
        />
        <Row
          ok={workerOk}
          label="Signal monitor (tick-by-tick)"
          detail={worker?.at
            ? `Last seen ${dataAge(new Date(worker.at).toISOString())}. Watching ${worker.binance?.pairs ?? 0} crypto pairs${worker.twelve?.enabled ? ` and ${worker.twelve.symbols} FX/commodity/index symbols` : ""}. ${worker.pushes_delivered ?? 0} notifications sent since start.`
            : "Not running. Entry, target and invalidation alerts fall back to the 5-minute refresh."}
        />
        <Row
          ok={pipelineOk}
          label="Market refresh"
          detail={pipeline?.at
            ? `Last run ${dataAge(new Date(pipeline.at).toISOString())}: ${pipeline.assets} assets, ${pipeline.rec?.created ?? 0} new signals, ${pipeline.lifecycle_events ?? 0} signal updates${pipeline.failed ? `, ${pipeline.failed} assets failed` : ""}.`
            : "No refresh recorded yet."}
        />
      </CardContent>
    </Card>
  );
}
