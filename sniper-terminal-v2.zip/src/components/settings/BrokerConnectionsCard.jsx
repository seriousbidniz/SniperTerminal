import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plug, Loader2, Trash2, ShieldCheck, ShieldAlert, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";
import { dataAge } from "@/lib/freshness";

const STATUS = {
  pending_verification: { icon: Clock, cls: "text-warning", label: "Checking key permissions" },
  verified: { icon: ShieldCheck, cls: "text-profit", label: "Connected, read-only" },
  rejected: { icon: ShieldAlert, cls: "text-loss", label: "Rejected" },
  error: { icon: ShieldAlert, cls: "text-loss", label: "Sync error" },
  revoked: { icon: ShieldAlert, cls: "text-muted-foreground", label: "Revoked" },
};

export default function BrokerConnectionsCard() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ label: "", api_key: "", api_secret: "", days: "30" });

  const { data, isLoading } = useQuery({
    queryKey: ["brokerConnections"],
    queryFn: async () => (await base44.functions.invoke("brokerConnections", { op: "list" })).data,
    refetchInterval: (q) => (q.state.data?.connections?.some((c) => c.status === "pending_verification") ? 10_000 : false),
  });
  const connections = data?.connections || [];

  const call = async (payload, success) => {
    setBusy(true);
    try {
      const res = await base44.functions.invoke("brokerConnections", payload);
      if (res.data?.error) throw new Error(res.data.error);
      toast({ title: success });
      qc.invalidateQueries({ queryKey: ["brokerConnections"] });
      return true;
    } catch (e) {
      toast({ title: "Couldn't update the connection", description: e.response?.data?.error || e.message, variant: "destructive" });
      return false;
    } finally {
      setBusy(false);
    }
  };

  const add = async () => {
    const ok = await call({
      op: "create", broker: "binance", label: form.label,
      api_key: form.api_key.trim(), api_secret: form.api_secret.trim(),
      track_since: new Date(Date.now() - Number(form.days) * 86400_000).toISOString(),
    }, "Key saved — checking it's read-only");
    if (ok) { setForm({ label: "", api_key: "", api_secret: "", days: "30" }); setAdding(false); }
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2"><Plug className="w-4 h-4" /> Broker accounts</CardTitle>
        <CardDescription className="text-xs">
          Read-only sync so the app can see which signals you actually traded and work out your real win rate. The app can't place, change or cancel orders.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading && <p className="text-xs text-muted-foreground">Loading…</p>}
        {connections.map((c) => {
          const st = STATUS[c.status] || STATUS.error;
          const Icon = st.icon;
          return (
            <div key={c.id} className="rounded-lg border border-border px-3 py-2.5 space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold capitalize">{c.broker}</span>
                {c.label && <span className="text-xs text-muted-foreground">{c.label}</span>}
                <span className="text-[11px] font-mono text-muted-foreground">••••{c.key_last4}</span>
                <span className={`ml-auto inline-flex items-center gap-1 text-[11px] ${st.cls}`}><Icon className="w-3.5 h-3.5" /> {st.label}</span>
              </div>
              {c.status_message && <p className="text-[11px] text-muted-foreground">{c.status_message}</p>}
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-muted-foreground">{c.last_sync_at ? `Last synced ${dataAge(c.last_sync_at)}` : "Not synced yet"}</span>
                <Button size="sm" variant="ghost" className="h-7 text-xs text-loss" disabled={busy}
                  onClick={() => window.confirm("Remove this connection? Imported trades stay unless you also clear history.") && call({ op: "delete", id: c.id }, "Connection removed")}>
                  <Trash2 className="w-3.5 h-3.5 mr-1" /> Remove
                </Button>
              </div>
            </div>
          );
        })}

        {!adding ? (
          <Button size="sm" variant="outline" className="text-xs" onClick={() => setAdding(true)}>Connect Binance</Button>
        ) : (
          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 space-y-3">
            <ol className="text-[11px] text-foreground/85 space-y-1 list-decimal pl-4">
              <li>In Binance, go to API Management and create a new system-generated (HMAC) key.</li>
              <li>Tick <span className="font-semibold">Enable Reading</span> only. Leave trading, withdrawals and transfers off.</li>
              <li>Optionally restrict the key to the sync server's IP address.</li>
            </ol>
            <p className="text-[11px] text-muted-foreground">Keys with any trading or withdrawal permission are rejected and deleted automatically. Secrets are encrypted before they're stored.</p>
            <div className="grid gap-2">
              <div><Label htmlFor="bk-label" className="text-[11px]">Name (optional)</Label><Input id="bk-label" className="h-8 text-xs" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Main account" /></div>
              <div><Label htmlFor="bk-key" className="text-[11px]">API key</Label><Input id="bk-key" className="h-8 text-xs font-mono" autoComplete="off" value={form.api_key} onChange={(e) => setForm({ ...form, api_key: e.target.value })} /></div>
              <div><Label htmlFor="bk-secret" className="text-[11px]">Secret key</Label><Input id="bk-secret" type="password" className="h-8 text-xs font-mono" autoComplete="off" value={form.api_secret} onChange={(e) => setForm({ ...form, api_secret: e.target.value })} /></div>
              <div>
                <Label htmlFor="bk-days" className="text-[11px]">Import trades from the last</Label>
                <select id="bk-days" className="h-8 w-full rounded-md border border-input bg-background px-2 text-xs" value={form.days} onChange={(e) => setForm({ ...form, days: e.target.value })}>
                  <option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option><option value="180">180 days</option>
                </select>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="text-xs" disabled={busy || !form.api_key || !form.api_secret} onClick={add}>
                {busy && <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" />} Save and verify
              </Button>
              <Button size="sm" variant="ghost" className="text-xs" onClick={() => setAdding(false)}>Cancel</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
