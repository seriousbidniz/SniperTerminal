import React, { useEffect, useState } from "react";
import { Bell, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useUserSettings } from "@/hooks/useUserSettings";
import { pushSupport, currentSubscription, enablePush, disablePush, sendTestPush } from "@/lib/push";

export default function NotificationsCard() {
  const { settings, save } = useUserSettings();
  const { toast } = useToast();
  const [deviceOn, setDeviceOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const support = typeof window !== "undefined" ? pushSupport() : { supported: false };

  useEffect(() => { currentSubscription().then((s) => setDeviceOn(!!s)).catch(() => {}); }, []);

  const toggleDevice = async (on) => {
    setBusy(true);
    try {
      if (on) {
        await enablePush();
        setDeviceOn(true);
        toast({ title: "Notifications on", description: "This device will get signal alerts." });
      } else {
        await disablePush();
        setDeviceOn(false);
        toast({ title: "Notifications off for this device" });
      }
    } catch (e) {
      toast({ title: "Couldn't change notifications", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const test = async () => {
    setBusy(true);
    try {
      const r = await sendTestPush();
      toast({ title: "Test notification queued", description: r?.note });
    } catch (e) {
      toast({ title: "Test failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2"><Bell className="w-4 h-4" /> Notifications</CardTitle>
        <CardDescription className="text-xs">Push alerts to this phone or computer, even when the app is closed</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <Label htmlFor="push-device" className="text-xs">Push on this device</Label>
            {!support.supported && <p className="text-[11px] text-warning mt-0.5">{support.reason}</p>}
          </div>
          <div className="flex items-center gap-2">
            {busy && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
            <Switch id="push-device" checked={deviceOn} disabled={busy || (!support.supported && !deviceOn)} onCheckedChange={toggleDevice} />
          </div>
        </div>

        <div className="space-y-3 border-t border-border pt-3">
          <div className="flex items-center justify-between gap-3">
            <Label className="text-xs">New signals scoring at least</Label>
            <Select value={String(settings.push_new_signals_min_score)} onValueChange={(v) => save({ push_new_signals_min_score: Number(v) })}>
              <SelectTrigger className="h-7 w-[90px] text-xs"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                {[60, 70, 75, 80, 85, 90, 101].map((n) => <SelectItem key={n} value={String(n)}>{n > 100 ? "Never" : n}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between gap-3">
            <Label className="text-xs">Entry, target and invalidation alerts</Label>
            <Select value={settings.push_lifecycle} onValueChange={(v) => save({ push_lifecycle: v })}>
              <SelectTrigger className="h-7 w-[150px] text-xs"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="executed_only">Trades I took</SelectItem>
                <SelectItem value="all">Every signal</SelectItem>
                <SelectItem value="off">Off</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <p className="text-[11px] text-muted-foreground -mt-1">"Trades I took" needs a connected broker so the app knows which signals you executed.</p>
          <div className="flex items-center justify-between gap-3">
            <Label htmlFor="push-viral" className="text-xs">Tradable viral moves</Label>
            <Switch id="push-viral" checked={!!settings.push_viral} onCheckedChange={(v) => save({ push_viral: v })} />
          </div>
        </div>

        <Button size="sm" variant="outline" className="text-xs" disabled={!deviceOn || busy} onClick={test}>Send a test notification</Button>
      </CardContent>
    </Card>
  );
}
