import React from "react";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function DirectionBadge({ direction }) {
  if (direction === "bullish") {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-profit bg-profit/10 border border-profit/30 px-2 py-0.5 rounded-full">
        <TrendingUp className="w-3 h-3" /> Bullish
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs font-medium text-loss bg-loss/10 border border-loss/30 px-2 py-0.5 rounded-full">
      <TrendingDown className="w-3 h-3" /> Bearish
    </span>
  );
}