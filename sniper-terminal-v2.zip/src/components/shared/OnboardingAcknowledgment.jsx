import React, { useState, useEffect } from "react";
import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * One-time onboarding acknowledgment modal.
 * Shows once per user to establish informed consent.
 * Stored in localStorage.
 */

const STORAGE_KEY = "sniperTerminal_onboardingAcknowledged";

export default function OnboardingAcknowledgment() {
  const [visible, setVisible] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const acknowledged = localStorage.getItem(STORAGE_KEY);
    if (!acknowledged) {
      setVisible(true);
    }
  }, []);

  const handleAcknowledge = () => {
    if (checked) {
      localStorage.setItem(STORAGE_KEY, "true");
      setVisible(false);
    }
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-card border-2 border-loss/40 rounded-xl max-w-md w-full shadow-xl">
        {/* Header */}
        <div className="bg-loss/15 border-b border-loss/30 px-6 py-4 flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-loss flex-shrink-0" />
          <h2 className="text-lg font-black text-loss">Important Disclosure</h2>
        </div>

        {/* Content */}
        <div className="px-6 py-6 space-y-4">
          <p className="text-sm text-foreground/90 leading-relaxed">
            <strong>Sniper Terminal is a market analysis tool only — it does NOT provide financial advice.</strong>
          </p>

          <ul className="text-xs text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>You assume all risk.</strong> All signals are for speculative analysis. You are solely responsible for your trading decisions.</li>
            <li><strong>No guarantees.</strong> Past performance ≠ future results. Signals may be wrong, data may be stale, or algorithms may contain errors.</li>
            <li><strong>Extreme risk.</strong> Trading carries a substantial risk of loss — you can lose your entire investment or more with leverage.</li>
            <li><strong>Only trade what you can afford to lose.</strong> Do not risk money needed for living expenses, debt repayment, or savings.</li>
            <li><strong>Consult professionals.</strong> Seek independent financial, tax, and legal advice before trading.</li>
          </ul>

          <div className="bg-secondary/30 border border-border rounded-lg px-3 py-2.5">
            <p className="text-[11px] text-muted-foreground/80 leading-relaxed">
              By continuing, you acknowledge that you have read, understood, and accept the <a href="/terms" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Terms of Service</a>, <a href="/privacy-policy" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Privacy Policy</a>, and <a href="/risk-disclaimer" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Risk Disclaimer</a>.
            </p>
          </div>

          {/* Checkbox */}
          <label className="flex items-start gap-2 p-3 bg-secondary/20 rounded-lg border border-border cursor-pointer hover:bg-secondary/30 transition-colors">
            <input
              type="checkbox"
              checked={checked}
              onChange={(e) => setChecked(e.target.checked)}
              className="mt-1 cursor-pointer"
            />
            <span className="text-xs text-foreground/90">
              I have read the risk disclosures and acknowledge that I trade at my own risk. I am responsible for my decisions. <strong>I will not hold Sniper Terminal liable for any losses.</strong>
            </span>
          </label>
        </div>

        {/* Footer */}
        <div className="border-t border-border px-6 py-4 flex gap-2 justify-end">
          <Button
            size="sm"
            onClick={handleAcknowledge}
            disabled={!checked}
            className="text-xs"
          >
            <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />
            I Accept & Continue
          </Button>
        </div>
      </div>
    </div>
  );
}