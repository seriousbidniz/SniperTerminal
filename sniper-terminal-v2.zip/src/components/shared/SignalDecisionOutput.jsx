import React from "react";
import { Zap, Clock, ShieldOff, TrendingDown } from "lucide-react";

/**
 * Derives an explicit action recommendation from signal inputs.
 * Works for both RecommendedTradeSignals and ViralTradeSignals.
 */

function norm(v, fallback = 50) {
  return v == null || isNaN(v) ? fallback : Math.max(0, Math.min(100, v));
}

export function deriveDecision(signal) {
  const opp       = norm(signal.opportunity_score ?? signal.viral_score ?? 50);
  const risk      = norm(signal.risk_score ?? 50);
  const exhaustion = norm(signal.exhaustion_score ?? 30);
  const liquidity = norm(signal.liquidity_score ?? signal.liquidity_quality_score ?? 50);
  const label     = signal.ai_label;

  // Hard avoid conditions
  if (label === "avoid") {
    return {
      id: "avoid",
      label: "Avoid",
      description: "Liquidity or exhaustion conditions make this untradeable at this time.",
      icon: ShieldOff,
      color: "text-loss",
      bg: "bg-loss/10",
      border: "border-loss/30",
    };
  }

  // Reduce position — high risk or high exhaustion overrides opportunity
  if (risk >= 65 || exhaustion >= 60 || liquidity < 30) {
    return {
      id: "reduce",
      label: "Risk Conditions Elevated — Consider Reducing Exposure",
      description: "Risk, exhaustion, or liquidity conditions are unfavourable. Consider reducing or avoiding new exposure.",
      icon: TrendingDown,
      color: "text-warning",
      bg: "bg-warning/10",
      border: "border-warning/30",
    };
  }

  // Wait — moderate setup or caution label
  if (label === "caution" || opp < 58 || (risk >= 50 && exhaustion >= 40)) {
    return {
      id: "wait",
      label: "Wait for Confirmation",
      description: "Setup exists but conditions are not fully aligned. Wait for a cleaner entry signal.",
      icon: Clock,
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/30",
    };
  }

  // Enter — high opp, manageable risk, healthy liquidity
  if (opp >= 65 && risk < 50 && liquidity >= 45 && exhaustion < 45) {
    return {
      id: "enter",
      label: "Conditions Aligned for Entry Evaluation",
      description: "Opportunity, risk, and liquidity conditions align. Setup meets minimum quality thresholds for independent evaluation. This is NOT a recommendation to trade.",
      icon: Zap,
      color: "text-profit",
      bg: "bg-profit/10",
      border: "border-profit/30",
    };
  }

  // Default to wait
  return {
    id: "wait",
    label: "Wait for Confirmation",
    description: "Setup is emerging but not all conditions are fully aligned yet.",
    icon: Clock,
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/30",
  };
}

export default function SignalDecisionOutput({ signal }) {
  const decision = deriveDecision(signal);
  const Icon = decision.icon;

  return (
    <div className={`rounded-xl border px-4 py-3 ${decision.bg} ${decision.border}`}>
      <div className={`flex items-center gap-2 mb-1.5 ${decision.color}`}>
        <Icon className="w-4 h-4" />
        <span className="text-sm font-bold">{decision.label}</span>
        <span className="ml-auto text-[9px] font-semibold uppercase tracking-widest opacity-60">Decision Output</span>
      </div>
      <p className="text-xs text-foreground/80 leading-relaxed">{decision.description}</p>
      <p className="text-[10px] text-muted-foreground/50 mt-2">Not financial advice. Validate independently before acting.</p>
    </div>
  );
}