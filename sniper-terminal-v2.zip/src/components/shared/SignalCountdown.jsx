import React from "react";
import { Timer, ShieldAlert, CheckCircle2, XCircle, Radio } from "lucide-react";
import { useNow } from "@/hooks/useNow";
import { useLivePrice } from "@/hooks/useLivePrice";
import { signalTiming, STATE_COPY } from "@/lib/signalTiming";
import { formatDuration, formatPrice } from "@/lib/format";

function tone(t) {
  if (t.state === "invalidated" || t.state === "breached") return { text: "text-loss", bg: "bg-loss/10", border: "border-loss/30", bar: "bg-loss" };
  if (!t.live) return { text: "text-muted-foreground", bg: "bg-secondary/40", border: "border-border", bar: "bg-muted-foreground/40" };
  if (t.state === "target_hit") return { text: "text-profit", bg: "bg-profit/10", border: "border-profit/30", bar: "bg-profit" };
  if (t.urgent) return { text: "text-warning", bg: "bg-warning/10", border: "border-warning/30", bar: "bg-warning" };
  return { text: "text-primary", bg: "bg-primary/10", border: "border-primary/25", bar: "bg-primary" };
}

/**
 * Live expiry + invalidation countdown.
 *  variant="compact" — one-line pill for list rows and cards
 *  variant="full"    — drawer panel with progress, entry window and live distance to the stop
 * Pass `asset` (for live crypto prices) and `fallbackPrice` (latest snapshot).
 */
export default function SignalCountdown({ signal, asset, fallbackPrice = null, fallbackTs = null, variant = "compact" }) {
  const now = useNow();
  const mt = asset?.market_type || signal.market_type;
  const { price, live } = useLivePrice(asset, fallbackPrice ?? signal.last_price ?? null, fallbackTs ?? signal.last_price_at);
  const t = signalTiming(signal, price, now);
  const c = tone(t);
  const Icon = t.state === "target_hit" ? CheckCircle2 : t.state === "invalidated" || t.state === "breached" ? XCircle : t.urgent ? ShieldAlert : Timer;

  if (variant === "compact") {
    return (
      <span
        className={`inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded border whitespace-nowrap ${c.text} ${c.bg} ${c.border}`}
        title={`${STATE_COPY[t.state]}${t.estimated ? " (expiry estimated)" : ""}${t.distPct != null ? ` — ${t.distPct.toFixed(2)}% from invalidation` : ""}`}
      >
        <Icon className="w-3 h-3" />
        {t.live ? `${t.estimated ? "~" : ""}${formatDuration(t.remaining)}` : STATE_COPY[t.state]}
        {t.live && t.distPct != null && <span className="opacity-70">· {t.distPct.toFixed(1)}% to stop</span>}
      </span>
    );
  }

  return (
    <div className={`rounded-xl border px-4 py-3 space-y-2.5 ${c.bg} ${c.border}`} aria-live="polite">
      <div className="flex items-center gap-2">
        <Icon className={`w-4 h-4 ${c.text}`} />
        <span className={`text-xs font-bold ${c.text}`}>{STATE_COPY[t.state]}</span>
        {live && (
          <span className="ml-auto inline-flex items-center gap-1 text-[10px] text-profit">
            <Radio className="w-3 h-3" /> Live price
          </span>
        )}
      </div>

      {t.live && (
        <>
          <div className="flex items-baseline justify-between">
            <span className="text-[11px] text-muted-foreground">Signal expires in</span>
            <span className={`text-lg font-mono font-bold tabular-nums ${c.text}`}>
              {t.estimated ? "~" : ""}{formatDuration(t.remaining)}
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-background/60 overflow-hidden" role="progressbar" aria-valuenow={Math.round(t.elapsedFrac * 100)} aria-valuemin={0} aria-valuemax={100} aria-label="Signal time elapsed">
            <div className={`h-full ${c.bar} transition-[width] duration-1000`} style={{ width: `${t.elapsedFrac * 100}%` }} />
          </div>
          <p className="text-[10px] text-muted-foreground">
            Void after {new Date(t.expiresAt).toLocaleString("en-GB", { weekday: "short", hour: "2-digit", minute: "2-digit" })}
            {t.estimated && " (estimated — signal predates hard expiries)"}
          </p>
          {t.entryRemaining != null && (
            <p className="text-[11px] text-foreground/80">
              {t.entryRemaining > 0
                ? <>Entry zone must trade within <span className="font-mono font-semibold">{formatDuration(t.entryRemaining)}</span> or the setup is dropped.</>
                : "Entry window has passed — the setup lapses at the next check unless price is in the zone."}
            </p>
          )}
        </>
      )}

      {signal.invalidation != null && (
        <div className="grid grid-cols-3 gap-2 pt-1">
          <div>
            <p className="text-[10px] text-muted-foreground">Price</p>
            <p className="text-xs font-mono font-semibold">{formatPrice(price, mt)}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground">Invalidation</p>
            <p className="text-xs font-mono font-semibold text-loss">{formatPrice(signal.invalidation, mt)}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground">Distance</p>
            <p className={`text-xs font-mono font-semibold ${t.breached ? "text-loss" : t.urgent ? "text-warning" : ""}`}>
              {t.distPct == null ? "—" : `${t.distPct.toFixed(2)}%`}
              {t.distAtr != null && <span className="text-muted-foreground font-normal"> ({t.distAtr.toFixed(1)} ATR)</span>}
            </p>
          </div>
        </div>
      )}
      {t.state === "breached" && (
        <p className="text-[11px] text-loss">Price has traded through the invalidation level. The thesis is void; the server will confirm on its next check.</p>
      )}
    </div>
  );
}
