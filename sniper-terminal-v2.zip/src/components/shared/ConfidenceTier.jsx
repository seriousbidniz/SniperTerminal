import React from "react";

/**
 * A/B/C/D Trade Stack Confidence Tier badge.
 * Derived from opportunity, risk, multi-signal alignment, and data quality.
 */

export function deriveTierGrade(signal) {
  const opp      = signal.opportunity_score ?? signal.viral_score ?? 0;
  const risk     = signal.risk_score ?? 50;
  const exhaust  = signal.exhaustion_score ?? 30;
  const liq      = signal.liquidity_score ?? signal.liquidity_quality_score ?? 50;
  const dq       = signal.data_quality;
  const label    = signal.ai_label;

  // Hard D — incomplete or avoid
  if (dq === "full_fallback" || label === "avoid" || exhaust >= 65) {
    return { grade: "D", label: "Conflicting", color: "text-loss", bg: "bg-loss/15", border: "border-loss/40", description: "Conflicting or incomplete signals. Do not trade." };
  }

  // Score composite
  const oppW  = Math.min(opp, 100) * 0.40;
  const riskW = (100 - Math.min(risk, 100)) * 0.30;
  const liqW  = Math.min(liq, 100) * 0.20;
  const dqW   = dq === "live" ? 10 : dq === "partial" ? 5 : 0;
  const composite = oppW + riskW + liqW + dqW;

  if (composite >= 75) return { grade: "A", label: "Aligned",    color: "text-profit",          bg: "bg-profit/15",  border: "border-profit/40",  description: "Strong multi-signal alignment. Highest confidence tier." };
  if (composite >= 58) return { grade: "B", label: "Moderate",   color: "text-primary",          bg: "bg-primary/15", border: "border-primary/40", description: "Reasonable alignment with minor caveats." };
  if (composite >= 42) return { grade: "C", label: "Weak",       color: "text-warning",          bg: "bg-warning/15", border: "border-warning/40", description: "Mixed signals. Size down significantly if acting." };
  return                      { grade: "D", label: "Conflicting", color: "text-loss",             bg: "bg-loss/15",    border: "border-loss/40",    description: "Conflicting or incomplete signals. Do not trade." };
}

export default function ConfidenceTier({ signal, showLabel = true }) {
  const tier = deriveTierGrade(signal);
  return (
    <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-lg border font-bold ${tier.color} ${tier.bg} ${tier.border}`}>
      <span className="text-base leading-none font-black">{tier.grade}</span>
      {showLabel && <span className="text-[9px] uppercase tracking-widest">{tier.label}</span>}
    </div>
  );
}