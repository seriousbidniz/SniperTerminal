import React from "react";
import { TrendingUp, Zap, AlertTriangle, Layers, RotateCcw, ShieldAlert, Activity } from "lucide-react";

/**
 * Derives the dominant "why this trade exists" reason from signal inputs.
 * Works for both RecommendedTradeSignals and ViralTradeSignals.
 *
 * Returns: { id, label, description, icon, color, bg, border }
 */

function norm(v) {
  return v == null || isNaN(v) ? 50 : Math.max(0, Math.min(100, v));
}

export function deriveTradeReason(signal) {
  // Support both recommended and viral signal shapes
  const trend       = norm(signal.trend_score_input);
  const momentum    = norm(signal.momentum_score_input);
  const volatility  = norm(signal.volatility ?? signal.volatility_score_input ?? 30);
  const liquidity   = norm(signal.liquidity_score ?? signal.liquidity_quality_score ?? 50);
  const attention   = norm(signal.attention_score ?? signal.attention_score_input ?? 50);
  const catalyst    = norm(signal.catalyst_score_input ?? 50);
  const sentiment   = norm(signal.sentiment_score_input ?? signal.sentiment_spike_score ?? 50);
  const rsi         = signal.rsi ?? null;
  const viral       = signal.viral_score ?? null;
  const volSpike    = signal.volume_spike_score ?? 0;

  // ── Pattern matching (order = priority) ──────────────────────────────────

  // 1. Crowd-driven attention spike: high attention + low liquidity
  if (attention >= 65 && liquidity < 45) {
    return {
      id: "crowd_spike",
      label: "Crowd Attention Spike",
      description: "High social/search attention with thin liquidity — likely a short-term crowd-driven move. Late entries face sharp reversal risk.",
      icon: Zap,
      color: "text-warning",
      bg: "bg-warning/10",
      border: "border-warning/30",
    };
  }

  // 2. Strong continuation: trend + momentum aligned, low volatility, decent liquidity
  if (trend >= 62 && momentum >= 62 && volatility < 45 && liquidity >= 50) {
    return {
      id: "continuation",
      label: "Trend Continuation",
      description: "Momentum and trend are aligned in a low-volatility environment with solid liquidity — conditions favour a controlled continuation setup.",
      icon: TrendingUp,
      color: "text-profit",
      bg: "bg-profit/10",
      border: "border-profit/30",
    };
  }

  // 3. Reversal: RSI extreme + opposing momentum
  if (rsi != null && (rsi > 72 || rsi < 28) && (momentum >= 58 || momentum <= 42)) {
    return {
      id: "reversal",
      label: "Reversal Signal",
      description: `RSI at ${Math.round(rsi)} — overextended conditions with a momentum shift. This is a mean-reversion setup, not a trend follow.`,
      icon: RotateCcw,
      color: "text-viral",
      bg: "bg-viral/10",
      border: "border-viral/30",
    };
  }

  // 4. Volume breakout: high volume spike + positive momentum
  if (volSpike >= 50 && momentum >= 58) {
    return {
      id: "volume_breakout",
      label: "Volume-Led Breakout",
      description: "Abnormal volume surge accompanied by strong momentum — suggests institutional or high-conviction participation driving the move.",
      icon: Activity,
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/30",
    };
  }

  // 5. High-risk viral: viral + low liquidity
  if (viral != null && viral >= 55 && liquidity < 40) {
    return {
      id: "viral_danger",
      label: "Viral — Low Liquidity",
      description: "Asset is trending virally but lacks the liquidity to support safe position sizing. High slippage and reversal risk at current crowd levels.",
      icon: ShieldAlert,
      color: "text-loss",
      bg: "bg-loss/10",
      border: "border-loss/30",
    };
  }

  // 6. Catalyst-driven: strong catalyst score
  if (catalyst >= 68) {
    return {
      id: "catalyst",
      label: "Catalyst-Driven",
      description: "A material catalyst is supporting this move. Score reflects event quality — validate the catalyst is still live before entering.",
      icon: Layers,
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/30",
    };
  }

  // 7. Weak/mixed: no dominant driver
  if (trend < 52 && momentum < 52 && attention < 52) {
    return {
      id: "mixed",
      label: "Mixed — No Dominant Driver",
      description: "No single indicator is strongly in control. Setup passes minimum thresholds across multiple factors but lacks a clear dominant catalyst.",
      icon: AlertTriangle,
      color: "text-muted-foreground",
      bg: "bg-secondary/40",
      border: "border-border",
    };
  }

  // 8. Default: momentum-led
  return {
    id: "momentum_led",
    label: "Momentum-Led",
    description: "Short-term price momentum is the primary driver. Trend confirmation is partial — watch for continuation vs fade at key levels.",
    icon: TrendingUp,
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/30",
  };
}

/**
 * Compact inline pill — use in tables, cards
 */
export function TradeReasonPill({ signal, className = "" }) {
  const reason = deriveTradeReason(signal);
  const Icon = reason.icon;
  return (
    <span
      className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded border whitespace-nowrap ${reason.color} ${reason.bg} ${reason.border} ${className}`}
      title={reason.description}
    >
      <Icon className="w-2.5 h-2.5 flex-shrink-0" />
      {reason.label}
    </span>
  );
}

/**
 * Full block — use in drawers/detail views
 */
export function TradeReasonBlock({ signal }) {
  const reason = deriveTradeReason(signal);
  const Icon = reason.icon;
  return (
    <div className={`rounded-xl border px-4 py-3 ${reason.bg} ${reason.border}`}>
      <div className={`flex items-center gap-2 text-xs font-bold mb-1.5 ${reason.color}`}>
        <Icon className="w-3.5 h-3.5" />
        <span>Why This Trade Exists</span>
        <span className="ml-auto text-[9px] font-semibold opacity-70 uppercase tracking-wider">{reason.label}</span>
      </div>
      <p className="text-xs text-foreground/80 leading-relaxed">{reason.description}</p>
    </div>
  );
}