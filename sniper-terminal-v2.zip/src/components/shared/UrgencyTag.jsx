import React from "react";
import { deriveTimeExpectation } from "./SignalTimeExpectation";

/**
 * Compressed urgency tag — replaces verbose time labels with 3 states.
 * 🔥 Immediate | ⏳ Developing | 💤 Low Priority
 */

export function deriveUrgency(signal) {
  const time = deriveTimeExpectation(signal);
  if (time.id === "immediate") return { emoji: "🔥", label: "Immediate", color: "text-loss", bg: "bg-loss/10", border: "border-loss/30" };
  if (time.id === "short")     return { emoji: "⏳", label: "Developing", color: "text-warning", bg: "bg-warning/10", border: "border-warning/30" };
  return                              { emoji: "💤", label: "Low Priority", color: "text-muted-foreground", bg: "bg-secondary/40", border: "border-border" };
}

export default function UrgencyTag({ signal, className = "" }) {
  const u = deriveUrgency(signal);
  return (
    <span className={`inline-flex items-center gap-1 text-[9px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded border ${u.color} ${u.bg} ${u.border} ${className}`}>
      <span>{u.emoji}</span>
      {u.label}
    </span>
  );
}