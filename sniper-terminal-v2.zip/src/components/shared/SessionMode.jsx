import React, { createContext, useContext, useState } from "react";
import { Zap, Moon } from "lucide-react";

/**
 * Session Mode — Intraday vs Swing.
 * Provides a context consumed by scoring/display components.
 *
 * Intraday:  tighter thresholds, higher urgency weight, prefer immediate setups
 * Swing:     wider thresholds, medium-term windows, deprioritise viral
 */

const SessionModeContext = createContext({ mode: "swing", setMode: () => {} });

export function SessionModeProvider({ children }) {
  const [mode, setMode] = useState("swing");
  return (
    <SessionModeContext.Provider value={{ mode, setMode }}>
      {children}
    </SessionModeContext.Provider>
  );
}

export function useSessionMode() {
  return useContext(SessionModeContext);
}

/**
 * Returns session-adjusted thresholds for scoring/filtering.
 */
export function getSessionThresholds(mode) {
  if (mode === "intraday") {
    return {
      minOppScore: 62,     // tighter — need cleaner setup
      maxRiskScore: 55,    // less tolerance
      minLiquidity: 55,    // must be liquid enough for fast in/out
      preferUrgency: ["immediate"],
      label: "Intraday",
      description: "Fast-moving setups only. Immediate urgency preferred.",
    };
  }
  return {
    minOppScore: 52,
    maxRiskScore: 65,
    minLiquidity: 40,
    preferUrgency: ["immediate", "short", "medium"],
    label: "Swing",
    description: "Medium-term setups. All urgency windows considered.",
  };
}

/**
 * Toggle button — compact, used in headers
 */
export function SessionModeToggle({ className = "" }) {
  const { mode, setMode } = useSessionMode();
  const isIntraday = mode === "intraday";
  return (
    <div className={`flex items-center rounded-lg border border-border overflow-hidden ${className}`}>
      <button
        onClick={() => setMode("intraday")}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-widest transition-colors ${
          isIntraday ? "bg-warning/20 text-warning border-r border-warning/30" : "text-muted-foreground hover:text-foreground border-r border-border"
        }`}
      >
        <Zap className="w-3 h-3" />
        Intraday
      </button>
      <button
        onClick={() => setMode("swing")}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-widest transition-colors ${
          !isIntraday ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Moon className="w-3 h-3" />
        Swing
      </button>
    </div>
  );
}