import React from "react";
import { AlertTriangle } from "lucide-react";

export default function StaleDataBanner({ message }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 bg-warning/10 border border-warning/20 rounded-md text-warning text-xs">
      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
      <span>{message || "Data may be stale. Confidence reduced."}</span>
    </div>
  );
}