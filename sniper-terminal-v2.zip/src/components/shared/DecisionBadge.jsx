import React from "react";
import { Zap, Clock, TrendingDown, ShieldOff } from "lucide-react";
import { deriveDecision } from "./SignalDecisionOutput";

/**
 * Dominant single-glance decision badge.
 * size: "sm" | "md" | "lg"
 */

const CONFIG = {
  enter:  { icon: Zap,          label: "CONDITIONS ALIGNED",  classes: "text-profit bg-profit/15 border-profit/50 shadow-[0_0_12px_rgba(16,185,129,0.2)]" },
  wait:   { icon: Clock,        label: "WAIT",        classes: "text-primary bg-primary/15 border-primary/50" },
  reduce: { icon: TrendingDown, label: "REDUCE EXPOSURE",      classes: "text-warning bg-warning/15 border-warning/50" },
  avoid:  { icon: ShieldOff,    label: "AVOID",       classes: "text-loss bg-loss/15 border-loss/50 shadow-[0_0_12px_rgba(239,68,68,0.2)]" },
};

export default function DecisionBadge({ signal, size = "md" }) {
  const decision = deriveDecision(signal);
  const cfg = CONFIG[decision.id] || CONFIG.wait;
  const Icon = cfg.icon;

  const sizes = {
    sm: { wrap: "px-1.5 py-0.5 text-[9px] gap-1 rounded", icon: "w-2.5 h-2.5" },
    md: { wrap: "px-2.5 py-1 text-[10px] gap-1.5 rounded-lg", icon: "w-3 h-3" },
    lg: { wrap: "px-4 py-2 text-sm gap-2 rounded-xl font-black tracking-widest", icon: "w-4 h-4" },
  };

  const s = sizes[size] || sizes.md;

  return (
    <span className={`inline-flex items-center border font-bold uppercase tracking-widest ${cfg.classes} ${s.wrap}`}>
      <Icon className={`flex-shrink-0 ${s.icon}`} />
      {cfg.label}
    </span>
  );
}