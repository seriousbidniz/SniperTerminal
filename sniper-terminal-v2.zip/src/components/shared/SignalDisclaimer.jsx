import React from "react";
import { AlertTriangle } from "lucide-react";

/**
 * Signal disclaimer banner — used in all detail drawers.
 * Emphasizes non-advisory nature, illustrative intent, model assumptions.
 */

export default function SignalDisclaimer({ signalType = "recommended" }) {
  const messages = {
    recommended: "This signal reflects market analysis only — NOT a trading recommendation. Illustrative scenarios are based on model assumptions. Not tailored financial advice.",
    viral: "Virality measures social attention, not trade quality. This is NOT a recommendation. Late entries into viral moves face extreme loss risk.",
    alert: "This alert reflects rule-based analysis only. Not financial advice or a recommendation to trade.",
  };

  return (
    <div className="flex items-start gap-2.5 bg-loss/5 border border-loss/20 rounded-lg px-3 py-2.5 text-[11px] text-loss/75">
      <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
      <p className="leading-relaxed">
        <strong>Disclaimer:</strong> {messages[signalType]} Conduct independent research and consult financial professionals before making any trading decisions.
      </p>
    </div>
  );
}