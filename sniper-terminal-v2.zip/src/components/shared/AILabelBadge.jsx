import React from "react";

const labelStyles = {
  tradable: "text-profit bg-profit/10 border-profit/30",
  caution: "text-warning bg-warning/10 border-warning/30",
  avoid: "text-loss bg-loss/10 border-loss/30",
};

export default function AILabelBadge({ label }) {
  if (!label) return null;
  return (
    <span className={`inline-flex text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded border ${labelStyles[label] || labelStyles.caution}`}>
      {label}
    </span>
  );
}