import React from "react";

const stateStyles = {
  early: "text-profit bg-profit/10 border-profit/30",
  building: "text-primary bg-primary/10 border-primary/30",
  crowded: "text-warning bg-warning/10 border-warning/30",
  exhausted: "text-loss bg-loss/10 border-loss/30",
};

export default function MoveStateBadge({ state }) {
  if (!state) return null;
  return (
    <span className={`inline-flex text-[11px] font-medium px-2 py-0.5 rounded border ${stateStyles[state] || stateStyles.building}`}>
      {state.charAt(0).toUpperCase() + state.slice(1)}
    </span>
  );
}