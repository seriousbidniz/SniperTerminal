import React from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ShieldCheck, AlertTriangle, Minus } from "lucide-react";

/**
 * Cross-signal confidence tier for a given asset.
 * Reads the active viral signal for the same asset and combines it
 * with the recommended signal to produce a unified confidence tier.
 */

function norm(v, fallback = 50) {
  return v == null || isNaN(v) ? fallback : Math.max(0, Math.min(100, v));
}

function deriveTier(recSignal, viralSignal) {
  const opp      = norm(recSignal?.opportunity_score ?? 0);
  const risk     = norm(recSignal?.risk_score ?? 50);
  const viralScore = norm(viralSignal?.viral_score ?? 0);
  const moveState  = viralSignal?.move_state;
  const aiLabel    = viralSignal?.ai_label;
  const recDir   = recSignal?.direction;

  const signals = [];

  // Recommended signal alignment
  if (opp >= 70 && risk < 40) signals.push({ label: `Recommended ${recDir}`, positive: true });
  else if (opp >= 55) signals.push({ label: `Recommended ${recDir} (moderate)`, positive: null });
  else signals.push({ label: "Weak recommended signal", positive: false });

  // Viral alignment
  if (viralSignal) {
    if ((moveState === "early" || moveState === "building") && aiLabel === "tradable") {
      signals.push({ label: `Viral: ${moveState} — tradable`, positive: true });
    } else if (aiLabel === "caution") {
      signals.push({ label: `Viral: ${aiLabel}`, positive: null });
    } else if (aiLabel === "avoid") {
      signals.push({ label: `Viral: avoid`, positive: false });
    }
  } else {
    signals.push({ label: "No viral signal", positive: null });
  }

  // Risk level
  if (risk < 35) signals.push({ label: "Risk: low", positive: true });
  else if (risk < 60) signals.push({ label: "Risk: moderate", positive: null });
  else signals.push({ label: "Risk: high", positive: false });

  const positives = signals.filter(s => s.positive === true).length;
  const negatives = signals.filter(s => s.positive === false).length;

  if (positives >= 2 && negatives === 0) {
    return {
      tier: "HIGH CONFIDENCE",
      color: "text-profit",
      bg: "bg-profit/10",
      border: "border-profit/30",
      icon: ShieldCheck,
      description: "Multiple independent signals agree. Conditions are aligned across recommended, viral, and risk dimensions.",
      signals,
    };
  }
  if (negatives >= 2) {
    return {
      tier: "LOW CONFIDENCE",
      color: "text-loss",
      bg: "bg-loss/10",
      border: "border-loss/30",
      icon: AlertTriangle,
      description: "Significant conflicts between signals. Treat this setup with high scepticism.",
      signals,
    };
  }
  return {
    tier: "MEDIUM CONFIDENCE",
    color: "text-warning",
    bg: "bg-warning/10",
    border: "border-warning/30",
    icon: Minus,
    description: "Mixed alignment — some signals support the setup, others are neutral or conflicting. Size down.",
    signals,
  };
}

export default function MultiSignalAlignment({ signal }) {
  const assetId = signal?.asset;

  const { data: viralSignals = [] } = useQuery({
    queryKey: ["viralForAsset", assetId],
    queryFn: () => assetId
      ? base44.entities.ViralTradeSignals.filter({ asset: assetId, status: { $in: LIVE_SIGNAL_STATUSES } }, "-timestamp", 1)
      : Promise.resolve([]),
    enabled: !!assetId,
    staleTime: 30_000,
  });

  const viralSignal = viralSignals[0] || null;
  const result = deriveTier(signal, viralSignal);
  const Icon = result.icon;

  return (
    <div className={`rounded-xl border px-4 py-3 ${result.bg} ${result.border}`}>
      <div className={`flex items-center gap-2 mb-2 ${result.color}`}>
        <Icon className="w-4 h-4" />
        <span className="text-xs font-black tracking-wide">{result.tier}</span>
        <span className="ml-auto text-[9px] font-semibold uppercase tracking-widest opacity-50">Multi-Signal</span>
      </div>
      <p className="text-xs text-foreground/80 leading-relaxed mb-2">{result.description}</p>
      <div className="space-y-1">
        {result.signals.map((s, i) => (
          <div key={i} className="flex items-center gap-2 text-[11px]">
            <span className={
              s.positive === true ? "text-profit" :
              s.positive === false ? "text-loss" :
              "text-muted-foreground"
            }>
              {s.positive === true ? "✓" : s.positive === false ? "✗" : "–"}
            </span>
            <span className="text-foreground/70">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}