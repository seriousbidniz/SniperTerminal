import React from "react";
import { Ban } from "lucide-react";
import { isStale } from "@/lib/freshness";

/**
 * Hard block rendered when a signal fails validation.
 * Replaces the entire action area — not just a warning.
 *
 * Returns { blocked: bool, reason: string } from deriveFailFast()
 * so callers can gate child rendering.
 */

export function deriveFailFast(signal) {
  // Stale data
  if (isStale(signal.timestamp)) {
    return { blocked: true, reason: "Signal is stale. Data is too old to act on. Refresh signals first." };
  }

  // Full fallback — no real data
  if (signal.data_quality === "full_fallback") {
    return { blocked: true, reason: "Signal built from default fallback values. Live data is unavailable for this asset. Do not trade." };
  }

  // Hard avoid from AI label
  if (signal.ai_label === "avoid") {
    return { blocked: true, reason: "Signal is labelled AVOID by the AI engine — liquidity or exhaustion conditions make this untradeable." };
  }

  // Confidence too low
  const conf = signal.data_confidence ?? null;
  if (conf != null && conf < 50) {
    return { blocked: true, reason: `Data confidence is critically low (${Math.round(conf)}%). Signal integrity cannot be verified.` };
  }

  return { blocked: false, reason: null };
}

export default function FailFastBlock({ signal, children }) {
  const { blocked, reason } = deriveFailFast(signal);

  if (!blocked) return children;

  return (
    <div className="rounded-xl border-2 border-loss/60 bg-loss/10 px-5 py-5 space-y-3">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-loss/20 flex items-center justify-center flex-shrink-0">
          <Ban className="w-5 h-5 text-loss" />
        </div>
        <div>
          <p className="text-sm font-black text-loss uppercase tracking-widest">Do Not Trade This Signal</p>
          <p className="text-xs text-loss/80 mt-0.5">Hard block — validation failed</p>
        </div>
      </div>
      <p className="text-xs text-foreground/80 leading-relaxed bg-loss/5 border border-loss/20 rounded-lg px-3 py-2">{reason}</p>
      <p className="text-[10px] text-muted-foreground/50">Refresh market data or wait for a new signal before evaluating this asset.</p>
    </div>
  );
}