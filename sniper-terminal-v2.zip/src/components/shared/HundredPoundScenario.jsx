import React from "react";
import { PoundSterling, AlertTriangle, Clock } from "lucide-react";

/**
 * £100 Illustrative Scenario — asset-specific, derived from real signal data.
 *
 * RecommendedScenario:
 *   - Uses stored entry/target/invalidation levels if present.
 *   - Falls back to deriving them from current price + volatility + setup_type + risk_score.
 *
 * ViralScenario:
 *   - Uses actual change_1h, change_4h, change_24h from raw_inputs to anchor scenarios.
 *   - Falls back to volatility-scaled ranges if no price change data available.
 *   - Never uses generic hardcoded percentages.
 */

function fmtGbp(v) {
  if (v == null || isNaN(v)) return "—";
  return "£" + v.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtPrice(v) {
  if (v == null || isNaN(v)) return null;
  if (v >= 1000) return "$" + v.toLocaleString("en-GB", { maximumFractionDigits: 0 });
  if (v >= 1)    return "$" + v.toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return "$" + v.toLocaleString("en-GB", { minimumFractionDigits: 4, maximumFractionDigits: 6 });
}

function ScenarioRow({ label, value, color = "text-foreground", pct, sublabel }) {
  return (
    <div className="flex items-start justify-between py-1.5 border-b border-border/30 last:border-0 gap-2">
      <div className="min-w-0">
        <span className="text-[11px] text-muted-foreground">{label}</span>
        {sublabel && <div className="text-[9px] text-muted-foreground/50 font-mono">{sublabel}</div>}
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        {pct != null && (
          <span className={`text-[10px] font-mono ${pct > 0 ? "text-profit" : pct < 0 ? "text-loss" : "text-muted-foreground"}`}>
            {pct > 0 ? "+" : ""}{pct.toFixed(1)}%
          </span>
        )}
        <span className={`text-xs font-mono font-bold ${color}`}>{fmtGbp(value)}</span>
      </div>
    </div>
  );
}

function TimeframeTag({ label }) {
  return (
    <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-border/30">
      <Clock className="w-3 h-3 text-muted-foreground/50 flex-shrink-0" />
      <span className="text-[10px] text-muted-foreground/60">
        <span className="font-medium">Est. timeframe (indicative only):</span> {label}
      </span>
    </div>
  );
}

function getRecommendedTimeframe(signal) {
  const setup = signal.setup_type || "";
  if (setup.includes("breakout") || setup === "reversal") return "hours to 1–3 days";
  if (setup.includes("pullback") || setup.includes("continuation")) return "1–7 days";
  if (setup.includes("breakdown") || setup.includes("failure")) return "hours to 2 days";
  return "days to weeks";
}

function getViralTimeframe(moveState) {
  switch (moveState) {
    case "early":     return "hours to 1–2 days";
    case "building":  return "1–3 days";
    case "crowded":   return "intraday — very short window";
    case "exhausted": return "immediate — window likely closing";
    default:          return "hours to days";
  }
}

// ─── Derive price levels from signal inputs when not stored ──────────────────
function deriveRecommendedLevels(signal) {
  // Use stored levels first
  const currentPrice = signal.current_price ?? signal.price ?? null;
  const entryLow  = signal.entry_low  ?? null;
  const entryHigh = signal.entry_high ?? null;
  const target1   = signal.target_1   ?? null;
  const target2   = signal.target_2   ?? null;
  const invalid   = signal.invalidation ?? null;

  // If we have stored levels, return them
  if ((entryLow || entryHigh) && (target1 || invalid)) {
    return { entryLow, entryHigh, target1, target2, invalid, derived: false };
  }

  // No stored levels — derive from current price + signal quality inputs
  if (!currentPrice || currentPrice <= 0) return null;

  const volatility = Math.max(0, Math.min(100, signal.volatility ?? signal.risk_score ?? 30));
  const riskScore  = Math.max(0, Math.min(100, signal.risk_score ?? 40));
  const dir        = signal.direction || "bullish";
  const setup      = signal.setup_type || "";

  // Scale move expectations with volatility and setup type
  // Higher vol = wider expected move, but also wider stop
  const volFactor = 0.5 + (volatility / 100) * 1.5; // 0.5x–2x scalar

  let stopPct, t1Pct, t2Pct;

  if (setup.includes("breakout") || setup.includes("breakdown")) {
    stopPct = (2.5 + riskScore * 0.04) * volFactor;
    t1Pct   = (5  + volatility * 0.08) * volFactor;
    t2Pct   = (10 + volatility * 0.12) * volFactor;
  } else if (setup.includes("reversal")) {
    stopPct = (3  + riskScore * 0.05) * volFactor;
    t1Pct   = (7  + volatility * 0.10) * volFactor;
    t2Pct   = (14 + volatility * 0.15) * volFactor;
  } else if (setup.includes("continuation")) {
    stopPct = (2  + riskScore * 0.03) * volFactor;
    t1Pct   = (4  + volatility * 0.06) * volFactor;
    t2Pct   = (8  + volatility * 0.10) * volFactor;
  } else {
    // pullback or default
    stopPct = (2  + riskScore * 0.035) * volFactor;
    t1Pct   = (4  + volatility * 0.07) * volFactor;
    t2Pct   = (8  + volatility * 0.11) * volFactor;
  }

  const sign = dir === "bullish" ? 1 : -1;
  const entryMid  = currentPrice;
  const derivedT1    = entryMid * (1 + sign * (t1Pct / 100));
  const derivedT2    = entryMid * (1 + sign * (t2Pct / 100));
  const derivedStop  = entryMid * (1 - sign * (stopPct / 100));

  return {
    entryLow:  entryMid * 0.998,
    entryHigh: entryMid * 1.002,
    target1:   derivedT1,
    target2:   derivedT2,
    invalid:   derivedStop,
    derived: true,
    currentPrice,
  };
}

// ─── RecommendedScenario ─────────────────────────────────────────────────────
export function RecommendedScenario({ signal }) {
  const levels = deriveRecommendedLevels(signal);
  if (!levels) return null;

  const { entryLow, entryHigh, target1, target2, invalid, derived, currentPrice } = levels;
  const entryMid = (entryLow != null && entryHigh != null)
    ? (entryLow + entryHigh) / 2
    : entryLow ?? entryHigh;

  if (!entryMid) return null;

  const BASE = 100;
  const calc = (price) => {
    if (price == null) return null;
    const pct = ((price - entryMid) / entryMid) * 100;
    return { value: BASE * (1 + pct / 100), pct };
  };

  const atT1  = calc(target1);
  const atT2  = calc(target2);
  const atInv = calc(invalid);

  if (!atT1 && !atInv) return null;

  const timeframe = getRecommendedTimeframe(signal);
  const dir = signal.direction || "bullish";

  return (
    <div className="rounded-lg border border-border bg-secondary/20 px-3 py-3 space-y-2">
      <div className="flex items-center gap-1.5 mb-1">
        <PoundSterling className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-[11px] font-semibold text-muted-foreground">
          £100 Illustrative Example
        </span>
        {derived && (
          <span className="ml-auto text-[9px] text-muted-foreground/40 italic">levels estimated from volatility</span>
        )}
      </div>

      <ScenarioRow
        label={`Entry midpoint`}
        sublabel={fmtPrice(entryMid)}
        value={BASE}
        pct={0}
        color="text-foreground"
      />
      {atT1 && (
        <ScenarioRow
          label={`→ Target 1`}
          sublabel={fmtPrice(target1)}
          value={atT1.value}
          pct={atT1.pct}
          color={atT1.pct >= 0 ? "text-profit" : "text-loss"}
        />
      )}
      {atT2 && (
        <ScenarioRow
          label={`→ Target 2`}
          sublabel={fmtPrice(target2)}
          value={atT2.value}
          pct={atT2.pct}
          color={atT2.pct >= 0 ? "text-profit" : "text-loss"}
        />
      )}
      {atInv && (
        <ScenarioRow
          label={`→ Invalidation / Stop`}
          sublabel={fmtPrice(invalid)}
          value={atInv.value}
          pct={atInv.pct}
          color="text-loss"
        />
      )}

      {atT1 && atInv && (
        <div className="text-[10px] text-muted-foreground/70 pt-1 font-mono">
          R:R ratio ≈ {Math.abs(atT1.pct / atInv.pct).toFixed(1)}:1
        </div>
      )}

      <TimeframeTag label={timeframe} />

      <div className="flex items-start gap-1.5 pt-1 border-t border-border/30">
         <AlertTriangle className="w-3 h-3 text-muted-foreground/50 flex-shrink-0 mt-0.5" />
         <p className="text-[9px] text-muted-foreground/50 leading-relaxed">
           <strong>Illustrative only.</strong> Not a recommendation. {derived ? "Levels estimated from model assumptions (live price, volatility, risk score, setup type) — not guaranteed accuracy." : "Based on stored signal levels and model assumptions."} Not tailored financial advice. Conduct independent research and consult professionals before trading.
         </p>
       </div>
    </div>
  );
}

// ─── ViralScenario ────────────────────────────────────────────────────────────
export function ViralScenario({ signal }) {
  const BASE = 100;

  // Extract actual observed price changes from raw_inputs (asset-specific)
  const raw = signal.raw_inputs || {};
  const c1h  = raw.change_1h  ?? signal.change_1h  ?? null;
  const c4h  = raw.change_4h  ?? signal.change_4h  ?? null;
  const c24h = raw.change_24h ?? signal.change_24h ?? null;
  const volatility = Math.max(0, Math.min(100, raw.volatility ?? signal.volatility ?? 30));
  const moveState  = signal.move_state || "building";
  const exhaustion = Math.max(0, Math.min(100, signal.exhaustion_score ?? 30));
  const crowding   = Math.max(0, Math.min(100, signal.crowding_score ?? 30));

  // Derive the recent observed momentum as a basis for forward scenarios
  // Best available: 4h momentum. Fallback: 1h scaled up, or 24h/4 as proxy
  const recentMomentum = c4h ?? (c1h != null ? c1h * 3 : null) ?? (c24h != null ? c24h / 2 : null);

  // Risk multiplier: exhaustion and crowding shrink the upside, widen the downside
  const riskMultiplier = 1 - ((exhaustion + crowding) / 200) * 0.6; // 1.0 → 0.7 range
  const absRecentMom   = recentMomentum != null ? Math.abs(recentMomentum) : null;

  let conservativePct, optimisticPct, downsidePct;

  if (absRecentMom != null) {
    // Asset-specific: anchor to actual observed momentum
    // Conservative = ~50% of recent move continuing
    // Optimistic   = ~100–120% of recent move continuing
    // Downside     = reversal of 60–80% of recent move
    conservativePct = +(absRecentMom * 0.50 * riskMultiplier).toFixed(1);
    optimisticPct   = +(absRecentMom * 1.10 * riskMultiplier).toFixed(1);
    downsidePct     = -(absRecentMom * 0.70 / riskMultiplier).toFixed(1);

    // Clamp to sensible ranges per move state
    const caps = {
      early:     { up: 60,  down: -20 },
      building:  { up: 40,  down: -18 },
      crowded:   { up: 15,  down: -20 },
      exhausted: { up: 5,   down: -30 },
    };
    const cap = caps[moveState] || { up: 40, down: -18 };
    conservativePct = Math.min(conservativePct, cap.up * 0.5);
    optimisticPct   = Math.min(optimisticPct,   cap.up);
    downsidePct     = Math.max(downsidePct,      cap.down);
  } else {
    // No price change data at all — use volatility-scaled ranges
    const volScale = 0.5 + (volatility / 100);
    const caps = {
      early:     [8 * volScale, 20 * volScale, -8  * volScale],
      building:  [5 * volScale, 14 * volScale, -10 * volScale],
      crowded:   [3 * volScale,  8 * volScale, -14 * volScale],
      exhausted: [1 * volScale,  3 * volScale, -18 * volScale],
    };
    const [c, o, d] = caps[moveState] || caps.building;
    conservativePct = +c.toFixed(1);
    optimisticPct   = +o.toFixed(1);
    downsidePct     = +d.toFixed(1);
  }

  const timeframe = getViralTimeframe(moveState);
  const hasRealData = absRecentMom != null;

  return (
    <div className="rounded-lg border border-border bg-secondary/20 px-3 py-3 space-y-2">
      <div className="flex items-center gap-1.5 mb-1">
        <PoundSterling className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-[11px] font-semibold text-muted-foreground">£100 Illustrative Move Example</span>
      </div>
      <p className="text-[10px] text-muted-foreground/70">
        {hasRealData
          ? <>Scenarios anchored to this asset's actual <span className="font-mono font-medium">{c4h != null ? "4h" : c1h != null ? "1h" : "24h"} momentum ({recentMomentum > 0 ? "+" : ""}{recentMomentum?.toFixed(1)}%)</span> — adjusted for exhaustion ({Math.round(exhaustion)}) and crowding ({Math.round(crowding)}).</>
          : <>Scenarios based on volatility profile ({Math.round(volatility)}) at <span className="capitalize font-medium">{moveState}</span> stage — no price change data available for this asset.</>
        }
      </p>

      <ScenarioRow label="Starting position (£100)" value={BASE} pct={0} />
      <ScenarioRow
        label="Conservative continuation"
        sublabel={`+${conservativePct}%`}
        value={BASE * (1 + conservativePct / 100)}
        pct={conservativePct}
        color="text-profit"
      />
      <ScenarioRow
        label="Optimistic continuation"
        sublabel={`+${optimisticPct}%`}
        value={BASE * (1 + optimisticPct / 100)}
        pct={optimisticPct}
        color="text-profit"
      />
      <ScenarioRow
        label="Reversal / downside"
        sublabel={`${downsidePct}%`}
        value={BASE * (1 + downsidePct / 100)}
        pct={downsidePct}
        color="text-loss"
      />

      {optimisticPct > 0 && downsidePct < 0 && (
        <div className="text-[10px] text-muted-foreground/70 pt-1 font-mono">
          Skew ≈ {(optimisticPct / Math.abs(downsidePct)).toFixed(1)}:1 upside/downside
        </div>
      )}

      <TimeframeTag label={timeframe} />

      <div className="flex items-start gap-1.5 pt-1 border-t border-border/30">
         <AlertTriangle className="w-3 h-3 text-muted-foreground/50 flex-shrink-0 mt-0.5" />
         <p className="text-[9px] text-muted-foreground/50 leading-relaxed">
           <strong>Illustrative only. Example-based on model assumptions — not a recommendation or forecast.</strong> {hasRealData ? "Anchored to observed momentum — not a price prediction." : "Based on volatility profile, not live price action."} Virality measures attention, not quality. Not tailored financial advice. Conduct independent research and consult professionals.
         </p>
       </div>
    </div>
  );
}