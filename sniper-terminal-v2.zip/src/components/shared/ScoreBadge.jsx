import React from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

function getScoreColor(score, invert = false) {
  const s = invert ? 100 - score : score;
  if (s >= 75) return "text-profit bg-profit/10 border-profit/30";
  if (s >= 50) return "text-primary bg-primary/10 border-primary/30";
  if (s >= 25) return "text-warning bg-warning/10 border-warning/30";
  return "text-loss bg-loss/10 border-loss/30";
}

export default function ScoreBadge({ label, score, explanation, invert = false }) {
  if (score == null || score === undefined) {
    return (
      <div className="flex flex-col items-center gap-0.5">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
        <span className="text-xs text-muted-foreground/50 font-mono">—</span>
      </div>
    );
  }

  const badge = (
    <div className="flex flex-col items-center gap-0.5 cursor-pointer">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className={`text-sm font-mono font-semibold px-2 py-0.5 rounded border ${getScoreColor(score, invert)}`}>
        {Math.round(score)}
      </span>
    </div>
  );

  if (!explanation) return badge;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{badge}</TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs text-xs">
          {explanation}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}