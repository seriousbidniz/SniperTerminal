import React from "react";
import { Timer } from "lucide-react";

/**
 * Derives a time expectation for the signal's relevant window.
 * Based on volatility, move_state, setup_type, and risk.
 */

function norm(v, fallback = 50) {
  return v == null || isNaN(v) ? fallback : Math.max(0, Math.min(100, v));
}

export function deriveTimeExpectation(signal) {
  const volatility  = norm(signal.volatility ?? signal.volatility_score_input ?? 30);
  const moveState   = signal.move_state;
  const setupType   = signal.setup_type || "";
  const exhaustion  = norm(signal.exhaustion_score ?? 30);

  // Exhausted or crowded move — window is immediate or closing
  if (moveState === "exhausted" || exhaustion >= 60) {
    return {
      id: "immediate",
      label: "Immediate (0–6h)",
      sublabel: "Window is closing fast",
      color: "text-loss",
      bg: "bg-loss/10",
      border: "border-loss/25",
    };
  }

  // High volatility or early viral move — fast-moving
  if (volatility >= 65 || moveState === "early" || setupType.includes("breakout") || setupType.includes("breakdown")) {
    return {
      id: "immediate",
      label: "Immediate (0–6h)",
      sublabel: "High volatility — move may resolve quickly",
      color: "text-warning",
      bg: "bg-warning/10",
      border: "border-warning/25",
    };
  }

  // Building viral or reversal/pullback — short window
  if (moveState === "building" || setupType.includes("reversal") || setupType.includes("pullback")) {
    return {
      id: "short",
      label: "Short (6–24h)",
      sublabel: "Setup developing — monitor for entry trigger",
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/25",
    };
  }

  // Continuation setups — medium window
  if (setupType.includes("continuation") || volatility < 35) {
    return {
      id: "medium",
      label: "Medium (1–3 days)",
      sublabel: "Controlled setup — time allows for careful entry",
      color: "text-profit",
      bg: "bg-profit/10",
      border: "border-profit/25",
    };
  }

  // Default: short
  return {
    id: "short",
    label: "Short (6–24h)",
    sublabel: "Monitor for confirmation before acting",
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/25",
  };
}

export default function SignalTimeExpectation({ signal }) {
  const time = deriveTimeExpectation(signal);

  return (
    <div className={`flex items-center gap-3 rounded-xl border px-4 py-2.5 ${time.bg} ${time.border}`}>
      <Timer className={`w-4 h-4 flex-shrink-0 ${time.color}`} />
      <div className="min-w-0">
        <div className={`text-xs font-bold ${time.color}`}>{time.label}</div>
        <div className="text-[10px] text-muted-foreground/70">{time.sublabel}</div>
      </div>
      <span className="ml-auto text-[9px] font-semibold uppercase tracking-widest text-muted-foreground/40 flex-shrink-0">Time Window</span>
    </div>
  );
}