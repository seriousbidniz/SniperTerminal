import React from "react";

/**
 * Shows which data provider(s) were used for a snapshot.
 * Displays provider logos/badges in a compact format.
 */
export default function ProviderStatusBadge({ providers, confidence }) {
  if (!providers || Object.keys(providers).length === 0) {
    return (
      <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground/50 border border-border">
        No providers
      </span>
    );
  }

  // Extract unique provider names
  const uniqueProviders = [...new Set(Object.values(providers))];

  const providerColors = {
    binance: "bg-yellow-500/15 text-yellow-600 border-yellow-500/25",
    coingecko: "bg-purple-500/15 text-purple-600 border-purple-500/25",
    coinpaprika: "bg-blue-500/15 text-blue-600 border-blue-500/25",
    averaged: "bg-green-500/15 text-green-600 border-green-500/25",
  };

  return (
    <div className="flex flex-wrap gap-1 items-center">
      {uniqueProviders.map(provider => (
        <span
          key={provider}
          className={`inline-flex items-center gap-0.5 text-[9px] font-semibold px-1.5 py-0.5 rounded border ${providerColors[provider] || "bg-secondary/30 border-border text-muted-foreground"}`}
          title={`Data from ${provider}`}
        >
          {provider === "binance" && "🟡 Binance"}
          {provider === "coingecko" && "🟣 CG"}
          {provider === "coinpaprika" && "🔵 CP"}
          {provider === "averaged" && "⚖ Avg"}
          {!["binance", "coingecko", "coinpaprika", "averaged"].includes(provider) && provider}
        </span>
      ))}
      {confidence != null && confidence < 75 && (
        <span className="text-[9px] text-warning/70 font-semibold">({Math.round(confidence)}%)</span>
      )}
    </div>
  );
}