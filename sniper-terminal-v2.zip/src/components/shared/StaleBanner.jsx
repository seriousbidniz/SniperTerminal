import React from "react";
import { Clock } from "lucide-react";

/**
 * A compact banner shown when data is stale.
 * variant: "inline" (default) | "row" — row is for table cells
 */
export default function StaleBanner({ ageStr, message, variant = "inline" }) {
  if (variant === "row") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] text-warning/80 font-mono">
        <Clock className="w-2.5 h-2.5" />
        stale
      </span>
    );
  }

  return (
    <div className="flex items-center gap-2 bg-warning/5 border border-warning/25 rounded-lg px-3 py-2 text-[11px] text-warning/80">
      <Clock className="w-3.5 h-3.5 flex-shrink-0" />
      <span>
        <span className="font-medium">Data may be outdated</span>
        {ageStr && <span className="ml-1 font-mono">({ageStr} old)</span>}
        {message && <span className="ml-1">— {message}</span>}
      </span>
    </div>
  );
}