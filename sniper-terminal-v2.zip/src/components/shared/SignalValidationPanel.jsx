import React from "react";
import { CheckCircle2, AlertTriangle, XCircle, Clock } from "lucide-react";
import { isStale, dataAge } from "@/lib/freshness";

/**
 * Live signal validation panel — shows data freshness, completeness,
 * and confidence downgrade warnings before the user acts.
 */

function ValidationRow({ icon: RowIcon, label, value, status }) {
  const Icon = RowIcon;
  const statusColors = {
    ok:      "text-profit",
    warn:    "text-warning",
    danger:  "text-loss",
  };
  const StatusIcon = status === "ok" ? CheckCircle2 : status === "warn" ? AlertTriangle : XCircle;
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/30 last:border-0">
      <div className="flex items-center gap-2">
        <Icon className={`w-3 h-3 ${statusColors[status]}`} />
        <span className="text-[11px] text-muted-foreground">{label}</span>
      </div>
      <div className="flex items-center gap-1.5">
        <StatusIcon className={`w-3 h-3 ${statusColors[status]}`} />
        <span className={`text-[11px] font-medium font-mono ${statusColors[status]}`}>{value}</span>
      </div>
    </div>
  );
}

export default function SignalValidationPanel({ signal }) {
  const stale = isStale(signal.timestamp);
  const age = dataAge(signal.timestamp);

  // Freshness
  const freshnessStatus = stale ? "danger" : "ok";
  const freshnessValue  = stale ? `${age} old — STALE` : `${age} old — LIVE`;

  // Data completeness (for viral signals)
  const dataQuality = signal.data_quality;
  let completenessStatus = "ok";
  let completenessValue  = "All inputs present";
  if (dataQuality === "partial" || dataQuality === "partial_fallback") {
    completenessStatus = "warn";
    const missing = signal.raw_inputs?.missing_fields;
    completenessValue = missing?.length ? `${missing.length} field(s) derived` : "Some inputs derived";
  } else if (dataQuality === "full_fallback") {
    completenessStatus = "danger";
    completenessValue  = "Default fallback values used";
  }

  // Confidence
  const confidence = signal.data_confidence ?? signal.opportunity_score ?? signal.viral_score ?? null;
  let confStatus = "ok";
  let confValue  = confidence != null ? `${Math.round(confidence)}%` : "N/A";
  if (confidence != null && confidence < 60) { confStatus = "danger"; }
  else if (confidence != null && confidence < 80) { confStatus = "warn"; }

  // Overall gate
  const overallPass = !stale && completenessStatus !== "danger" && confStatus !== "danger";

  return (
    <div className="rounded-xl border border-border bg-secondary/10 px-4 py-3 space-y-1">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60">Signal Validation</span>
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
          overallPass
            ? "text-profit bg-profit/10 border-profit/25"
            : "text-loss bg-loss/10 border-loss/25"
        }`}>
          {overallPass ? "Verified" : "Caution"}
        </span>
      </div>
      <ValidationRow icon={Clock}         label="Data Freshness"    value={freshnessValue}    status={freshnessStatus} />
      <ValidationRow icon={CheckCircle2}  label="Data Completeness" value={completenessValue} status={completenessStatus} />
      {confidence != null && (
        <ValidationRow icon={AlertTriangle} label="Confidence Score" value={confValue} status={confStatus} />
      )}
      {!overallPass && (
        <p className="text-[10px] text-warning/70 pt-1.5 leading-relaxed">
          One or more validation checks failed. Act with extra caution or wait for a fresh signal.
        </p>
      )}
    </div>
  );
}