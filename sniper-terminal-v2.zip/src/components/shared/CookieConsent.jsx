import React, { useState, useEffect } from "react";
import { X, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Cookie Consent Banner — GDPR/UK GDPR compliant
 * Manages: Essential (required), Analytics, Marketing
 */

const DEFAULT_PREFERENCES = {
  essential: true, // Always true, non-optional
  analytics: false,
  marketing: false,
};

const STORAGE_KEY = "sniperTerminal_cookieConsent";

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [preferences, setPreferences] = useState(DEFAULT_PREFERENCES);
  const [showSettings, setShowSettings] = useState(false);

  // Initialize consent state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) {
      setVisible(true);
    } else {
      try {
        setPreferences(JSON.parse(saved));
      } catch {
        setVisible(true);
      }
    }
  }, []);

  const handleAcceptAll = () => {
    const newPrefs = {
      essential: true,
      analytics: true,
      marketing: true,
    };
    savePreferences(newPrefs);
  };

  const handleRejectAll = () => {
    const newPrefs = {
      essential: true,
      analytics: false,
      marketing: false,
    };
    savePreferences(newPrefs);
  };

  const handleSaveSettings = () => {
    savePreferences(preferences);
  };

  const savePreferences = (newPrefs) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newPrefs));
    setPreferences(newPrefs);
    setVisible(false);
    setShowSettings(false);
    // Trigger analytics/marketing load based on preferences (implementation depends on your tracking setup)
    window.dispatchEvent(new CustomEvent("cookiePreferencesChanged", { detail: newPrefs }));
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4 sm:px-6 sm:py-6">
        {!showSettings ? (
          <>
            {/* Main Banner */}
            <div className="flex flex-col gap-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm mb-2">We Use Cookies</h3>
                  <p className="text-xs text-muted-foreground/80 leading-relaxed">
                    We use cookies to enhance your experience, analyze traffic, and for marketing purposes. Essential cookies are always enabled. You can customize your preferences below.
                  </p>
                </div>
                <button
                  onClick={() => setVisible(false)}
                  className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Buttons */}
              <div className="flex flex-wrap gap-2 items-center justify-between">
                <button
                  onClick={() => setShowSettings(true)}
                  className="flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors font-medium"
                >
                  <Settings className="w-3.5 h-3.5" />
                  Customize
                </button>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRejectAll}
                    className="text-xs"
                  >
                    Reject All
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleAcceptAll}
                    className="text-xs"
                  >
                    Accept All
                  </Button>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Settings Panel */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm">Cookie Preferences</h3>
                <button
                  onClick={() => setShowSettings(false)}
                  className="text-muted-foreground hover:text-foreground transition-colors p-1"
                  aria-label="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Cookie Types */}
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {/* Essential */}
                <div className="flex items-start gap-3 p-3 bg-secondary/20 rounded-lg border border-border/40">
                  <input
                    type="checkbox"
                    id="essential"
                    checked={preferences.essential}
                    disabled
                    className="mt-1 cursor-not-allowed"
                  />
                  <div className="flex-1">
                    <label htmlFor="essential" className="text-xs font-semibold block cursor-not-allowed">
                      Essential Cookies (Required)
                    </label>
                    <p className="text-[11px] text-muted-foreground/70 mt-1">
                      Necessary for the App to function: authentication, session management, security. Always enabled.
                    </p>
                  </div>
                </div>

                {/* Analytics */}
                <div className="flex items-start gap-3 p-3 bg-secondary/10 rounded-lg border border-border">
                  <input
                    type="checkbox"
                    id="analytics"
                    checked={preferences.analytics}
                    onChange={(e) => setPreferences({ ...preferences, analytics: e.target.checked })}
                    className="mt-1 cursor-pointer"
                  />
                  <div className="flex-1">
                    <label htmlFor="analytics" className="text-xs font-semibold block cursor-pointer">
                      Analytics Cookies
                    </label>
                    <p className="text-[11px] text-muted-foreground/70 mt-1">
                      Help us understand how you use the App (e.g., pages visited, features used). Used by Google Analytics. No personal identification.
                    </p>
                  </div>
                </div>

                {/* Marketing */}
                <div className="flex items-start gap-3 p-3 bg-secondary/10 rounded-lg border border-border">
                  <input
                    type="checkbox"
                    id="marketing"
                    checked={preferences.marketing}
                    onChange={(e) => setPreferences({ ...preferences, marketing: e.target.checked })}
                    className="mt-1 cursor-pointer"
                  />
                  <div className="flex-1">
                    <label htmlFor="marketing" className="text-xs font-semibold block cursor-pointer">
                      Marketing & Advertising Cookies
                    </label>
                    <p className="text-[11px] text-muted-foreground/70 mt-1">
                      Enable targeted ads and retargeting. Allows third parties to show you relevant content.
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 justify-end flex-wrap pt-2 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowSettings(false)}
                  className="text-xs"
                >
                  Back
                </Button>
                <Button
                  size="sm"
                  onClick={handleSaveSettings}
                  className="text-xs"
                >
                  Save Preferences
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Privacy & Cookie Policy Links */}
      <div className="bg-secondary/20 border-t border-border px-4 sm:px-6 py-2 text-[10px] text-muted-foreground/60 space-y-1">
        <p>
          By using this App, you agree to our cookie use. Read our{" "}
          <a href="/privacy-policy" className="text-primary hover:text-primary/80 underline">Privacy Policy</a>,{" "}
          <a href="/terms" className="text-primary hover:text-primary/80 underline">Terms of Service</a>, and{" "}
          <a href="/risk-disclaimer" className="text-primary hover:text-primary/80 underline">Risk Disclaimer</a>.
        </p>
      </div>
    </div>
  );
}