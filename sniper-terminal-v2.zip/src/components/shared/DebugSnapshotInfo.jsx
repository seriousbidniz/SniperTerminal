import React from "react";
import { Code, AlertTriangle } from "lucide-react";

/**
 * Debug component to show snapshot metadata and data quality info.
 * Only visible in development or when explicitly toggled.
 */
export default function DebugSnapshotInfo({ snapshot, signal }) {
  if (!snapshot && !signal) return null;

  const snap = snapshot;
  const dataQuality = snap?._data_quality || signal?.data_quality;
  const missingFields = snap?._missing_fields || signal?.raw_inputs?.missing_fields || [];
  const source = snap?._fetch_source;
  const timestamp = snap?._fetch_timestamp || snap?.timestamp;

  const isIncomplete = dataQuality === "incomplete";
  const isPartial = dataQuality === "partial";
  const isLive = dataQuality === "live";

  const qualityColor = isIncomplete
    ? "text-loss bg-loss/5 border-loss/25"
    : isPartial
    ? "text-warning bg-warning/5 border-warning/25"
    : "text-profit bg-profit/5 border-profit/25";

  return (
    <details className={`border rounded-lg px-3 py-2.5 cursor-pointer transition-colors ${qualityColor}`}>
      <summary className="flex items-center gap-2 text-xs font-semibold select-none">
        <Code className="w-3 h-3" />
        Debug: Snapshot Metadata
      </summary>

      <div className="mt-2.5 space-y-1.5 text-[11px] font-mono">
        {/* Data Quality */}
        {dataQuality && (
          <div className="flex justify-between">
            <span className="text-muted-foreground">Data Quality:</span>
            <span className={`font-bold uppercase ${isIncomplete ? "text-loss" : isPartial ? "text-warning" : "text-profit"}`}>
              {dataQuality}
            </span>
          </div>
        )}

        {timestamp && (
          <div className="flex justify-between">
            <span className="text-muted-foreground">Fetched:</span>
            <span className="text-foreground/70">
              {new Date(timestamp).toLocaleString("en-GB", { dateStyle: "short", timeStyle: "short" })}
            </span>
          </div>
        )}

        {/* Provider info (per-field) */}
        {source && source._source_providers && (
          <div className="mt-2 pt-1.5 border-t border-border/30">
            <div className="font-bold text-muted-foreground mb-1">Providers per field:</div>
            <div className="space-y-0.5 text-[10px]">
              {Object.entries(source._source_providers || {}).map(([field, provider]) => (
                <div key={field} className="flex justify-between text-foreground/70">
                  <span>{field}:</span>
                  <span className="font-semibold text-foreground">{provider}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Confidence score */}
        {source?._confidence != null && (
          <div className="flex justify-between pt-1.5 border-t border-border/30">
            <span className="text-muted-foreground">Confidence:</span>
            <span className="font-semibold text-foreground">{Math.round(source._confidence)}%</span>
          </div>
        )}

        {/* Missing fields */}
        {missingFields.length > 0 && (
          <div className="mt-2 p-1.5 bg-current/10 rounded border border-current/20">
            <div className="flex items-center gap-1 mb-1 text-warning">
              <AlertTriangle className="w-3 h-3" />
              <span className="font-bold">Missing from source:</span>
            </div>
            <div className="text-[10px] text-foreground/70 flex flex-wrap gap-1">
              {missingFields.map((f, i) => (
                <span key={i} className="bg-current/20 px-1.5 py-0.5 rounded">
                  {f}
                </span>
              ))}
            </div>
          </div>
        )}

        {isPartial && (
          <div className="mt-2 p-1.5 bg-warning/10 rounded border border-warning/25 text-warning/80 text-[10px]">
            <span className="font-bold">⚠ Partial snapshot:</span> Some fields missing from providers, but sufficient for scoring.
          </div>
        )}
      </div>
    </details>
  );
}