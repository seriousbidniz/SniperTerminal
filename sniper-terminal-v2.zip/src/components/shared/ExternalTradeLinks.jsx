import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink, Copy, Check, ClipboardList, Info } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useUserProfile } from "@/hooks/useUserProfile";
import { useUserSettings } from "@/hooks/useUserSettings";
import { buildOrderTicket, venueLinks } from "@/lib/orderTicket";

const money = (n) => (n == null ? "—" : Number(n).toLocaleString("en-GB", { maximumFractionDigits: 2 }));

function CopyButton({ text, label }) {
  const [done, setDone] = useState(false);
  const copy = async (e) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(text);
      setDone(true);
      setTimeout(() => setDone(false), 1500);
    } catch {
      window.prompt("Copy this:", text);
    }
  };
  return (
    <button
      type="button"
      onClick={copy}
      disabled={!text}
      className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground disabled:opacity-30 focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
      aria-label={`Copy ${label}`}
    >
      {done ? <Check className="w-3 h-3 text-profit" /> : <Copy className="w-3 h-3" />}
    </button>
  );
}

/**
 * Order ticket: pre-filled trade parameters sized to the user's risk settings,
 * copyable field-by-field or as one string, plus venue links. Uniswap links are
 * genuinely pre-filled (documented URL params). Centralised exchanges don't
 * accept order values in a URL, so for those we open the right pair and the
 * values are one tap away on the clipboard. The app never places orders.
 */
export default function ExternalTradeLinks({ signal, asset: assetProp }) {
  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
    enabled: !assetProp,
  });
  const asset = assetProp || assets.find((a) => a.id === signal?.asset) || null;
  const { profile } = useUserProfile();
  const { settings } = useUserSettings();

  const ticket = useMemo(
    () => buildOrderTicket({ signal, asset, investAmount: profile?.invest_amount, riskPct: settings.risk_per_trade_pct }),
    [signal, asset, profile?.invest_amount, settings.risk_per_trade_pct],
  );
  const links = useMemo(() => venueLinks({ signal, asset, ticket }), [signal, asset, ticket]);
  const mt = asset?.market_type;
  const tradable = signal && ["active", "triggered"].includes(signal.status || "active");

  if (!asset && !links.length) return null;

  return (
    <div className="space-y-3">
      <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
        <ClipboardList className="w-3.5 h-3.5" /> Order ticket
      </p>

      {ticket ? (
        <div className={`rounded-xl border border-border bg-secondary/20 ${tradable ? "" : "opacity-60"}`}>
          {!tradable && (
            <p className="px-3 pt-2.5 text-[11px] text-warning">This signal is no longer open for new entries.</p>
          )}
          <dl className="grid grid-cols-2 gap-x-3 gap-y-1.5 p-3">
            {ticket.fields.filter((f) => f.value).map((f) => (
              <div key={f.label} className="flex items-center justify-between gap-1 min-w-0">
                <dt className="text-[10px] text-muted-foreground">{f.label}</dt>
                <dd className="flex items-center gap-1 min-w-0">
                  <span className={`text-xs font-mono font-semibold truncate ${f.label === "Side" ? (ticket.side === "BUY" ? "text-profit" : "text-loss") : ""}`}>{f.value}</span>
                  <CopyButton text={f.value} label={f.label} />
                </dd>
              </div>
            ))}
          </dl>
          <div className="border-t border-border px-3 py-2 space-y-1.5">
            <div className="flex items-center gap-2">
              <code className="flex-1 text-[10px] font-mono text-foreground/80 break-all">{ticket.paramString}</code>
              <CopyButton text={ticket.paramString} label="order string" />
              <CopyButton text={JSON.stringify(ticket.json)} label="order JSON" />
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              {ticket.qty != null ? (
                <>Sized to risk {ticket.riskPct}% of your {money(profile?.invest_amount)} ({money(ticket.riskAmount)}) if the stop is hit
                  {ticket.capped && " — capped at your full amount, so actual risk is lower"}. Position value ≈ {money(ticket.notional)}. Set amount and risk % in Settings.</>
              ) : (
                <>Add the amount you invest in Settings → Profile to get a suggested position size.</>
              )}
              {ticket.side === "SELL" && mt === "crypto" && " A SELL on spot closes a holding; opening a short needs margin or futures."}
            </p>
          </div>
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground">
          {signal?.viral_score != null
            ? "Viral signals flag an unusual move rather than a planned entry, so no order is pre-filled. Use the invalidation level above as your exit if you trade it."
            : "This signal has no entry levels (it was created before trade levels were added), so no order can be pre-filled."}
        </p>
      )}

      {links.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {links.map((l) => (
            <a
              key={l.id}
              href={l.href}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => l.id === "binance" && ticket && navigator.clipboard?.writeText(ticket.paramString).catch(() => {})}
              className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary ${
                l.prefilled ? "text-profit bg-profit/10 border-profit/30 hover:bg-profit/20" : "text-foreground bg-secondary/40 border-border hover:bg-secondary"
              }`}
            >
              {l.label}
              <ExternalLink className="w-3 h-3 opacity-60" />
            </a>
          ))}
        </div>
      )}
      {links.some((l) => l.id === "binance") && (
        <p className="text-[10px] text-muted-foreground flex gap-1">
          <Info className="w-3 h-3 flex-shrink-0 mt-px" />
          Binance doesn't accept order values in a link. Opening it copies the order string so you can paste each value.
        </p>
      )}
    </div>
  );
}
