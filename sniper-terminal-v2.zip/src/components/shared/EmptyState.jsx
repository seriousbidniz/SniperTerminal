import React from "react";

export default function EmptyState({ icon: Icon, title, description }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {Icon && <Icon className="w-10 h-10 text-muted-foreground/30 mb-3" />}
      <p className="text-sm font-medium text-muted-foreground">{title || "No data available"}</p>
      {description && <p className="text-xs text-muted-foreground/60 mt-1 max-w-sm">{description}</p>}
    </div>
  );
}