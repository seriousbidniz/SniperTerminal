import { useSyncExternalStore } from "react";

// One shared 1-second clock for every countdown on screen.
let now = Date.now();
const subs = new Set();
let timer = null;
function subscribe(fn) {
  subs.add(fn);
  if (!timer) timer = setInterval(() => { now = Date.now(); subs.forEach((f) => f()); }, 1000);
  return () => {
    subs.delete(fn);
    if (!subs.size) { clearInterval(timer); timer = null; }
  };
}
export function useNow() {
  return useSyncExternalStore(subscribe, () => now, () => now);
}
