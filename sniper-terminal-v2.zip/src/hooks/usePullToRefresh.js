import { useRef, useState, useCallback } from 'react';

/**
 * Reusable pull-to-refresh hook.
 * Returns a ref to attach to the scrollable container.
 */
export function usePullToRefresh(onRefresh) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const touchStartY = useRef(null);

  const handleTouchStart = useCallback((e) => {
    if (window.scrollY === 0) touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback(async (e) => {
    if (touchStartY.current == null) return;
    const delta = e.changedTouches[0].clientY - touchStartY.current;
    touchStartY.current = null;
    if (delta > 80 && !isRefreshing && onRefresh) {
      setIsRefreshing(true);
      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
      }
    }
  }, [isRefreshing, onRefresh]);

  return { touchStartY: handleTouchStart, touchEndY: handleTouchEnd, isRefreshing };
}