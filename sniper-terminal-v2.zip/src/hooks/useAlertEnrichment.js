import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Loads Assets + latest MarketSnapshots and returns:
 *   - assetMap   { [assetId]: asset }
 *   - snapMap    { [assetId]: latestSnapshot }
 *   - enrich(alert) → alert with resolved identity fields
 */
export function useAlertEnrichment() {
  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const { data: snapshots = [] } = useQuery({
    queryKey: ["latestSnapshots"],
    queryFn: () => base44.entities.MarketSnapshots.list("-timestamp", 500),
    staleTime: 30_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    assets.forEach(a => { m[a.id] = a; });
    return m;
  }, [assets]);

  const snapMap = useMemo(() => {
    const m = {};
    snapshots.forEach(s => {
      if (!s.asset || s.price == null) return;
      if (!m[s.asset] || new Date(s.timestamp) > new Date(m[s.asset].timestamp)) {
        m[s.asset] = s;
      }
    });
    return m;
  }, [snapshots]);

  /**
   * Enrich a raw alert record with resolved asset identity + live price.
   * Priority for symbol: alert.asset_id → Assets → alert.asset (stored symbol) → "Unknown Asset"
   * Priority for price:  fresh snapshot → stale snapshot → alert.current_price → null
   */
  const enrich = useMemo(() => (alert) => {
    const assetId = alert.asset_id;
    const asset = assetId ? assetMap[assetId] : null;

    // Identity resolution
    const resolvedSymbol  = asset?.symbol || alert.asset || null;
    const resolvedName    = asset?.name || alert.display_name || null;
    const resolvedMarket  = asset?.market_type || alert.market_type || null;

    // Price resolution
    const snap = assetId ? snapMap[assetId] : null;
    const STALE_MS = 4 * 60 * 60 * 1000;
    const snapIsStale = snap ? (Date.now() - new Date(snap.timestamp).getTime() > STALE_MS) : false;
    const livePrice = snap?.price ?? alert.current_price ?? null;
    const priceIsStale = snap ? snapIsStale : false;

    // Is the identity valid? (can we show something meaningful?)
    const hasValidIdentity = !!(resolvedSymbol || resolvedName);

    return {
      ...alert,
      // Resolved fields (override stored ones)
      _resolved: true,
      _asset: asset,           // full Asset record or null
      _symbol: resolvedSymbol,
      _name: resolvedName,
      _market_type: resolvedMarket,
      _live_price: livePrice,
      _price_is_stale: priceIsStale,
      _has_valid_identity: hasValidIdentity,
      _snapshot: snap,         // full latest MarketSnapshot or null — for signal-specific projections
    };
  }, [assetMap, snapMap]);

  return { assetMap, snapMap, enrich };
}