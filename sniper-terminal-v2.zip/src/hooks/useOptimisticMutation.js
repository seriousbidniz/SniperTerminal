import { useMutation } from '@tanstack/react-query';

/**
 * Wrapper for optimistic mutations — optimistically update cache before server confirms.
 */
export function useOptimisticMutation({
  mutationFn,
  queryKey,
  onOptimisticUpdate,
  onSuccess,
  onError
}) {
  return useMutation({
    mutationFn,
    onMutate: async (variables) => {
      // Optimistically update cache
      if (onOptimisticUpdate) {
        onOptimisticUpdate(variables);
      }
    },
    onSuccess,
    onError
  });
}