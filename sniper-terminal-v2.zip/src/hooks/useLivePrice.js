import { useEffect, useState, useSyncExternalStore } from "react";
import { subscribePrice, getStreamStatus, onStreamStatus } from "@/lib/realtime/binanceTicker";
import { binancePair } from "../../base44/shared/symbols.js";

/**
 * Live price for an asset. Crypto streams from Binance; everything else falls
 * back to `fallback` (latest server snapshot). Returns { price, ts, live }.
 */
export function useLivePrice(asset, fallback = null, fallbackTs = null) {
  const pair = asset ? binancePair(asset) : null;
  const [tick, setTick] = useState(null);
  useEffect(() => {
    setTick(null);
    if (!pair) return undefined;
    return subscribePrice(pair, setTick);
  }, [pair]);
  if (tick && Date.now() - tick.ts < 120_000) return { price: tick.price, ts: tick.ts, live: true };
  return { price: fallback, ts: fallbackTs ? new Date(fallbackTs).getTime() : null, live: false };
}

export function useStreamStatus() {
  return useSyncExternalStore(onStreamStatus, getStreamStatus, () => "idle");
}
