import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export const SETTINGS_DEFAULTS = {
  push_enabled: true,
  push_new_signals_min_score: 75,
  push_lifecycle: "executed_only",
  push_viral: false,
  risk_per_trade_pct: 1,
  preferred_venue: "binance",
};

// Row-level security limits UserSettings to the signed-in user's own row.
export function useUserSettings() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["userSettings"],
    queryFn: () => base44.entities.UserSettings.list("-updated_date", 1),
  });
  const row = rows[0] ?? null;
  const save = useMutation({
    mutationFn: (patch) => (row?.id
      ? base44.entities.UserSettings.update(row.id, patch)
      : base44.entities.UserSettings.create({ ...SETTINGS_DEFAULTS, ...patch, user_email: user?.email })),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["userSettings"] }),
  });
  return { settings: { ...SETTINGS_DEFAULTS, ...(row || {}) }, isLoading, save: save.mutate, isSaving: save.isPending };
}
