import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

// Entity → React Query keys to refresh when that entity changes server-side.
const MAP = {
  RecommendedTradeSignals: [["recommendedSignals"], ["recSignals"]],
  ViralTradeSignals: [["viralTradeSignals"], ["viralSignals"]],
  Alerts: [["allAlerts"], ["alerts"]],
  SignalExecutions: [["userPerformance"]],
  BrokerConnections: [["brokerConnections"]],
};

/**
 * Subscribes to Base44 realtime entity events (WebSocket, built into the SDK)
 * and invalidates cached queries — at most once per second per entity, so a
 * refresh writing 50 rows causes one refetch, not 50.
 */
export function useRealtimeSync() {
  const qc = useQueryClient();
  useEffect(() => {
    const unsubs = [];
    const timers = {};
    for (const [entity, keys] of Object.entries(MAP)) {
      const handler = base44.entities[entity];
      if (!handler?.subscribe) continue;
      try {
        unsubs.push(handler.subscribe(() => {
          if (timers[entity]) return;
          timers[entity] = setTimeout(() => {
            timers[entity] = null;
            // Partial key match refreshes every query that starts with this key.
            keys.forEach((queryKey) => qc.invalidateQueries({ queryKey }));
          }, 1000);
        }));
      } catch {
        // Realtime unavailable — pages still refetch on their own intervals.
      }
    }
    return () => {
      unsubs.forEach((u) => { try { u(); } catch { /* ignore */ } });
      Object.values(timers).forEach((t) => t && clearTimeout(t));
    };
  }, [qc]);
}
