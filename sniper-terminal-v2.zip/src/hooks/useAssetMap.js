import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

// Shares the ["allAssets"] cache used across the app.
export function useAssetMap() {
  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });
  return useMemo(() => Object.fromEntries(assets.map((a) => [a.id, a])), [assets]);
}
