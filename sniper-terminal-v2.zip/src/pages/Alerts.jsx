import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Bell, Clock, Zap, Eye, ShieldAlert, LogOut, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import EmptyState from "@/components/shared/EmptyState";
import AlertDetailDrawer from "@/components/alerts/AlertDetailDrawer";
import AlertCard from "@/components/alerts/AlertCard";
import { useAlertEnrichment } from "@/hooks/useAlertEnrichment";
import InvestmentProjection from "@/components/alerts/InvestmentProjection";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";

// ─── Configuration ────────────────────────────────────────────────────────────
const ACTION_GROUPS = [
  { key: "exit_hedge",  label: "Exit / Hedge", icon: LogOut,      color: "text-loss",             headBg: "bg-loss/10" },
  { key: "reduce_risk", label: "Reduce Risk",  icon: ShieldAlert, color: "text-warning",           headBg: "bg-warning/10" },
  { key: "act_now",     label: "Act Now",       icon: Zap,         color: "text-primary",           headBg: "bg-primary/10" },
  { key: "prepare",     label: "Prepare",       icon: Clock,       color: "text-foreground",        headBg: "bg-secondary/30" },
  { key: "watch",       label: "Watch",         icon: Eye,         color: "text-muted-foreground",  headBg: "bg-secondary/20" },
];

// ─── Action Group Section ─────────────────────────────────────────────────────
function ActionGroup({ group, alerts, onDismiss, onSnooze, onSelect }) {
  if (alerts.length === 0) return null;
  const Icon = group.icon;
  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <div className={`flex items-center gap-2 px-4 py-2.5 ${group.headBg} border-b border-border`}>
        <Icon className={`w-4 h-4 ${group.color}`} />
        <span className={`text-sm font-semibold ${group.color}`}>{group.label}</span>
        <span className="text-xs text-muted-foreground font-mono">({alerts.length})</span>
      </div>
      <div className="p-2 space-y-1.5">
        {alerts.map(a => (
          <AlertCard
            key={a.id}
            alert={a}
            onDismiss={onDismiss}
            onSnooze={onSnooze}
            onSelect={onSelect}
          />
        ))}
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Alerts() {
  const [tab, setTab] = useState("active");
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const queryClient = useQueryClient();
  const containerRef = useRef(null);

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["allAlerts"] });
  };
  const { touchStartY, touchEndY, isRefreshing } = usePullToRefresh(handleRefresh);

  // Enrichment: resolves asset identity + live price from Asset Universe + MarketSnapshots
  const { enrich } = useAlertEnrichment();

  const { data: rawAlerts = [], isLoading } = useQuery({
    queryKey: ["allAlerts", tab],
    queryFn: () => {
      if (tab === "active")    return base44.entities.Alerts.filter({ status: "active" },    "-triggered_at", 300);
      if (tab === "snoozed")   return base44.entities.Alerts.filter({ status: "snoozed" },   "-triggered_at", 100);
      if (tab === "dismissed") return base44.entities.Alerts.filter({ status: "dismissed" }, "-triggered_at", 100);
      return [];
    },
  });

  // Enrich all alerts with resolved asset identity + live price
  const alerts = rawAlerts.map(enrich);

  const updateAlert = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Alerts.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["allAlerts"] }),
  });

  const handleDismiss = (id) => updateAlert.mutate({ id, data: { status: "dismissed" } });
  const handleSnooze  = (id) => updateAlert.mutate({ id, data: { status: "snoozed" } });

  const handleGenerate = async () => {
    setIsGenerating(true);
    await base44.functions.invoke("generateAlerts", {});
    await queryClient.invalidateQueries({ queryKey: ["allAlerts"] });
    setIsGenerating(false);
  };

  // Group active alerts by action_classification
  const grouped = {};
  ACTION_GROUPS.forEach(g => { grouped[g.key] = []; });
  alerts.forEach(a => {
    const key = a.action_classification;
    if (grouped[key]) grouped[key].push(a);
    else grouped["watch"]?.push(a);
  });

  const totalActive = alerts.length;
  const TABS = ["active", "snoozed", "dismissed"];

  return (
    <div className="space-y-4" ref={containerRef} onTouchStart={touchStartY} onTouchEnd={touchEndY}>
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" /> Alerts
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Rule-based alert queue — grouped by required action
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="text-xs gap-1.5"
          onClick={handleGenerate}
          disabled={isGenerating}
        >
          <RefreshCw className={`w-3 h-3 ${isGenerating ? "animate-spin" : ""}`} />
          {isGenerating ? "Generating…" : "Run Alert Engine"}
        </Button>
      </div>

      {/* Investment Projection */}
      <InvestmentProjection />

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary/40 p-1 rounded-lg w-fit">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors capitalize ${tab === t ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Alert Detail Drawer */}
      <AlertDetailDrawer alert={selectedAlert} onClose={() => setSelectedAlert(null)} />

      {/* Content */}
      {isLoading ? (
        <div className="py-12 text-center text-xs text-muted-foreground">Loading alerts…</div>
      ) : tab === "active" ? (
        totalActive === 0 ? (
          <EmptyState
            icon={Bell}
            title="No active alerts"
            description="Run the alert engine to evaluate current signals and holdings against defined rules."
          />
        ) : (
          <div className="space-y-3">
            {ACTION_GROUPS.map(group => (
              <ActionGroup
                key={group.key}
                group={group}
                alerts={grouped[group.key] || []}
                onDismiss={handleDismiss}
                onSnooze={handleSnooze}
                onSelect={setSelectedAlert}
              />
            ))}
          </div>
        )
      ) : (
        alerts.length === 0 ? (
          <EmptyState icon={Bell} title={`No ${tab} alerts`} />
        ) : (
          <div className="space-y-2">
            {alerts.map(a => (
              <AlertCard
                key={a.id}
                alert={a}
                onDismiss={handleDismiss}
                onSnooze={handleSnooze}
                onSelect={setSelectedAlert}
              />
            ))}
          </div>
        )
      )}
    </div>
  );
}