import React from "react";
import { ArrowLeft, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";

export default function RiskDisclaimer() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-3">
          <Link to="/" className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back</span>
          </Link>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-loss" /> Risk Disclaimer
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        <div className="text-xs text-muted-foreground/50 font-mono">
          Last updated: {new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}
        </div>

        {/* Critical Banner */}
        <div className="bg-loss/15 border-2 border-loss/40 rounded-xl px-6 py-4 space-y-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-loss flex-shrink-0 mt-0.5" />
            <div>
              <h2 className="text-lg font-black text-loss mb-2">NO LIABILITY — READ CAREFULLY</h2>
              <p className="text-sm text-foreground/90 font-semibold">
                Sniper Terminal provides <strong>market intelligence and analysis only</strong>. We accept <strong>zero liability</strong> for any trading losses, financial harm, or damages resulting from the use of this App. You assume all risk of loss.
              </p>
            </div>
          </div>
        </div>

        {/* 1. No Financial Advice */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">1. This Is Not Financial Advice</h2>
          <div className="bg-loss/10 border border-loss/25 rounded-lg px-4 py-3 space-y-2">
            <p className="text-sm text-foreground/80 leading-relaxed">
              <strong>Sniper Terminal does not provide financial advice, investment advice, or trading recommendations.</strong> All signals, analysis, scores, and projections are provided for speculative and analytical purposes only. They are not intended to be relied upon as financial or investment advice.
            </p>
            <p className="text-sm text-foreground/80 leading-relaxed">
              You must not use the App to make trading or investment decisions. You are solely responsible for all decisions you make regarding your money and assets. We strongly recommend consulting independent financial, tax, and legal professionals before trading.
            </p>
          </div>
        </section>

        {/* 2. Market Intelligence Only */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">2. Market Intelligence & Analysis Tool</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App is a decision-support tool that generates market analysis signals based on algorithmic scoring. This is NOT:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>A regulated financial service or investment platform</li>
            <li>A recommendation to buy, sell, hold, or trade any asset</li>
            <li>A forecast of future price movements (no predictions are guaranteed)</li>
            <li>Professional or institutional-grade analysis (retail tool only)</li>
            <li>A substitute for your own independent research and due diligence</li>
          </ul>
        </section>

        {/* 3. No Guarantees on Accuracy */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">3. No Guarantees on Data or Accuracy</h2>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Data Quality:</strong> Market data is sourced from third parties (CoinGecko, DEX Screener, Yahoo Finance, etc.). We do not verify accuracy and cannot guarantee completeness or timeliness.</li>
            <li><strong>Stale Data:</strong> Signals may become outdated quickly. Market conditions change rapidly — an analysis from 1 hour ago may be invalid now.</li>
            <li><strong>Algorithm Errors:</strong> Our scoring algorithms may contain bugs, logic errors, or produce incorrect results without warning.</li>
            <li><strong>No Warranties:</strong> The App is provided "AS IS" with no warranty of accuracy, fitness for purpose, or non-infringement.</li>
            <li><strong>Missing Data:</strong> If live data is unavailable, we use fallback values — signals generated from fallback data are less reliable.</li>
          </ul>
        </section>

        {/* 4. Past Performance */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">4. Past Performance ≠ Future Results</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            <strong>Historical returns and past performance do not guarantee or indicate future profitability.</strong> Assets that have performed well in the past may lose value significantly. Trading signals that worked historically may fail in different market conditions. You must not assume that backtested or historical performance will repeat.
          </p>
        </section>

        {/* 5. Extreme Risk Warning */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">5. Trading Carries Extreme Risk</h2>
          <div className="bg-loss/10 border border-loss/25 rounded-lg px-4 py-3 space-y-2">
            <p className="text-sm text-foreground/80 font-semibold">
              All trading and investing in financial assets — whether crypto, FX, commodities, or equities — carries a substantial risk of loss:
            </p>
            <ul className="text-sm text-foreground/80 space-y-1.5 ml-4 list-disc">
              <li>You can lose your entire investment or more (especially with leverage)</li>
              <li>Market volatility can result in rapid, unpredictable price swings</li>
              <li>Leverage and derivatives amplify both gains AND losses exponentially</li>
              <li>Crypto and emerging markets are highly speculative and unregulated</li>
              <li>Liquidity can dry up suddenly, making it impossible to exit a position</li>
              <li>Scams, hacks, and exchange failures can result in total loss of funds</li>
              <li>Emotional trading (fear, greed) leads to poor decisions and losses</li>
            </ul>
          </div>
        </section>

        {/* 6. Money You Can Afford to Lose */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">6. Only Trade Money You Can Afford to Lose</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            <strong>You must only trade with capital you can afford to lose in its entirety without affecting your livelihood, savings, or financial security.</strong> Do not borrow money to trade. Do not risk money needed for rent, food, debt repayment, or emergency funds. Do not trade with money from loans or mortgages.
          </p>
        </section>

        {/* 7. Viral & Crowded Markets */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">7. Warning: Viral & Crowded Market Signals</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App identifies "viral" assets showing abnormal attention and volume spikes. <strong>Viral signals are HIGHEST RISK and NOT recommended for most traders.</strong>
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Viral moves are often driven by retail crowd euphoria, not fundamental value</li>
            <li>Late entries into viral moves face sharp reversals and total loss risk</li>
            <li>Liquidity can vanish suddenly, trapping late participants</li>
            <li>These assets are targets for manipulation and fraud</li>
          </ul>
        </section>

        {/* 8. No Responsibility for Losses */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">8. We Accept No Responsibility for Trading Losses</h2>
          <div className="bg-loss/10 border border-loss/25 rounded-lg px-4 py-3 space-y-2">
            <p className="text-sm text-foreground/80 font-semibold">
              <strong>We assume zero liability for any losses, damages, or financial harm resulting from your use of the App, including:</strong>
            </p>
            <ul className="text-sm text-foreground/80 space-y-1.5 ml-4 list-disc">
              <li>Direct trading losses or profit loss</li>
              <li>Losses from following signals that prove unprofitable</li>
              <li>Tax consequences or regulatory fines</li>
              <li>Losses from stale or incorrect data</li>
              <li>Technical errors, bugs, or service outages</li>
              <li>Losses from third-party API failures or data feeds</li>
              <li>Unauthorized access or account compromise (if not your fault)</li>
              <li>Indirect or consequential losses of any kind</li>
            </ul>
          </div>
        </section>

        {/* 9. Regulatory Compliance */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">9. You Are Responsible for Regulatory Compliance</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App is available in the UK, EU, and US. <strong>You are solely responsible for ensuring your use complies with all applicable laws and regulations in your jurisdiction, including:</strong>
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Financial conduct rules and licensing requirements</li>
            <li>KYC/AML (Know Your Customer / Anti-Money Laundering) obligations</li>
            <li>Tax reporting and capital gains declarations</li>
            <li>Restrictions on certain asset classes in your region</li>
            <li>Age restrictions (must be 18+)</li>
            <li>Restrictions on leverage or margin trading</li>
          </ul>
        </section>

        {/* 10. Third-Party Services */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">10. Third-Party Data & Services</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App relies on third-party APIs and data providers (CoinGecko, DEX Screener, Yahoo Finance, Twelve Data, etc.). We do not control, endorse, or guarantee their accuracy:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Third-party data feeds can fail, become stale, or contain errors</li>
            <li>We are not responsible for inaccuracies in their data</li>
            <li>Price feeds may be delayed or manipulated</li>
            <li>Exchange outages or API failures are beyond our control</li>
          </ul>
        </section>

        {/* 11. Mental Health & Addiction */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">11. Mental Health Warning</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            Frequent trading and speculative investing can be psychologically addictive and emotionally damaging:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Losses can trigger anxiety, depression, or financial trauma</li>
            <li>Pursuit of recovery losses often leads to larger losses</li>
            <li>Overconfidence bias can lead to excessive risk-taking</li>
            <li>If you struggle with gambling addiction, do not use this App</li>
          </ul>
          <p className="text-sm text-foreground/80 leading-relaxed mt-3">
            If you need support, please reach out to financial counselors or mental health professionals.
          </p>
        </section>

        {/* 12. Use At Your Own Risk */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">12. Use At Your Own Risk</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            By using Sniper Terminal, you acknowledge that:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>You understand the extreme risks of trading and investing</li>
            <li>You are trading at your own risk and accept all consequences</li>
            <li>You will not hold us liable for any losses or damages</li>
            <li>You have read and understood this entire Risk Disclaimer</li>
            <li>You have independent financial and tax advice from professionals</li>
          </ul>
        </section>

        <div className="border-t border-border pt-6 mt-8">
          <p className="text-[10px] text-muted-foreground/40 leading-relaxed">
            <strong>Disclaimer:</strong> This Risk Disclaimer is provided for informational purposes and does not constitute legal advice. It reflects our current understanding of risk disclosure best practices. Consult legal professionals for your jurisdiction's specific requirements. Sniper Terminal assumes no liability for injuries, losses, or damages arising from the use of this App.
          </p>
        </div>
      </div>
    </div>
  );
}