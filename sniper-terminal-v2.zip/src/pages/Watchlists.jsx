import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import EmptyState from "../components/shared/EmptyState";
import AssetSearchBar from "@/components/assets/AssetSearchBar";
import MobileHeader from "@/components/layout/MobileHeader";

export default function Watchlists() {
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState("");
  const [selectedList, setSelectedList] = useState(null);

  const queryClient = useQueryClient();

  const { data: watchlists } = useQuery({
    queryKey: ["watchlists"],
    queryFn: () => base44.entities.Watchlists.list("-created_date", 50),
    initialData: [],
  });

  const { data: items } = useQuery({
    queryKey: ["watchlistItems"],
    queryFn: () => base44.entities.WatchlistItems.list("-created_date", 500),
    initialData: [],
  });

  const createList = useMutation({
    mutationFn: (data) => base44.entities.Watchlists.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["watchlists"] }); setShowNew(false); setNewName(""); },
  });

  const addItem = useMutation({
    mutationFn: (data) => base44.entities.WatchlistItems.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["watchlistItems"] }); },
  });

  const deleteItem = useMutation({
    mutationFn: (id) => base44.entities.WatchlistItems.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["watchlistItems"] }),
  });

  const active = selectedList || watchlists[0];
  const activeItems = items.filter(i => active && i.watchlist_id === active.id);

  return (
    <div className="space-y-4">
      <MobileHeader icon={Eye} title="Watchlists" subtitle="Monitor assets you're tracking" />
      <div className="hidden md:flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Eye className="w-5 h-5 text-primary" /> Watchlists
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Monitor assets you're tracking</p>
        </div>
        <Button variant="outline" size="sm" className="text-xs" onClick={() => setShowNew(true)}>
          <Plus className="w-3 h-3 mr-1" /> New List
        </Button>
      </div>

      {watchlists.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          {watchlists.map(w => (
            <button key={w.id} onClick={() => setSelectedList(w)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${active?.id === w.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {w.name}
            </button>
          ))}
        </div>
      )}

      {!active ? (
        <EmptyState icon={Eye} title="No watchlists yet" description="Create a watchlist to start monitoring assets." />
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between">
            <span className="text-sm font-semibold">{active.name}</span>
                <div className="w-56 sm:w-72">
              <AssetSearchBar
                placeholder="Search or add asset…"
                onSelect={(asset) => {
                  if (active) addItem.mutate({ watchlist_id: active.id, asset_symbol: asset.symbol, asset_name: asset.name });
                }}
                onCreated={(asset) => {
                  if (active) addItem.mutate({ watchlist_id: active.id, asset_symbol: asset.symbol, asset_name: asset.name });
                }}
              />
            </div>
          </div>
          {activeItems.length === 0 ? (
            <EmptyState icon={Eye} title="Empty watchlist" description="Add assets to this watchlist." />
          ) : (
            <div className="divide-y divide-border">
              {activeItems.map(item => (
                <div key={item.id} className="px-4 py-2.5 flex items-center justify-between hover:bg-accent/50 transition-colors">
                  <div>
                    <span className="font-mono font-semibold text-sm">{item.asset_symbol}</span>
                    {item.asset_name && <span className="text-xs text-muted-foreground ml-2">{item.asset_name}</span>}
                    {item.notes && <p className="text-xs text-muted-foreground/70 mt-0.5">{item.notes}</p>}
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteItem.mutate(item.id)}>
                    <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>New Watchlist</DialogTitle></DialogHeader>
          <Input placeholder="Watchlist name" value={newName} onChange={e => setNewName(e.target.value)} className="bg-secondary/50" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
            <Button onClick={() => createList.mutate({ name: newName })} disabled={!newName.trim()}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


    </div>
  );
}