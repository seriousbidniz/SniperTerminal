import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Globe, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import EmptyState from "../components/shared/EmptyState";

export default function Markets() {
  const [search, setSearch] = useState("");
  const [marketFilter, setMarketFilter] = useState("all");

  const { data: assets } = useQuery({
    queryKey: ["assets"],
    queryFn: () => base44.entities.Assets.list("-volume_24h", 100),
    initialData: [],
  });

  const filtered = useMemo(() => {
    let result = assets;
    if (marketFilter !== "all") result = result.filter(a => a.market_type === marketFilter);
    if (search) result = result.filter(a => 
      a.symbol?.toLowerCase().includes(search.toLowerCase()) || 
      a.name?.toLowerCase().includes(search.toLowerCase())
    );
    return result;
  }, [assets, marketFilter, search]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
          <Globe className="w-5 h-5 text-primary" /> Markets Explorer
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">Browse and explore tracked assets</p>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-sm">
          <Search className="w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search assets..." value={search} onChange={e => setSearch(e.target.value)} className="h-8 bg-secondary/50 border-border text-sm" />
        </div>
        <Select value={marketFilter} onValueChange={setMarketFilter}>
          <SelectTrigger className="h-8 text-xs w-28 bg-secondary/50 border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="crypto">Crypto</SelectItem>
            <SelectItem value="fx">FX</SelectItem>
            <SelectItem value="commodity">Commodity</SelectItem>
            <SelectItem value="index">Index</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Globe} title="No assets found" description="Add assets to start tracking markets." />
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-[10px] text-muted-foreground uppercase tracking-wider">
                  <th className="text-left px-4 py-2.5">Asset</th>
                  <th className="text-right px-4 py-2.5">Price</th>
                  <th className="text-right px-4 py-2.5">1h</th>
                  <th className="text-right px-4 py-2.5">24h</th>
                  <th className="text-right px-4 py-2.5">7d</th>
                  <th className="text-right px-4 py-2.5">Volume 24h</th>
                  <th className="text-right px-4 py-2.5">Liquidity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(asset => (
                  <tr key={asset.id} className="hover:bg-accent/50 transition-colors">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold">{asset.symbol}</span>
                        <span className="text-xs text-muted-foreground">{asset.name}</span>
                        <span className="text-[9px] text-muted-foreground/50 uppercase">{asset.market_type}</span>
                      </div>
                    </td>
                    <td className="text-right px-4 py-2.5 font-mono">${asset.current_price?.toLocaleString() ?? "—"}</td>
                    <td className={`text-right px-4 py-2.5 font-mono ${(asset.price_change_1h || 0) >= 0 ? "text-profit" : "text-loss"}`}>
                      {asset.price_change_1h != null ? `${asset.price_change_1h > 0 ? "+" : ""}${asset.price_change_1h.toFixed(2)}%` : "—"}
                    </td>
                    <td className={`text-right px-4 py-2.5 font-mono ${(asset.price_change_24h || 0) >= 0 ? "text-profit" : "text-loss"}`}>
                      {asset.price_change_24h != null ? `${asset.price_change_24h > 0 ? "+" : ""}${asset.price_change_24h.toFixed(2)}%` : "—"}
                    </td>
                    <td className={`text-right px-4 py-2.5 font-mono ${(asset.price_change_7d || 0) >= 0 ? "text-profit" : "text-loss"}`}>
                      {asset.price_change_7d != null ? `${asset.price_change_7d > 0 ? "+" : ""}${asset.price_change_7d.toFixed(2)}%` : "—"}
                    </td>
                    <td className="text-right px-4 py-2.5 font-mono text-muted-foreground">
                      {asset.volume_24h ? `$${(asset.volume_24h / 1e6).toFixed(1)}M` : "—"}
                    </td>
                    <td className="text-right px-4 py-2.5 font-mono">{asset.liquidity_score ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}