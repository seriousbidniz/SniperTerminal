import React from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-3">
          <Link to="/" className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back</span>
          </Link>
          <h1 className="text-2xl font-bold">Privacy Policy</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        <div className="text-xs text-muted-foreground/50 font-mono">
          Last updated: {new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}
        </div>

        {/* Intro */}
        <section className="space-y-3">
          <p className="text-sm text-foreground/80 leading-relaxed">
            Sniper Terminal ("we", "us", "our", or "Company") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information in compliance with <strong>GDPR (EU Regulation 2016/679)</strong>, <strong>UK GDPR</strong>, and applicable US data protection laws.
          </p>
          <p className="text-sm text-foreground/80 leading-relaxed">
            Please read this Privacy Policy carefully. If you do not agree with our practices, please do not use the App.
          </p>
        </section>

        {/* 1. Information We Collect */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">1. Information We Collect</h2>
          
          <h3 className="text-base font-semibold mt-4">1.1 Information You Provide</h3>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Account Registration:</strong> Name, email address, password (via Base44 authentication)</li>
            <li><strong>Payment Information:</strong> Credit card, billing address, transaction history (processed through [Payment Provider — TBC]; we do not store card data)</li>
            <li><strong>Profile Data:</strong> Trading preferences, risk appetite, investment timeline, portfolio information</li>
            <li><strong>User Content:</strong> Trading notes, watchlists, portfolio holdings, strategy preferences</li>
          </ul>

          <h3 className="text-base font-semibold mt-4">1.2 Information Collected Automatically</h3>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Device & Log Data:</strong> IP address, browser type, OS, device identifiers, pages visited, time spent, referral source</li>
            <li><strong>Cookies & Tracking:</strong> Session cookies, analytics cookies, preference cookies (with your consent)</li>
            <li><strong>Interaction Data:</strong> Features used, signals viewed, assets tracked, alerts set</li>
            <li><strong>Geolocation:</strong> Approximate location from IP (not precise GPS)</li>
          </ul>

          <h3 className="text-base font-semibold mt-4">1.3 Third-Party Data</h3>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>We receive market data from CoinGecko, DEX Screener, Yahoo Finance, Twelve Data — these are not personal data</li>
            <li>If you connect social/financial accounts, we receive only aggregated, non-personal data</li>
          </ul>
        </section>

        {/* 2. Legal Basis for Processing */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">2. Legal Basis for Processing (GDPR/UK GDPR)</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            We process personal data on the following legal bases:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Consent:</strong> For marketing, analytics, and non-essential cookies (you can withdraw at any time)</li>
            <li><strong>Contract:</strong> To provide the App and process payments</li>
            <li><strong>Legal Obligation:</strong> To comply with laws (e.g., AML/KYC, tax reporting)</li>
            <li><strong>Legitimate Interests:</strong> To improve the App, detect fraud, enforce our terms</li>
          </ul>
        </section>

        {/* 3. How We Use Your Data */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">3. How We Use Your Data</h2>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>To provide and maintain the App and generate signals/analysis</li>
            <li>To process payments and manage billing</li>
            <li>To send transactional emails (account updates, password resets)</li>
            <li>To improve the App and develop new features</li>
            <li>To detect, prevent, and address fraud, abuse, and security issues</li>
            <li>To comply with legal obligations and enforce our Terms</li>
            <li>To send promotional emails (only with your explicit consent)</li>
            <li>To conduct analytics and understand user behaviour</li>
          </ul>
        </section>

        {/* 4. Data Sharing & Disclosure */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">4. Data Sharing & Disclosure</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            <strong>We do not sell your personal data.</strong> We may share data with:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Service Providers:</strong> Payment processors, hosting providers, analytics services (under data processing agreements)</li>
            <li><strong>Legal Authorities:</strong> When required by law or court order</li>
            <li><strong>Business Transfers:</strong> In case of merger, acquisition, or asset sale</li>
            <li><strong>With Your Consent:</strong> For integrations or third-party services you explicitly authorize</li>
          </ul>
        </section>

        {/* 5. Data Retention */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">5. Data Retention</h2>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Account Data:</strong> Retained for the duration of your account and 12 months after deletion (for legal/compliance purposes)</li>
            <li><strong>Payment Records:</strong> Retained for 7 years (tax & regulatory compliance)</li>
            <li><strong>Log & Interaction Data:</strong> Retained for 6 months, then anonymized</li>
            <li><strong>Cookies:</strong> Session cookies deleted at logout; analytics cookies retained for 13 months</li>
          </ul>
          <p className="text-sm text-foreground/80 leading-relaxed mt-3">
            You can request deletion of your account at any time. We will remove personal data within 30 days, except where legally required to retain it.
          </p>
        </section>

        {/* 6. Your Rights (GDPR/UK GDPR) */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">6. Your Rights Under GDPR & UK GDPR</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            If you are in the EU or UK, you have the following rights:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Right to Access:</strong> Request a copy of your personal data</li>
            <li><strong>Right to Rectification:</strong> Correct inaccurate data</li>
            <li><strong>Right to Erasure:</strong> Request deletion of your data ("right to be forgotten")</li>
            <li><strong>Right to Restrict Processing:</strong> Limit how your data is used</li>
            <li><strong>Right to Data Portability:</strong> Export your data in a portable format</li>
            <li><strong>Right to Object:</strong> Opt out of marketing or profiling</li>
            <li><strong>Right to Withdraw Consent:</strong> Withdraw consent for non-contractual processing</li>
          </ul>
          <p className="text-sm text-foreground/80 leading-relaxed mt-3">
            To exercise these rights, email us at [privacy@sniperterminal.com — TBC]. We will respond within 30 days.
          </p>
        </section>

        {/* 7. Security */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">7. Security Measures</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            We implement industry-standard security measures to protect your data:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>SSL/TLS encryption for data in transit</li>
            <li>Encryption at rest for sensitive data</li>
            <li>Regular security audits and penetration testing</li>
            <li>Restricted access to personal data (least-privilege principle)</li>
            <li>Multi-factor authentication support</li>
          </ul>
          <p className="text-sm text-foreground/80 leading-relaxed mt-3">
            However, no method of transmission or storage is 100% secure. We cannot guarantee absolute security.
          </p>
        </section>

        {/* 8. Cookies & Tracking */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">8. Cookies & Tracking Technologies</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            We use cookies for:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Essential:</strong> Session management, authentication (no consent required)</li>
            <li><strong>Analytics:</strong> Google Analytics, Mixpanel (consent required in EU/UK)</li>
            <li><strong>Preference:</strong> Remember your theme, language, settings</li>
            <li><strong>Marketing:</strong> Retargeting pixels (consent required)</li>
          </ul>
          <p className="text-sm text-foreground/80 leading-relaxed mt-3">
            You can manage cookie preferences via our Cookie Consent Banner. You can also disable cookies in your browser settings, but some features may not work.
          </p>
        </section>

        {/* 9. International Data Transfers */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">9. International Data Transfers</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App is hosted on US servers. If you are in the EU/UK, your data may be transferred to the US. We ensure such transfers comply with GDPR Article 46 through Standard Contractual Clauses (SCCs) or adequacy decisions.
          </p>
        </section>

        {/* 10. Data Protection Officer */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">10. Data Protection Officer & Supervisory Authority</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            If you have privacy concerns, you may lodge a complaint with your local data protection authority:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>EU:</strong> Your Member State's Data Protection Authority</li>
            <li><strong>UK:</strong> Information Commissioner's Office (ICO) — www.ico.org.uk</li>
            <li><strong>US:</strong> FTC (Federal Trade Commission) — www.ftc.gov</li>
          </ul>
        </section>

        {/* 11. Contact */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">11. Contact Us</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            For privacy inquiries, data requests, or complaints:
          </p>
          <div className="bg-secondary/20 border border-border rounded-lg px-4 py-3 text-sm font-mono space-y-1">
            <div>Email: <span className="text-primary">[privacy@sniperterminal.com — TBC]</span></div>
            <div>Address: <span className="text-primary">[Company Address — TBC]</span></div>
            <div>Data Protection Officer: <span className="text-primary">[DPO — TBC]</span></div>
          </div>
        </section>

        <div className="border-t border-border pt-6 mt-8">
          <p className="text-[10px] text-muted-foreground/40 leading-relaxed">
            This Privacy Policy is effective as of the date above and will be updated as our practices evolve. We will notify you of material changes via email or by posting a notice on the App.
          </p>
        </div>
      </div>
    </div>
  );
}