import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Newspaper, Calendar } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EmptyState from "../components/shared/EmptyState";

const categoryColors = {
  bullish: "text-profit bg-profit/10 border-profit/30",
  bearish: "text-loss bg-loss/10 border-loss/30",
  mixed: "text-warning bg-warning/10 border-warning/30",
  macro: "text-primary bg-primary/10 border-primary/30",
  regulation: "text-viral bg-viral/10 border-viral/30",
  protocol: "text-primary bg-primary/10 border-primary/30",
  exchange: "text-muted-foreground bg-secondary border-border",
  exploit: "text-loss bg-loss/10 border-loss/30",
  narrative: "text-viral bg-viral/10 border-viral/30",
};

export default function News() {
  const [tab, setTab] = useState("news");
  const [catFilter, setCatFilter] = useState("all");

  const { data: newsEvents } = useQuery({
    queryKey: ["newsAll"],
    queryFn: () => base44.entities.NewsEvents.list("-created_date", 100),
    initialData: [],
  });

  const { data: macroEvents } = useQuery({
    queryKey: ["macroAll"],
    queryFn: () => base44.entities.MacroEvents.list("-scheduled_at", 50),
    initialData: [],
  });

  const filteredNews = useMemo(() => {
    if (catFilter === "all") return newsEvents;
    return newsEvents.filter(e => e.category === catFilter);
  }, [newsEvents, catFilter]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
          <Newspaper className="w-5 h-5 text-primary" /> News & Catalysts
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">Track market-moving events and narratives</p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-secondary">
          <TabsTrigger value="news" className="text-xs">News Events</TabsTrigger>
          <TabsTrigger value="macro" className="text-xs">Macro Calendar</TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === "news" && (
        <>
          <div className="flex gap-1.5 flex-wrap">
            {["all", "bullish", "bearish", "mixed", "macro", "regulation", "protocol", "exchange", "exploit", "narrative"].map(c => (
              <button key={c} onClick={() => setCatFilter(c)}
                className={`px-2.5 py-1 rounded text-[10px] uppercase tracking-wider font-medium transition-colors ${catFilter === c ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                {c}
              </button>
            ))}
          </div>
          {filteredNews.length === 0 ? (
            <EmptyState icon={Newspaper} title="No news events" />
          ) : (
            <div className="space-y-2">
              {filteredNews.map(event => (
                <div key={event.id} className="bg-card border border-border rounded-lg px-4 py-3 hover:bg-accent/50 transition-colors">
                  <div className="flex items-start gap-3">
                    <span className={`text-[10px] font-medium uppercase px-1.5 py-0.5 rounded border flex-shrink-0 mt-0.5 ${categoryColors[event.category] || categoryColors.mixed}`}>
                      {event.category}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{event.title}</p>
                      {event.summary && <p className="text-xs text-muted-foreground mt-1">{event.summary}</p>}
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                        {event.impact_level && <span className={event.impact_level === "critical" || event.impact_level === "high" ? "text-loss" : ""}>{event.impact_level} impact</span>}
                        {event.source && <span>{event.source}</span>}
                        {event.related_assets?.length > 0 && <span className="font-mono">{event.related_assets.join(", ")}</span>}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {tab === "macro" && (
        macroEvents.length === 0 ? (
          <EmptyState icon={Calendar} title="No macro events" description="Add upcoming macro events to track market impact." />
        ) : (
          <div className="space-y-2">
            {macroEvents.map(event => (
              <div key={event.id} className="bg-card border border-border rounded-lg px-4 py-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{event.title}</p>
                    {event.description && <p className="text-xs text-muted-foreground mt-1">{event.description}</p>}
                    <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                      <span className="uppercase">{event.event_type?.replace(/_/g, " ")}</span>
                      <span className={event.impact_level === "critical" || event.impact_level === "high" ? "text-loss" : ""}>{event.impact_level} impact</span>
                    </div>
                  </div>
                  {event.scheduled_at && (
                    <span className="text-xs font-mono text-muted-foreground flex-shrink-0">
                      {new Date(event.scheduled_at).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )
      )}
    </div>
  );
}