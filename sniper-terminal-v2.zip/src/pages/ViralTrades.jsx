import SignalCountdown from "@/components/shared/SignalCountdown";
import React, { useState, useMemo } from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Flame, RefreshCw, AlertTriangle } from "lucide-react";
import { TradeReasonPill } from "@/components/shared/TradeReasonIndicator";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ViralDetailDrawer from "@/components/drilldown/ViralDetailDrawer";
import EmptyState from "@/components/shared/EmptyState";
import StaleBanner from "@/components/shared/StaleBanner";
import { isStale } from "@/lib/freshness";

const STALE_MS = 6 * 60 * 60 * 1000;

const moveStateColors = {
  early:     "text-profit bg-profit/10 border-profit/25",
  building:  "text-primary bg-primary/10 border-primary/25",
  crowded:   "text-warning bg-warning/10 border-warning/25",
  exhausted: "text-loss bg-loss/10 border-loss/25",
};

const aiColors = {
  tradable: "text-profit bg-profit/10 border-profit/25",
  caution:  "text-warning bg-warning/10 border-warning/25",
  avoid:    "text-loss bg-loss/10 border-loss/25",
};

function ScoreBar({ value, inverted = false }) {
  if (value == null) return <span className="text-muted-foreground/30 text-xs font-mono">—</span>;
  const pct = Math.min(Math.max(Math.round(value), 0), 100);
  const display = inverted ? 100 - pct : pct;
  const color = display >= 70 ? "text-profit" : display >= 45 ? "text-warning" : "text-loss";
  return <span className={`font-mono font-bold text-xs ${color}`}>{pct}</span>;
}

export default function ViralTrades() {
  const [selected, setSelected] = useState(null);
  const [sortBy, setSortBy] = useState("viral_score");
  const [labelFilter, setLabelFilter] = useState("all");
  const [stateFilter, setStateFilter] = useState("all");
  const [isRefreshing, setIsRefreshing] = useState(false);

  const queryClient = useQueryClient();

  const { data: rawSignals = [], isLoading } = useQuery({
    queryKey: ["viralTradeSignals"],
    queryFn: () => base44.entities.ViralTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-viral_score", 200),
  });

  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    assets.forEach(a => { m[a.id] = a; });
    return m;
  }, [assets]);

  const enriched = useMemo(() => rawSignals.map(sig => {
    const asset = assetMap[sig.asset];
    const rawInputs = sig.raw_inputs ? JSON.parse(sig.raw_inputs) : {};
    return {
      ...sig,
      asset_symbol: asset?.symbol || sig.asset || "—",
      asset_name: asset?.name || "",
      market_type: asset?.market_type || "crypto",
      is_stale: isStale(sig.timestamp, STALE_MS),
      raw_inputs: rawInputs,
    };
  }), [rawSignals, assetMap]);

  // Separate live signals from full-fallback signals
  const liveSignals = useMemo(() => enriched.filter(s => s.data_quality !== "full_fallback"), [enriched]);
  const fallbackSignals = useMemo(() => enriched.filter(s => s.data_quality === "full_fallback"), [enriched]);

  const filtered = useMemo(() => {
    let r = liveSignals;
    if (labelFilter !== "all") r = r.filter(s => s.ai_label === labelFilter);
    if (stateFilter !== "all") r = r.filter(s => s.move_state === stateFilter);
    return [...r].sort((a, b) => (b[sortBy] || 0) - (a[sortBy] || 0));
  }, [liveSignals, labelFilter, stateFilter, sortBy]);

  const hasStale = filtered.some(s => s.is_stale);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await base44.functions.invoke("scoreViralTrades", {});
      queryClient.invalidateQueries({ queryKey: ["viralTradeSignals"] });
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-viral" />
            <h1 className="text-xl font-bold tracking-tight">Viral Trades</h1>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Assets with abnormal attention, volume spikes, or rapid narrative acceleration. <strong>Virality ≠ trade quality.</strong>
          </p>
        </div>
        <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={handleRefresh} disabled={isRefreshing}>
          <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin" : ""}`} />
          {isRefreshing ? "Scoring…" : "Recompute"}
        </Button>
      </div>

      {/* Disclaimer */}
      <div className="flex items-start gap-2 bg-viral/5 border border-viral/20 rounded-lg px-3 py-2.5 text-xs text-viral/80">
        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
        <span>Viral signals measure market attention — not setup quality. High viral scores often indicate late-stage or overcrowded moves. Use independent analysis before acting.</span>
      </div>

      {hasStale && <StaleBanner message="Some viral data may be delayed. Labels shown with reduced certainty." />}

      {fallbackSignals.length > 0 && (
        <div className="flex items-start gap-2 bg-warning/5 border border-warning/25 rounded-lg px-3 py-2.5 text-xs text-warning/80">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
          <div>
            <span className="font-medium">Incomplete Data:</span> {fallbackSignals.length} asset{fallbackSignals.length !== 1 ? "s" : ""} excluded — missing core viral inputs (change_1h, change_4h, volume change, attention, or liquidity). Only showing signals with complete asset-specific data.
          </div>
        </div>
      )}

      {liveSignals.length === 0 && rawSignals.length === 0 && (
        <div className="flex items-start gap-2 bg-info/5 border border-info/25 rounded-lg px-3 py-2.5 text-xs text-info/80">
          No viral signals available. Run Recompute or Refresh All to generate signals from assets with complete market data.
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <Select value={labelFilter} onValueChange={setLabelFilter}>
          <SelectTrigger className="h-7 text-xs w-[110px] bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent className="text-xs">
            <SelectItem value="all">All Labels</SelectItem>
            <SelectItem value="tradable">Tradable</SelectItem>
            <SelectItem value="caution">Caution</SelectItem>
            <SelectItem value="avoid">Avoid</SelectItem>
          </SelectContent>
        </Select>
        <Select value={stateFilter} onValueChange={setStateFilter}>
          <SelectTrigger className="h-7 text-xs w-[110px] bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent className="text-xs">
            <SelectItem value="all">All States</SelectItem>
            <SelectItem value="early">Early</SelectItem>
            <SelectItem value="building">Building</SelectItem>
            <SelectItem value="crowded">Crowded</SelectItem>
            <SelectItem value="exhausted">Exhausted</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="h-7 text-xs w-[130px] bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent className="text-xs">
            <SelectItem value="viral_score">Sort: Viral ↓</SelectItem>
            <SelectItem value="attention_score">Sort: Attention ↓</SelectItem>
            <SelectItem value="volume_spike_score">Sort: Volume ↓</SelectItem>
            <SelectItem value="liquidity_quality_score">Sort: Liquidity ↓</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-[10px] text-muted-foreground font-mono ml-auto">
          {filtered.length === 0 && liveSignals.length === 0 ? "No signals with valid data" : (
            <>
              {filtered.length} signal{filtered.length !== 1 ? "s" : ""} with real asset-specific data
              {fallbackSignals.length > 0 && <span className="ml-1 text-warning">({fallbackSignals.length} incomplete excluded)</span>}
            </>
          )}
        </span>
      </div>

      {filtered.length < 20 && liveSignals.length < 20 && liveSignals.length > 0 && (
        <div className="text-[11px] text-muted-foreground/60 bg-secondary/20 border border-border/40 rounded-lg px-3 py-2">
          Only {liveSignals.length} viral signal{liveSignals.length !== 1 ? "s" : ""} with valid data available. Run Recompute or Refresh All to generate more from tracked assets.
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-xs text-muted-foreground">Loading viral signals…</div>
        ) : filtered.length === 0 ? (
          <EmptyState icon={Flame} title="No viral signals" description="Run Recompute or Refresh All to generate viral signals from tracked assets." />
        ) : (
          <>
            {/* Mobile cards */}
            <div className="md:hidden divide-y divide-border">
              {filtered.map(s => (
                <button
                  key={s.id}
                  onClick={() => setSelected(s)}
                  className={`w-full text-left px-4 py-3.5 hover:bg-viral/5 transition-colors ${s.is_stale ? "opacity-60" : ""}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-sm">{s.asset_symbol}</span>
                        <SignalCountdown signal={s} asset={assetMap[s.asset]} />
                        {s.market_type && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase bg-secondary text-muted-foreground border-border">{s.market_type}</span>
                        )}
                        {s.is_stale && <StaleBanner variant="row" />}
                      </div>
                      {s.asset_name && <div className="text-[10px] text-muted-foreground/60 mt-0.5">{s.asset_name}</div>}
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {s.move_state && (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${moveStateColors[s.move_state] || ""}`}>
                          {s.move_state}
                        </span>
                      )}
                      {s.ai_label && (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${aiColors[s.ai_label] || ""}`}>
                          {s.ai_label}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-x-4 gap-y-1 text-[11px]">
                  <div className="flex justify-between"><span className="text-muted-foreground">Viral</span><span className="font-mono text-viral font-bold">{Math.round(s.viral_score)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Attn</span><span className="font-mono">{Math.round(s.attention_score)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Liq</span><span className="font-mono">{Math.round(s.liquidity_quality_score)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Vol</span><span className="font-mono">{Math.round(s.volume_spike_score)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Crowd</span><span className="font-mono text-warning">{Math.round(s.crowding_score)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Exhaust</span><span className="font-mono text-warning">{Math.round(s.exhaustion_score)}</span></div>
                  </div>
                  {s.summary && <p className="text-[11px] text-muted-foreground/60 mt-2 line-clamp-2 leading-relaxed">{s.summary}</p>}
                </button>
              ))}
            </div>

            {/* Desktop table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-secondary/20">
                    {["Asset", "Label", "State", "Viral", "Attention", "Vol Spike", "Liquidity", "Crowd Risk", "Exhaust Risk", "Reason", "Summary", "Time"].map(h => (
                      <th key={h} className="px-3 py-2.5 text-left text-[10px] text-muted-foreground uppercase tracking-wider whitespace-nowrap font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map(s => (
                    <tr
                      key={s.id}
                      onClick={() => setSelected(s)}
                      className={`cursor-pointer transition-colors hover:bg-accent/30 ${s.is_stale ? "opacity-60" : ""}`}
                    >
                      <td className="px-3 py-3 whitespace-nowrap">
                        <div className="font-mono font-bold text-sm">{s.asset_symbol}</div>
                        <div className="mt-1"><SignalCountdown signal={s} asset={assetMap[s.asset]} /></div>
                        {s.asset_name && <div className="text-[10px] text-muted-foreground/60 truncate max-w-[100px]">{s.asset_name}</div>}
                        {s.is_stale && <span className="text-[9px] text-warning">⚠ stale</span>}
                      </td>
                      <td className="px-3 py-3">
                        {s.ai_label && (
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${aiColors[s.ai_label] || ""}`}>
                            {s.ai_label}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-3">
                        {s.move_state && (
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${moveStateColors[s.move_state] || ""}`}>
                            {s.move_state}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.viral_score)} /></td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.attention_score)} /></td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.volume_spike_score)} /></td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.liquidity_quality_score)} /></td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.crowding_score)} inverted /></td>
                      <td className="px-3 py-3 text-center"><ScoreBar value={Math.round(s.exhaustion_score)} inverted /></td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <TradeReasonPill signal={s} />
                      </td>
                      <td className="px-3 py-3 max-w-[180px]">
                        <span className="line-clamp-2 text-muted-foreground/70 text-[11px] leading-relaxed">{s.summary || "—"}</span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className="font-mono text-[10px] text-muted-foreground/40">
                          {s.timestamp ? new Date(s.timestamp).toLocaleString("en-GB", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <ViralDetailDrawer signal={selected} onClose={() => setSelected(null)} />
    </div>
  );
}