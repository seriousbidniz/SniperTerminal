import SignalCountdown from "@/components/shared/SignalCountdown";
import { formatPrice } from "@/lib/format";
import React, { useState, useMemo } from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Crosshair, RefreshCw, Loader2 } from "lucide-react";
import { TradeReasonPill } from "@/components/shared/TradeReasonIndicator";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { isStale } from "@/lib/freshness";
import StaleBanner from "@/components/shared/StaleBanner";
import RecommendedDetailDrawer from "@/components/drilldown/RecommendedDetailDrawer.jsx";
import DecisionBadge from "@/components/shared/DecisionBadge";
import UrgencyTag from "@/components/shared/UrgencyTag";
import ConfidenceTier from "@/components/shared/ConfidenceTier";
import { SessionModeToggle, useSessionMode, getSessionThresholds } from "@/components/shared/SessionMode";

const STALE_MS = 4 * 60 * 60 * 1000;

const directionColors = {
  bullish: "text-profit bg-profit/10 border-profit/30",
  bearish: "text-loss bg-loss/10 border-loss/30",
};

function ScoreCell({ value, invert = false }) {
  if (value == null) return <span className="text-muted-foreground/30 font-mono text-xs">—</span>;
  const score = Math.round(value);
  const s = invert ? 100 - score : score;
  const color = s >= 70 ? "text-profit" : s >= 45 ? "text-warning" : "text-loss";
  const ring = s >= 70 ? "ring-profit/20" : s >= 45 ? "ring-warning/20" : "ring-loss/20";
  return (
    <span className={`font-mono font-bold text-sm ${color} ring-1 ${ring} rounded px-1.5 py-0.5 bg-card`}>
      {score}
    </span>
  );
}

export default function RecommendedTradesPage() {
  const [selected, setSelected] = useState(null);
  const [dirFilter, setDirFilter] = useState("all");
  const [setupFilter, setSetupFilter] = useState("all");
  const [minScore, setMinScore] = useState("0");
  const [marketFilter, setMarketFilter] = useState("all");
  const [sortBy, setSortBy] = useState("opportunity_score");
  const [recomputing, setRecomputing] = useState(false);

  const queryClient = useQueryClient();
  const { mode } = useSessionMode();
  const sessionThresholds = getSessionThresholds(mode);

  const { data: signals = [], isLoading } = useQuery({
    queryKey: ["recommendedSignals"],
    queryFn: () => base44.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-opportunity_score", 200),
  });

  const { data: assets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    assets.forEach(a => { m[a.id] = a; });
    return m;
  }, [assets]);

  const enriched = useMemo(() => signals.map(sig => {
    const asset = assetMap[sig.asset];
    return {
      ...sig,
      asset_symbol: asset?.symbol || sig.asset || "—",
      asset_name: asset?.name || "",
      market_type: asset?.market_type || "crypto",
      is_stale: isStale(sig.timestamp, STALE_MS),
    };
  }), [signals, assetMap]);

  const setupTypes = useMemo(() => {
    const s = new Set(enriched.map(s => s.setup_type).filter(Boolean));
    return Array.from(s);
  }, [enriched]);

  const filtered = useMemo(() => {
    let r = enriched;
    if (dirFilter !== "all") r = r.filter(s => s.direction === dirFilter);
    if (setupFilter !== "all") r = r.filter(s => s.setup_type === setupFilter);
    if (marketFilter !== "all") r = r.filter(s => s.market_type === marketFilter);
    const min = parseFloat(minScore) || sessionThresholds.minOppScore;
    r = r.filter(s => (s.opportunity_score || 0) >= min);
    r = r.filter(s => (s.risk_score ?? 100) <= sessionThresholds.maxRiskScore);
    return [...r].sort((a, b) => {
      if (sortBy === "risk_score") return (a[sortBy] || 0) - (b[sortBy] || 0); // risk: lower is better
      return (b[sortBy] || 0) - (a[sortBy] || 0);
    });
  }, [enriched, dirFilter, setupFilter, minScore, marketFilter, sortBy]);

  const handleRecompute = async () => {
    setRecomputing(true);
    try {
      await base44.functions.invoke("recomputeRecommendedTrades", {});
      queryClient.invalidateQueries({ queryKey: ["recommendedSignals"] });
    } finally {
      setRecomputing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Crosshair className="w-5 h-5 text-primary" /> Recommended Trades
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Active signals — analysis only, not financial advice
          </p>
        </div>
        <div className="flex items-center gap-2">
          <SessionModeToggle />
          <Button size="sm" variant="outline" className="text-xs gap-1.5" onClick={handleRecompute} disabled={recomputing}>
            {recomputing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
            Recompute
          </Button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
        {/* Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-border bg-secondary/10">
          <span className="text-xs text-muted-foreground font-mono">
            {filtered.length} signal{filtered.length !== 1 ? "s" : ""}
          </span>
          <div className="flex flex-wrap gap-1.5">
            <Select value={dirFilter} onValueChange={setDirFilter}>
              <SelectTrigger className="h-7 text-xs w-[100px] bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="all">All dirs.</SelectItem>
                <SelectItem value="bullish">↑ Bullish</SelectItem>
                <SelectItem value="bearish">↓ Bearish</SelectItem>
              </SelectContent>
            </Select>
            <Select value={setupFilter} onValueChange={setSetupFilter}>
              <SelectTrigger className="h-7 text-xs w-[110px] bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="all">All setups</SelectItem>
                {setupTypes.map(t => (
                  <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={marketFilter} onValueChange={setMarketFilter}>
              <SelectTrigger className="h-7 text-xs w-[100px] bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="all">All markets</SelectItem>
                <SelectItem value="crypto">Crypto</SelectItem>
                <SelectItem value="fx">FX</SelectItem>
                <SelectItem value="commodity">Commodity</SelectItem>
                <SelectItem value="index">Index</SelectItem>
              </SelectContent>
            </Select>
            <Select value={minScore} onValueChange={setMinScore}>
              <SelectTrigger className="h-7 text-xs w-[96px] bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="0">Any score</SelectItem>
                <SelectItem value="50">≥ 50</SelectItem>
                <SelectItem value="60">≥ 60</SelectItem>
                <SelectItem value="70">≥ 70</SelectItem>
                <SelectItem value="80">≥ 80</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="h-7 text-xs w-[130px] bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                <SelectItem value="opportunity_score">Sort: Opp. ↓</SelectItem>
                <SelectItem value="conviction_score">Sort: Conv. ↓</SelectItem>
                <SelectItem value="risk_score">Sort: Risk ↑</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Session mode indicator */}
        <div className={`px-4 py-1.5 border-b border-border/40 text-[10px] font-medium flex items-center gap-2 ${mode === "intraday" ? "bg-warning/5 text-warning/80" : "bg-primary/5 text-primary/70"}`}>
          <span className="uppercase tracking-widest font-bold">{sessionThresholds.label} Mode</span>
          <span className="text-muted-foreground/60">— {sessionThresholds.description}</span>
        </div>

        {!isLoading && enriched.length < 20 && (
          <div className="px-4 py-2 border-b border-border/40 text-[11px] text-muted-foreground/60 bg-secondary/10 flex items-center gap-1.5">
            <span className="text-warning/60">⚠</span>
            {enriched.length === 0
              ? "No signals yet. Add tracked assets in Asset Universe and run Recompute to generate recommendations."
              : `${enriched.length} signal${enriched.length !== 1 ? "s" : ""} available (target: 20+). Signal quality is not lowered to fill quotas — add more tracked assets and run Recompute to increase coverage.`}
          </div>
        )}
        {isLoading ? (
          <div className="py-14 text-center text-xs text-muted-foreground">Loading signals…</div>
        ) : filtered.length === 0 ? (
          <div className="py-14 text-center text-xs text-muted-foreground/60">No active signals match your filters.</div>
        ) : (
          <>
          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-border">
            {filtered.map(s => (
              <button
                key={s.id}
                onClick={() => setSelected(s)}
                className={`w-full text-left px-4 py-3 hover:bg-primary/5 transition-colors ${s.is_stale ? "opacity-60" : ""}`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-sm">{s.asset_symbol}</span>
                      {s.is_stale && <StaleBanner variant="row" />}
                    </div>
                    <DecisionBadge signal={s} size="md" />
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <UrgencyTag signal={s} />
                      <SignalCountdown signal={s} asset={assetMap[s.asset]} />
                      <ConfidenceTier signal={s} showLabel={false} />
                    </div>
                  </div>
                  <ScoreCell value={s.opportunity_score} />
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {s.direction && (
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase ${directionColors[s.direction] || ""}`}>
                      {s.direction === "bullish" ? "▲" : "▼"} {s.direction}
                    </span>
                  )}
                  {s.setup_type && <span className="text-[10px] text-muted-foreground capitalize">{s.setup_type.replace(/_/g, " ")}</span>}
                </div>
                <div className="mt-1"><TradeReasonPill signal={s} /></div>
              </button>
            ))}
          </div>

          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border/60 bg-secondary/5">
                  {["Decision", "Urgency", "Grade", "Asset", "Dir.", "Setup", "Entry Zone", "Inv.", "T1", "OPP", "RISK", "Reason", "Time"].map(h => (
                    <th key={h} className="px-4 py-2.5 text-left text-[9px] font-semibold text-muted-foreground/70 uppercase tracking-widest whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => (
                  <tr
                    key={s.id}
                    onClick={() => setSelected(s)}
                    className={[
                      "group border-b border-border/40 cursor-pointer transition-all duration-100",
                      s.is_stale ? "opacity-55 hover:opacity-75 bg-warning/[0.03]" : "hover:bg-primary/[0.04]",
                    ].join(" ")}
                  >
                    <td className="px-4 py-3 whitespace-nowrap"><DecisionBadge signal={s} size="md" /></td>
                    <td className="px-4 py-3 whitespace-nowrap"><UrgencyTag signal={s} />
                      <SignalCountdown signal={s} asset={assetMap[s.asset]} /></td>
                    <td className="px-4 py-3 whitespace-nowrap"><ConfidenceTier signal={s} showLabel={false} /></td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-foreground text-[13px] group-hover:text-primary transition-colors">
                          {s.asset_symbol}
                        </span>
                        {s.is_stale && <StaleBanner variant="row" />}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {s.direction ? (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md border uppercase tracking-wide ${directionColors[s.direction] || "text-muted-foreground border-border"}`}>
                          {s.direction === "bullish" ? "▲ Long" : "▼ Short"}
                        </span>
                      ) : "—"}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-muted-foreground/80 capitalize">
                      {s.setup_type ? s.setup_type.replace(/_/g, " ") : "—"}
                    </td>
                    <td className="px-4 py-3 font-mono whitespace-nowrap text-muted-foreground/70 text-[11px]">
                      {s.entry_low != null || s.entry_high != null
                        ? `${s.entry_low != null ? `${formatPrice(s.entry_low, s.market_type)}` : "—"} – ${s.entry_high != null ? `${formatPrice(s.entry_high, s.market_type)}` : "—"}`
                        : <span className="text-muted-foreground/30">—</span>}
                    </td>
                    <td className="px-4 py-3 font-mono whitespace-nowrap text-loss/80 text-[11px]">
                      {s.invalidation != null ? `${formatPrice(s.invalidation, s.market_type)}` : <span className="text-muted-foreground/30">—</span>}
                    </td>
                    <td className="px-4 py-3 font-mono whitespace-nowrap text-profit/80 text-[11px]">
                      {s.target_1 != null ? `${formatPrice(s.target_1, s.market_type)}` : <span className="text-muted-foreground/30">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center"><ScoreCell value={s.opportunity_score} /></td>
                    <td className="px-4 py-3 text-center"><ScoreCell value={s.risk_score} invert /></td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <TradeReasonPill signal={s} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-mono text-[10px] text-muted-foreground/40">
                        {s.timestamp
                          ? new Date(s.timestamp).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
                          : "—"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </>
        )}
      </div>

      <RecommendedDetailDrawer signal={selected} onClose={() => setSelected(null)} />
    </div>
  );
}