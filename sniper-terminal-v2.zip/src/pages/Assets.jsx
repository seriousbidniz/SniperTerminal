import React, { useState, useMemo, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Database, Plus, Search, Clock, CheckCircle2, XCircle, RefreshCw, AlertCircle, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AddAssetDialog from "@/components/assets/AddAssetDialog";
import AssetDetailDrawer from "@/components/assets/AssetDetailDrawer";
import EmptyState from "@/components/shared/EmptyState";
import MobileHeader from "@/components/layout/MobileHeader";

const STATUS_CONFIG = {
  active:       { label: "Active",       icon: CheckCircle2, color: "text-profit",          bg: "bg-profit/10 border-profit/25" },
  pending_data: { label: "Pending Data", icon: Clock,        color: "text-warning",          bg: "bg-warning/10 border-warning/25" },
  inactive:     { label: "Inactive",     icon: XCircle,      color: "text-muted-foreground", bg: "bg-secondary border-border" },
  error:        { label: "Error",        icon: AlertCircle,  color: "text-loss",             bg: "bg-loss/10 border-loss/25" },
};

const PROVIDER_LABELS = {
  coingecko:    "CG",
  dex_screener: "DEX",
  twelve_data:  "12D",
  alpha_vantage:"AV",
  manual:       "Manual",
};

export default function Assets() {
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [marketFilter, setMarketFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("symbol");
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [refreshingId, setRefreshingId] = useState(null);
  const [refreshErrors, setRefreshErrors] = useState({});
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedResult, setSeedResult] = useState(null);
  const [isRefreshingAll, setIsRefreshingAll] = useState(false);

  const queryClient = useQueryClient();

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
  });

  const { data: snapshots = [] } = useQuery({
    queryKey: ["allSnapshots"],
    queryFn: () => base44.entities.MarketSnapshots.list("-timestamp", 200),
  });

  const snapshotAssetIds = useMemo(() => new Set(snapshots.map(s => s.asset).filter(Boolean)), [snapshots]);

  const updateAsset = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Assets.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["allAssets"] }),
  });

  // Auto-promote pending_data → active when snapshot exists
  useEffect(() => {
    const pendingWithData = assets.filter(
      a => a.status === "pending_data" && snapshotAssetIds.has(a.id)
    );
    pendingWithData.forEach(a => updateAsset.mutate({ id: a.id, data: { status: "active", active: true } }));
  }, [assets, snapshotAssetIds]); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-open asset drawer when navigated here with ?highlight=ASSET_ID (e.g. from alert drawer)
  useEffect(() => {
    if (!assets.length || selectedAsset) return;
    const params = new URLSearchParams(window.location.search);
    const highlightId = params.get("highlight");
    if (highlightId) {
      const found = assets.find(a => a.id === highlightId);
      if (found) setSelectedAsset(found);
    }
  }, [assets]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => {
    let result = assets;
    if (search) result = result.filter(a =>
      a.symbol?.toLowerCase().includes(search.toLowerCase()) ||
      a.name?.toLowerCase().includes(search.toLowerCase())
    );
    if (marketFilter !== "all") result = result.filter(a => a.market_type === marketFilter);
    if (statusFilter !== "all") result = result.filter(a => (a.status || "active") === statusFilter);
    return [...result].sort((a, b) => {
      if (sortBy === "symbol")          return (a.symbol || "").localeCompare(b.symbol || "");
      if (sortBy === "market_type")     return (a.market_type || "").localeCompare(b.market_type || "");
      if (sortBy === "liquidity_score") return (b.liquidity_score || 0) - (a.liquidity_score || 0);
      if (sortBy === "last_refresh_at") return new Date(b.last_refresh_at || 0) - new Date(a.last_refresh_at || 0);
      return 0;
    });
  }, [assets, search, marketFilter, statusFilter, sortBy]);

  const hasSnapshot = (asset) => snapshotAssetIds.has(asset.id);

  const handleSeedAssets = async () => {
    setIsSeeding(true);
    setSeedResult(null);
    try {
      const res = await base44.functions.invoke("seedAssets", {});
      setSeedResult(res.data);
      queryClient.invalidateQueries({ queryKey: ["allAssets"] });
    } finally {
      setIsSeeding(false);
    }
  };

  const handleRefreshAll = async () => {
    setIsRefreshingAll(true);
    try {
      await base44.functions.invoke("refreshAll", {});
      queryClient.invalidateQueries({ queryKey: ["allAssets"] });
      queryClient.invalidateQueries({ queryKey: ["allSnapshots"] });
    } finally {
      setIsRefreshingAll(false);
    }
  };

  const handleRefresh = async (asset) => {
    if (!asset.data_provider || asset.data_provider === "manual") return;
    setRefreshingId(asset.id);
    setRefreshErrors(prev => ({ ...prev, [asset.id]: null }));
    try {
      const res = await base44.functions.invoke("fetchAssetMarketData", { asset_id: asset.id });
      if (!res.data?.success) {
        setRefreshErrors(prev => ({ ...prev, [asset.id]: res.data?.error || "Provider fetch failed" }));
      }
      queryClient.invalidateQueries({ queryKey: ["allAssets"] });
      queryClient.invalidateQueries({ queryKey: ["allSnapshots"] });
    } catch (e) {
      setRefreshErrors(prev => ({ ...prev, [asset.id]: e.message || "Refresh failed" }));
    } finally {
      setRefreshingId(null);
    }
  };

  return (
    <div className="space-y-4">
      <MobileHeader icon={Database} title="Asset Universe" subtitle="All tracked assets — preloaded and user-added" />
      <div className="hidden md:flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Database className="w-5 h-5 text-primary" /> Asset Universe
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            All tracked assets — preloaded and user-added
          </p>
        </div>
        <div className="flex items-center gap-2">
          {assets.length < 50 && (
            <Button size="sm" variant="outline" className="text-xs gap-1.5" onClick={handleSeedAssets} disabled={isSeeding}>
              <Layers className={`w-3.5 h-3.5 ${isSeeding ? "animate-pulse" : ""}`} />
              {isSeeding ? "Seeding…" : "Seed 60+ Assets"}
            </Button>
          )}
          <Button size="sm" variant="outline" className="text-xs gap-1.5" onClick={handleRefreshAll} disabled={isRefreshingAll}>
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingAll ? "animate-spin" : ""}`} />
            {isRefreshingAll ? "Refreshing…" : "Refresh All"}
          </Button>
          <Button size="sm" className="text-xs gap-1.5" onClick={() => setShowAdd(true)}>
            <Plus className="w-3.5 h-3.5" /> Add Asset
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search symbol or name…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 h-8 text-xs bg-secondary/50"
          />
        </div>
        <Select value={marketFilter} onValueChange={setMarketFilter}>
          <SelectTrigger className="h-8 text-xs w-28 bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Markets</SelectItem>
            <SelectItem value="crypto">Crypto</SelectItem>
            <SelectItem value="fx">FX</SelectItem>
            <SelectItem value="commodity">Commodity</SelectItem>
            <SelectItem value="index">Index</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="h-8 text-xs w-32 bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="pending_data">Pending Data</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="h-8 text-xs w-36 bg-secondary/50"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="symbol">Sort: Symbol</SelectItem>
            <SelectItem value="market_type">Sort: Market</SelectItem>
            <SelectItem value="liquidity_score">Sort: Liquidity ↓</SelectItem>
            <SelectItem value="last_refresh_at">Sort: Recent ↓</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-[10px] text-muted-foreground font-mono ml-auto">
          {filtered.length} asset{filtered.length !== 1 ? "s" : ""}
          {assets.length < 50 && assets.length > 0 && (
            <span className="ml-1 text-warning/60">(target: 50+)</span>
          )}
        </span>
      </div>

      {seedResult && (
        <div className="flex items-center gap-2 bg-profit/5 border border-profit/25 rounded-lg px-3 py-2 text-[11px] text-profit/80">
          <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
          <span>Seeded {seedResult.created} new assets ({seedResult.skipped} already existed). Run "Refresh All" from the dashboard to fetch market data.</span>
        </div>
      )}

      {!isLoading && assets.length < 50 && assets.length > 0 && (
        <div className="flex items-start gap-2 bg-secondary/30 border border-border rounded-lg px-3 py-2 text-[11px] text-muted-foreground">
          <span className="text-warning/60 flex-shrink-0">⚠</span>
          <span>{assets.length} of 50+ target assets tracked. Add more assets to increase signal coverage.</span>
        </div>
      )}

      {isLoading ? (
        <div className="py-10 text-center text-xs text-muted-foreground">Loading assets…</div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Database} title="No assets found" description="Try adjusting filters or add a new asset." />
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          {/* Desktop header */}
          <div className="hidden md:grid grid-cols-[2fr_1fr_1fr_1fr_1fr_auto] gap-4 px-4 py-2.5 bg-secondary/30 border-b border-border text-[10px] text-muted-foreground uppercase tracking-wider">
            <span>Asset</span><span>Market</span><span>Status</span><span>Market Data</span><span>Liquidity</span><span></span>
          </div>
          <div className="divide-y divide-border">
            {filtered.map(asset => {
              const status = asset.status || "active";
              const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.active;
              const Icon = cfg.icon;
              const dataLive = hasSnapshot(asset);
              const canRefresh = asset.data_provider && asset.data_provider !== "manual";
              const isRefreshing = refreshingId === asset.id;

              return (
                <div
                  key={asset.id}
                  onClick={() => setSelectedAsset(asset)}
                  className="px-4 py-3 grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_1fr_1fr_auto] gap-2 md:gap-4 items-center hover:bg-accent/20 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-mono font-bold text-sm">{asset.symbol}</span>
                        {asset.user_added && (
                          <span className="text-[9px] font-semibold px-1 py-0.5 bg-primary/10 border border-primary/25 text-primary rounded uppercase tracking-wide">Custom</span>
                        )}
                        {asset.data_provider && asset.data_provider !== "manual" && (
                          <span className="text-[9px] font-semibold px-1 py-0.5 bg-secondary border border-border text-muted-foreground rounded uppercase tracking-wide">
                            {PROVIDER_LABELS[asset.data_provider] || asset.data_provider}
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground truncate block">{asset.name}</span>
                      {asset.data_error && (
                        <span className="text-[10px] text-loss/70 truncate block">{asset.data_error}</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <span className="text-xs bg-secondary px-2 py-0.5 rounded font-medium capitalize">{asset.market_type}</span>
                  </div>
                  <div>
                    <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-md border ${cfg.bg} ${cfg.color}`}>
                      <Icon className="w-2.5 h-2.5" />{cfg.label}
                    </span>
                  </div>
                  <div>
                    <span className={`text-[10px] font-medium ${dataLive ? "text-profit" : "text-muted-foreground/50"}`}>
                      {dataLive ? "Live" : "No snapshot"}
                    </span>
                  </div>
                  <div className="font-mono text-xs text-muted-foreground">
                    {asset.liquidity_score != null ? asset.liquidity_score : "—"}
                  </div>
                  <div className="flex flex-col items-end gap-1" onClick={e => e.stopPropagation()}>
                    {canRefresh && (
                      <button
                        onClick={() => handleRefresh(asset)}
                        disabled={isRefreshing}
                        title={`Refresh via ${asset.data_provider}`}
                        className="text-muted-foreground hover:text-primary transition-colors disabled:opacity-40"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
                      </button>
                    )}
                    {refreshErrors[asset.id] && (
                      <span className="text-[9px] text-loss max-w-[120px] text-right leading-tight" title={refreshErrors[asset.id]}>
                        {refreshErrors[asset.id].length > 60 ? refreshErrors[asset.id].slice(0, 60) + "…" : refreshErrors[asset.id]}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <AddAssetDialog
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onCreated={() => queryClient.invalidateQueries({ queryKey: ["allAssets"] })}
      />

      <AssetDetailDrawer
        asset={selectedAsset}
        onClose={() => setSelectedAsset(null)}
      />
    </div>
  );
}