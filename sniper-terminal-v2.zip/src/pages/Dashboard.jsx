import React, { useMemo } from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";
import DashboardMarketPulse from "@/components/dashboard/DashboardMarketPulse";
import DashboardRecommended from "@/components/dashboard/DashboardRecommended";
import DashboardViral from "@/components/dashboard/DashboardViral";
import DashboardAlerts from "@/components/dashboard/DashboardAlerts";
import DashboardPortfolio from "@/components/dashboard/DashboardPortfolio";
import AssetSearchBar from "@/components/assets/AssetSearchBar";
import PortfolioRiskStrip from "@/components/dashboard/PortfolioRiskStrip";
import TodaysBrief from "@/components/dashboard/TodaysBrief";
import SinceLastLogin from "@/components/dashboard/SinceLastLogin";
import { SessionModeToggle } from "@/components/shared/SessionMode";

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { data: recommended = [] } = useQuery({
    queryKey: ["recommendedSignals"],
    queryFn: () => base44.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-opportunity_score", 200),
  });

  const { data: viral = [], refetch: refetchViral } = useQuery({
    queryKey: ["viralSignals"],
    queryFn: () => base44.entities.ViralTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-viral_score", 200),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ["alerts"],
    queryFn: () => base44.entities.Alerts.filter({ status: "active" }, "-triggered_at", 100),
  });

  const { data: portfolios = [] } = useQuery({
    queryKey: ["portfolios"],
    queryFn: () => base44.entities.Portfolios.list("-created_date", 10),
  });

  const { data: holdings = [] } = useQuery({
    queryKey: ["holdings"],
    queryFn: () => base44.entities.Holdings.list("-created_date", 200),
  });

  const { data: allAssets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const assetMap = useMemo(() => {
    const m = {};
    allAssets.forEach(a => { m[a.id] = a; });
    return m;
  }, [allAssets]);

  // Pull-to-refresh
  const handleRefresh = async () => {
    await queryClient.invalidateQueries();
  };
  const { touchStartY, touchEndY, isRefreshing } = usePullToRefresh(handleRefresh);

  // Derive latest data timestamp from most recent signal
  const latestTimestamp = (() => {
    const all = [
      ...recommended.map(r => r.timestamp),
      ...viral.map(v => v.timestamp),
    ].filter(Boolean).sort().reverse();
    return all[0] || null;
  })();

  return (
    <div
      className="space-y-5"
      onTouchStart={touchStartY}
      onTouchEnd={touchEndY}
    >
      {isRefreshing && (
        <div className="flex justify-center py-2">
          <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Market intelligence overview — analysis only, not financial advice
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-52 sm:w-64">
            <AssetSearchBar
              placeholder="Quick-add asset…"
              onSelect={() => {}}
              onCreated={() => queryClient.invalidateQueries({ queryKey: ["allAssets"] })}
            />
          </div>
          <SessionModeToggle />
          <span className="hidden sm:block text-[10px] text-muted-foreground font-mono whitespace-nowrap">
            {new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
          </span>
        </div>
      </div>

      <SinceLastLogin recommended={recommended} viral={viral} alerts={alerts} />

      <TodaysBrief
        recommended={recommended}
        viral={viral}
        alerts={alerts}
        holdings={holdings}
        assetMap={assetMap}
      />

      <PortfolioRiskStrip holdings={holdings} portfolios={portfolios} />

      <DashboardMarketPulse
        recommendedCount={recommended.length}
        viralCount={viral.length}
        alertCount={alerts.length}
        holdingsCount={holdings.length}
        latestTimestamp={latestTimestamp}
      />

      <DashboardRecommended signals={recommended} />

      <DashboardViral signals={viral} refetchViral={refetchViral} />

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        <DashboardAlerts alerts={alerts} />
        <DashboardPortfolio portfolios={portfolios} />
      </div>
    </div>
  );
}