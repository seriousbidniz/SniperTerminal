import React, { useState, useMemo, useRef } from "react";
import { LIVE_SIGNAL_STATUSES } from "@/lib/signalStatus";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Briefcase, Plus, AlertTriangle, RefreshCw, Target, Zap, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import AssetSearchBar from "@/components/assets/AssetSearchBar";
import HoldingDetailDrawer from "@/components/portfolio/HoldingDetailDrawer";
import PortfolioEditDialog from "@/components/portfolio/PortfolioEditDialog";
import HoldingEditDialog from "@/components/portfolio/HoldingEditDialog";
import { isStale, STALE_THRESHOLD_MS, PRICE_STALE_THRESHOLD_MS } from "@/lib/freshness";
import { fmtPnlPct, pnlPctColor } from "@/lib/pnl";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmtUsd(v) {
  if (v == null || isNaN(v)) return "—";
  return "$" + Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtPnl(v) {
  if (v == null || isNaN(v)) return "—";
  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
  return `${sign}$${Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
function pnlColor(v) {
  if (v == null || isNaN(v)) return "";
  return v > 0 ? "text-profit" : v < 0 ? "text-loss" : "text-foreground";
}

function resolvePrice(holding, snapshotsBySymbol) {
  const entry = holding.average_entry ?? 0;
  const snap = snapshotsBySymbol[holding.asset?.toUpperCase()];

  if (snap?.price != null) {
    const snapIsStale = isStale(snap.timestamp, STALE_THRESHOLD_MS);
    const effectivePrice = snap.price;
    const pnlPercent = entry > 0 ? ((effectivePrice - entry) / entry) * 100 : 0;
    return { effectivePrice, pnlPercent, priceStatus: snapIsStale ? "stale" : "live", snapTimestamp: snap.timestamp };
  }
  if (holding.live_price != null) {
    const effectivePrice = holding.live_price;
    const pnlPercent = entry > 0 ? ((effectivePrice - entry) / entry) * 100 : 0;
    const snapIsStale = isStale(holding.updated_date, PRICE_STALE_THRESHOLD_MS);
    return { effectivePrice, pnlPercent, priceStatus: snapIsStale ? "stale" : "live", snapTimestamp: holding.updated_date };
  }
  return { effectivePrice: entry, pnlPercent: entry > 0 ? 0 : null, priceStatus: "fallback", snapTimestamp: null };
}

function computeEnrichedHoldings(rawHoldings, snapshotsBySymbol) {
  const withPrices = rawHoldings.map(h => {
    const qty = h.quantity ?? 0;
    const entry = h.average_entry ?? 0;
    const { effectivePrice, pnlPercent, priceStatus, snapTimestamp } = resolvePrice(h, snapshotsBySymbol);
    const current_value = qty * effectivePrice;
    const unrealised_pnl = (effectivePrice - entry) * qty;
    return { ...h, effectivePrice, pnlPercent, priceStatus, snapTimestamp, current_value, unrealised_pnl };
  });
  const totalValue = withPrices.reduce((s, h) => s + (h.current_value || 0), 0);
  return withPrices.map(h => ({
    ...h,
    allocation_percent: totalValue > 0 ? (h.current_value / totalValue) * 100 : 0,
  }));
}

function SummaryCard({ label, children }) {
  return (
    <div className="bg-card border border-border rounded-lg px-4 py-3">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      <div className="mt-0.5">{children}</div>
    </div>
  );
}

function PriceCell({ holding }) {
  const { effectivePrice, priceStatus } = holding;
  if (priceStatus === "fallback") {
    return (
      <div className="flex items-center gap-1.5">
        <span className="text-muted-foreground/40 font-mono text-xs">{fmtUsd(effectivePrice)}</span>
        <span className="text-[9px] text-muted-foreground/50 bg-secondary px-1 py-0.5 rounded">Awaiting</span>
      </div>
    );
  }
  if (priceStatus === "stale") {
    return (
      <div className="flex items-center gap-1.5">
        <span className="text-warning/70 font-mono text-xs">{fmtUsd(effectivePrice)}</span>
        <span className="text-[9px] text-warning/70 bg-warning/10 border border-warning/25 px-1 py-0.5 rounded">Stale</span>
      </div>
    );
  }
  return <span className="font-mono text-xs">{fmtUsd(effectivePrice)}</span>;
}

function SignalBadges({ hasRec, hasViral, viralLabel }) {
  return (
    <div className="flex items-center gap-1">
      {hasRec && (
        <span title="Active recommended signal" className="text-[9px] font-semibold px-1.5 py-0.5 rounded border text-primary bg-primary/10 border-primary/30 flex items-center gap-0.5">
          <Target className="w-2.5 h-2.5" /> REC
        </span>
      )}
      {hasViral && (
        <span title={`Viral signal: ${viralLabel}`} className={`text-[9px] font-semibold px-1.5 py-0.5 rounded border flex items-center gap-0.5 ${viralLabel === "tradable" ? "text-profit bg-profit/10 border-profit/30" : viralLabel === "avoid" ? "text-loss bg-loss/10 border-loss/30" : "text-warning bg-warning/10 border-warning/30"}`}>
          <Zap className="w-2.5 h-2.5" /> {viralLabel?.toUpperCase()}
        </span>
      )}
      {!hasRec && !hasViral && (
        <span className="text-[9px] text-muted-foreground/40">—</span>
      )}
    </div>
  );
}

export default function Portfolio() {
  const [selectedPortfolioId, setSelectedPortfolioId] = useState(null);
  const [showNewPortfolio, setShowNewPortfolio] = useState(false);
  const [showEditPortfolio, setShowEditPortfolio] = useState(false);
  const [showAddHolding, setShowAddHolding] = useState(false);
  const [selectedHolding, setSelectedHolding] = useState(null);
  const [editingHolding, setEditingHolding] = useState(null);
  const [newName, setNewName] = useState("");
  const [holdingForm, setHoldingForm] = useState({
    asset: "", quantity: "", average_entry: "", live_price: "",
    stop_loss: "", take_profit: "", invalidation: "", thesis_notes: "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const containerRef = useRef(null);

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["portfolioSnapshots", "allAssets"] });
  };
  const { touchStartY, touchEndY } = usePullToRefresh(handleRefresh);

  const { data: portfolios = [] } = useQuery({
    queryKey: ["portfolios"],
    queryFn: () => base44.entities.Portfolios.list("-created_date", 20),
  });

  const { data: allHoldings = [] } = useQuery({
    queryKey: ["holdings"],
    queryFn: () => base44.entities.Holdings.list("-created_date", 500),
  });

  const { data: allAssets = [] } = useQuery({
    queryKey: ["allAssets"],
    queryFn: () => base44.entities.Assets.list("-created_date", 500),
    staleTime: 60_000,
  });

  const { data: allSnapshots = [] } = useQuery({
    queryKey: ["portfolioSnapshots"],
    queryFn: () => base44.entities.MarketSnapshots.list("-timestamp", 1000),
    staleTime: 60_000,
  });

  const { data: recSignals = [] } = useQuery({
    queryKey: ["recSignals"],
    queryFn: () => base44.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-opportunity_score", 200),
    staleTime: 60_000,
  });

  const { data: viralSignals = [] } = useQuery({
    queryKey: ["viralSignals"],
    queryFn: () => base44.entities.ViralTradeSignals.filter({ status: { $in: LIVE_SIGNAL_STATUSES } }, "-viral_score", 200),
    staleTime: 60_000,
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ["alerts"],
    queryFn: () => base44.entities.Alerts.filter({ status: "active" }, "-triggered_at", 500),
    staleTime: 30_000,
  });

  // Build lookup maps
  const snapshotsBySymbol = useMemo(() => {
    const idToSymbol = {};
    allAssets.forEach(a => { idToSymbol[a.id] = a.symbol?.toUpperCase(); });
    const map = {};
    allSnapshots.forEach(snap => {
      if (!snap.asset || snap.price == null) return;
      const symbol = idToSymbol[snap.asset];
      if (!symbol) return;
      if (!map[symbol] || new Date(snap.timestamp) > new Date(map[symbol].timestamp)) {
        map[symbol] = snap;
      }
    });
    return map;
  }, [allAssets, allSnapshots]);

  // assetId → asset for signal matching
  const assetBySymbol = useMemo(() => {
    const m = {};
    allAssets.forEach(a => { if (a.symbol) m[a.symbol.toUpperCase()] = a; });
    return m;
  }, [allAssets]);

  // Latest active recommended signal per asset id
  const recByAssetId = useMemo(() => {
    const m = {};
    recSignals.forEach(s => { if (s.asset && !m[s.asset]) m[s.asset] = s; });
    return m;
  }, [recSignals]);

  // Latest active viral signal per asset id
  const viralByAssetId = useMemo(() => {
    const m = {};
    viralSignals.forEach(s => { if (s.asset && !m[s.asset]) m[s.asset] = s; });
    return m;
  }, [viralSignals]);

  // Alerts grouped by asset symbol (uppercased)
  const alertsBySymbol = useMemo(() => {
    const m = {};
    alerts.forEach(a => {
      if (!a.asset) return;
      const sym = a.asset.toUpperCase();
      if (!m[sym]) m[sym] = [];
      m[sym].push(a);
    });
    return m;
  }, [alerts]);

  const createPortfolio = useMutation({
    mutationFn: (data) => base44.entities.Portfolios.create(data),
    onMutate: async (data) => {
      // Optimistically update portfolios list
      await queryClient.cancelQueries({ queryKey: ["portfolios"] });
      const previous = queryClient.getQueryData(["portfolios"]);
      const optimistic = { ...data, id: `temp-${Date.now()}`, created_date: new Date().toISOString() };
      queryClient.setQueryData(["portfolios"], (old) => [...(old || []), optimistic]);
      return { previous };
    },
    onSuccess: (created) => {
      queryClient.invalidateQueries({ queryKey: ["portfolios"] });
      setSelectedPortfolioId(created.id);
      setShowNewPortfolio(false);
      setNewName("");
    },
    onError: (_err, _variables, context) => {
      if (context?.previous) {
        queryClient.setQueryData(["portfolios"], context.previous);
      }
    },
  });

  const createHolding = useMutation({
    mutationFn: (data) => base44.entities.Holdings.create(data),
    onMutate: async (data) => {
      await queryClient.cancelQueries({ queryKey: ["holdings"] });
      const previous = queryClient.getQueryData(["holdings"]);
      const optimistic = { ...data, id: `temp-${Date.now()}`, created_date: new Date().toISOString() };
      queryClient.setQueryData(["holdings"], (old) => [...(old || []), optimistic]);
      return { previous };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["holdings"] });
      setShowAddHolding(false);
      setHoldingForm({ asset: "", quantity: "", average_entry: "", live_price: "", stop_loss: "", take_profit: "", invalidation: "", thesis_notes: "" });
    },
    onError: (_err, _variables, context) => {
      if (context?.previous) {
        queryClient.setQueryData(["holdings"], context.previous);
      }
    },
  });

  const handleRefreshAll = async () => {
    try {
      const res = await base44.functions.invoke("refreshAll", {});
      queryClient.invalidateQueries();
      const d = res.data;
      toast({
        title: "Refresh complete",
        description: `${d?.results?.snapshots_created ?? 0} snapshots, ${d?.results?.recommended?.created ?? 0} rec signals, ${d?.results?.viral?.created ?? 0} viral signals, ${d?.results?.alerts?.created ?? 0} alerts created.`,
      });
    } catch (e) {
      toast({ title: "Refresh failed", description: e.message, variant: "destructive" });
    }
  };

  const activePortfolio = portfolios.find(p => p.id === selectedPortfolioId) || portfolios[0] || null;

  const rawHoldings = useMemo(
    () => allHoldings.filter(h => activePortfolio && h.portfolio === activePortfolio.id),
    [allHoldings, activePortfolio]
  );

  const holdings = useMemo(
    () => computeEnrichedHoldings(rawHoldings, snapshotsBySymbol),
    [rawHoldings, snapshotsBySymbol]
  );

  // Enrich each holding with signals/alerts
  const enrichedHoldings = useMemo(() => holdings.map(h => {
    const sym = h.asset?.toUpperCase();
    const asset = assetBySymbol[sym];
    const recSignal = asset ? recByAssetId[asset.id] : null;
    const viralSignal = asset ? viralByAssetId[asset.id] : null;
    const holdingAlerts = alertsBySymbol[sym] || [];
    return { ...h, recSignal, viralSignal, holdingAlerts };
  }), [holdings, assetBySymbol, recByAssetId, viralByAssetId, alertsBySymbol]);

  const totalHoldingsValue = holdings.reduce((s, h) => s + (isNaN(h.current_value) ? 0 : (h.current_value || 0)), 0);
  const cashBalance = activePortfolio?.cash_balance ?? 0;
  const totalValue = totalHoldingsValue + cashBalance;
  const unrealisedPnl = holdings.reduce((s, h) => s + (isNaN(h.unrealised_pnl) ? 0 : (h.unrealised_pnl || 0)), 0);
  const realisedPnl = activePortfolio?.realised_pnl ?? 0;
  const hasStaleOrMissingData = holdings.some(h => h.priceStatus !== "live");
  const portfolioAlerts = alerts.filter(a => !a.asset);

  const handleAddHolding = () => {
    const qty = parseFloat(holdingForm.quantity) || 0;
    const entry = parseFloat(holdingForm.average_entry) || 0;
    createHolding.mutate({
      portfolio: activePortfolio.id,
      asset: holdingForm.asset.trim().toUpperCase(),
      quantity: qty,
      average_entry: entry,
      live_price: parseFloat(holdingForm.live_price) || null,
      stop_loss: parseFloat(holdingForm.stop_loss) || null,
      take_profit: parseFloat(holdingForm.take_profit) || null,
      invalidation: parseFloat(holdingForm.invalidation) || null,
      thesis_notes: holdingForm.thesis_notes || null,
    });
  };

  // Holding selected for drawer — pull through its enriched data
  const drawerHolding = selectedHolding
    ? enrichedHoldings.find(h => h.id === selectedHolding.id) || null
    : null;

  return (
    <div className="space-y-4" ref={containerRef} onTouchStart={touchStartY} onTouchEnd={touchEndY}>
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-primary" /> Portfolio
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Track positions, P&L, and exposure</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            className="text-xs gap-1.5"
            onClick={handleRefreshAll}

          >
            <RefreshCw className="w-3 h-3" />
Refresh All
          </Button>
          <Button variant="outline" size="sm" className="text-xs" onClick={() => setShowNewPortfolio(true)}>
            <Plus className="w-3 h-3 mr-1" /> New Portfolio
          </Button>
          {activePortfolio && (
            <Button size="sm" className="text-xs" onClick={() => setShowAddHolding(true)}>
              <Plus className="w-3 h-3 mr-1" /> Add Holding
            </Button>
          )}
          <div className="w-52 sm:w-64">
            <AssetSearchBar placeholder="Find or add asset…" onSelect={() => {}} onCreated={() => {}} />
          </div>
        </div>
      </div>

      {/* Portfolio tabs */}
      {portfolios.length > 0 && (
        <div className="flex gap-2 flex-wrap items-center">
          {portfolios.map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPortfolioId(p.id)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activePortfolio?.id === p.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {p.name}
            </button>
          ))}
          {activePortfolio && (
            <button
              onClick={() => setShowEditPortfolio(true)}
              className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors"
              title="Edit portfolio"
            >
              <Pencil className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {!activePortfolio ? (
        <div className="py-16 text-center text-xs text-muted-foreground">
          No portfolios yet. Create one to start tracking positions.
        </div>
      ) : (
        <>
          {/* Stale/missing data banner */}
          {hasStaleOrMissingData && (
            <div className="flex items-center gap-2 bg-warning/5 border border-warning/20 rounded-lg px-3 py-2 text-[11px] text-warning/80">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Some holdings are using estimated or stale prices. P&L values are approximate — use Refresh All or add live data for accuracy.</span>
            </div>
          )}

          {/* Portfolio-level alerts */}
          {portfolioAlerts.length > 0 && (
            <div className="flex items-center gap-2 bg-loss/5 border border-loss/20 rounded-lg px-3 py-2 text-[11px] text-loss/80">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{portfolioAlerts.length} portfolio-level alert{portfolioAlerts.length > 1 ? "s" : ""} active — check the Alerts page for details.</span>
            </div>
          )}

          {/* Summary cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <SummaryCard label="Total Value">
              <span className="text-xl font-bold font-mono">{fmtUsd(totalValue)}</span>
            </SummaryCard>
            <SummaryCard label="Cash Balance">
              <span className="text-xl font-bold font-mono text-muted-foreground">{fmtUsd(cashBalance)}</span>
            </SummaryCard>
            <SummaryCard label="Unrealised P&L">
              <span className={`text-xl font-bold font-mono ${pnlColor(unrealisedPnl)}`}>{fmtPnl(unrealisedPnl)}</span>
            </SummaryCard>
            <SummaryCard label="Realised P&L">
              <span className={`text-xl font-bold font-mono ${pnlColor(realisedPnl)}`}>{fmtPnl(realisedPnl)}</span>
            </SummaryCard>
          </div>

          {/* Holdings table */}
          {holdings.length === 0 ? (
            <div className="py-12 text-center text-xs text-muted-foreground bg-card border border-border rounded-xl">
              No holdings in this portfolio. Add one to get started.
            </div>
          ) : (
            <div className="bg-card border border-border rounded-xl overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-secondary/20">
                    {["Asset", "Qty", "Avg Entry", "Price", "Current Value", "Unr. P&L", "P&L %", "Alloc %", "Signals", "Alerts", "Stop Loss", "Take Profit", ""].map(h => (
                      <th key={h} className="px-3 py-2.5 text-left text-[10px] text-muted-foreground uppercase tracking-wider whitespace-nowrap font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {enrichedHoldings.map(h => {
                    const rowDimmed = h.priceStatus === "fallback";
                    const hasAlerts = h.holdingAlerts.length > 0;
                    return (
                      <tr
                        key={h.id}
                        onClick={() => setSelectedHolding(h)}
                        className={`hover:bg-accent/30 transition-colors cursor-pointer ${rowDimmed ? "opacity-70" : ""} group`}
                      >
                        <td className="px-3 py-3 font-mono font-semibold">{h.asset || "—"}</td>
                        <td className="px-3 py-3 font-mono">{h.quantity != null ? h.quantity.toLocaleString() : "—"}</td>
                        <td className="px-3 py-3 font-mono">{h.average_entry != null ? fmtUsd(h.average_entry) : "—"}</td>
                        <td className="px-3 py-3"><PriceCell holding={h} /></td>
                        <td className="px-3 py-3 font-mono">{fmtUsd(h.current_value)}</td>
                        <td className={`px-3 py-3 font-mono font-semibold ${h.priceStatus === "fallback" ? "text-muted-foreground/40" : pnlColor(h.unrealised_pnl)}`}>
                          {h.priceStatus === "fallback" ? "—" : fmtPnl(h.unrealised_pnl)}
                        </td>
                        <td className={`px-3 py-3 font-mono font-semibold ${h.priceStatus === "fallback" ? "text-muted-foreground/40" : pnlPctColor(h.pnlPercent)}`}>
                          {h.priceStatus === "fallback"
                            ? <span className="text-[9px] text-muted-foreground/40">No data</span>
                            : fmtPnlPct(h.pnlPercent, h.priceStatus === "stale")
                          }
                        </td>
                        <td className="px-3 py-3 font-mono text-muted-foreground">
                          {h.allocation_percent != null ? `${h.allocation_percent.toFixed(1)}%` : "—"}
                        </td>
                        <td className="px-3 py-3">
                          <SignalBadges
                            hasRec={!!h.recSignal}
                            hasViral={!!h.viralSignal}
                            viralLabel={h.viralSignal?.ai_label}
                          />
                        </td>
                        <td className="px-3 py-3">
                          {hasAlerts ? (
                            <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded border text-warning bg-warning/10 border-warning/30 flex items-center gap-0.5 w-fit">
                              <AlertTriangle className="w-2.5 h-2.5" /> {h.holdingAlerts.length}
                            </span>
                          ) : (
                            <span className="text-[9px] text-muted-foreground/40">—</span>
                          )}
                        </td>
                        <td className="px-3 py-3 font-mono text-loss">{h.stop_loss != null ? fmtUsd(h.stop_loss) : "—"}</td>
                        <td className="px-3 py-3 font-mono text-profit">{h.take_profit != null ? fmtUsd(h.take_profit) : "—"}</td>
                        <td className="px-3 py-3">
                          <button
                            onClick={(e) => { e.stopPropagation(); setEditingHolding(h); }}
                            className="p-1 rounded text-muted-foreground/40 hover:text-foreground hover:bg-secondary transition-colors opacity-0 group-hover:opacity-100"
                            title="Edit holding"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t border-border bg-secondary/20">
                    <td className="px-3 py-2.5 text-[10px] text-muted-foreground uppercase tracking-wider font-semibold" colSpan={4}>Total</td>
                    <td className="px-3 py-2.5 font-mono font-semibold text-xs">{fmtUsd(totalHoldingsValue)}</td>
                    <td className={`px-3 py-2.5 font-mono font-semibold text-xs ${pnlColor(unrealisedPnl)}`}>{fmtPnl(unrealisedPnl)}</td>
                    <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground">100%</td>
                    <td colSpan={5} />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </>
      )}

      {/* Holding Detail Drawer */}
      <HoldingDetailDrawer
        holding={drawerHolding}
        recSignal={drawerHolding?.recSignal}
        viralSignal={drawerHolding?.viralSignal}
        alerts={drawerHolding?.holdingAlerts || []}
        onClose={() => setSelectedHolding(null)}
        onEdit={(h) => { setSelectedHolding(null); setEditingHolding(h); }}
      />

      {/* Portfolio Edit Dialog */}
      <PortfolioEditDialog
        portfolio={activePortfolio}
        open={showEditPortfolio}
        onClose={() => setShowEditPortfolio(false)}
      />

      {/* Holding Edit Dialog */}
      <HoldingEditDialog
        holding={editingHolding}
        open={!!editingHolding}
        onClose={() => setEditingHolding(null)}
      />

      {/* New Portfolio Dialog */}
      <Dialog open={showNewPortfolio} onOpenChange={setShowNewPortfolio}>
        <DialogContent className="bg-card border-border">
          <DialogHeader><DialogTitle>Create Portfolio</DialogTitle></DialogHeader>
          <Input
            placeholder="Portfolio name"
            value={newName}
            onChange={e => setNewName(e.target.value)}
            className="bg-secondary/50"
            onKeyDown={e => e.key === "Enter" && newName.trim() && createPortfolio.mutate({ name: newName.trim() })}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewPortfolio(false)}>Cancel</Button>
            <Button onClick={() => createPortfolio.mutate({ name: newName.trim() })} disabled={!newName.trim()}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Holding Dialog */}
      <Dialog open={showAddHolding} onOpenChange={setShowAddHolding}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader><DialogTitle>Add Holding</DialogTitle></DialogHeader>
          <p className="text-[11px] text-muted-foreground -mt-1">
            Live prices are pulled automatically from MarketSnapshots when available. Enter a manual price override for assets without live data.
          </p>
          <div className="space-y-3">
            <Input
              placeholder="Asset symbol (e.g. BTC, ETH, $FARTBOY)"
              value={holdingForm.asset}
              onChange={e => setHoldingForm({ ...holdingForm, asset: e.target.value })}
              className="bg-secondary/50"
            />
            <div className="grid grid-cols-2 gap-2">
              <Input type="number" placeholder="Quantity" value={holdingForm.quantity}
                onChange={e => setHoldingForm({ ...holdingForm, quantity: e.target.value })}
                className="bg-secondary/50" />
              <Input type="number" placeholder="Avg entry price" value={holdingForm.average_entry}
                onChange={e => setHoldingForm({ ...holdingForm, average_entry: e.target.value })}
                className="bg-secondary/50" />
              <Input type="number" placeholder="Manual price override (optional)" value={holdingForm.live_price}
                onChange={e => setHoldingForm({ ...holdingForm, live_price: e.target.value })}
                className="bg-secondary/50 col-span-2" />
              <Input type="number" placeholder="Stop loss" value={holdingForm.stop_loss}
                onChange={e => setHoldingForm({ ...holdingForm, stop_loss: e.target.value })}
                className="bg-secondary/50" />
              <Input type="number" placeholder="Take profit" value={holdingForm.take_profit}
                onChange={e => setHoldingForm({ ...holdingForm, take_profit: e.target.value })}
                className="bg-secondary/50" />
              <Input type="number" placeholder="Invalidation level" value={holdingForm.invalidation}
                onChange={e => setHoldingForm({ ...holdingForm, invalidation: e.target.value })}
                className="bg-secondary/50 col-span-2" />
            </div>
            <Textarea placeholder="Thesis notes (optional)" value={holdingForm.thesis_notes}
              onChange={e => setHoldingForm({ ...holdingForm, thesis_notes: e.target.value })}
              className="bg-secondary/50 h-16" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddHolding(false)}>Cancel</Button>
            <Button
              onClick={handleAddHolding}
              disabled={!holdingForm.asset.trim() || !holdingForm.quantity || !holdingForm.average_entry}
            >
              Add
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}