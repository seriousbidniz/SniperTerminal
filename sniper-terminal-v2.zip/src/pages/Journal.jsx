import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import EmptyState from "../components/shared/EmptyState";

const typeColors = {
  trade_review: "bg-primary/10 text-primary",
  market_observation: "bg-viral/10 text-viral",
  lesson_learned: "bg-profit/10 text-profit",
  strategy_note: "bg-warning/10 text-warning",
  mistake_log: "bg-loss/10 text-loss",
  win_analysis: "bg-profit/10 text-profit",
};

export default function Journal() {
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", entry_type: "trade_review", emotion_state: "neutral", key_takeaway: "" });
  const queryClient = useQueryClient();

  const { data: entries } = useQuery({
    queryKey: ["journalEntries"],
    queryFn: () => base44.entities.JournalEntries.list("-created_date", 100),
    initialData: [],
  });

  const createEntry = useMutation({
    mutationFn: (data) => base44.entities.JournalEntries.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["journalEntries"] }); setShowNew(false); setForm({ title: "", content: "", entry_type: "trade_review", emotion_state: "neutral", key_takeaway: "" }); },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary" /> Trade Journal
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Record decisions, review outcomes, and improve</p>
        </div>
        <Button size="sm" className="text-xs" onClick={() => setShowNew(true)}>
          <Plus className="w-3 h-3 mr-1" /> New Entry
        </Button>
      </div>

      {entries.length === 0 ? (
        <EmptyState icon={BookOpen} title="No journal entries" description="Start documenting your trades and market observations." />
      ) : (
        <div className="space-y-2">
          {entries.map(entry => (
            <div key={entry.id} className="bg-card border border-border rounded-lg px-4 py-3">
              <div className="flex items-start gap-3">
                <span className={`text-[10px] font-medium uppercase px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5 ${typeColors[entry.entry_type] || "bg-secondary text-muted-foreground"}`}>
                  {entry.entry_type?.replace(/_/g, " ")}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{entry.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{entry.content}</p>
                  {entry.key_takeaway && (
                    <p className="text-xs text-foreground/80 mt-1.5 italic">💡 {entry.key_takeaway}</p>
                  )}
                  <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                    {entry.emotion_state && <span>Mood: {entry.emotion_state}</span>}
                    {entry.outcome && <span>Outcome: {entry.outcome}</span>}
                    {entry.asset_symbol && <span className="font-mono">{entry.asset_symbol}</span>}
                    <span>{new Date(entry.created_date).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader><DialogTitle>New Journal Entry</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Title" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="bg-secondary/50" />
            <Textarea placeholder="What happened? What did you decide? What did you learn?" value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} className="bg-secondary/50 h-32" />
            <div className="grid grid-cols-2 gap-3">
              <Select value={form.entry_type} onValueChange={v => setForm({ ...form, entry_type: v })}>
                <SelectTrigger className="bg-secondary/50 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="trade_review">Trade Review</SelectItem>
                  <SelectItem value="market_observation">Observation</SelectItem>
                  <SelectItem value="lesson_learned">Lesson Learned</SelectItem>
                  <SelectItem value="strategy_note">Strategy Note</SelectItem>
                  <SelectItem value="mistake_log">Mistake Log</SelectItem>
                  <SelectItem value="win_analysis">Win Analysis</SelectItem>
                </SelectContent>
              </Select>
              <Select value={form.emotion_state} onValueChange={v => setForm({ ...form, emotion_state: v })}>
                <SelectTrigger className="bg-secondary/50 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="confident">Confident</SelectItem>
                  <SelectItem value="anxious">Anxious</SelectItem>
                  <SelectItem value="frustrated">Frustrated</SelectItem>
                  <SelectItem value="greedy">Greedy</SelectItem>
                  <SelectItem value="fearful">Fearful</SelectItem>
                  <SelectItem value="neutral">Neutral</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Input placeholder="Key takeaway" value={form.key_takeaway} onChange={e => setForm({ ...form, key_takeaway: e.target.value })} className="bg-secondary/50" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
            <Button onClick={() => createEntry.mutate(form)} disabled={!form.title.trim() || !form.content.trim()}>Save Entry</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}