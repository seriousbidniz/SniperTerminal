import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Gauge, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MobileHeader from "@/components/layout/MobileHeader";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const pct = (v) => (v == null ? "—" : `${(v * 100).toFixed(0)}%`);
const r2 = (v) => (v == null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)}R`);
const label = (s) => String(s || "").replace(/_/g, " ");

function Stat({ title, value, note, tone }) {
  return (
    <div className="rounded-xl border border-border bg-card px-4 py-3">
      <p className="text-[11px] text-muted-foreground">{title}</p>
      <p className={`text-2xl font-mono font-bold tabular-nums mt-0.5 ${tone || ""}`}>{value}</p>
      {note && <p className="text-[10px] text-muted-foreground mt-0.5">{note}</p>}
    </div>
  );
}

function Table({ head, rows, empty }) {
  if (!rows.length) return <p className="text-xs text-muted-foreground py-6 text-center">{empty}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-xs">
        <thead><tr className="border-b border-border">{head.map((h) => <th key={h} scope="col" className="text-left font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i} className="border-b border-border/40">{r.map((c, j) => <td key={j} className="px-3 py-2 whitespace-nowrap">{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

export default function Performance() {
  const [days, setDays] = useState("90");
  const { data, isLoading, error } = useQuery({
    queryKey: ["userPerformance", days],
    queryFn: async () => (await base44.functions.invoke("userPerformance", { days: Number(days) })).data,
  });
  const u = data?.user;
  const p = data?.platform;

  return (
    <div className="space-y-5">
      <MobileHeader icon={Gauge} title="Performance" subtitle="Your verified results" />
      <div className="hidden md:flex items-end justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2"><Gauge className="w-5 h-5 text-primary" /> Performance</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Results from trades synced from your broker, and the platform's full signal track record</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">Period</span>
        <Select value={days} onValueChange={setDays}>
          <SelectTrigger className="h-7 w-[110px] text-xs"><SelectValue /></SelectTrigger>
          <SelectContent className="text-xs">
            <SelectItem value="30">30 days</SelectItem><SelectItem value="90">90 days</SelectItem>
            <SelectItem value="180">180 days</SelectItem><SelectItem value="365">12 months</SelectItem>
          </SelectContent>
        </Select>
        {isLoading && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
      </div>
      {error && <p className="text-xs text-loss">Couldn't load performance: {error.message}</p>}

      {data && (
        <>
          <section className="space-y-3" aria-labelledby="mine">
            <h2 id="mine" className="text-sm font-semibold">Your trades</h2>
            {!data.has_broker && (
              <p className="text-xs text-muted-foreground rounded-lg border border-dashed border-border p-3">
                Connect a read-only broker account in <Link to="/settings" className="text-primary underline">Settings</Link> and the trades you take on signals will appear here automatically, with a win rate based on real fills rather than estimates.
              </p>
            )}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat title="Win rate" value={pct(u?.win_rate)} note={`${u?.wins ?? 0} wins, ${u?.losses ?? 0} losses`} tone={u?.win_rate == null ? "" : u.win_rate >= 0.5 ? "text-profit" : "text-loss"} />
              <Stat title="Average result" value={r2(u?.avg_r)} note="per trade, in units of risk" tone={u?.avg_r == null ? "" : u.avg_r >= 0 ? "text-profit" : "text-loss"} />
              <Stat title="Signals traded" value={u?.executed ?? 0} note={`${u?.open ?? 0} still open`} />
              <Stat title="Realised P&L" value={u?.total_pnl == null ? "—" : u.total_pnl.toLocaleString("en-GB", { maximumFractionDigits: 2 })} note={u?.fees_partial ? "Some fees paid in another coin aren't deducted" : "in quote currency, after fees"} />
            </div>
            {u && u.closed > u.closed_high_confidence && (
              <p className="text-[11px] text-muted-foreground">{u.closed - u.closed_high_confidence} closed trade(s) were filled outside the signal's entry zone, so they're tracked but left out of your win rate.</p>
            )}
            <Table
              head={["Asset", "Setup", "Side", "Entry", "Exit", "Result", "Status"]}
              empty="No signal trades in this period yet."
              rows={(data.recent_executions || []).map((e) => [
                <span key="a" className="font-mono font-semibold">{e.asset_symbol}</span>, label(e.setup_type),
                e.direction === "bullish" ? "Long" : "Short",
                e.avg_entry?.toPrecision(6) ?? "—", e.avg_exit?.toPrecision(6) ?? "—",
                <span key="r" className={e.r_multiple == null ? "" : e.r_multiple >= 0 ? "text-profit" : "text-loss"}>{r2(e.r_multiple)}</span>,
                e.status === "open" ? "Open" : `${e.outcome}${e.match_confidence === "low" ? " (outside zone)" : ""}`,
              ])}
            />
          </section>

          <section className="space-y-3" aria-labelledby="platform">
            <h2 id="platform" className="text-sm font-semibold">Every signal the platform issued</h2>
            <p className="text-[11px] text-muted-foreground">All resolved signals in the period, not a selection. A win means Target 1 traded before the invalidation level.</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Stat title="Win rate" value={pct(p?.win_rate)} />
              <Stat title="Average result" value={r2(p?.avg_r)} />
              <Stat title="Entries filled" value={p?.triggered ?? 0} />
              <Stat title="Never reached entry" value={p?.untriggered ?? 0} />
            </div>
            <Table
              head={["Setup", "Direction", "Trades", "Win rate", "Average"]}
              empty="No resolved signals yet. Outcomes appear as signals hit targets, invalidation or expiry."
              rows={(p?.by_setup || []).sort((a, b) => b.n - a.n).map((b) => [label(b.setup_type), b.direction, b.n, pct(b.win_rate), r2(b.avg_r)])}
            />
          </section>

          <section className="space-y-3" aria-labelledby="calib">
            <h2 id="calib" className="text-sm font-semibold">What the engine has learned</h2>
            <p className="text-[11px] text-muted-foreground">
              Each setup is back-tested on recent hourly history, then blended with live outcomes. The back-test counts for at most 50 trades, so real results take over as they build up. Setups with fewer than 30 samples are treated as having no edge.
            </p>
            <Table
              head={["Setup", "Market", "Samples", "Win rate", "Expectancy", "Typical time to resolve", "Evidence"]}
              empty="Calibration runs hourly; the first results appear after the first run."
              rows={(data.calibration || []).filter((c) => c.n_effective > 0).map((c) => [
                label(c.setup_type), c.market_type, Math.round(c.n_effective), pct(c.win_rate),
                <span key="e" className={c.expectancy_r > 0 ? "text-profit" : "text-loss"}>{r2(c.expectancy_r)}</span>,
                c.median_bars_to_resolution ? `${Math.round(c.median_bars_to_resolution)}h` : "—",
                `${c.source}${c.n_effective < 30 ? " · not enough yet" : ""}`,
              ])}
            />
          </section>
        </>
      )}
    </div>
  );
}
