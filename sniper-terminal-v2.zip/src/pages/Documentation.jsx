import React, { useRef, useState } from "react";
import { FileText, Download, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

// ─── Section / sub-components ─────────────────────────────────────────────────

function Section({ id, title, children }) {
  return (
    <section id={id} className="mb-10">
      <h2 className="text-base font-bold text-foreground border-b border-border pb-2 mb-4 tracking-tight">{title}</h2>
      {children}
    </section>
  );
}

function Sub({ title, children }) {
  return (
    <div className="mb-5">
      <h3 className="text-sm font-semibold text-primary mb-2">{title}</h3>
      {children}
    </div>
  );
}

function Para({ children }) {
  return <p className="text-sm text-foreground/80 leading-relaxed mb-2">{children}</p>;
}

function Code({ children }) {
  return (
    <code className="bg-secondary/60 border border-border/60 text-xs font-mono px-1.5 py-0.5 rounded text-primary/90">
      {children}
    </code>
  );
}

function Table({ headers, rows }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-border mb-4">
      <table className="w-full text-xs">
        <thead>
          <tr className="bg-secondary/30 border-b border-border">
            {headers.map(h => (
              <th key={h} className="px-3 py-2 text-left font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/50">
          {rows.map((row, i) => (
            <tr key={i} className="hover:bg-secondary/10">
              {row.map((cell, j) => (
                <td key={j} className="px-3 py-2 text-foreground/80 align-top">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FormulaBox({ children }) {
  return (
    <div className="bg-secondary/30 border border-border/60 rounded-lg px-4 py-3 font-mono text-xs text-foreground/90 mb-3 whitespace-pre-wrap leading-relaxed">
      {children}
    </div>
  );
}

function Note({ children }) {
  return (
    <div className="bg-warning/5 border border-warning/20 rounded-lg px-3 py-2 text-xs text-warning/80 mb-3">
      ⚠ {children}
    </div>
  );
}

// ─── TOC ──────────────────────────────────────────────────────────────────────

const TOC = [
  { id: "overview",         label: "1. Platform Overview" },
  { id: "entities",         label: "2. Data Model & Entities" },
  { id: "data-pipeline",    label: "3. Data Pipeline & Provider Logic" },
  { id: "recommended",      label: "4. Recommended Trade Engine" },
  { id: "viral",            label: "5. Viral Signal Engine" },
  { id: "intelligence",     label: "6. Signal Intelligence Components" },
  { id: "decision-engine",  label: "7. Decision Engine UI Layer" },
  { id: "trade-reason",     label: "8. Trade Reason Indicator" },
  { id: "scenario",         label: "9. £100 Illustrative Scenario" },
  { id: "alerts",           label: "10. Alert Engine" },
  { id: "alert-enrichment", label: "11. Alert Enrichment & Position Guidance" },
  { id: "user-profile",     label: "12. User Profile & Position Sizing" },
  { id: "summaries",        label: "13. Automated Summarisation" },
  { id: "freshness",        label: "14. Data Freshness & Staleness" },
  { id: "portfolio",        label: "15. Portfolio & Holdings" },
  { id: "ui",               label: "16. UI Surface & Display Logic" },
  { id: "automations",      label: "17. Automations & Scheduling" },
  { id: "constraints",      label: "18. Design Constraints & Integrity Rules" },
  { id: "risk-disclosure",  label: "19. Risk Disclosure & Regulatory Compliance" },
];

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Documentation() {
  const printRef = useRef(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleDownload = async () => {
    const el = printRef.current;
    if (!el) return;
    setIsGenerating(true);
    try {
      const canvas = await html2canvas(el, {
        scale: 2,
        useCORS: true,
        logging: false,
        scrollY: 0,
        windowWidth: el.scrollWidth,
        windowHeight: el.scrollHeight,
      });

      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * pageWidth) / canvas.width;

      let yOffset = 0;
      let page = 0;

      while (yOffset < imgHeight) {
        if (page > 0) pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, -yOffset, imgWidth, imgHeight);
        yOffset += pageHeight;
        page++;
      }

      pdf.save("sniper-terminal-documentation.pdf");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-4">

      {/* Page header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Technical Documentation
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Sniper Terminal — complete logic, scoring, and output reference
          </p>
        </div>
        <Button variant="outline" size="sm" className="text-xs gap-1.5" onClick={handleDownload} disabled={isGenerating}>
          <Download className="w-3.5 h-3.5" />
          {isGenerating ? "Generating PDF…" : "Download PDF"}
        </Button>
      </div>

      <div className="flex gap-6 items-start">

        {/* Sidebar TOC — sticky */}
        <aside className="hidden xl:block w-52 flex-shrink-0 sticky top-4">
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">Contents</p>
            <ul className="space-y-0.5">
              {TOC.map(item => (
                <li key={item.id}>
                  <a
                    href={`#${item.id}`}
                    className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors py-0.5"
                  >
                    <ChevronRight className="w-2.5 h-2.5 flex-shrink-0" />
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* Document body */}
        <div ref={printRef} className="flex-1 bg-card border border-border rounded-xl p-8 max-w-4xl print:shadow-none print:border-none">

          <div className="mb-8 pb-6 border-b border-border">
            <h1 className="text-2xl font-black tracking-tight text-foreground">Sniper Terminal</h1>
            <p className="text-sm text-muted-foreground mt-1">Platform Logic, Scoring & Output Reference</p>
            <p className="text-xs text-muted-foreground/50 mt-1 font-mono">
              Generated: {new Date().toLocaleString("en-GB", { dateStyle: "long", timeStyle: "short" })}
            </p>
            <Note>This document is for informational and technical reference only. Nothing in this platform constitutes financial advice.</Note>
          </div>

          {/* ── 1. Overview ── */}
          <Section id="overview" title="1. Platform Overview">
            <Para>
              Sniper Terminal is a market intelligence platform for multi-asset trading research across crypto, FX, commodities, and indices. It is a decision-support tool — it aggregates, scores, and surfaces signals to help users identify setups worth investigating. It does not provide financial advice and does not make trading decisions.
            </Para>
            <Para>
              The platform is built on three core analytical engines:
            </Para>
            <Table
              headers={["Engine", "Purpose", "Output Entity"]}
              rows={[
                ["Recommended Trade Engine", "Score technical quality of identified setups", "RecommendedTradeSignals"],
                ["Viral Signal Engine", "Measure market attention and crowd-based momentum", "ViralTradeSignals"],
                ["Alert Engine", "Rule-based monitoring of signals and holdings", "Alerts"],
              ]}
            />
            <Para>
              All engines read from <Code>MarketSnapshots</Code> (price, volume, RSI, indicator inputs) and <Code>Assets</Code> (liquidity scores, classification) as their primary data sources.
            </Para>
          </Section>

          {/* ── 2. Data Model ── */}
          <Section id="entities" title="2. Data Model & Entities">

            <Sub title="Assets">
              <Para>The master list of tracked instruments. Each asset has a <Code>symbol</Code>, <Code>market_type</Code> (crypto / fx / commodity / index), <Code>asset_class</Code>, and a <Code>liquidity_score</Code> (0–100) that feeds into every scoring engine.</Para>
              <Table
                headers={["Field", "Type", "Description"]}
                rows={[
                  ["symbol", "string", "Ticker, e.g. BTC, EUR/USD"],
                  ["market_type", "enum", "crypto | fx | commodity | index"],
                  ["liquidity_score", "number 0–100", "Affects opportunity, risk, crowding, and exhaustion scores"],
                  ["active", "boolean", "Only active=true assets are processed by scoring engines"],
                  ["narrative_tags", "string[]", "Thematic labels, e.g. ai, rwa, defi"],
                ]}
              />
            </Sub>

            <Sub title="MarketSnapshots">
              <Para>Time-series records capturing market state for each asset. The scoring engines always use the <strong>most recent snapshot per asset</strong>.</Para>
              <Table
                headers={["Field", "Type", "Used By"]}
                rows={[
                  ["asset", "ref → Assets.id", "All engines"],
                  ["timestamp", "ISO datetime", "Freshness checks, all engines"],
                  ["price", "number", "Display only"],
                  ["change_1h / change_4h / change_24h", "number (%)", "Viral engine (crowding, exhaustion, viral score)"],
                  ["volume / volume_change_percent", "number", "Viral engine"],
                  ["volatility", "number 0–100", "Recommended engine (risk score, penalty)"],
                  ["rsi", "number 0–100", "Recommended engine (RSI multiplier, risk)"],
                  ["trend_score_input", "number 0–100", "Recommended engine"],
                  ["momentum_score_input", "number 0–100", "Recommended engine"],
                  ["sentiment_score_input", "number 0–100", "Both engines"],
                  ["catalyst_score_input", "number 0–100", "Recommended engine"],
                  ["attention_score_input", "number 0–100", "Viral engine"],
                ]}
              />
            </Sub>

            <Sub title="RecommendedTradeSignals">
              <Para>One record per asset per scoring run (status=active). Represents a directional setup that passed the minimum quality threshold. Key scored fields: <Code>opportunity_score</Code>, <Code>conviction_score</Code>, <Code>risk_score</Code>, <Code>direction</Code>, <Code>setup_type</Code>. Explainability fields: <Code>why_now</Code>, <Code>what_kills_it</Code>, <Code>score_boost_factors</Code>, <Code>score_penalty_factors</Code>, <Code>confidence_note</Code>. Snapshot inputs are snapshotted onto the signal: <Code>trend_score_input</Code>, <Code>momentum_score_input</Code>, <Code>catalyst_score_input</Code>, <Code>liquidity_score</Code>.</Para>
            </Sub>

            <Sub title="ViralTradeSignals">
              <Para>One record per asset per scoring run. Represents a viral attention event — not a trade recommendation. Always carries a disclaimer that virality reflects attention, not quality.</Para>
            </Sub>

            <Sub title="Alerts">
              <Para>Generated by the alert engine. Each alert has an <Code>action_classification</Code> (exit_hedge → reduce_risk → act_now → prepare → watch) that determines display priority. Alerts are deduplicated by a composite key of alert_type + asset + trigger_reason.</Para>
            </Sub>

            <Sub title="Holdings & Portfolios">
              <Para>User-defined position tracking. Holdings store quantity, average_entry, live_price, stop_loss, take_profit, and invalidation. P&amp;L is computed client-side from stored fields. Holdings P&amp;L feeds the alert engine.</Para>
            </Sub>
          </Section>

          {/* ── 3. Data Pipeline ── */}
          <Section id="data-pipeline" title="3. Data Pipeline & Provider Logic">
            <Para>
              Market data is sourced from three providers: <strong>CoinGecko</strong> (crypto), <strong>DEX Screener</strong> (on-chain DEX pairs), and <strong>Twelve Data</strong> (FX, commodities, indices). The primary fetch functions are <Code>fetchAssetMarketData</Code> (single asset, on-demand) and <Code>refreshAll</Code> (batch pipeline for all CoinGecko assets, rate-limited).
            </Para>

            <Sub title="3.1 CoinGecko Field Derivation">
              <Para>CoinGecko's free tier does not always return <Code>change_4h</Code> or <Code>volume_change_percent</Code> directly. These are derived as follows:</Para>
              <FormulaBox>{`change_4h (if missing from API):
  if change_24h AND change_1h available:
    change_4h ≈ change_24h / 4 + change_1h × 0.5   (clamped ±50%)
  elif change_24h available:
    change_4h ≈ change_24h / 4

volume_change_percent (if volume and market_cap available):
  expected_volume = market_cap × 0.02   (2% daily turnover baseline)
  volume_change_percent = ((volume − expected_volume) / expected_volume) × 100
  (clamped −100% to +500%)

liquidity_score (from market_cap_rank):
  liquidity_score = clamp(100 − (rank / 500) × 80, 5, 100)
  (rank 1 → ~100; rank 500+ → ~5)

attention_score_input (v2 — asset-differentiating formula):
  rankBase     = rank ≤ 10 ? 60 : rank ≤ 50 ? 50 : rank ≤ 200 ? 38 : 25
  momentumBoost = clamp(|change_1h| × 4, 0, 20) + clamp(|change_24h| × 1.5, 0, 18)
  volBoost     = clamp((volume / marketCap) × 100, 0, 15)  // vol/mcap ratio
  attention_score_input = clamp(round(rankBase + momentumBoost + volBoost), 5, 95)

  NOTE: v2 uses a lower rankBase so that assets with actual price action and
  volume spikes score meaningfully higher than quiet large-caps. The previous
  v1 formula (rankBase + |change_24h|×2) produced near-identical scores for
  all assets within the same rank tier.

sentiment_score_input:
  base = 50 + change_24h × 2
  if change_24h and change_7d have same sign → +8 (aligned trend bonus)
  sentiment_score_input = clamp(base, 5, 95)

trend_score_input:
  base = 50 + change_7d × 1.2 + change_24h × 1.0
  trend_score_input = clamp(base, 5, 95)

momentum_score_input:
  base = 50 + change_1h × 6 + change_24h × 1.5
  momentum_score_input = clamp(base, 5, 95)

rsi (proxy):
  rsi = clamp(50 + change_24h × 1.8, 10, 90)

volatility:
  volatility = clamp(|change_24h| × 2.5 + |change_1h| × 1.5, 0, 100)`}</FormulaBox>
              <Note>All derived fields are proxies. They approximate real technical indicators from available API data. catalyst_score_input defaults to 50 (neutral) as CoinGecko does not provide catalyst data.</Note>
            </Sub>

            <Sub title="3.2 refreshAll — Batch Pipeline">
              <Para><Code>refreshAll</Code> orchestrates a complete data refresh in four sequential steps. Critically, it uses the <strong>same full viral scoring logic</strong> as <Code>scoreViralTrades</Code> — including market-type profiles, crowding/exhaustion scoring, move state, AI label, and explainability fields. Early versions used a simplified inline block that bypassed these; this was corrected in v2.</Para>
              <Table
                headers={["Step", "Action"]}
                rows={[
                  ["1. Fetch market data", "Fetches live data from CoinGecko for up to 25 active CoinGecko assets, rate-limited at 1.3s between requests (~30 req/min). Writes a new MarketSnapshot per asset and updates asset liquidity_score, status, and last_refresh_at."],
                  ["2. Recompute Recommended signals", "Supersedes all existing active recommended signals, then re-scores from the freshest snapshot per asset. Assets with neutral direction or opp < 52 are skipped."],
                  ["3. Recompute Viral signals", "Supersedes all existing active viral signals, then re-scores using the full viral scoring pipeline (viral score, crowding, exhaustion, move state, AI label, explainability, raw_inputs). Assets missing minimum required fields (no price momentum or no attention) are skipped. Assets with viral_score < 30 are skipped."],
                  ["4. Generate Alerts", "Evaluates all fresh recommended and viral signals plus portfolio holdings against alert rules, writes new deduplicated alerts."],
                ]}
              />
              <Para>The 25-asset limit per run is intentional (CoinGecko free tier rate limit). Portfolios with more than 25 CoinGecko assets require multiple sequential "Refresh All" runs.</Para>
            </Sub>

            <Sub title="3.3 Data Quality Tracking (Viral Engine)">
              <Para>Each viral signal stores a <Code>data_quality</Code> field and <Code>raw_inputs</Code> JSON to enable full audit of what data the score was computed from:</Para>
              <Table
                headers={["data_quality value", "Meaning"]}
                rows={[
                  ["live", "All preferred fields (change_1h, change_4h, volume_change_percent, attention, sentiment) present in the snapshot"],
                  ["partial", "Some preferred fields missing — derived fallbacks used. Score is still calculated; confidence is reduced."],
                  ["incomplete", "Minimum required fields missing (no price momentum OR no attention). Asset is skipped — no signal written."],
                ]}
              />
              <Para><Code>raw_inputs</Code> stores: change_1h, change_4h, volume_change_percent, attention_score_input, sentiment_score_input, liquidity_score, volatility, rsi, snapshot_timestamp, missing_fields. Displayed in the viral detail drawer for transparency.</Para>
            </Sub>
          </Section>

          {/* ── 4. Recommended Engine ── */}
          <Section id="recommended" title="4. Recommended Trade Engine">
            <Para>
              Three functions implement this engine: <Code>scoreRecommendedTrades</Code> (single-asset, called by fetchAssetMarketData), <Code>recomputeRecommendedTrades</Code> (full recompute from existing snapshots), and <Code>refreshAll</Code> (orchestrates a full pipeline refresh). All share identical scoring logic. Assets with neutral direction or opportunity score below 52 are skipped and not written to the database.
            </Para>

            <Sub title="3.1 Input Normalisation">
              <Para>All raw inputs (0–100 scale) are normalised via:</Para>
              <FormulaBox>norm(v) = clamp(v, 0, 100)   // null/NaN → 50 (neutral)</FormulaBox>
            </Sub>

            <Sub title="3.2 Opportunity Score">
              <Para>Weighted sum of five factors (inputs already 0–100, weights sum to 1.0), then adjusted by RSI multiplier and volatility penalty:</Para>
              <FormulaBox>{`base = trend × 0.30 + momentum × 0.25 + catalyst × 0.20 + sentiment × 0.15 + liquidity × 0.10

RSI multiplier:
  RSI > 80  → × 0.70   (heavily overbought)
  RSI > 70  → × 0.85   (overbought)
  RSI < 20  → × 0.70   (heavily oversold)
  RSI < 30  → × 0.85   (oversold)
  otherwise → × 1.00

Volatility × liquidity penalty (subtracted from base):
  vol > 70 AND liq < 40 → −12
  vol > 70 AND liq < 60 → −7
  vol > 55 AND liq < 40 → −5
  otherwise → 0

opportunity_score = clamp(round(base × RSI_multiplier − penalty), 0, 100)`}</FormulaBox>
            </Sub>

            <Sub title="3.3 Conviction Score">
              <Para>Pure signal alignment — no volatility noise or RSI adjustment. Inputs already 0–100, no ×100 multiplier:</Para>
              <FormulaBox>{`conviction_score = clamp(round(
  trend × 0.35 + momentum × 0.30 + catalyst × 0.20 + liquidity × 0.15
), 0, 100)`}</FormulaBox>
              <Para>This score reflects underlying directional alignment. It will naturally vary across assets based on differing trend, momentum, catalyst, and liquidity inputs.</Para>
            </Sub>

            <Sub title="3.4 Risk Score">
              <Para>Higher = more dangerous. Derived from adverse-signal inputs:</Para>
              <FormulaBox>{`liq_risk = 100 − liquidity

rsi_risk:
  RSI > 80 or < 20  → 35
  RSI > 70 or < 30  → 15
  otherwise          → 0

risk_score = clamp(round(
  volatility × 0.45 + liq_risk × 0.35 + rsi_risk × 0.20
), 0, 100)`}</FormulaBox>
            </Sub>

            <Sub title="3.5 Direction">
              <FormulaBox>{`avg = (trend + momentum) / 2
avg ≥ 58 → "bullish"
avg ≤ 42 → "bearish"
otherwise → "neutral"  (skipped — not written to DB)`}</FormulaBox>
            </Sub>

            <Sub title="3.6 Setup Type">
              <FormulaBox>{`Reversal (bullish): rsi < 32 AND momentum > 55
Reversal (bearish): rsi > 68 AND momentum < 45
Breakout:     bullish AND trend > 72 AND momentum > 65
Continuation: bullish AND trend > 60 AND momentum > 52
Pullback:     bullish AND (fallback)
Breakdown:    bearish AND trend < 28 AND momentum < 35
Bear cont.:   bearish AND trend < 40 AND momentum < 48
Bear pullback failure: bearish AND (fallback)`}</FormulaBox>
            </Sub>

            <Sub title="3.7 Confidence Note">
              <Table
                headers={["Condition", "Note"]}
                rows={[
                  ["opp ≥ 75 AND risk < 35", "High-confidence setup: strong signal alignment with low risk profile."],
                  ["opp ≥ 60 AND risk < 55", "Moderate confidence: meets quality threshold but monitor risk factors closely."],
                  ["risk ≥ 65", "Low confidence: elevated risk score — use reduced position sizing."],
                  ["Otherwise", "Marginal setup: passed threshold but alignment is mixed. Validate independently."],
                ]}
              />
            </Sub>

            <Sub title="3.8 Activation Threshold">
              <Para>Only assets with <Code>opportunity_score ≥ 52</Code> AND non-neutral direction are written to <Code>RecommendedTradeSignals</Code>. Each run supersedes the previous active signal for the same asset before creating a fresh record.</Para>
            </Sub>

            <Sub title="3.9 Stored Fields">
              <Table
                headers={["Field", "Description"]}
                rows={[
                  ["opportunity_score", "Composite quality score (0–100) with RSI and vol adjustments"],
                  ["conviction_score", "Pure directional alignment score (0–100), no volatility noise"],
                  ["risk_score", "Adverse conditions score (0–100) — higher = more dangerous"],
                  ["direction", "bullish | bearish"],
                  ["setup_type", "Enumerated setup classification (breakout, continuation, etc.)"],
                  ["trend/momentum/catalyst_score_input", "Snapshot inputs stored on signal for verification"],
                  ["liquidity_score", "Asset liquidity snapshot used during scoring"],
                  ["why_now, what_kills_it, score_boost_factors, score_penalty_factors, confidence_note", "Explainability text derived from scoring inputs"],
                ]}
              />
            </Sub>
          </Section>

          {/* ── 5. Viral Engine ── */}
          <Section id="viral" title="5. Viral Signal Engine (scoreViralTrades)">
            <Para>Measures market attention and momentum intensity. A high viral score means the market is paying attention — not that the trade is good. Every output carries an explicit quality disclaimer. The engine is <strong>market-type aware</strong> — thresholds for crowding and exhaustion differ between crypto, FX, commodities, and indices to reflect their typical move magnitudes.</Para>

            <Sub title="4.1 Viral Score">
              <FormulaBox>{`price_change_to_scale(pct) = clamp((|pct| / 50) × 100, 0, 100)

vol_score = clamp((|volume_change_percent| / 200) × 100, 0, 100)
price_accel = change_1h_scaled × 0.65 + change_4h_scaled × 0.35

viral_score = clamp(round(
  attention × 0.35 + vol_score × 0.30 + price_accel × 0.20 + sentiment × 0.15
), 0, 100)

Minimum threshold to appear in feed: viral_score ≥ 30`}</FormulaBox>
            </Sub>

            <Sub title="4.2 Market-Type Threshold Profiles">
              <Para>Crowding and exhaustion use asset-class-specific move thresholds. What constitutes a "large" 1h move varies significantly between asset classes:</Para>
              <Table
                headers={["Market type", "Crowding: large 1h move", "Crowding: large 4h move", "Exhaustion: extreme 1h move"]}
                rows={[
                  ["crypto", "> 8%", "> 15%", "> 12%"],
                  ["fx", "> 0.6%", "> 1.2%", "> 1.0%"],
                  ["commodity", "> 2.0%", "> 4.0%", "> 3.5%"],
                  ["index", "> 1.5%", "> 3.0%", "> 2.5%"],
                ]}
              />
            </Sub>

            <Sub title="4.3 Crowding Score (high = dangerous, late-entry risk)">
              <FormulaBox>{`score = 0
|change_1h| > profile.p1h_high  → +30   | > profile.p1h_mid  → +15
|change_4h| > profile.p4h_high  → +25   | > profile.p4h_mid  → +12
volatility > 70                  → +20   | > 50               → +10
sentiment  > 80                  → +15   | > 65               → +7

crowding_score = clamp(score, 0, 100)`}</FormulaBox>
            </Sub>

            <Sub title="4.4 Exhaustion Score (high = move is tapped out)">
              <FormulaBox>{`score = 0
|change_1h| > profile.p1h_extreme → +35
|change_1h| > profile.p1h_high    → +18
|change_1h| > profile.p1h_mid     → +8
volatility > 80  → +25   | > 60 → +12
attention > 75 AND liquidity < 40  → +25
attention > 60 AND liquidity < 40  → +12

exhaustion_score = clamp(score, 0, 100)`}</FormulaBox>
            </Sub>

            <Sub title="4.5 Move State">
              <FormulaBox>{`exhaustion ≥ 60                                              → "exhausted"
crowding  ≥ 55                                              → "crowded"
viral ≥ ms.early_viral AND crowding < ms.early_crowding
  AND exhaustion < ms.early_exhaustion                      → "early"
viral ≥ ms.building_viral AND crowding < ms.building_crowding → "building"
default                                                     → "building"

(ms thresholds: crypto early_viral=45; fx/commodity/index early_viral=40)`}</FormulaBox>
            </Sub>

            <Sub title="4.6 AI Label (strict priority-ordered decision tree, no ML)">
              <FormulaBox>{`Priority 1: liquidity < 25                      → "avoid"
Priority 2: state = "exhausted"                  → "avoid"
Priority 3: exhaustion ≥ 65                      → "avoid"
           exhaustion ≥ 45                       → "caution"
Priority 4: state = "crowded" AND liq < 50       → "avoid"
           state = "crowded"                     → "caution"
           crowding ≥ 50                         → "caution"
Priority 5: liq < 50                             → "caution"
Priority 6: crowding ≥ 35                        → "caution"
Priority 7: (early or building) AND liq ≥ 50
            AND exhaustion < 40 AND crowding < 35 → "tradable"
Default:    "caution"`}</FormulaBox>
              <Note>The label "tradable" never means "buy." It means liquidity and exhaustion conditions are acceptable for careful entry evaluation only.</Note>
            </Sub>

            <Sub title="4.7 Explainability Fields">
              <Para>Each viral signal stores: <Code>viral_boost_factors</Code>, <Code>viral_penalty_factors</Code>, <Code>confidence_note</Code>, <Code>summary</Code>, and <Code>score_explanation</Code> (JSON). All are derived deterministically from the scoring inputs — no AI generation at runtime.</Para>
            </Sub>
          </Section>

          {/* ── 6. Signal Intelligence Components ── */}
          <Section id="intelligence" title="6. Signal Intelligence Components">
            <Para>
              Every signal detail drawer (both Recommended and Viral) surfaces five derived intelligence components. All are computed client-side from stored signal fields — no additional API calls at render time.
            </Para>

            <Sub title="6.1 Signal Decision Output">
              <Para>Produces a single actionable recommendation derived from the signal's risk, opportunity, exhaustion, and liquidity scores. Shown as a full text block in drawers, always accompanied by a disclaimer:</Para>
              <Table
                headers={["Decision", "Trigger Logic (priority-ordered)", "Guidance shown"]}
                rows={[
                  ["AVOID", "risk ≥ 70, OR liquidity < 25, OR exhaustion ≥ 65, OR ai_label = avoid", "Conditions are unfavourable. Do not enter."],
                  ["REDUCE EXPOSURE", "risk ≥ 55 AND opp < 60, OR exhaustion ≥ 45", "Risk conditions are elevated — consider reducing exposure or exiting."],
                  ["WAIT FOR CONFIRMATION", "opp ≥ 52 but risk 45–54, OR ai_label = caution", "Setup exists but conditions are not fully aligned. Wait for confirmation."],
                  ["CONDITIONS ALIGNED FOR ENTRY EVALUATION", "opp ≥ 65 AND risk < 45 AND (exhaustion < 40 or no exhaustion)", "Scoring inputs are aligned. Conditions warrant independent evaluation of entry."],
                ]}
              />
              <Note>All decision outputs carry a footer disclaimer: "Not financial advice. Validate independently before acting."</Note>
            </Sub>

            <Sub title="6.2 Signal Time Expectation">
              <Para>Estimates the expected operative window for the signal based on volatility, move state, and setup type. Three tiers:</Para>
              <Table
                headers={["Window", "Criteria", "Meaning"]}
                rows={[
                  ["IMMEDIATE (0–6h)", "move_state = exhausted OR crowded, OR volatility > 70, OR setup = breakout/reversal with high vol", "Window is narrow — act quickly or skip."],
                  ["SHORT (6–24h)", "volatility 40–70, OR setup = breakout/reversal/continuation", "Standard intraday-to-overnight window."],
                  ["MEDIUM (1–3 days)", "volatility < 40 AND setup = pullback or continuation with low momentum", "Slower setup — monitor over several sessions."],
                ]}
              />
            </Sub>

            <Sub title="6.3 Multi-Signal Alignment (Recommended drawer only)">
              <Para>Cross-checks the recommended signal against the active viral signal for the same asset (if one exists) to produce a unified confidence tier:</Para>
              <Table
                headers={["Tier", "Logic", "Meaning"]}
                rows={[
                  ["HIGH CONFIDENCE", "≥ 2 positive signals, 0 negatives", "Multiple independent signals agree across recommended, viral, and risk dimensions."],
                  ["MEDIUM CONFIDENCE", "Mixed — some positive, some neutral/negative", "Partial alignment. Size down."],
                  ["LOW CONFIDENCE", "≥ 2 negative signals", "Significant cross-signal conflict. Treat with high scepticism."],
                ]}
              />
              <Para>Positive signals: opp ≥ 70 AND risk &lt; 40, viral = early/building AND tradable, risk &lt; 35. Negative signals: opp &lt; 52, viral = avoid, risk ≥ 60. The viral signal is fetched live at drawer open time via a filtered query on ViralTradeSignals.</Para>
            </Sub>

            <Sub title="6.4 Signal Validation Panel">
              <Para>An audit dashboard shown in every detail drawer. Checks four conditions and produces an overall VERIFIED or CAUTION gate:</Para>
              <Table
                headers={["Check", "Pass condition", "Fail condition"]}
                rows={[
                  ["Data Freshness", "Signal age < 4h (recommended) / < 6h (viral)", "Signal is stale — confidence is degraded"],
                  ["Completeness (Viral)", "No missing_fields in raw_inputs", "One or more required fields were missing at score time"],
                  ["Data Confidence", "data_confidence ≥ 70", "Confidence score below threshold — fallback values used"],
                  ["Liquidity Gate", "liquidity_score ≥ 40 (rec) / liquidity_quality_score ≥ 40 (viral)", "Thin liquidity — execution risk is elevated"],
                ]}
              />
              <Para>Overall gate: VERIFIED if all four pass. CAUTION if any fail. For recommended signals that do not carry data_quality metadata, completeness and confidence checks are skipped (shown as OK with a note).</Para>
            </Sub>

            <Sub title="6.5 External Trade Links (Quick Actions)">
              <Para>One-click access buttons derived from the asset symbol and metadata. Links are constructed client-side — no API calls:</Para>
              <Table
                headers={["Link", "URL pattern", "Shown when"]}
                rows={[
                  ["Trade on Binance", "https://www.binance.com/en/trade/{SYMBOL}_USDT", "Always (when symbol available)"],
                  ["TradingView Chart", "https://www.tradingview.com/chart/?symbol={SYMBOL}USDT", "Always"],
                  ["CoinGecko", "asset.coingecko_profile_url OR https://coingecko.com/en/coins/{provider_asset_id}", "When CoinGecko URL or provider_asset_id is stored"],
                  ["DEX Screener", "https://dexscreener.com/{chain_id}/{pair_address}", "When chain_id and pair_address stored on asset"],
                  ["Official Site", "asset.official_website_url", "When stored on asset"],
                ]}
              />
              <Note>Links open in a new tab. Users must verify they are connecting to the correct asset on the target exchange — the platform does not validate live exchange listings.</Note>
            </Sub>
          </Section>

          {/* ── 7. Decision Engine UI Layer ── */}
          <Section id="decision-engine" title="7. Decision Engine UI Layer">
            <Para>
              Six deterministic UI components form the <strong>Decision Engine Layer</strong> — a set of glanceable, always-visible indicators designed to minimise cognitive load and surface the most important trade decision information without requiring the user to open a drawer. All are computed client-side from stored signal fields.
            </Para>

            <Sub title="7.1 DecisionBadge">
              <Para>A single dominant action badge shown at the top of every signal card, table row, and detail drawer. Four states derived from the same <Code>deriveDecision()</Code> logic as <Code>SignalDecisionOutput</Code>:</Para>
              <Table
                headers={["Badge", "Condition", "Visual"]}
                rows={[
                  ["CONDITIONS ALIGNED", "opp ≥ 65 AND risk < 50 AND liquidity ≥ 45 AND exhaustion < 45", "Green glow border"],
                  ["WAIT", "ai_label = caution OR opp < 58 OR (risk ≥ 50 AND exhaustion ≥ 40)", "Blue"],
                  ["REDUCE EXPOSURE", "risk ≥ 65 OR exhaustion ≥ 60 OR liquidity < 30", "Amber"],
                  ["AVOID", "ai_label = avoid", "Red glow border"],
                ]}
              />
              <Para>Sizes: <Code>sm</Code> (table cells), <Code>md</Code> (cards), <Code>lg</Code> (drawer headers — bold uppercase with tracking).</Para>
            </Sub>

            <Sub title="7.2 UrgencyTag">
              <Para>Compresses the Signal Time Expectation into a 3-state emoji + label tag shown next to DecisionBadge in tables and cards:</Para>
              <Table
                headers={["Tag", "Maps from TimeExpectation.id", "Colour"]}
                rows={[
                  ["🔥 Immediate", "immediate", "Red"],
                  ["⏳ Developing", "short", "Amber"],
                  ["💤 Low Priority", "medium", "Muted"],
                ]}
              />
            </Sub>

            <Sub title="7.3 ConfidenceTier (A/B/C/D)">
              <Para>A signal-stack reliability grade derived from opportunity, risk, exhaustion, liquidity, and data quality. Shown as a single letter badge with a short label in tables and full text in drawers:</Para>
              <Table
                headers={["Grade", "Label", "Composite score threshold", "Visual"]}
                rows={[
                  ["A", "Aligned", "composite ≥ 75", "Green"],
                  ["B", "Moderate", "composite ≥ 58", "Blue"],
                  ["C", "Weak", "composite ≥ 42", "Amber"],
                  ["D", "Conflicting", "< 42 OR data_quality = full_fallback OR exhaustion ≥ 65", "Red"],
                ]}
              />
              <FormulaBox>{`composite = opp × 0.40 + (100 − risk) × 0.30 + liquidity × 0.20 + dq_bonus × 0.10
dq_bonus: data_quality = "live" → 10 | "partial" → 5 | otherwise → 0`}</FormulaBox>
              <Para>Hard-D overrides: <Code>data_quality = full_fallback</Code>, <Code>ai_label = avoid</Code>, or <Code>exhaustion_score ≥ 65</Code> → always D regardless of composite.</Para>
            </Sub>

            <Sub title="7.4 FailFastBlock">
              <Para>A hard gate — not a warning — that completely replaces the decision/action area in a drawer when signal data is too degraded to act on. Blocks rendering of DecisionBadge, Decision Output, Time Expectation, Validation Panel, and External Links for the affected signal.</Para>
              <Table
                headers={["Block condition", "Reason shown to user"]}
                rows={[
                  ["Signal age > 6h (viral) or > 4h (rec)", "Data is stale — scoring inputs may no longer reflect market conditions"],
                  ["status = suppressed_fallback", "Multiple assets with identical default values — scoring run used fallback data"],
                  ["ai_label = avoid", "AI label is AVOID — execution risk is too high to evaluate entry"],
                  ["data_confidence < 40", "Data confidence is critically low — too many missing inputs"],
                ]}
              />
              <Note>When FailFastBlock is active, the signal's score breakdown and explainability are still shown — only the action components are gated. This allows users to understand why the block fired.</Note>
            </Sub>

            <Sub title="7.5 SessionMode (Intraday / Swing)">
              <Para>A global context toggle in the dashboard header. Switches the scoring thresholds used to filter and interpret signals across all views:</Para>
              <Table
                headers={["Mode", "Min opportunity", "Max risk", "Min liquidity", "Description"]}
                rows={[
                  ["Intraday", "60", "50", "55", "Higher quality bar — filters for tight, clean setups only. Short time horizon."],
                  ["Swing", "50", "65", "40", "Relaxed thresholds — allows developing setups and lower-liquidity assets. Multi-day horizon."],
                ]}
              />
              <Para>Session mode is stored in React context (<Code>SessionModeContext</Code>) and persists for the session. The active mode and its thresholds are shown as an info bar on the Recommended Trades page.</Para>
            </Sub>

            <Sub title="7.6 PortfolioRiskStrip">
              <Para>A persistent header strip on the main dashboard displaying three portfolio-level risk metrics derived client-side from all open holdings:</Para>
              <Table
                headers={["Metric", "Calculation", "Condition for warning colour"]}
                rows={[
                  ["Net Bias", "Count bullish vs bearish signals on holdings by direction", "If heavily skewed one way (net exposure risk)"],
                  ["Unprotected %", "% of holdings with no stop_loss set", "≥ 30% unprotected → amber; ≥ 60% → red"],
                  ["Near Limit", "Count of holdings within 10% of stop_loss OR take_profit level", "Any position within threshold → amber"],
                ]}
              />
              <Para>Clicking the strip navigates to the Portfolio page. No backend calls — all calculations use holdings already loaded in the dashboard query cache.</Para>
            </Sub>
          </Section>

          {/* ── 8. Trade Reason Indicator ── */}
          <Section id="trade-reason" title="8. Trade Reason Indicator">
            <Para>
              Every signal (recommended and viral) carries a <strong>Trade Reason Indicator</strong> — a deterministic label derived from the signal's scoring inputs that explains <em>why this trade exists</em> in plain English. It appears as a compact pill in all signal tables and as a full explanatory block in detail drawers.
            </Para>
            <Para>The indicator uses a priority-ordered pattern matching system — no ML or AI:</Para>
            <Table
              headers={["Pattern ID", "Label", "Trigger Condition", "Description shown to user"]}
              rows={[
                ["crowd_spike", "Crowd Attention Spike", "attention ≥ 65 AND liquidity < 45", "High social/search attention with thin liquidity — likely short-term crowd-driven move. Late entries face sharp reversal risk."],
                ["continuation", "Trend Continuation", "trend ≥ 62 AND momentum ≥ 62 AND volatility < 45 AND liquidity ≥ 50", "Momentum and trend aligned in a low-volatility environment with solid liquidity — conditions favour a controlled continuation setup."],
                ["reversal", "Reversal Signal", "RSI > 72 OR RSI < 28, AND momentum shifted", "RSI overextended with a momentum shift — mean-reversion setup, not a trend follow."],
                ["volume_breakout", "Volume-Led Breakout", "volume_spike_score ≥ 50 AND momentum ≥ 58", "Abnormal volume surge with strong momentum — suggests institutional or high-conviction participation."],
                ["viral_danger", "Viral — Low Liquidity", "viral_score ≥ 55 AND liquidity < 40", "Asset is trending virally but lacks liquidity for safe sizing. High slippage and reversal risk."],
                ["catalyst", "Catalyst-Driven", "catalyst_score_input ≥ 68", "A material catalyst is supporting the move. Validate the catalyst is still live before entering."],
                ["mixed", "Mixed — No Dominant Driver", "trend < 52 AND momentum < 52 AND attention < 52", "No single indicator strongly in control. Setup passes minimum thresholds across multiple factors."],
                ["momentum_led", "Momentum-Led", "(default fallback)", "Short-term momentum is the primary driver. Trend confirmation is partial — watch for fade at key levels."],
              ]}
            />
            <Note>Pattern matching is evaluated in priority order — the first matching pattern wins. Inputs used: trend_score_input, momentum_score_input, volatility (or volatility_score_input), liquidity_score (or liquidity_quality_score), attention_score (or attention_score_input), catalyst_score_input, rsi, viral_score, volume_spike_score. Fields are normalised to 0–100 with null→50 fallback.</Note>
          </Section>

          {/* ── 9. £100 Scenario ── */}
          <Section id="scenario" title="9. £100 Illustrative Scenario">
            <Para>
              Shown in every signal detail drawer. Provides an asset-specific illustrative example of what a £100 position would be worth at each key price level. Two variants exist: one for Recommended signals (price-level anchored) and one for Viral signals (momentum anchored).
            </Para>

            <Sub title="8.1 Recommended Scenario">
              <Para>Uses stored entry/target/invalidation levels if present on the signal. If they are not stored (the scoring engine currently does not derive price targets), levels are <strong>derived from the live price + scoring inputs</strong>:</Para>
              <FormulaBox>{`entryMid = current_price (or midpoint of entry_low/entry_high if stored)

vol_factor = 0.5 + (volatility / 100) × 1.5   // scales 0.5× at 0 vol → 2× at 100 vol

Per setup type (% moves scaled by vol_factor):
  breakout/breakdown:   stop=2.5+risk×0.04,  T1=5+vol×0.08,   T2=10+vol×0.12
  reversal:             stop=3+risk×0.05,    T1=7+vol×0.10,   T2=14+vol×0.15
  continuation:         stop=2+risk×0.03,    T1=4+vol×0.06,   T2=8+vol×0.10
  pullback/default:     stop=2+risk×0.035,   T1=4+vol×0.07,   T2=8+vol×0.11

pct_at_target = ((target - entryMid) / entryMid) × 100
£_at_target   = £100 × (1 + pct_at_target / 100)

R:R = |T1_pct / stop_pct|`}</FormulaBox>
              <Para>When levels are derived (not stored), this is disclosed below the scenario with the note "levels estimated from live price, volatility, risk score, and setup type."</Para>
            </Sub>

            <Sub title="8.2 Viral Scenario">
              <Para>Anchored to the asset's <strong>actual observed price momentum</strong> from <Code>raw_inputs</Code> — not hardcoded generic percentages:</Para>
              <FormulaBox>{`// Best available momentum anchor (in priority order):
recentMomentum = raw_inputs.change_4h
              ?? raw_inputs.change_1h × 3
              ?? raw_inputs.change_24h / 2

// Risk adjustment — exhaustion and crowding shrink upside, widen downside
riskMultiplier = 1 − ((exhaustion_score + crowding_score) / 200) × 0.6
// range: 1.0 (no risk) → ~0.7 (max risk)

conservative = |recentMomentum| × 0.50 × riskMultiplier
optimistic   = |recentMomentum| × 1.10 × riskMultiplier
downside     = −|recentMomentum| × 0.70 / riskMultiplier

// Capped per move state:
early:     up cap 30%  / down cap −20%
building:  up cap 20%  / down cap −18%
crowded:   up cap 7.5% / down cap −20%
exhausted: up cap 2.5% / down cap −30%

// Fallback (no price change data available):
// Use volatility-scaled ranges per move state — NOT hardcoded`}</FormulaBox>
              <Para>The drawer labels show which timeframe anchored the scenarios (4h, 1h, or 24h) and the upside/downside skew ratio.</Para>
              <Note>Scenarios are illustrative only. They are anchored to observed price action, not forecasts. High exhaustion and crowding scores will produce narrow or negative upside ranges — this is intentional and reflects real risk conditions.</Note>
            </Sub>
          </Section>

          {/* ── 10. Alert Engine ── */}
          <Section id="alerts" title="10. Alert Engine (generateAlerts / refreshAll)">

            <Para>Evaluates current active signals and holdings against rule sets. Alerts are deduplicated using a composite key of <Code>alert_type::asset_symbol::asset_id</Code> (or with a suffix variant for secondary conditions on the same asset) — the same alert will never be written twice while a matching active alert exists in the queue.</Para>
            <Para>Stale signals (older than 4 hours for recommended, 6 hours for viral) are skipped entirely — no alerts are raised on outdated data.</Para>

            <Sub title="5.1 Alert Rules">
              <Table
                headers={["Rule", "Condition", "Severity", "Action"]}
                rows={[
                  ["High opportunity", "opp ≥ 68 AND risk < 55 (not stale)", "medium / high (if opp ≥ 80)", "act_now"],
                  ["Moderate opportunity", "opp ≥ 52 AND opp < 68 (not stale)", "low", "prepare"],
                  ["High risk score", "risk ≥ 65 on any rec signal (not stale)", "high / critical (if risk ≥ 80)", "reduce_risk"],
                  ["Viral avoid/caution", "ai_label = avoid or caution (not stale)", "high (avoid) / medium (caution)", "reduce_risk or watch"],
                  ["Viral + thin liquidity", "viral_score ≥ 50 AND liquidity_quality_score < 35 (not stale)", "medium", "watch"],
                  ["Holding drawdown ≥ 10%", "pnl% ≤ −10% (from live or snapshot price)", "high", "reduce_risk"],
                  ["Holding drawdown ≥ 20%", "pnl% ≤ −20%", "critical (or high if price is stale)", "exit_hedge"],
                  ["Holding gain ≥ 20%", "pnl% ≥ +20%", "medium (or low if price is stale)", "prepare (take_profit alert)"],
                ]}
              />
            </Sub>

            <Sub title="5.2 Deduplication Key Format">
              <Table
                headers={["Alert type", "Dedup key"]}
                rows={[
                  ["opportunity_score (high)", "opportunity_score::SYMBOL::ASSET_ID"],
                  ["opportunity_score (prepare)", "opportunity_score::SYMBOL::ASSET_ID_prepare"],
                  ["indicator (risk)", "indicator::SYMBOL::ASSET_ID"],
                  ["viral_score (label)", "viral_score::SYMBOL::ASSET_ID"],
                  ["viral_score (liquidity)", "viral_score::SYMBOL::ASSET_ID_liq"],
                  ["stop_loss", "stop_loss::SYMBOL::HOLDING_ID"],
                  ["take_profit", "take_profit::SYMBOL::HOLDING_ID"],
                ]}
              />
            </Sub>

            <Sub title="5.3 Action Classification Priority (UI display order)">
              <Table
                headers={["Priority", "Class", "Meaning"]}
                rows={[
                  ["1 (highest)", "exit_hedge", "Position may need to be closed or hedged immediately"],
                  ["2", "reduce_risk", "Reduce exposure, tighten stops, or size down"],
                  ["3", "act_now", "High-conviction setup ready to evaluate"],
                  ["4", "prepare", "Developing setup or profit-taking opportunity"],
                  ["5 (lowest)", "watch", "Monitor — no immediate action warranted"],
                ]}
              />
            </Sub>

            <Sub title="5.4 Price Source for Holdings Alerts">
              <Para>Price is sourced in this order: (1) latest MarketSnapshot for the asset, (2) <Code>live_price</Code> stored on the holding, (3) skipped entirely if no price is available. If the price source is stale, alert severity is downgraded by one level and a note is appended to the summary.</Para>
            </Sub>
          </Section>

          {/* ── 11. Alert Enrichment ── */}
          <Section id="alert-enrichment" title="11. Alert Enrichment & Position Guidance Engine">
            <Para>
              Every alert displayed in the UI passes through a two-stage enrichment pipeline before being rendered. This pipeline resolves asset identity, attaches live market data, and computes a unique signal-specific position guidance output for each alert.
            </Para>

            <Sub title="11.1 useAlertEnrichment Hook">
              <Para>Runs client-side on page load. Fetches all <Code>Assets</Code> and latest <Code>MarketSnapshots</Code>, then attaches resolved fields to every raw alert:</Para>
              <Table
                headers={["Resolved field", "Source", "Purpose"]}
                rows={[
                  ["_symbol", "asset.symbol → alert.asset (fallback)", "Display name for the asset"],
                  ["_name", "asset.name → alert.display_name (fallback)", "Full asset name"],
                  ["_market_type", "asset.market_type → alert.market_type (fallback)", "Drives market-type-specific return rates in projection"],
                  ["_live_price", "Latest MarketSnapshot.price → alert.current_price (fallback)", "Current price display"],
                  ["_price_is_stale", "Snapshot age > 4h", "Triggers stale price warning in UI"],
                  ["_asset", "Full Assets record", "Provides liquidity_score, chain data, provider URLs"],
                  ["_snapshot", "Full MarketSnapshot record", "Provides RSI, change_1h/4h, volume, volatility, trend/momentum/sentiment/catalyst scores"],
                ]}
              />
              <Para>The <Code>_snapshot</Code> field was added specifically to power the <Code>AlertProfileProjection</Code> engine — it contains all the live market inputs needed to differentiate every alert's position guidance.</Para>
            </Sub>

            <Sub title="11.2 AlertProfileProjection — Signal Quality Scoring Engine">
              <Para>
                <Code>AlertProfileProjection</Code> is rendered on every actionable alert card (inline strip) and in the detail drawer (full block). It computes a unique 8-factor signal quality score (0–100) from the live snapshot attached to the alert. No two alerts with different market data will produce the same output.
              </Para>
              <Para><strong>Actionable alert types:</strong> opportunity_score, viral_score, take_profit, act_now, prepare, indicator, price.</Para>

              <Para><strong>8-factor scoring engine (total: 0–100 pts):</strong></Para>
              <Table
                headers={["Factor", "Max pts", "Inputs used", "Logic"]}
                rows={[
                  ["Trend & Momentum", "25", "trend_score_input, momentum_score_input", "trend × 0.6 + momentum × 0.4, scaled to 25"],
                  ["RSI Regime", "20", "snapshot.rsi", "Ideal zone 40–65 → 20pts; >75 overbought → 4pts; <30 oversold → 6pts"],
                  ["Volume Confirmation", "15", "snapshot.volume_change_percent", "volChg > 100% → 15pts; > 40% → 12pts; < −30% → 3pts"],
                  ["Price Momentum", "20", "snapshot.change_4h (or change_1h)", "Scaled by market-type factor (FX ×15, crypto ×1, commodity ×5, index ×8)"],
                  ["Liquidity Quality", "15", "asset.liquidity_score", "liquidity / 100 × 15"],
                  ["Sentiment + Catalyst", "10", "sentiment_score_input, catalyst_score_input", "(sentiment + catalyst) / 200 × 10"],
                  ["Alert Modifiers", "±25", "severity, action_classification, pnl_pct", "Severity/action bonuses and penalties; P&L context adjustments"],
                  ["Volatility Penalty", "−8 max", "snapshot.volatility, asset.liquidity_score", "High vol + low liquidity → −8; high vol alone → −4"],
                ]}
              />
              <Note>The market-type price momentum scaling is critical for cross-asset fairness — a 1% 4h move is extreme for EUR/USD but trivial for a small-cap crypto. Scaling prevents FX and index alerts from being systematically underscored.</Note>
            </Sub>

            <Sub title="11.3 Kelly-Inspired Position Sizing">
              <Para>Position size is not a fixed percentage of capital — it is computed from a half-Kelly formula using signal quality as a proxy for edge and risk-adjusted score as a proxy for odds:</Para>
              <FormulaBox>{`// Estimated win rate from quality (50%–90% range)
winRate  = 0.50 + (quality / 100) × 0.40

// Estimated reward:risk ratio from riskAdj score (1:1 to 3:1 range)
rrRatio  = 1.0 + (riskAdj / 100) × 2.0

// Full Kelly fraction
kelly    = winRate − (1 − winRate) / rrRatio

// Half-Kelly (safety factor), capped by profile base allocation
fraction = clamp(kelly × 0.5, 0.02, baseAlloc × 1.5)

positionAmt = clamp(available × fraction, £1, available × 50%)`}</FormulaBox>
              <Para>Base allocation ceilings by risk appetite: low → 8%, medium → 18%, high → 32%. Half-Kelly can scale these up to 1.5× for very high quality signals.</Para>
            </Sub>

            <Sub title="11.4 Market-Type Adjusted Return Rates">
              <Para>Return rate benchmarks differ by market type — crypto has dramatically higher expected volatility and return potential than FX. All rates are illustrative and compounded over the user's timeline:</Para>
              <Table
                headers={["Market Type", "Low risk p.a.", "Medium risk p.a.", "High risk p.a."]}
                rows={[
                  ["crypto",    "12%", "35%",  "80%"],
                  ["fx",        "4%",  "10%",  "22%"],
                  ["commodity", "6%",  "15%",  "32%"],
                  ["index",     "7%",  "12%",  "20%"],
                  ["default",   "8%",  "20%",  "45%"],
                ]}
              />
              <Para>The base rate is then multiplied by a quality confidence factor:</Para>
              <FormulaBox>{`confMult    = clamp(0.30 + (quality / 100) × 1.0, 0.30, 1.40)
dirBonus    = (trend > 65 AND momentum > 65) ? +10% of baseRate : (both < 40) ? −10% : 0

signalRate    = baseRate × confMult + dirBonus
conservRate   = signalRate × 0.35
optimisticRate = signalRate × 1.80`}</FormulaBox>
            </Sub>

            <Sub title="11.5 Sub-scores (shown in full drawer block)">
              <Table
                headers={["Sub-score", "Formula", "Meaning"]}
                rows={[
                  ["Conviction", "trend × 0.5 + momentum × 0.3 + sentiment × 0.2", "Directional signal agreement"],
                  ["Risk Adj", "100 − volatility × 0.5 − (100 − liquidity) × 0.5", "Execution safety score — higher = safer conditions"],
                  ["Market Health", "liquidity × 0.6 + (100 − volatility) × 0.4", "Asset-level tradability"],
                  ["Liquidity", "asset.liquidity_score (direct)", "Raw liquidity score from asset record"],
                ]}
              />
            </Sub>

            <Sub title="11.6 Reduce / Exit Handling">
              <Para>When <Code>action_classification</Code> is <Code>reduce_risk</Code> or <Code>exit_hedge</Code>, the projection switches to a capital protection mode — no position sizing or return projections are shown. Instead, a warning block is rendered showing quality score, RSI, and volatility context, explaining why protecting existing capital is prioritised over deploying new capital.</Para>
            </Sub>
          </Section>

          {/* ── 12. User Profile ── */}
          <Section id="user-profile" title="12. User Profile & Trader Preferences">
            <Para>
              The <Code>UserProfile</Code> entity stores trader-specific preferences that personalise the entire platform experience — including position guidance on every alert, investment projections, and the page-level <Code>InvestmentProjection</Code> panel.
            </Para>

            <Sub title="12.1 UserProfile Entity Fields">
              <Table
                headers={["Field", "Type", "Values", "Effect"]}
                rows={[
                  ["alias", "string", "Any text", "Shown in position guidance header (e.g. 'Alex's Position Guidance')"],
                  ["risk_appetite", "enum", "low / medium / high", "Sets base allocation ceiling and base return rate benchmark"],
                  ["invest_amount", "number", "£ available capital", "Capital pool for position sizing calculations"],
                  ["goal_amount", "number", "£ target", "Drives goal progress bar on every alert projection"],
                  ["timeline", "enum", "4_weeks / 3_months / 6_months / 1_year / long_term", "Compound period for projection calculations"],
                ]}
              />
              <Para>Profile is stored as a UserProfile entity record (one per user, created/updated via the Settings page ProfileCard component). Fetched via the <Code>useUserProfile</Code> hook which caches with TanStack Query.</Para>
            </Sub>

            <Sub title="12.2 InvestmentProjection (Alerts page panel)">
              <Para>A page-level summary panel at the top of the Alerts page showing overall portfolio projection based on the user's full capital and timeline — not signal-specific. Uses the same base return rates and timeline as individual alert projections but applies them to the entire invest_amount with conservative/base/optimistic scenarios and goal progress bar.</Para>
            </Sub>

            <Sub title="12.3 ProfileCard (Settings page)">
              <Para>Allows users to set or update all UserProfile fields. Changes are persisted immediately to the UserProfile entity and invalidate the <Code>useUserProfile</Code> query cache, refreshing all alert projections and the InvestmentProjection panel in real time.</Para>
            </Sub>
          </Section>

          {/* ── 13. Summaries ── */}
          <Section id="summaries" title="13. Automated Summarisation (generateSummaries)">
            <Para>Runs hourly via scheduled automation. Generates human-readable summaries for active recommended signals, viral signals, and alerts. Summaries are written back to the database and displayed in the UI.</Para>
            <Para>The summarisation function is strictly field-driven — it only reads existing entity fields and aggregates them into structured prose. It never speculates, never implies price targets beyond what is stored, and always appends a stale data warning if the source signal is more than 4 hours old.</Para>
            <Table
              headers={["Mode", "Source fields", "Written to"]}
              rows={[
                ["recommended", "direction, setup_type, opportunity_score, conviction_score, risk_score, entry_low, entry_high, invalidation, score_boost_factors, score_penalty_factors, confidence_note", "why_now"],
                ["viral", "viral_score, ai_label, move_state, liquidity_quality_score, crowding_score, exhaustion_score, viral_boost_factors, viral_penalty_factors, confidence_note", "summary"],
                ["alerts", "alert_type, severity, trigger_reason, action_classification, pnl_pct", "summary"],
              ]}
            />
            <Note>All summary prose is generated deterministically from stored fields. No LLM or AI model is used at summary generation time.</Note>
          </Section>

          {/* ── 14. Freshness ── */}
          <Section id="freshness" title="14. Data Freshness & Staleness">
            <Table
              headers={["Threshold", "Value", "Applied to"]}
              rows={[
                ["STALE_THRESHOLD_MS", "4 hours", "Signals, snapshots, alert engine"],
                ["PRICE_STALE_THRESHOLD_MS", "2 hours", "Portfolio holding live_price column"],
              ]}
            />
            <Para>When data is stale:</Para>
            <ul className="list-disc pl-5 space-y-1 text-sm text-foreground/80 mb-3">
              <li>Table rows dim to 55% opacity and show a STALE badge next to the asset name.</li>
              <li>Detail drawers show a full stale banner at the top.</li>
              <li>Confidence notes are replaced with a downgraded version: <em>"Data is Xh Ym old — confidence is reduced…"</em></li>
              <li>The alert engine skips stale signals entirely — no alerts are raised on old data.</li>
            </ul>
            <Para>Missing timestamps are always treated as stale.</Para>
          </Section>

          {/* ── 15. Portfolio ── */}
          <Section id="portfolio" title="15. Portfolio & Holdings">
            <Para>All P&amp;L calculations are performed client-side from stored fields. No backend calculation function exists for portfolio metrics.</Para>
            <FormulaBox>{`current_value   = quantity × live_price   (fallback: quantity × average_entry)
unrealised_pnl  = (live_price − average_entry) × quantity
allocation_pct  = current_value / total_holdings_value × 100

total_portfolio_value = Σ current_value (all holdings) + cash_balance`}</FormulaBox>
            <Para>Holdings also feed the alert engine: drawdowns of ≥10% and gains of ≥20% trigger alerts with the appropriate action classification.</Para>
          </Section>

          {/* ── 16. UI ── */}
          <Section id="ui" title="16. UI Surface & Display Logic">
            <Sub title="Score Colour Bands">
              <Table
                headers={["Score range (direct)", "Colour", "Meaning"]}
                rows={[
                  ["≥ 70", "Green (profit)", "Strong / favourable"],
                  ["45 – 69", "Yellow (warning)", "Moderate"],
                  ["< 45", "Red (loss)", "Weak / unfavourable"],
                ]}
              />
              <Para>Risk Score is inverted before colour assignment: a risk score of 80 displays as effective score 20 (red), because high risk is bad. Conviction score uses the same direct colour band as Opportunity.</Para>
            </Sub>

            <Sub title="Dashboard Sections">
              <Para><strong>Daily Recommended Trades:</strong> Filterable by direction, setup type, and minimum opportunity score. Sortable by opportunity_score or conviction_score. Table shows OPP, CONV, and RISK columns. Clicking a row opens the detail drawer.</Para>
              <Para><strong>Viral Trades:</strong> Sorted by viral_score descending. Always shows the virality disclaimer. Includes per-row score columns for all six viral metrics (viral, attention, vol spike, liquidity, crowd risk, exhaustion risk). Clicking a row opens the viral detail drawer.</Para>
              <Para><strong>Dashboard Alerts:</strong> Grouped by action_classification. Shows up to 4 alerts per group with a link to the full Alerts page.</Para>
              <Para><strong>Dashboard Market Pulse:</strong> Header stat bar showing count of active signals, viral signals, alerts, and holdings. Clicking navigates to the relevant page.</Para>
              <Para><strong>Today's Trading Brief:</strong> Collapsible action-first panel at the top of the dashboard. Shows market bias, portfolio warnings, top 3 ENTER NOW trades, top 3 risks, and early mover watch pills. See Section 16 sub-section for full detail.</Para>
              <Para><strong>Since Last Login:</strong> Slim strip below the dashboard header showing new signal/alert counts since the previous session. Hidden when nothing new has arrived. Powered by localStorage — no backend dependency.</Para>
            </Sub>

            <Sub title="Trade Reason Indicator">
              <Para>A compact pill shown in all signal table rows and a full explanatory block inside detail drawers. Derived from signal inputs via priority-ordered pattern matching — see Section 6 for full pattern table. Supports both recommended and viral signal shapes. On hover the pill shows the full description.</Para>
            </Sub>

            <Sub title="Detail Drawers — Recommended">
              <Para>Shows (in order): Signal Decision Output (Enter/Wait/Avoid/Reduce), Signal Time Expectation, Multi-Signal Alignment confidence tier, Opportunity/Conviction/Risk score chips, confidence note, Trade Reason Indicator block, key price levels (entry low/high, invalidation, T1, T2), £100 illustrative scenario (asset-specific, derived from live price + volatility if targets not stored), score explainability (boost + penalty factors), why now, what kills it, Signal Validation Panel, External Trade Links (Quick Actions), navigation links.</Para>
            </Sub>

            <Sub title="Detail Drawers — Viral">
              <Para>Shows (in order): asset name, market type, age/stale status, viral score, centralized signal disclaimer (<Code>SignalDisclaimer</Code> component with viral context), confidence note, all sub-scores (attention, volume spike, sentiment, liquidity, crowding risk, exhaustion risk), score explainability (boost + penalty factors), data quality warning (if partial data), raw input values with missing field audit, Trade Reason Indicator block, Signal Decision Output, Signal Time Expectation, Signal Validation Panel, External Trade Links, £100 move scenario (anchored to actual asset momentum), full summary, navigation links.</Para>
            </Sub>

            <Sub title="Alerts Page">
              <Para>Alerts are grouped by action_classification in priority order (exit_hedge first, then reduce_risk, act_now, prepare, watch). Each alert card shows severity dot, alert type tag, market type, trigger reason, P&amp;L if applicable, and dismiss/snooze controls. Active, snoozed, and dismissed alerts are accessible via tabs. Clicking an alert opens the <Code>AlertDetailDrawer</Code> with full metadata and navigation to the related signal or asset.</Para>
            </Sub>

            <Sub title="Assets Page">
              <Para>Lists all tracked assets with status (active / pending_data / inactive / error), market data availability (live snapshot vs. no snapshot), liquidity score, data provider badge, and a per-row refresh button. Includes a "Seed 60+ Assets" utility to bootstrap the universe and an "Add Asset" dialog with multi-provider search.</Para>
            </Sub>

            <Sub title="Recommended Trades Page (full page)">
              <Para>Extended view of all active recommended signals with additional filters: market type, minimum score, setup type, and sort by opportunity or conviction. Same drawer on click.</Para>
            </Sub>

            <Sub title="Viral Trades Page (full page)">
              <Para>Extended view of all active viral signals with filters for label (tradable / caution / avoid) and move state. Same drawer on click.</Para>
            </Sub>

            <Sub title="Today's Trading Brief (TodaysBrief — Dashboard, top panel)">
              <Para>A collapsible, action-first summary panel at the very top of the Dashboard — the first thing users see on load. Designed around four user questions: <em>What should I look at? What should I do? What should I avoid? What changed?</em></Para>
              <Table
                headers={["Section", "Content", "Data source"]}
                rows={[
                  ["Market Bias", "Bullish / Bearish / Mixed — derived from ratio of bullish vs bearish active recommended signals (≥65% bullish → Bullish; ≤35% → Bearish; otherwise Mixed)", "RecommendedTradeSignals (enriched)"],
                  ["Portfolio Warning", "Count of exit_hedge + reduce_risk alerts. Tappable — navigates to Alerts page.", "Alerts (active)"],
                  ["Top 3 ENTER NOW trades", "Highest-conviction signals where deriveDecision() = 'enter', sorted by opportunity_score. Each card shows asset, action reason from why_now, setup type, OPP score. Opens Recommended drawer on tap.", "RecommendedTradeSignals (enriched)"],
                  ["Top 3 Risks", "Highest-risk signals where decision = 'avoid' or 'reduce' (recommended), plus viral signals with ai_label = avoid or exhaustion > 65 AND crowding > 60. Opens appropriate drawer on tap.", "Both signal types (enriched)"],
                  ["Early Movers (Watch)", "Viral signals with ai_label = tradable AND move_state = early. Shown as quick-tap symbol pills. Max 5.", "ViralTradeSignals (enriched)"],
                ]}
              />
              <Para>The panel is collapsible (persists collapse state in component state). When collapsed, market bias and portfolio warning count are still visible in the header row.</Para>
              <Note>TodaysBrief performs no additional data fetches. All data (recommended, viral, alerts, holdings) is passed from the Dashboard parent component which already loads these via TanStack Query. Asset enrichment uses the shared assetMap derived from the allAssets query.</Note>
            </Sub>

            <Sub title="SinceLastLogin Strip (Dashboard, below header)">
              <Para>A slim contextual strip that surfaces what has changed since the user's previous visit. Appears only when new signals or alerts have arrived since the last session — hidden otherwise to avoid noise.</Para>
              <Table
                headers={["Mechanism", "Detail"]}
                rows={[
                  ["Last login timestamp", "Stored in localStorage (key: sniper_last_login) as ISO string on every page load. Previous value is read first, then overwritten."],
                  ["New signal detection", "Filters recommended, viral, and alert arrays by timestamp/triggered_at > lastLogin date. Counts displayed per type."],
                  ["Session count tracking", "Previous session's signal counts stored in localStorage (key: sniper_prev_counts) for delta comparison. Shown as +N delta badges."],
                  ["Visibility rule", "Strip is hidden if lastLogin is null (first visit) or if no new signals/alerts exist since last login."],
                ]}
              />
            </Sub>
          </Section>

          {/* ── 17. Automations ── */}
          <Section id="automations" title="17. Automations & Scheduling">
            <Table
              headers={["Automation", "Schedule", "Function", "Purpose"]}
              rows={[
                ["Alert Engine", "Every 30 minutes", "generateAlerts", "Evaluate signals and holdings against rules, write new alerts"],
                ["Summarisation", "Every 60 minutes", "generateSummaries", "Refresh prose summaries for all active signals and alerts"],
              ]}
            />
            <Para>Functions can also be triggered manually from the UI:</Para>
            <ul className="list-disc pl-5 space-y-1 text-sm text-foreground/80 mb-3">
              <li><strong>Alerts page</strong> → "Run Alert Engine" triggers <Code>generateAlerts</Code>.</li>
              <li><strong>Viral Trades page</strong> → "Recompute" triggers <Code>scoreViralTrades</Code>.</li>
              <li><strong>Recommended Trades page</strong> → "Recompute" triggers <Code>recomputeRecommendedTrades</Code>.</li>
              <li><strong>Assets page</strong> → per-row refresh icon triggers <Code>fetchAssetMarketData</Code> for a single asset.</li>
              <li><strong>Assets page</strong> → "Seed 60+ Assets" triggers <Code>seedAssets</Code> to bootstrap the asset universe.</li>
              <li><strong>Dashboard</strong> → a full pipeline refresh triggers <Code>refreshAll</Code> which runs: fetch all assets → recompute recommended → recompute viral → generate alerts, in sequence.</li>
            </ul>
          </Section>

          {/* ── 18. Constraints ── */}
          <Section id="constraints" title="18. Design Constraints & Integrity Rules">
            <ul className="list-disc pl-5 space-y-2 text-sm text-foreground/80">
              <li>The scoring engines never overwrite existing active signals — each run supersedes the previous record per asset and creates a fresh one. Stale pass happens before create to avoid orphaned records.</li>
              <li>Conviction score uses inputs directly (0–100 scale). There is no ×100 multiplier. The formula produces values in the 0–100 range naturally from weighted inputs.</li>
              <li>The alert engine deduplicates by composite key (<Code>alert_type::symbol::asset_id</Code>). The same alert cannot appear twice in the active queue.</li>
              <li>Viral signals never claim a direction or price target. They are explicitly capped to attention-measurement language and always carry a disclaimer.</li>
              <li>The summarisation function never invents data — it only aggregates already-stored entity fields into structured prose.</li>
              <li>No engine uses external AI or ML at runtime. All scoring is deterministic rule-based arithmetic.</li>
              <li>Stale data (<Code>&gt; 4h</Code> recommended, <Code>&gt; 6h</Code> viral) is visually flagged everywhere it appears. The alert engine skips stale signals entirely.</li>
              <li>All pages display a disclaimer: "Analysis only. Not financial advice."</li>
              <li>Neutral-direction assets (trend/momentum avg 42–58) are excluded from the recommended signal feed.</li>
              <li>Opportunity score below 52 → asset skipped. Viral score below 30 → asset skipped.</li>
              <li>The viral engine uses market-type-specific thresholds. A 5% 1h move is extraordinary for FX but ordinary for crypto. This prevents FX and index assets from being systematically mis-labelled.</li>
              <li>Holdings P&amp;L alerts downgrade severity by one level when the price used is stale, and append a warning note to the alert summary.</li>
              <li>The Trade Reason Indicator uses priority-ordered pattern matching from existing signal fields — no additional API calls or AI inference at render time. It degrades gracefully to "Momentum-Led" when no dominant pattern matches.</li>
              <li>CoinGecko's <Code>change_4h</Code> is rarely returned on the free tier. The engine derives it from <Code>change_24h / 4 + change_1h × 0.5</Code>. This is documented in raw_inputs.missing_fields on each viral signal.</li>
              <li>The refreshAll batch is capped at 25 CoinGecko assets per run to stay within the free-tier rate limit (~30 req/min with 1.3s delay). Assets beyond position 25 require a second run.</li>
              <li><Code>refreshAll</Code> uses the same full viral scoring pipeline as <Code>scoreViralTrades</Code> (market-type profiles, crowding, exhaustion, move state, AI label, explainability). A previous simplified block that bypassed this logic was replaced in v2.</li>
              <li><Code>attention_score_input</Code> (v2) uses a lower rank baseline (60/50/38/25) plus 1h momentum × 4, 24h change × 1.5, and volume/mcap ratio to differentiate assets. The previous v1 formula produced near-identical scores across all assets within the same rank tier.</li>
              <li>The five Signal Intelligence Components (Decision Output, Time Expectation, Multi-Signal Alignment, Validation Panel, External Trade Links) are all derived client-side from stored signal fields. No additional API calls are made at drawer render time.</li>
              <li>The £100 Viral Scenario is anchored to the asset's actual observed momentum from raw_inputs (change_4h → change_1h × 3 → change_24h / 2 fallback chain), then adjusted by exhaustion and crowding scores. It does not use hardcoded generic percentages. Fallback to volatility-scaled ranges only when no price change data exists.</li>
              <li>The £100 Recommended Scenario derives price targets from live price + volatility + risk_score + setup_type when stored targets are absent. This is disclosed in the drawer UI.</li>
              <li>Multi-Signal Alignment fetches the active viral signal for the same asset at drawer-open time via a filtered SDK query. This is the only live data fetch performed at UI render time.</li>
              <li><strong>DecisionBadge</strong> uses the same <Code>deriveDecision()</Code> function as SignalDecisionOutput — there is a single source of truth. The badge is a visual shorthand; the full decision block in the drawer is the authoritative output.</li>
              <li><strong>UrgencyTag</strong> maps directly from <Code>deriveTimeExpectation()</Code> — immediate → 🔥, short → ⏳, medium → 💤. It does not introduce new logic.</li>
              <li><strong>ConfidenceTier (A–D)</strong> has three hard-D override conditions: full_fallback data, ai_label=avoid, exhaustion ≥ 65. These bypass the composite score entirely. D always means "do not trade."</li>
              <li><strong>FailFastBlock</strong> is a hard rendering gate, not a warning. When active, action components (Decision Output, Time Expectation, Validation Panel, External Links) are not rendered at all — only the block message is shown. Score breakdown remains visible to explain the block.</li>
              <li><strong>SessionMode</strong> thresholds (Intraday: opp ≥ 60, risk ≤ 50, liq ≥ 55 / Swing: opp ≥ 50, risk ≤ 65, liq ≥ 40) apply to filtering only — they do not retroactively modify stored scores.</li>
              <li><strong>PortfolioRiskStrip</strong> metrics are computed entirely client-side from the dashboard holdings cache. No backend calls are made for these calculations.</li>
              <li><strong>AlertProfileProjection</strong> — every alert projection is unique. No two alerts with different market data will produce identical output. The 8-factor scoring engine ingests live snapshot data (RSI, 4h change, volume, volatility, trend, momentum, sentiment, catalyst) plus asset liquidity and market type. Position sizing uses a half-Kelly formula; return rates are benchmarked per market type (crypto vs FX vs commodity vs index) and scaled by quality confidence factor.</li>
              <li><strong>Alert enrichment</strong> attaches the full <Code>_snapshot</Code> (latest MarketSnapshot) and <Code>_asset</Code> records to every alert at render time. This is the foundation of all signal-specific projection calculations. If no snapshot exists for an asset, projections default to neutral market inputs and disclose this to the user.</li>
              <li><strong>UserProfile</strong> settings (alias, risk_appetite, invest_amount, goal_amount, timeline) are global inputs that scale all projections. They are never hardcoded into individual alerts — all projection logic reads from the live UserProfile record at render time. A change to the profile immediately affects all displayed projections without requiring a data refresh.</li>
              <li><strong>Market-type return rate benchmarks</strong> reflect genuine asset class behaviour differences. A high-risk crypto position is modelled at 80% p.a. illustrative base; the same risk appetite on an FX position uses 22% p.a. These are illustrative only — they reflect historical volatility profiles, not guaranteed returns.</li>
              <li><strong>TodaysBrief</strong> uses the same <Code>deriveDecision()</Code> function as DecisionBadge and SignalDecisionOutput — single source of truth for ENTER/WAIT/REDUCE/AVOID classification. It does not introduce a separate scoring pass. All data is inherited from the Dashboard query cache; no additional fetches are made.</li>
              <li><strong>TodaysBrief market bias</strong> is computed purely from the direction field on active RecommendedTradeSignals. It is a directional summary, not a forecast. Mixed is shown when bullish signals are between 35% and 65% of total — this is intentional, preventing false conviction on balanced markets.</li>
              <li><strong>TodaysBrief Top 3 Risks</strong> combines recommended signals (decision = avoid/reduce) and viral signals (ai_label = avoid OR exhaustion &gt; 65 AND crowding &gt; 60) into a unified risk list, sorted by the best available risk proxy score. Viral entries open the viral drawer; recommended entries open the recommended drawer.</li>
              <li><strong>SinceLastLogin</strong> uses localStorage only — no backend calls, no user data is stored server-side. The strip is completely stateless from the server's perspective and degrades gracefully (hidden) if localStorage is unavailable or cleared.</li>
              <li><strong>SinceLastLogin</strong> overwrites the stored timestamp on every page load (including refresh). This means the "since last login" window resets on each page load — it reflects changes since the previous tab/session open, not since a calendar-day login event.</li>
            </ul>
          </Section>

          {/* ── 19. Risk Disclosure & User Acknowledgment ── */}
          <Section id="risk-disclosure" title="19. Risk Disclosure & Regulatory Compliance">
            <Para>
              The platform implements three layers of risk friction to ensure user awareness before trading: an onboarding acknowledgment modal on first app load, centralized signal disclaimers in all detail drawers, and standardized disclaimers on all £100 illustrative scenarios.
            </Para>

            <Sub title="19.1 OnboardingAcknowledgment Modal">
              <Para>Displayed once per user (stored in localStorage). Users must explicitly acknowledge that they: (1) understand trading carries substantial risk of total loss, (2) assume all responsibility for trading decisions, (3) will not hold Sniper Terminal liable for losses, and (4) have read the Terms, Privacy Policy, and Risk Disclaimer pages. Until acknowledged, users cannot proceed to the app.</Para>
            </Sub>

            <Sub title="19.2 SignalDisclaimer Component">
              <Para>Centralized disclaimer rendered at the top of all signal detail drawers. Adapts its message based on <Code>signalType</Code> prop: "recommended", "viral", or "alert". Recommended drawers state "This is not financial advice." Viral drawers state "Virality measures attention, not trade quality. High scores may indicate overcrowded or late-stage moves." All versions include a footer: "Validate independently. Consult professionals before trading."</Para>
            </Sub>

            <Sub title="19.3 £100 Illustrative Scenario Disclaimers">
              <Para>Both Recommended and Viral scenarios display identical footer disclaimers stating: "Illustrative only. Not a recommendation or forecast. Based on model assumptions — not tailored financial advice. Conduct independent research and consult professionals before trading."</Para>
            </Sub>

            <Sub title="19.4 CookieConsent & Privacy">
              <Para>A persistent cookie consent banner at page bottom allows users to opt in/out of analytics and marketing tracking. Essential cookies are always enabled. Links to Privacy Policy, Terms of Service, and Risk Disclaimer are prominently displayed.</Para>
            </Sub>
          </Section>

          {/* Footer */}
          <div className="border-t border-border pt-6 mt-8">
            <p className="text-[10px] text-muted-foreground/40 leading-relaxed">
              Sniper Terminal — Internal Technical Reference. This document reflects the platform logic as of the date generated above. All scoring is deterministic and rule-based. All user communications emphasize risk and disclaim financial advice. Regulatory compliance via risk disclaimers, onboarding acknowledgment, and privacy controls.
            </p>
          </div>

        </div>
      </div>


    </div>
  );
}