import React from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center gap-3">
          <Link to="/" className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back</span>
          </Link>
          <h1 className="text-2xl font-bold">Terms of Service</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        <div className="text-xs text-muted-foreground/50 font-mono">
          Last updated: {new Date().toLocaleDateString("en-GB", { year: "numeric", month: "long", day: "numeric" })}
        </div>

        {/* 1. Acceptance of Terms */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">1. Acceptance of Terms</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            By accessing and using Sniper Terminal ("the App"), you agree to be bound by these Terms of Service ("Terms"). If you do not accept these Terms, you must not use the App. We reserve the right to modify these Terms at any time. Your continued use of the App constitutes acceptance of any changes.
          </p>
        </section>

        {/* 2. No Financial Advice */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">2. No Financial Advice</h2>
          <div className="bg-loss/10 border border-loss/30 rounded-lg px-4 py-3 space-y-2">
            <p className="text-sm font-bold text-loss/90">CRITICAL DISCLAIMER</p>
            <p className="text-sm text-foreground/80 leading-relaxed">
              The App provides <strong>market intelligence, structured analysis, and decision-support signals only</strong>. It does NOT constitute financial advice, investment advice, or a recommendation to buy, sell, or hold any asset. All content is provided for speculative and analytical purposes only.
            </p>
            <p className="text-sm text-foreground/80 leading-relaxed">
              You must not rely on the App to make financial decisions. The App is a tool for your own research and analysis — you are solely responsible for all trading and investment decisions. You agree to consult independent financial, tax, and legal professionals before trading any asset.
            </p>
          </div>
        </section>

        {/* 3. No Liability */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">3. Limitation of Liability</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            <strong>TO THE MAXIMUM EXTENT PERMITTED BY LAW:</strong>
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>The App is provided "AS IS" without warranties of any kind — express, implied, or statutory.</li>
            <li>We shall not be liable for any direct, indirect, incidental, special, or consequential damages arising from your use of or inability to use the App, including but not limited to trading losses, profit loss, data loss, or any other financial loss.</li>
            <li>This limitation applies even if we have been advised of the possibility of such damages.</li>
            <li>In jurisdictions that do not allow the exclusion of certain implied warranties, our liability is limited to the maximum extent permitted.</li>
          </ul>
        </section>

        {/* 4. Signals & Analysis */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">4. Signals, Analysis & Past Performance</h2>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li><strong>Past performance is not indicative of future results.</strong> Historical returns do not guarantee future profits.</li>
            <li>All signals, scores, and analysis are generated algorithmically and are not guaranteed to be accurate or profitable.</li>
            <li>Market conditions change rapidly. Signals may become stale or invalid without notice.</li>
            <li>You are responsible for independently verifying all data before acting on it.</li>
            <li>The App may contain errors, bugs, or incomplete data. We do not warrant the accuracy or completeness of any analysis.</li>
          </ul>
        </section>

        {/* 5. User Responsibilities */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">5. User Responsibilities</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            You agree to:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Use the App solely for lawful purposes and in accordance with all applicable laws and regulations.</li>
            <li>Not use the App to conduct any illegal or fraudulent activity.</li>
            <li>Maintain the confidentiality of your account credentials and notify us immediately of any unauthorized access.</li>
            <li>Not attempt to disrupt, damage, or compromise the security of the App or its infrastructure.</li>
            <li>Assume full responsibility for your trading and investment decisions.</li>
          </ul>
        </section>

        {/* 6. Risk Acknowledgment */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">6. Risk Acknowledgment</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            You acknowledge that:
          </p>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>Trading and investing in financial assets carries substantial risk of loss, including total loss of capital.</li>
            <li>You only trade money you can afford to lose entirely.</li>
            <li>Market conditions are unpredictable and volatile.</li>
            <li>The App's signals and analysis may lead to losses — we accept no responsibility for such losses.</li>
            <li>Leverage and derivatives increase risk exponentially.</li>
          </ul>
        </section>

        {/* 7. Data & Account */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">7. Account & Data</h2>
          <ul className="text-sm text-foreground/80 space-y-2 ml-4 list-disc">
            <li>You are responsible for the information you provide when registering an account.</li>
            <li>All data you provide must be accurate, complete, and up to date.</li>
            <li>We collect payment data through [Payment Provider — TBC]. See our Privacy Policy for details on data handling.</li>
            <li>We may suspend or terminate your account if we reasonably believe you are in breach of these Terms or applicable law.</li>
            <li>We retain the right to delete inactive accounts and associated data in accordance with our data retention policy.</li>
          </ul>
        </section>

        {/* 8. Intellectual Property */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">8. Intellectual Property</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            All content, design, algorithms, and materials in the App are the intellectual property of Sniper Terminal or its licensors. You may not copy, modify, distribute, or reverse-engineer any part of the App without written permission.
          </p>
        </section>

        {/* 9. Third-Party Links & Data */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">9. Third-Party Links & Data Sources</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App may link to or incorporate data from third parties (CoinGecko, DEX Screener, Yahoo Finance, Twelve Data, etc.). We do not endorse or guarantee the accuracy of third-party data. We are not responsible for the content, accuracy, or availability of external sites or APIs.
          </p>
        </section>

        {/* 10. Regulatory Compliance */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">10. Regulatory Compliance</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            The App is provided for analytical and research purposes in the UK, EU, and US. We do not execute trades, hold funds, or provide regulated financial services. Users are responsible for ensuring compliance with all regulations in their jurisdiction, including KYC/AML requirements, tax reporting, and financial conduct rules.
          </p>
        </section>

        {/* 11. Termination */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">11. Termination</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            We may terminate or suspend your access to the App at any time, with or without cause, and without notice or liability to you.
          </p>
        </section>

        {/* 12. Governing Law */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">12. Governing Law & Jurisdiction</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            These Terms are governed by the laws of [Jurisdiction — TBC]. Any legal action or proceeding arising under these Terms shall be brought exclusively in [Jurisdiction — TBC] courts.
          </p>
        </section>

        {/* 13. Contact */}
        <section className="space-y-3">
          <h2 className="text-xl font-bold">13. Contact</h2>
          <p className="text-sm text-foreground/80 leading-relaxed">
            For questions or concerns regarding these Terms, please contact:
          </p>
          <div className="bg-secondary/20 border border-border rounded-lg px-4 py-3 text-sm font-mono space-y-1">
            <div>Legal: <span className="text-primary">[legal@sniperterminal.com — TBC]</span></div>
            <div>Support: <span className="text-primary">[support@sniperterminal.com — TBC]</span></div>
            <div>Address: <span className="text-primary">[Company Address — TBC]</span></div>
          </div>
        </section>

        <div className="border-t border-border pt-6 mt-8">
          <p className="text-[10px] text-muted-foreground/40 leading-relaxed">
            By using Sniper Terminal, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service in their entirety. If you do not agree, do not use the App.
          </p>
        </div>
      </div>
    </div>
  );
}