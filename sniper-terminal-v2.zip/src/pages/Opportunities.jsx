import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Crosshair } from "lucide-react";
import RecommendedTrades from "../components/dashboard/RecommendedTrades";
import TradeDetailDrawer from "../components/drilldown/TradeDetailDrawer";

export default function Opportunities() {
  const [selectedTrade, setSelectedTrade] = useState(null);

  const { data: signals } = useQuery({
    queryKey: ["allOpportunities"],
    queryFn: () => base44.entities.OpportunitySignals.list("-opportunity_score", 100),
    initialData: [],
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
          <Crosshair className="w-5 h-5 text-primary" /> Opportunities
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          Quality-ranked trade setups — analysis only, conditions may change rapidly
        </p>
      </div>
      <RecommendedTrades signals={signals} onSelectTrade={setSelectedTrade} />
      <TradeDetailDrawer trade={selectedTrade} onClose={() => setSelectedTrade(null)} />
    </div>
  );
}