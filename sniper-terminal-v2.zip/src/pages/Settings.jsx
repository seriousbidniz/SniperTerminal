import React, { useState } from "react";
import { Settings as SettingsIcon, Shield, LogOut } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import MobileHeader from "@/components/layout/MobileHeader";
import ProfileCard from "@/components/profile/ProfileCard";
import NotificationsCard from "@/components/settings/NotificationsCard";
import BrokerConnectionsCard from "@/components/settings/BrokerConnectionsCard";
import LiveDataStatusCard from "@/components/settings/LiveDataStatusCard";
import { useUserSettings } from "@/hooks/useUserSettings";

export default function Settings() {
  const { settings, save } = useUserSettings();
  const [signingOut, setSigningOut] = useState(false);

  return (
    <div className="space-y-4 max-w-2xl">
      <MobileHeader icon={SettingsIcon} title="Settings" subtitle="Alerts, accounts and risk" />
      <div className="hidden md:block">
        <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
          <SettingsIcon className="w-5 h-5 text-primary" /> Settings
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">Alerts, accounts and risk</p>
      </div>

      <LiveDataStatusCard />
      <NotificationsCard />

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2"><Shield className="w-4 h-4" /> Position sizing</CardTitle>
          <CardDescription className="text-xs">Used to pre-fill the quantity on every order ticket</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between gap-3">
            <Label className="text-xs">Risk per trade (if the stop is hit)</Label>
            <Select value={String(settings.risk_per_trade_pct)} onValueChange={(v) => save({ risk_per_trade_pct: Number(v) })}>
              <SelectTrigger className="h-7 w-[90px] text-xs"><SelectValue /></SelectTrigger>
              <SelectContent className="text-xs">
                {[0.25, 0.5, 1, 1.5, 2, 3].map((n) => <SelectItem key={n} value={String(n)}>{n}%</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <p className="text-[11px] text-muted-foreground">Percentage of the amount you invest (set in your profile below). Quantity = risk ÷ distance from entry to invalidation, capped at your full amount.</p>
        </CardContent>
      </Card>

      <BrokerConnectionsCard />
      <ProfileCard />

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-sm">Account</CardTitle>
          <CardDescription className="text-xs">To have your account and data deleted, contact the app owner. Removing a broker connection above deletes its stored keys immediately.</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="outline" size="sm" className="text-xs" disabled={signingOut}
            onClick={async () => { setSigningOut(true); await base44.auth.logout("/"); }}>
            <LogOut className="w-3.5 h-3.5 mr-1.5" /> Sign out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
