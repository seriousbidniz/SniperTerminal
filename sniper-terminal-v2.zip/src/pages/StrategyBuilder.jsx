import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Wrench, Plus, Trash2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import EmptyState from "../components/shared/EmptyState";

const ruleFields = [
  { value: "price_change_24h", label: "Price Change 24h (%)" },
  { value: "volume_change", label: "Volume Change (%)" },
  { value: "rsi", label: "RSI" },
  { value: "atr", label: "ATR" },
  { value: "trend_state", label: "Trend State" },
  { value: "market_cap", label: "Market Cap ($)" },
  { value: "liquidity_score", label: "Liquidity Score" },
  { value: "sentiment_score", label: "Sentiment Score" },
  { value: "opportunity_score", label: "Opportunity Score" },
  { value: "viral_score", label: "Viral Score" },
  { value: "catalyst_type", label: "Catalyst Type" },
];

const operators = ["greater_than", "less_than", "equals", "between"];

export default function StrategyBuilder() {
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [rules, setRules] = useState([{ field: "opportunity_score", operator: "greater_than", value: "70" }]);

  const queryClient = useQueryClient();

  const { data: strategies } = useQuery({
    queryKey: ["strategies"],
    queryFn: () => base44.entities.StrategyTemplates.list("-created_date", 50),
    initialData: [],
  });

  const createStrategy = useMutation({
    mutationFn: (data) => base44.entities.StrategyTemplates.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["strategies"] }); setShowNew(false); setName(""); setDesc(""); setRules([{ field: "opportunity_score", operator: "greater_than", value: "70" }]); },
  });

  const deleteStrategy = useMutation({
    mutationFn: (id) => base44.entities.StrategyTemplates.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["strategies"] }),
  });

  const addRule = () => setRules([...rules, { field: "price_change_24h", operator: "greater_than", value: "" }]);
  const removeRule = (i) => setRules(rules.filter((_, idx) => idx !== i));
  const updateRule = (i, key, val) => {
    const updated = [...rules];
    updated[i] = { ...updated[i], [key]: val };
    setRules(updated);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <Wrench className="w-5 h-5 text-primary" /> Strategy Builder
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Create custom screening and alert strategies</p>
        </div>
        <Button size="sm" className="text-xs" onClick={() => setShowNew(true)}>
          <Plus className="w-3 h-3 mr-1" /> New Strategy
        </Button>
      </div>

      {strategies.length === 0 ? (
        <EmptyState icon={Wrench} title="No strategies yet" description="Build a custom strategy to find trades matching your criteria." />
      ) : (
        <div className="space-y-2">
          {strategies.map(s => {
            let parsedRules = [];
            try { parsedRules = JSON.parse(s.rules || "[]"); } catch {}
            return (
              <div key={s.id} className="bg-card border border-border rounded-lg px-4 py-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-semibold">{s.name}</p>
                    {s.description && <p className="text-xs text-muted-foreground mt-0.5">{s.description}</p>}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {parsedRules.map((r, i) => (
                        <span key={i} className="text-[10px] bg-secondary text-muted-foreground px-2 py-0.5 rounded font-mono">
                          {r.field} {r.operator?.replace(/_/g, " ")} {r.value}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                      {s.last_run && <span>Last run: {new Date(s.last_run).toLocaleString()}</span>}
                      <span>{s.match_count || 0} matches</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteStrategy.mutate(s.id)}>
                      <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showNew} onOpenChange={setShowNew}>
        <DialogContent className="bg-card border-border max-w-lg">
          <DialogHeader><DialogTitle>New Strategy</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Strategy name" value={name} onChange={e => setName(e.target.value)} className="bg-secondary/50" />
            <Textarea placeholder="Description (optional)" value={desc} onChange={e => setDesc(e.target.value)} className="bg-secondary/50 h-16" />

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold">Rules</span>
                <Button variant="outline" size="sm" className="text-xs h-6" onClick={addRule}>
                  <Plus className="w-3 h-3 mr-1" /> Add Rule
                </Button>
              </div>
              {rules.map((rule, i) => (
                <div key={i} className="flex items-center gap-2">
                  <Select value={rule.field} onValueChange={v => updateRule(i, "field", v)}>
                    <SelectTrigger className="h-7 text-xs bg-secondary/50 flex-1"><SelectValue /></SelectTrigger>
                    <SelectContent>{ruleFields.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent>
                  </Select>
                  <Select value={rule.operator} onValueChange={v => updateRule(i, "operator", v)}>
                    <SelectTrigger className="h-7 text-xs bg-secondary/50 w-28"><SelectValue /></SelectTrigger>
                    <SelectContent>{operators.map(o => <SelectItem key={o} value={o}>{o.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input placeholder="Value" value={rule.value} onChange={e => updateRule(i, "value", e.target.value)} className="h-7 text-xs bg-secondary/50 w-20" />
                  {rules.length > 1 && (
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => removeRule(i)}>
                      <Trash2 className="w-3 h-3 text-muted-foreground" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNew(false)}>Cancel</Button>
            <Button onClick={() => createStrategy.mutate({ name, description: desc, rules: JSON.stringify(rules) })} disabled={!name.trim()}>
              <Save className="w-3 h-3 mr-1" /> Save Strategy
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}