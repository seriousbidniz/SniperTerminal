// ─────────────────────────────────────────────────────────────────────────────
// Technical indicators — pure functions, no I/O.
// Shared by Base44 backend functions (Deno) and the realtime worker (Node).
// Every function returns an array the same length as its input, with `null`
// for bars where the indicator is not yet defined (warm-up period).
// ─────────────────────────────────────────────────────────────────────────────

export function sma(values, period) {
  const out = new Array(values.length).fill(null);
  let sum = 0;
  let count = 0;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    sum += v;
    count++;
    if (count > period) sum -= values[i - period];
    if (count >= period) out[i] = sum / period;
  }
  return out;
}

// EMA seeded with the SMA of the first `period` values (standard convention).
export function ema(values, period) {
  const out = new Array(values.length).fill(null);
  if (values.length < period) return out;
  const k = 2 / (period + 1);
  let seed = 0;
  for (let i = 0; i < period; i++) seed += values[i];
  let prev = seed / period;
  out[period - 1] = prev;
  for (let i = period; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

// Wilder's RSI.
export function rsi(closes, period = 14) {
  const out = new Array(closes.length).fill(null);
  if (closes.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

// Wilder's Average True Range.
export function atr(highs, lows, closes, period = 14) {
  const n = closes.length;
  const out = new Array(n).fill(null);
  if (n <= period) return out;
  const tr = new Array(n).fill(0);
  tr[0] = highs[0] - lows[0];
  for (let i = 1; i < n; i++) {
    tr[i] = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1]),
    );
  }
  let prev = 0;
  for (let i = 1; i <= period; i++) prev += tr[i];
  prev /= period;
  out[period] = prev;
  for (let i = period + 1; i < n; i++) {
    prev = (prev * (period - 1) + tr[i]) / period;
    out[i] = prev;
  }
  return out;
}

export function stdev(values, period) {
  const out = new Array(values.length).fill(null);
  for (let i = period - 1; i < values.length; i++) {
    let mean = 0;
    for (let j = i - period + 1; j <= i; j++) mean += values[j];
    mean /= period;
    let v = 0;
    for (let j = i - period + 1; j <= i; j++) v += (values[j] - mean) ** 2;
    out[i] = Math.sqrt(v / period);
  }
  return out;
}

export function bollinger(closes, period = 20, mult = 2) {
  const mid = sma(closes, period);
  const sd = stdev(closes, period);
  const upper = mid.map((m, i) => (m == null ? null : m + mult * sd[i]));
  const lower = mid.map((m, i) => (m == null ? null : m - mult * sd[i]));
  const width = mid.map((m, i) => (m == null || m === 0 ? null : (upper[i] - lower[i]) / m));
  return { mid, upper, lower, width };
}

// Donchian channel built from the PREVIOUS `period` bars (excludes bar i),
// so a close above upper[i] is a genuine breakout of the prior range.
export function donchian(highs, lows, period = 20) {
  const n = highs.length;
  const upper = new Array(n).fill(null);
  const lower = new Array(n).fill(null);
  for (let i = period; i < n; i++) {
    let hi = -Infinity;
    let lo = Infinity;
    for (let j = i - period; j < i; j++) {
      if (highs[j] > hi) hi = highs[j];
      if (lows[j] < lo) lo = lows[j];
    }
    upper[i] = hi;
    lower[i] = lo;
  }
  return { upper, lower };
}

export function macd(closes, fast = 12, slow = 26, signalPeriod = 9) {
  const f = ema(closes, fast);
  const s = ema(closes, slow);
  const line = closes.map((_, i) => (f[i] == null || s[i] == null ? null : f[i] - s[i]));
  const firstIdx = line.findIndex((v) => v != null);
  const signal = new Array(closes.length).fill(null);
  if (firstIdx >= 0) {
    const sub = ema(line.slice(firstIdx), signalPeriod);
    for (let i = 0; i < sub.length; i++) signal[firstIdx + i] = sub[i];
  }
  const hist = line.map((v, i) => (v == null || signal[i] == null ? null : v - signal[i]));
  return { line, signal, hist };
}

// Rolling percentile rank of value[i] within the trailing window (0–100).
export function percentRank(values, period) {
  const out = new Array(values.length).fill(null);
  for (let i = 0; i < values.length; i++) {
    if (values[i] == null) continue;
    const start = Math.max(0, i - period + 1);
    let below = 0;
    let total = 0;
    for (let j = start; j <= i; j++) {
      if (values[j] == null) continue;
      total++;
      if (values[j] <= values[i]) below++;
    }
    if (total >= Math.min(period, 30)) out[i] = (below / total) * 100;
  }
  return out;
}

/**
 * Pre-compute every series the signal engine needs, once per candle set.
 * candles: ascending [{ t, o, h, l, c, v }] — t is the bar OPEN time in ms.
 */
export function computeSeries(candles) {
  const o = candles.map((c) => c.o);
  const h = candles.map((c) => c.h);
  const l = candles.map((c) => c.l);
  const c = candles.map((c) => c.c);
  const v = candles.map((c) => (c.v == null || Number.isNaN(c.v) ? 0 : c.v));
  const hasVolume = v.some((x) => x > 0);
  const bb = bollinger(c, 20, 2);
  const dc = donchian(h, l, 20);
  const m = macd(c);
  return {
    candles, o, h, l, c, v, hasVolume,
    ema20: ema(c, 20),
    ema50: ema(c, 50),
    ema200: ema(c, 200),
    sma5: sma(c, 5),
    sma200: sma(c, 200),
    rsi14: rsi(c, 14),
    rsi2: rsi(c, 2),
    atr14: atr(h, l, c, 14),
    bbWidth: bb.width,
    bbWidthRank: percentRank(bb.width, 120),
    dcUpper: dc.upper,
    dcLower: dc.lower,
    macdHist: m.hist,
    volSma20: sma(v, 20),
  };
}
