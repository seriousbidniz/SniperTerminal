// ─────────────────────────────────────────────────────────────────────────────
// Signal engine
//
// Detects a small set of long-documented technical setups on CLOSED 1h candles,
// attaches concrete trade levels (entry zone, invalidation, targets) sized off
// ATR, scores them, and gives every signal a hard expiry.
//
// "Learning" works through calibration: calibrateSetups replays this exact
// engine bar-by-bar over historical candles (no look-ahead), records how each
// setup actually resolved, and blends that with live signal outcomes. Those
// statistics feed back into opportunity score, confidence and expiry here.
// Until a setup has enough samples it is treated as having NO edge (expected
// R = 0) — the engine never assumes a pattern works because it is famous.
// ─────────────────────────────────────────────────────────────────────────────
import { percentRank } from "./indicators.js";
import { roundPrice } from "./symbols.js";

export const TIMEFRAME = "1h";
export const BAR_MS = 60 * 60 * 1000;
export const ACTIVE_THRESHOLD = 52;
export const MIN_CALIBRATION_SAMPLES = 30;

// Default horizons/targets per setup. `origin` is shown to users so they can
// read up on the pattern themselves.
export const SETUPS = {
  bullish_breakout: {
    direction: "bullish", horizonBars: 24, entryWindowBars: 4, t1R: 1.5, t2R: 3.0,
    origin: "20-bar Donchian channel breakout (the Turtle traders' entry rule), filtered by the 50 EMA",
  },
  bearish_breakdown: {
    direction: "bearish", horizonBars: 24, entryWindowBars: 4, t1R: 1.5, t2R: 3.0,
    origin: "20-bar Donchian channel breakdown (Turtle-style), filtered by the 50 EMA",
  },
  bullish_pullback: {
    direction: "bullish", horizonBars: 36, entryWindowBars: 6, t1R: 1.5, t2R: 2.5,
    origin: "Trend pullback to the 20 EMA inside a 20/50(/200) EMA uptrend",
  },
  bearish_pullback_failure: {
    direction: "bearish", horizonBars: 36, entryWindowBars: 6, t1R: 1.5, t2R: 2.5,
    origin: "Failed rally into the 20 EMA inside a 20/50(/200) EMA downtrend",
  },
  bullish_continuation: {
    direction: "bullish", horizonBars: 24, entryWindowBars: 3, t1R: 1.2, t2R: 2.0,
    origin: "Momentum continuation: rising MACD histogram above the 20/50 EMAs",
  },
  bearish_continuation: {
    direction: "bearish", horizonBars: 24, entryWindowBars: 3, t1R: 1.2, t2R: 2.0,
    origin: "Momentum continuation: falling MACD histogram below the 20/50 EMAs",
  },
  reversal: {
    direction: null, horizonBars: 12, entryWindowBars: 2, t1R: 1.0, t2R: 1.8,
    origin: "RSI(2) extreme mean reversion with a 200-period trend filter (popularised by Larry Connors)",
  },
};

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const pct = (a, b) => (a == null || b == null || b === 0 ? null : ((a - b) / b) * 100);
const r1 = (v) => (v == null ? null : Math.round(v * 10) / 10);

export function calibrationKey(setupType, direction, marketType) {
  // Reversal is direction-agnostic in the enum, so key it by direction too.
  const s = setupType === "reversal" ? `reversal_${direction}` : setupType;
  return `${s}|${marketType || "crypto"}`;
}

// Extra per-candle series the engine needs on top of computeSeries().
export function enrichSeries(S) {
  if (S.atrPctRank) return S;
  const atrPct = S.atr14.map((a, i) => (a == null || !S.c[i] ? null : (a / S.c[i]) * 100));
  S.atrPct = atrPct;
  S.atrPctRank = percentRank(atrPct, 120);
  return S;
}

function trendScore(S, i, dir) {
  const c = S.c[i], e20 = S.ema20[i], e50 = S.ema50[i], e200 = S.ema200[i];
  const e50Prev = S.ema50[i - 5];
  const sgn = dir === "bullish" ? 1 : -1;
  let s = 0;
  if (sgn * (c - e20) > 0) s += 20;
  if (sgn * (e20 - e50) > 0) s += 25;
  if (e200 == null) s += 10;
  else {
    if (sgn * (e50 - e200) > 0) s += 25;
    if (sgn * (c - e200) > 0) s += 10;
  }
  if (e50Prev != null && sgn * (e50 - e50Prev) > 0) s += 20;
  return clamp(s);
}

function momentumScore(S, i, dir) {
  const h = S.macdHist[i], hp = S.macdHist[i - 1], r = S.rsi14[i];
  const sgn = dir === "bullish" ? 1 : -1;
  let s = 0;
  if (h != null && sgn * h > 0) s += 40;
  if (h != null && hp != null && sgn * (h - hp) > 0) s += 20;
  if (r != null) {
    const rr = dir === "bullish" ? r : 100 - r; // mirror for shorts
    if (rr >= 50 && rr <= 70) s += 40;
    else if (rr >= 40 && rr < 50) s += 20;
    else if (rr > 70 && rr <= 78) s += 15;
    else if (rr > 78) s += 5;
  }
  return clamp(s);
}

function volumeRatio(S, i) {
  if (!S.hasVolume) return null;
  const base = S.volSma20[i - 1];
  if (!base) return null;
  return S.v[i] / base;
}

/** Market snapshot fields at bar i (kept compatible with MarketSnapshots). */
export function snapshotAt(S, i) {
  enrichSeries(S);
  const c = S.c[i];
  let vol24 = 0;
  for (let j = Math.max(0, i - 23); j <= i; j++) vol24 += S.v[j] || 0;
  const vr = volumeRatio(S, i);
  const bull = (trendScore(S, i, "bullish") - trendScore(S, i, "bearish")) / 2 + 50;
  const mom = (momentumScore(S, i, "bullish") - momentumScore(S, i, "bearish")) / 2 + 50;
  const change1h = pct(c, S.c[i - 1]);
  // "Attention" here is a MARKET-ACTIVITY PROXY (volume surge + speed of move),
  // not social/search data. The app has no social data feed.
  let activity = 50;
  if (vr != null) activity += (vr - 1) * 25;
  if (change1h != null) activity += Math.min(Math.abs(change1h) / Math.max(S.atrPct[i] || 1, 0.05), 4) * 6;
  return {
    price: c,
    change_1h: r1(change1h),
    change_4h: r1(pct(c, S.c[i - 4])),
    change_24h: r1(pct(c, S.c[i - 24])),
    volume: S.hasVolume ? Math.round(vol24) : null,
    volume_change_percent: vr == null ? null : r1((vr - 1) * 100),
    volatility: S.atrPctRank[i] == null ? null : Math.round(S.atrPctRank[i]),
    rsi: S.rsi14[i] == null ? null : r1(S.rsi14[i]),
    trend_score_input: Math.round(clamp(bull)),
    momentum_score_input: Math.round(clamp(mom)),
    attention_score_input: Math.round(clamp(activity, 5, 95)),
    sentiment_score_input: null,
    catalyst_score_input: null,
    atr: S.atr14[i],
  };
}

function candidateLevels(S, i) {
  const c = S.c[i];
  const atr = S.atr14[i];
  const e20 = S.ema20[i], e50 = S.ema50[i], e200 = S.ema200[i];
  const out = [];
  const lowN = (n) => Math.min(...S.l.slice(Math.max(0, i - n + 1), i + 1));
  const highN = (n) => Math.max(...S.h.slice(Math.max(0, i - n + 1), i + 1));

  // 1. Donchian breakout / breakdown
  if (S.dcUpper[i] != null && c > S.dcUpper[i] && c > e50) {
    const lvl = S.dcUpper[i];
    out.push({ setup: "bullish_breakout", direction: "bullish", entryLow: lvl, entryHigh: c + 0.25 * atr, invalidation: lvl - atr });
  }
  if (S.dcLower[i] != null && c < S.dcLower[i] && c < e50) {
    const lvl = S.dcLower[i];
    out.push({ setup: "bearish_breakdown", direction: "bearish", entryLow: c - 0.25 * atr, entryHigh: lvl, invalidation: lvl + atr });
  }

  // 2. Trend pullback to the 20 EMA
  const up = e20 > e50 && (e200 == null || e50 > e200);
  const down = e20 < e50 && (e200 == null || e50 < e200);
  const r14 = S.rsi14[i];
  if (up && lowN(3) <= e20 + 0.25 * atr && c > e50 && r14 != null && r14 >= 38 && r14 <= 58) {
    const inv = Math.min(e50, lowN(10)) - 0.25 * atr;
    out.push({ setup: "bullish_pullback", direction: "bullish", entryLow: e20 - 0.25 * atr, entryHigh: e20 + 0.25 * atr, invalidation: inv });
  }
  if (down && highN(3) >= e20 - 0.25 * atr && c < e50 && r14 != null && r14 >= 42 && r14 <= 62) {
    const inv = Math.max(e50, highN(10)) + 0.25 * atr;
    out.push({ setup: "bearish_pullback_failure", direction: "bearish", entryLow: e20 - 0.25 * atr, entryHigh: e20 + 0.25 * atr, invalidation: inv });
  }

  // 3. Momentum continuation
  const h = S.macdHist[i], hp = S.macdHist[i - 1];
  if (h != null && hp != null && r14 != null) {
    if (e20 > e50 && c > e20 && h > 0 && h > hp && r14 > 55 && r14 < 72) {
      out.push({ setup: "bullish_continuation", direction: "bullish", entryLow: c - 0.5 * atr, entryHigh: c, invalidation: c - 2 * atr });
    }
    if (e20 < e50 && c < e20 && h < 0 && h < hp && r14 < 45 && r14 > 28) {
      out.push({ setup: "bearish_continuation", direction: "bearish", entryLow: c, entryHigh: c + 0.5 * atr, invalidation: c + 2 * atr });
    }
  }

  // 4. RSI(2) mean reversion with a 200-period trend filter
  const r2 = S.rsi2[i], s200 = S.sma200[i];
  if (r2 != null && s200 != null) {
    if (c > s200 && r2 < 10) {
      out.push({ setup: "reversal", direction: "bullish", entryLow: c - 0.25 * atr, entryHigh: c + 0.1 * atr, invalidation: c - 2 * atr, meanTarget: S.sma5[i] });
    }
    if (c < s200 && r2 > 90) {
      out.push({ setup: "reversal", direction: "bearish", entryLow: c - 0.1 * atr, entryHigh: c + 0.25 * atr, invalidation: c + 2 * atr, meanTarget: S.sma5[i] });
    }
  }
  return out;
}

function edgeFromCalibration(cal, t1R) {
  // With no evidence, assume the breakeven win rate → expected R of zero.
  const breakeven = 1 / (1 + t1R);
  if (!cal || !(cal.n_effective > 0)) {
    return { p: breakeven, expectedR: 0, nEff: 0, medianBars: null, source: "uncalibrated" };
  }
  const p = cal.win_rate ?? breakeven;
  const expectedR = cal.expectancy_r != null ? cal.expectancy_r : p * t1R - (1 - p);
  return { p, expectedR, nEff: cal.n_effective, medianBars: cal.median_bars_to_resolution ?? null, source: cal.source || "calibrated" };
}

/**
 * Analyse bar i (must be a CLOSED bar). Returns the best qualifying signal or
 * null. `calibrations` is a map keyed by calibrationKey().
 */
export function analyzeAt(S, i, asset, calibrations = {}) {
  enrichSeries(S);
  if (i < 60 || S.atr14[i] == null || S.ema50[i] == null || S.ema20[i] == null) return null;
  const atr = S.atr14[i];
  const c = S.c[i];
  const marketType = asset.market_type || "crypto";
  const liq = asset.liquidity_score ?? 50;
  const vr = volumeRatio(S, i);
  const volRank = S.atrPctRank[i] ?? 50;
  const squeeze = S.bbWidthRank[i - 1] != null && S.bbWidthRank[i - 1] < 30;

  let best = null;
  for (const cand of candidateLevels(S, i)) {
    const def = SETUPS[cand.setup];
    const dir = cand.direction;
    const sgn = dir === "bullish" ? 1 : -1;
    const entryLow = Math.min(cand.entryLow, cand.entryHigh);
    const entryHigh = Math.max(cand.entryLow, cand.entryHigh);
    const entryMid = (entryLow + entryHigh) / 2;
    const R = sgn * (entryMid - cand.invalidation);
    if (!(R > 0.3 * atr) || R > 4.5 * atr) continue; // stop too tight or too wide
    // Invalidation must sit outside the entry zone.
    if (dir === "bullish" && cand.invalidation >= entryLow) continue;
    if (dir === "bearish" && cand.invalidation <= entryHigh) continue;

    const cal = calibrations[calibrationKey(cand.setup, dir, marketType)];
    const edge = edgeFromCalibration(cal, def.t1R);

    let target1 = entryMid + sgn * def.t1R * R;
    if (cand.setup === "reversal" && cand.meanTarget != null && sgn * (cand.meanTarget - entryMid) > R) {
      target1 = cand.meanTarget; // mean-reversion target when it is further than 1R
    }
    const target2 = entryMid + sgn * def.t2R * R;

    // ── Scores ───────────────────────────────────────────────────────────────
    const trend = cand.setup === "reversal"
      ? clamp((sgn * (c - S.sma200[i]) > 0 ? 60 : 0) + (S.ema200[i] != null && sgn * (S.ema50[i] - S.ema200[i]) > 0 ? 40 : 0))
      : trendScore(S, i, dir);
    const momentum = cand.setup === "reversal"
      ? clamp(dir === "bullish" ? (10 - S.rsi2[i]) * 10 : (S.rsi2[i] - 90) * 10)
      : momentumScore(S, i, dir);
    const volume = vr == null ? 50 : clamp(40 + (vr - 1) * 40);
    const volRegime = clamp(100 - Math.abs(volRank - 50) * 1.2);
    let quality = trend * 0.3 + momentum * 0.25 + volume * 0.15 + clamp(liq) * 0.15 + volRegime * 0.15;
    if (squeeze && (cand.setup === "bullish_breakout" || cand.setup === "bearish_breakdown")) quality += 5;

    const edgeScore = clamp(50 + edge.expectedR * 60);
    const w = Math.min(0.5, edge.nEff / 200);
    let opportunity = quality * (1 - w) + edgeScore * w;
    const r14 = S.rsi14[i];
    if (r14 != null && cand.setup !== "reversal") {
      if (dir === "bullish" && r14 > 80) opportunity *= 0.8;
      if (dir === "bearish" && r14 < 20) opportunity *= 0.8;
    }
    opportunity = Math.round(clamp(opportunity));

    let rsiRisk = 0;
    if (r14 != null) rsiRisk = r14 > 80 || r14 < 20 ? 35 : r14 > 70 || r14 < 30 ? 15 : 0;
    const risk = Math.round(clamp(volRank * 0.45 + (100 - clamp(liq)) * 0.35 + rsiRisk * 0.2));

    const confirmations = [
      trend >= 60,
      momentum >= 60,
      vr != null && vr >= 1.2,
      edge.nEff >= MIN_CALIBRATION_SAMPLES && edge.expectedR > 0,
      squeeze || cand.setup === "bullish_pullback" || cand.setup === "bearish_pullback_failure",
      liq >= 60,
    ];
    const conviction = Math.round((confirmations.filter(Boolean).length / confirmations.length) * 100);

    if (!best || opportunity > best.opportunity_score) {
      best = {
        cand, def, edge, dir, entryLow, entryHigh, entryMid, R, target1, target2,
        trend, momentum, volume, vr, volRank, squeeze, liq,
        opportunity_score: opportunity, risk_score: risk, conviction_score: conviction,
      };
    }
  }
  if (!best) return null;

  // ── Horizon / expiry ───────────────────────────────────────────────────────
  const { def, edge } = best;
  let horizonBars = def.horizonBars;
  if (edge.nEff >= MIN_CALIBRATION_SAMPLES && edge.medianBars) {
    horizonBars = Math.round(Math.max(4, Math.min(96, edge.medianBars * 1.5)));
  }
  const barClose = S.candles[i].t + BAR_MS;
  const expiresAt = new Date(barClose + horizonBars * BAR_MS).toISOString();

  return buildSignalRecord(best, S, i, asset, horizonBars, expiresAt);
}

function buildSignalRecord(b, S, i, asset, horizonBars, expiresAt) {
  const mt = asset.market_type || "crypto";
  const rp = (x) => roundPrice(x, mt);
  const { cand, def, edge, dir } = b;

  const boosters = [];
  const reducers = [];
  if (b.trend >= 60) boosters.push(`trend structure aligned (${Math.round(b.trend)})`);
  if (b.momentum >= 60) boosters.push(`momentum confirming (${Math.round(b.momentum)})`);
  if (b.vr != null && b.vr >= 1.2) boosters.push(`volume ${b.vr.toFixed(1)}× the 20-bar average`);
  if (b.squeeze && cand.setup.includes("break")) boosters.push("breakout out of a volatility squeeze");
  if (edge.nEff >= MIN_CALIBRATION_SAMPLES && edge.expectedR > 0) {
    boosters.push(`historical edge: ${(edge.p * 100).toFixed(0)}% hit rate, ${edge.expectedR.toFixed(2)}R expectancy over ${Math.round(edge.nEff)} samples`);
  }
  if (b.trend < 45) reducers.push(`weak trend alignment (${Math.round(b.trend)})`);
  if (b.vr != null && b.vr < 0.8) reducers.push("below-average volume");
  if (b.volRank > 85) reducers.push(`volatility in the top ${Math.round(100 - b.volRank)}% of the last 120 bars`);
  if (b.liq < 40) reducers.push(`thin liquidity (${Math.round(b.liq)}) — slippage risk`);
  if (edge.nEff < MIN_CALIBRATION_SAMPLES) reducers.push("setup not yet calibrated — no proven edge assumed");
  else if (edge.expectedR <= 0) reducers.push(`historical expectancy is ${edge.expectedR.toFixed(2)}R for this setup`);

  const rr = def.t1R;
  const confidence =
    edge.nEff < MIN_CALIBRATION_SAMPLES
      ? "Uncalibrated: levels are rule-based but this setup has fewer than 30 resolved samples, so no edge is assumed."
      : edge.expectedR > 0.2 && b.risk_score < 55
        ? `Calibrated edge: ${(edge.p * 100).toFixed(0)}% of ${Math.round(edge.nEff)} comparable signals reached Target 1 before invalidation.`
        : edge.expectedR > 0
          ? `Marginal edge: ${edge.expectedR.toFixed(2)}R expectancy historically — size down.`
          : "Negative or zero historical expectancy — treat as watch-only.";

  return {
    direction: dir,
    setup_type: cand.setup,
    timeframe: "1h",
    entry_low: rp(b.entryLow),
    entry_high: rp(b.entryHigh),
    invalidation: rp(cand.invalidation),
    target_1: rp(b.target1),
    target_2: rp(b.target2),
    risk_reward_ratio: Math.round((Math.abs(b.target1 - b.entryMid) / b.R) * 100) / 100,
    atr: S.atr14[i],
    price_at_signal: S.c[i],
    generated_bar_time: new Date(S.candles[i].t).toISOString(),
    last_eval_bar_time: new Date(S.candles[i].t).toISOString(),
    expires_at: expiresAt,
    horizon_hours: horizonBars,
    entry_window_hours: def.entryWindowBars,
    opportunity_score: b.opportunity_score,
    risk_score: b.risk_score,
    conviction_score: b.conviction_score,
    trend_score_input: Math.round(b.trend),
    momentum_score_input: Math.round(b.momentum),
    catalyst_score_input: null,
    liquidity_score: b.liq,
    calibration_source: edge.source,
    calibration_samples: Math.round(edge.nEff),
    calibrated_win_rate: edge.nEff > 0 ? Math.round(edge.p * 1000) / 10 : null,
    expected_r: edge.nEff > 0 ? Math.round(edge.expectedR * 100) / 100 : null,
    pattern_origin: def.origin,
    why_now: boosters.length ? `Score driven by: ${boosters.join(", ")}.` : "Setup triggered on rule criteria with no strong confirming factors.",
    what_kills_it: `A ${dir === "bullish" ? "trade below" : "trade above"} ${rp(cand.invalidation)} invalidates the setup. ${reducers.length ? `Watch: ${reducers.join("; ")}.` : ""}`.trim(),
    score_boost_factors: boosters.length ? `${boosters.join("; ")}.` : "No dominant score boosters.",
    score_penalty_factors: reducers.length ? `${reducers.join("; ")}.` : "No significant penalties applied.",
    confidence_note: confidence,
    score_explanation: JSON.stringify({
      engine: "v2",
      inputs: {
        trend: Math.round(b.trend), momentum: Math.round(b.momentum), volume: Math.round(b.volume),
        liquidity: Math.round(b.liq), volatility_rank: Math.round(b.volRank), rsi14: S.rsi14[i] == null ? null : r1(S.rsi14[i]),
        atr: S.atr14[i],
      },
      calibration: { source: edge.source, samples: Math.round(edge.nEff), win_rate: edge.p, expected_r: edge.expectedR },
      boosters, reducers, reward_to_risk_t1: rr,
      opportunity: b.opportunity_score, risk: b.risk_score,
    }),
  };
}

// ─── Viral signals ───────────────────────────────────────────────────────────
// Same scoring model as the original app (kept for continuity), now fed by
// real candle-derived inputs, plus a direction, invalidation and expiry.
const VIRAL_PROFILES = {
  crypto:    { crowding: { p1h_high: 8, p1h_mid: 4, p4h_high: 15, p4h_mid: 8 }, exhaustion: { p1h_extreme: 12, p1h_high: 7, p1h_mid: 4 }, early_viral: 45 },
  fx:        { crowding: { p1h_high: 0.6, p1h_mid: 0.25, p4h_high: 1.2, p4h_mid: 0.5 }, exhaustion: { p1h_extreme: 1.0, p1h_high: 0.6, p1h_mid: 0.3 }, early_viral: 40 },
  commodity: { crowding: { p1h_high: 2.0, p1h_mid: 0.8, p4h_high: 4.0, p4h_mid: 2.0 }, exhaustion: { p1h_extreme: 3.5, p1h_high: 2.0, p1h_mid: 1.0 }, early_viral: 40 },
  index:     { crowding: { p1h_high: 1.5, p1h_mid: 0.6, p4h_high: 3.0, p4h_mid: 1.5 }, exhaustion: { p1h_extreme: 2.5, p1h_high: 1.5, p1h_mid: 0.7 }, early_viral: 40 },
};
const VIRAL_EXPIRY_HOURS = { early: 12, building: 8, crowded: 4, exhausted: 2 };

export function analyzeViral(snap, S, i, asset) {
  const mt = asset.market_type || "crypto";
  const prof = VIRAL_PROFILES[mt] || VIRAL_PROFILES.crypto;
  const liq = asset.liquidity_score ?? 50;
  if (snap.change_1h == null || snap.change_4h == null) return null;

  const attention = clamp(snap.attention_score_input ?? 50);
  const volScore = clamp((Math.abs(snap.volume_change_percent ?? 0) / 200) * 100);
  const scale = (p) => clamp((Math.abs(p) / 50) * 100);
  // Rescale moves by asset volatility so FX/indices are comparable to crypto.
  const atrPct = S.atrPct?.[i] || 1;
  const norm1h = (snap.change_1h / Math.max(atrPct, 0.05)) * 2;
  const norm4h = (snap.change_4h / Math.max(atrPct, 0.05)) * 1;
  const priceAccel = scale(norm1h) * 0.65 + scale(norm4h) * 0.35;
  const viral = Math.round(clamp(attention * 0.4 + volScore * 0.35 + priceAccel * 0.25));
  if (viral < 30) return null;

  const p1h = Math.abs(snap.change_1h), p4h = Math.abs(snap.change_4h);
  const vol = snap.volatility ?? 50;
  let crowding = 0;
  if (p1h > prof.crowding.p1h_high) crowding += 30; else if (p1h > prof.crowding.p1h_mid) crowding += 15;
  if (p4h > prof.crowding.p4h_high) crowding += 25; else if (p4h > prof.crowding.p4h_mid) crowding += 12;
  if (vol > 85) crowding += 20; else if (vol > 65) crowding += 10;
  const r14 = snap.rsi;
  if (r14 != null && (r14 > 75 || r14 < 25)) crowding += 15;
  crowding = clamp(Math.round(crowding));

  let exhaustion = 0;
  if (p1h > prof.exhaustion.p1h_extreme) exhaustion += 35; else if (p1h > prof.exhaustion.p1h_high) exhaustion += 18; else if (p1h > prof.exhaustion.p1h_mid) exhaustion += 8;
  if (vol > 90) exhaustion += 25; else if (vol > 75) exhaustion += 12;
  if (attention > 75 && liq < 40) exhaustion += 25; else if (attention > 60 && liq < 40) exhaustion += 12;
  if (r14 != null && (r14 > 82 || r14 < 18)) exhaustion += 15;
  exhaustion = clamp(Math.round(exhaustion));

  let state = "building";
  if (exhaustion >= 60) state = "exhausted";
  else if (crowding >= 55) state = "crowded";
  else if (viral >= prof.early_viral && crowding < 35 && exhaustion < 35) state = "early";

  let label = "caution";
  if (liq < 25 || state === "exhausted" || exhaustion >= 65) label = "avoid";
  else if (state === "crowded" && liq < 50) label = "avoid";
  else if ((state === "early" || state === "building") && liq >= 50 && exhaustion < 40 && crowding < 35) label = "tradable";

  const direction = snap.change_4h >= 0 ? "bullish" : "bearish";
  const atr = S.atr14[i];
  const lows = S.l.slice(Math.max(0, i - 3), i + 1);
  const highs = S.h.slice(Math.max(0, i - 3), i + 1);
  const invalidation = direction === "bullish" ? Math.min(...lows) - 0.5 * atr : Math.max(...highs) + 0.5 * atr;
  const hours = VIRAL_EXPIRY_HOURS[state];
  const barClose = S.candles[i].t + BAR_MS;

  const parts = [];
  if (snap.volume_change_percent != null && Math.abs(snap.volume_change_percent) > 30) parts.push(`volume ${Math.round(snap.volume_change_percent)}% vs 20-bar average`);
  if (Math.abs(snap.change_1h) >= prof.crowding.p1h_mid) parts.push(`${snap.change_1h > 0 ? "+" : ""}${snap.change_1h}% in the last hour`);
  if (Math.abs(snap.change_4h) >= prof.crowding.p4h_mid) parts.push(`${snap.change_4h > 0 ? "+" : ""}${snap.change_4h}% over 4 hours`);
  const stateNote = { exhausted: "Move appears exhausted.", crowded: "Crowded — late-entry risk elevated.", building: "Momentum building.", early: "Early-stage move." }[state];
  const labelNote = { avoid: "Labelled avoid.", caution: "Caution — size down.", tradable: "Tradable: acceptable liquidity and low exhaustion." }[label];

  return {
    viral_score: viral,
    attention_score: Math.round(attention),
    volume_spike_score: Math.round(volScore),
    sentiment_spike_score: null,
    liquidity_quality_score: Math.round(clamp(liq)),
    crowding_score: crowding,
    exhaustion_score: exhaustion,
    move_state: state,
    ai_label: label,
    direction,
    invalidation: roundPrice(invalidation, mt),
    price_at_signal: S.c[i],
    atr,
    expires_at: new Date(barClose + hours * BAR_MS).toISOString(),
    horizon_hours: hours,
    generated_bar_time: new Date(S.candles[i].t).toISOString(),
    summary: `${asset.symbol} is moving unusually${parts.length ? ` — ${parts.join(", ")}` : ""}. ${stateNote} ${labelNote}`,
    viral_boost_factors: parts.length ? `${parts.join(" and ")} increased the viral score.` : "Mild aggregate activity.",
    viral_penalty_factors: crowding >= 35 ? `Crowding ${crowding} and liquidity ${Math.round(clamp(liq))} reduced tradability.` : "No significant penalties.",
    confidence_note: "Activity score uses volume and price-speed proxies; the app has no social-media data feed.",
    score_explanation: JSON.stringify({ engine: "v2", viral_score: viral, crowding_score: crowding, exhaustion_score: exhaustion, inputs: { activity: attention, volume_change_pct: snap.volume_change_percent, change_1h: snap.change_1h, change_4h: snap.change_4h, volatility_rank: vol, liquidity: Math.round(clamp(liq)) } }),
    data_quality: "live",
    data_confidence: S.hasVolume ? 90 : 70,
    raw_inputs: JSON.stringify({ change_1h: snap.change_1h, change_4h: snap.change_4h, volume_change_percent: snap.volume_change_percent, attention_score_input: snap.attention_score_input, liquidity_score: liq, volatility: snap.volatility, rsi: snap.rsi, missing_fields: S.hasVolume ? [] : ["volume"] }),
  };
}
