// Symbol mapping between the Asset Universe and external venues/data sources.

// Binance re-tickered some assets. MATIC migrated to POL on Binance spot in 2024.
// If a mapping is wrong the stream simply returns nothing and the app falls back
// to the last REST snapshot, so an error here degrades gracefully.
const BINANCE_BASE_OVERRIDES = { MATIC: "POL" };

export function binanceBase(asset) {
  if (!asset || asset.market_type !== "crypto") return null;
  const sym = String(asset.provider_symbol || asset.symbol || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (!sym) return null;
  return BINANCE_BASE_OVERRIDES[sym] || sym;
}

export function binancePair(asset, quote = "USDT") {
  const base = binanceBase(asset);
  return base ? `${base}${quote}` : null;
}

export const YAHOO_SYMBOL_MAP = {
  SPX: "^GSPC", SP500: "^GSPC", NDX: "^NDX", NASDAQ: "^IXIC",
  DJI: "^DJI", DOW: "^DJI", FTSE: "^FTSE", DAX: "^GDAXI",
  NKY: "^N225", HSI: "^HSI", VIX: "^VIX", CAC40: "^FCHI", RUT: "^RUT",
  GOLD: "GC=F", XAU: "GC=F", "XAU/USD": "GC=F", XAUUSD: "GC=F",
  SILVER: "SI=F", XAG: "SI=F", "XAG/USD": "SI=F", XAGUSD: "SI=F",
  OIL: "CL=F", WTI: "CL=F", USOIL: "CL=F", "WTI/USD": "CL=F", WTIUSD: "CL=F",
  BRENT: "BZ=F", UKOIL: "BZ=F", BRENTUSD: "BZ=F", "BRENT/USD": "BZ=F",
  NATGAS: "NG=F", "NATGAS/USD": "NG=F",
  COPPER: "HG=F", "COPPER/USD": "HG=F",
  PLATINUM: "PL=F", "XPT/USD": "PL=F", PALLADIUM: "PA=F",
  WHEAT: "ZW=F", CORN: "ZC=F",
};

export function yahooSymbol(asset) {
  if (!asset) return null;
  if (asset.market_type === "crypto") {
    const base = String(asset.symbol || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    return base ? `${base}-USD` : null;
  }
  const candidates = [asset.provider_symbol, asset.provider_asset_id, asset.symbol]
    .filter(Boolean)
    .map((s) => String(s).toUpperCase());
  for (const c of candidates) if (YAHOO_SYMBOL_MAP[c]) return YAHOO_SYMBOL_MAP[c];
  for (const c of candidates) {
    // Plain FX pair, e.g. EUR/USD → EURUSD=X. Only for 3+3 letter currency codes.
    if (/^[A-Z]{3}\/[A-Z]{3}$/.test(c)) return c.replace("/", "") + "=X";
  }
  return null;
}

// TradingView exchange-prefixed ticker (TradingView's "EXCHANGE:SYMBOL" format).
const TV_INDEX_MAP = {
  SPX: "SP:SPX", NDX: "NASDAQ:NDX", DJI: "DJ:DJI", VIX: "VIX",
  FTSE: "FTSE:UKX", DAX: "XETR:DAX", NKY: "TVC:NI225", HSI: "TVC:HSI",
};
const TV_COMMODITY_MAP = {
  XAUUSD: "OANDA:XAUUSD", XAGUSD: "OANDA:XAGUSD", WTIUSD: "TVC:USOIL",
  BRENTUSD: "TVC:UKOIL", NATGAS: "NYMEX:NG1!", COPPER: "COMEX:HG1!",
};

export function tradingViewSymbol(asset) {
  if (!asset?.symbol) return null;
  const sym = String(asset.symbol).toUpperCase();
  if (asset.market_type === "crypto") {
    const pair = binancePair(asset);
    return pair ? `BINANCE:${pair}` : null;
  }
  if (asset.market_type === "fx") return `FX:${sym.replace("/", "")}`;
  if (asset.market_type === "index") return TV_INDEX_MAP[sym] || sym;
  if (asset.market_type === "commodity") return TV_COMMODITY_MAP[sym] || sym;
  return sym;
}

// Price precision appropriate to the instrument and magnitude.
export function priceDecimals(price, marketType) {
  if (price == null || !Number.isFinite(price)) return 2;
  const p = Math.abs(price);
  if (marketType === "fx") return p >= 20 ? 3 : 5;
  if (p >= 1000) return 2;
  if (p >= 1) return 4;
  if (p >= 0.01) return 6;
  return 8;
}

export function roundPrice(price, marketType) {
  if (price == null || !Number.isFinite(price)) return null;
  const d = priceDecimals(price, marketType);
  return Number(price.toFixed(d));
}
