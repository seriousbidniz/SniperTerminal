// HMAC-SHA256 request signing between the realtime worker and Base44.
// WebCrypto only, so it runs unchanged in Deno (Base44) and Node 20+ (worker).
const enc = new TextEncoder();
export const SIGNATURE_HEADER = "x-st-signature";
export const TIMESTAMP_HEADER = "x-st-timestamp";
export const MAX_SKEW_MS = 60_000;

async function hmacKey(secret) {
  return crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (hex) => new Uint8Array((hex.match(/.{1,2}/g) || []).map((h) => parseInt(h, 16)));

export async function signBody(secret, body, timestamp = Date.now()) {
  const key = await hmacKey(secret);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(`${timestamp}.${body}`));
  return { timestamp: String(timestamp), signature: toHex(sig) };
}

export async function verifyBody(secret, body, timestamp, signature, nowMs = Date.now()) {
  if (!secret || !timestamp || !signature) return false;
  const ts = Number(timestamp);
  if (!Number.isFinite(ts) || Math.abs(nowMs - ts) > MAX_SKEW_MS) return false;
  if (!/^[0-9a-f]{64}$/i.test(signature)) return false;
  const key = await hmacKey(secret);
  // crypto.subtle.verify is constant-time.
  return crypto.subtle.verify("HMAC", key, fromHex(signature), enc.encode(`${timestamp}.${body}`));
}
