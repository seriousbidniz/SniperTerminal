// AES-256-GCM envelope for broker API secrets at rest.
// Key: 32 random bytes, base64-encoded, stored ONLY as a secret
// (BROKER_ENCRYPTION_KEY) in Base44 and in the worker's environment.
// Format: "v1:<iv base64>:<ciphertext+tag base64>"
const enc = new TextEncoder();
const dec = new TextDecoder();

function b64encode(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}
function b64decode(str) {
  const s = atob(str);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

async function importKey(keyB64) {
  if (!keyB64) throw new Error("BROKER_ENCRYPTION_KEY is not configured");
  const raw = b64decode(keyB64);
  if (raw.length !== 32) throw new Error("BROKER_ENCRYPTION_KEY must decode to exactly 32 bytes");
  return crypto.subtle.importKey("raw", raw, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

export async function encryptSecret(keyB64, plaintext) {
  const key = await importKey(keyB64);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(plaintext));
  return `v1:${b64encode(iv)}:${b64encode(new Uint8Array(ct))}`;
}

export async function decryptSecret(keyB64, envelope) {
  const [v, ivB64, ctB64] = String(envelope || "").split(":");
  if (v !== "v1" || !ivB64 || !ctB64) throw new Error("Unrecognised secret envelope");
  const key = await importKey(keyB64);
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64decode(ivB64) }, key, b64decode(ctB64));
  return dec.decode(pt);
}
