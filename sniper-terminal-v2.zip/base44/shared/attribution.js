// ─────────────────────────────────────────────────────────────────────────────
// Attribution: which signals did a user actually trade, and how did it go?
//
// Inputs are broker fills (read-only sync). Matching rules, in order:
//   - An opposite-side fill on an asset with an OPEN execution closes it (FIFO).
//   - Otherwise a fill opens an execution if a signal on the same asset and
//     direction (buy↔bullish, sell↔bearish) was live at the fill time
//     (between signal creation and expiry + 2h grace).
//   - "high" confidence when the fill price is inside the entry zone ± 0.5 ATR,
//     "low" otherwise. Low-confidence matches are still tracked but flagged,
//     and excluded from the headline win rate.
//   - Fills matching nothing are kept as "unmatched" (manual trades).
// P&L uses quote-currency fees only when the commission was charged in the
// quote or base asset; fees paid in a third asset (e.g. BNB) are flagged.
// ─────────────────────────────────────────────────────────────────────────────
const GRACE_MS = 2 * 3600_000;
const EPS = 1e-9;

export function parseBinanceSymbol(symbol, quotes = ["USDT", "USDC", "FDUSD", "BUSD", "BTC", "ETH", "EUR"]) {
  for (const q of quotes) if (symbol.endsWith(q) && symbol.length > q.length) return { base: symbol.slice(0, -q.length), quote: q };
  return { base: symbol, quote: "" };
}

function feeInQuote(fill) {
  const ca = (fill.commission_asset || "").toUpperCase();
  if (!fill.commission) return { fee: 0, partial: false };
  if (ca === fill.quote_asset) return { fee: fill.commission, partial: false };
  if (ca === fill.base_asset) return { fee: fill.commission * fill.price, partial: false };
  return { fee: 0, partial: true };
}

function signalWindow(sig) {
  const start = new Date(sig.timestamp).getTime();
  const end = sig.expires_at ? new Date(sig.expires_at).getTime() + GRACE_MS : start + 72 * 3600_000;
  return [start, end];
}

export function matchEntrySignal(fill, candidates) {
  const t = new Date(fill.executed_at).getTime();
  const wantDir = fill.side === "buy" ? "bullish" : "bearish";
  let best = null;
  for (const sig of candidates) {
    if (sig.direction !== wantDir) continue;
    const [s, e] = signalWindow(sig);
    if (t < s || t > e) continue;
    const tol = 0.5 * (sig.atr || 0);
    const low = sig.entry_low ?? sig.entry_price ?? sig.price_at_signal;
    const high = sig.entry_high ?? sig.entry_price ?? sig.price_at_signal;
    const inZone = low != null && high != null && fill.price >= low - tol && fill.price <= high + tol;
    const score = (inZone ? 1e12 : 0) - Math.abs(t - s);
    if (!best || score > best.score) best = { sig, score, confidence: inZone ? "high" : "low" };
  }
  return best;
}

/**
 * fills: new fills for ONE user, any order.
 * openExecutions: that user's executions with status "open".
 * signalsByBase: { BASE: [signals...] } — recommended + viral, any status,
 *   each tagged with `kind`.
 * Returns { fillPatches, executionCreates, executionUpdates }.
 */
export function attributeFills(fills, openExecutions, signalsByBase, userEmail) {
  const sorted = [...fills].sort((a, b) => new Date(a.executed_at) - new Date(b.executed_at));
  const open = openExecutions.map((e) => ({ ...e, _dirty: false }));
  const creates = [];
  const fillPatches = [];

  for (const f of sorted) {
    const { fee, partial } = feeInQuote(f);
    // 1. Close/reduce an open execution on the opposite side.
    const closer = [...open, ...creates].find((e) => e.base_asset === f.base_asset && e.status === "open" &&
      ((e.direction === "bullish" && f.side === "sell") || (e.direction === "bearish" && f.side === "buy")));
    if (closer) {
      const qty = Math.min(f.qty, closer.open_qty);
      closer.exit_qty = (closer.exit_qty || 0) + qty;
      closer.exit_notional = (closer.exit_notional || 0) + qty * f.price;
      closer.fees = (closer.fees || 0) + fee * (qty / f.qty);
      closer.fees_partial = closer.fees_partial || partial;
      closer.open_qty -= qty;
      closer.exit_fill_ids = [...(closer.exit_fill_ids || []), f.external_trade_id];
      if (closer.open_qty <= EPS || closer.open_qty / closer.qty < 0.01) finalize(closer, f.executed_at);
      closer._dirty = true;
      fillPatches.push({ external_trade_id: f.external_trade_id, matched_signal_id: closer.signal_id, match_type: "signal_exit", match_confidence: closer.match_confidence });
      continue;
    }
    // 2. Open (or add to) an execution for a matching live signal.
    const m = matchEntrySignal(f, signalsByBase[f.base_asset] || []);
    if (!m) {
      fillPatches.push({ external_trade_id: f.external_trade_id, matched_signal_id: null, match_type: "unmatched", match_confidence: null });
      continue;
    }
    let ex = open.find((e) => e.signal_id === m.sig.id && e.status === "open") || creates.find((e) => e.signal_id === m.sig.id && e.status === "open");
    if (!ex) {
      ex = {
        user_email: userEmail, signal_id: m.sig.id, signal_kind: m.sig.kind, asset_id: m.sig.asset,
        base_asset: f.base_asset, quote_asset: f.quote_asset, asset_symbol: f.base_asset,
        direction: m.sig.direction, setup_type: m.sig.setup_type || "viral", invalidation: m.sig.invalidation,
        qty: 0, open_qty: 0, entry_notional: 0, fees: 0, fees_partial: false,
        opened_at: f.executed_at, status: "open", source: "broker_sync",
        match_confidence: m.confidence, entry_fill_ids: [],
      };
      creates.push(ex);
    }
    ex.qty += f.qty;
    ex.open_qty += f.qty;
    ex.entry_notional += f.qty * f.price;
    ex.avg_entry = ex.entry_notional / ex.qty;
    ex.fees += fee;
    ex.fees_partial = ex.fees_partial || partial;
    ex.entry_fill_ids = [...(ex.entry_fill_ids || []), f.external_trade_id];
    if (m.confidence === "low") ex.match_confidence = "low";
    ex._dirty = true;
    fillPatches.push({ external_trade_id: f.external_trade_id, matched_signal_id: m.sig.id, match_type: "signal_entry", match_confidence: m.confidence });
  }

  const strip = ({ _dirty, ...rest }) => rest;
  return {
    fillPatches,
    executionCreates: creates.map(strip),
    executionUpdates: open.filter((e) => e._dirty).map(strip),
  };
}

function finalize(ex, closedAt) {
  const closedQty = ex.exit_qty;
  const entryCost = (ex.avg_entry ?? ex.entry_notional / ex.qty) * closedQty;
  const gross = ex.direction === "bullish" ? ex.exit_notional - entryCost : entryCost - ex.exit_notional;
  const pnl = gross - (ex.fees || 0);
  const avgExit = ex.exit_notional / closedQty;
  const riskPerUnit = ex.invalidation != null ? Math.abs(ex.avg_entry - ex.invalidation) : null;
  ex.avg_exit = avgExit;
  ex.realised_pnl = Math.round(pnl * 1e6) / 1e6;
  ex.r_multiple = riskPerUnit ? Math.round((pnl / (riskPerUnit * closedQty)) * 100) / 100 : null;
  ex.outcome = Math.abs(ex.r_multiple ?? (pnl / entryCost) * 20) < 0.05 ? "breakeven" : pnl > 0 ? "win" : "loss";
  ex.status = "closed";
  ex.open_qty = 0;
  ex.closed_at = closedAt;
}

/** Headline stats for a user's executions. */
export function performanceStats(executions) {
  const closed = executions.filter((e) => e.status === "closed");
  const hi = closed.filter((e) => e.match_confidence === "high");
  const decided = hi.filter((e) => e.outcome === "win" || e.outcome === "loss");
  const wins = decided.filter((e) => e.outcome === "win").length;
  const rs = hi.map((e) => e.r_multiple).filter((r) => r != null);
  const bySetup = {};
  for (const e of hi) {
    const k = `${e.setup_type}|${e.direction}`;
    const b = (bySetup[k] ||= { setup_type: e.setup_type, direction: e.direction, n: 0, wins: 0, losses: 0, sum_r: 0, pnl: 0 });
    b.n++;
    if (e.outcome === "win") b.wins++;
    if (e.outcome === "loss") b.losses++;
    b.sum_r += e.r_multiple ?? 0;
    b.pnl += e.realised_pnl ?? 0;
  }
  return {
    executed: executions.length,
    open: executions.filter((e) => e.status === "open").length,
    closed: closed.length,
    closed_high_confidence: hi.length,
    wins,
    losses: decided.length - wins,
    breakeven: hi.filter((e) => e.outcome === "breakeven").length,
    win_rate: decided.length ? wins / decided.length : null,
    avg_r: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : null,
    total_pnl: hi.reduce((a, e) => a + (e.realised_pnl || 0), 0),
    fees_partial: hi.some((e) => e.fees_partial),
    by_setup: Object.values(bySetup).map((b) => ({ ...b, win_rate: b.wins + b.losses ? b.wins / (b.wins + b.losses) : null, avg_r: b.n ? b.sum_r / b.n : null })),
  };
}
