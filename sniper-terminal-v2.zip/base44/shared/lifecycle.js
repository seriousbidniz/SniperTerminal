// ─────────────────────────────────────────────────────────────────────────────
// Signal lifecycle — the single source of truth for how a signal moves through
//   active → triggered → target_hit → closed
//          ↘ invalidated            ↘ expired
// Used by: the realtime worker (1m candles, tick-level), the refresh pipeline
// (1h candles, for markets without a stream) and the backtester. Same rules
// everywhere, so live outcomes and backtest statistics are comparable.
//
// Conservative conventions (they bias results DOWN, never up):
//  - If invalidation and a target are both touched inside one bar, it's a loss.
//  - Entry fill is the worst price inside the entry zone unless the bar opened
//    inside the zone.
// ─────────────────────────────────────────────────────────────────────────────

const HOUR_MS = 3600_000;
export const LIVE_STATUSES = ["active", "triggered", "target_hit"];
export const TERMINAL_STATUSES = ["invalidated", "expired", "closed", "superseded"];

const ms = (iso) => (iso ? new Date(iso).getTime() : null);

export function rMultiple(direction, entry, invalidation, exitPrice) {
  const risk = direction === "bullish" ? entry - invalidation : invalidation - entry;
  if (!(risk > 0)) return null;
  const move = direction === "bullish" ? exitPrice - entry : entry - exitPrice;
  return Math.round((move / risk) * 100) / 100;
}

function fillPrice(sig, bar) {
  if (bar.o >= sig.entry_low && bar.o <= sig.entry_high) return bar.o;
  return sig.direction === "bullish" ? sig.entry_high : sig.entry_low;
}

/**
 * Evaluate one OHLC bar against a signal.
 * bar: { t (open ms), o, h, l, c, closeTime (ms, optional) }
 * kind: "recommended" | "viral"
 * Returns { events: [...], patch: {...} } — patch is the entity update.
 */
export function evaluateBar(signal, bar, kind = "recommended", nowMs = Date.now()) {
  const events = [];
  const patch = {};
  const s = { ...signal };
  if (!s.direction || s.invalidation == null) return { events, patch };
  if (TERMINAL_STATUSES.includes(s.status)) return { events, patch };

  const bull = s.direction === "bullish";
  const barTime = bar.closeTime ?? bar.t + HOUR_MS;
  const at = new Date(Math.min(barTime, nowMs)).toISOString();
  const touchedInvalidation = bull ? bar.l <= s.invalidation : bar.h >= s.invalidation;
  const touches = (level) => level != null && (bull ? bar.h >= level : bar.l <= level);

  const emit = (type, price, extra = {}) => events.push({ type, at, price, ...extra });

  // Viral signals have no entry zone: they are "in play" from creation.
  if (kind === "viral" && !s.entry_price) {
    s.entry_price = s.price_at_signal;
    patch.entry_price = s.entry_price;
  }

  const genMs = ms(s.timestamp) ?? ms(s.generated_bar_time) ?? nowMs;
  const entryDeadline = s.entry_window_hours ? genMs + s.entry_window_hours * HOUR_MS : null;

  // ── Waiting for entry ──────────────────────────────────────────────────────
  if (kind === "recommended" && s.status === "active") {
    const inZone = bar.l <= s.entry_high && bar.h >= s.entry_low;
    if (touchedInvalidation && !inZone) {
      Object.assign(patch, { status: "invalidated", invalidated_at: at, outcome: "invalidated_untriggered", outcome_r: null, closed_at: at });
      emit("invalidated", s.invalidation, { before_entry: true });
      return { events, patch };
    }
    if (inZone) {
      const fill = fillPrice(s, bar);
      Object.assign(patch, { status: "triggered", entry_triggered_at: at, entry_price: fill });
      s.status = "triggered";
      s.entry_price = fill;
      emit("entry_triggered", fill);
      if (touchedInvalidation) {
        // Same-bar entry + stop → conservative loss.
        Object.assign(patch, { status: "invalidated", invalidated_at: at, outcome: "loss", outcome_r: rMultiple(s.direction, fill, s.invalidation, s.invalidation), closed_at: at });
        emit("invalidated", s.invalidation);
        return { events, patch };
      }
      return { events, patch }; // targets checked from the next bar on
    }
    const expiredUntriggered = (entryDeadline && barTime >= entryDeadline) || (s.expires_at && barTime >= ms(s.expires_at));
    if (expiredUntriggered) {
      Object.assign(patch, { status: "expired", outcome: "expired_untriggered", outcome_r: null, closed_at: at });
      emit("expired", bar.c, { untriggered: true });
    }
    return { events, patch };
  }

  // ── In the trade (recommended "triggered"/"target_hit", or viral "active") ─
  const entry = s.entry_price;
  if (entry == null) return { events, patch };
  const t1Hit = !!s.target_1_hit_at;

  if (touchedInvalidation) {
    if (!t1Hit) {
      Object.assign(patch, { status: "invalidated", invalidated_at: at, outcome: "loss", outcome_r: rMultiple(s.direction, entry, s.invalidation, s.invalidation), closed_at: at });
    } else {
      // Outcome was already locked in as a T1 win; just stop monitoring.
      Object.assign(patch, { status: "closed", invalidated_at: at, closed_at: at });
    }
    emit("invalidated", s.invalidation, { after_target_1: t1Hit });
    return { events, patch };
  }

  if (!t1Hit && touches(s.target_1)) {
    Object.assign(patch, { status: "target_hit", target_1_hit_at: at, outcome: "win", outcome_r: rMultiple(s.direction, entry, s.invalidation, s.target_1) });
    s.target_1_hit_at = at;
    emit("target_1_hit", s.target_1);
  }
  if (s.target_1_hit_at && !s.target_2_hit_at && touches(s.target_2)) {
    Object.assign(patch, { status: "closed", target_2_hit_at: at, outcome: "win", outcome_r_t2: rMultiple(s.direction, entry, s.invalidation, s.target_2), closed_at: at });
    emit("target_2_hit", s.target_2);
    return { events, patch };
  }

  if (s.expires_at && barTime >= ms(s.expires_at)) {
    const already = patch.outcome || s.outcome;
    if (already === "win") {
      Object.assign(patch, { status: "closed", closed_at: at });
    } else {
      const r = rMultiple(s.direction, entry, s.invalidation, bar.c);
      Object.assign(patch, { status: "expired", outcome: r == null ? "expired_open" : r > 0.05 ? "expired_profit" : r < -0.05 ? "expired_loss" : "expired_flat", outcome_r: r, closed_at: at });
    }
    emit("expired", bar.c);
  }
  return { events, patch };
}

/** Run a sequence of bars, folding patches. Stops at the first terminal state. */
export function evaluateBars(signal, bars, kind = "recommended", nowMs = Date.now()) {
  let s = { ...signal };
  const events = [];
  const patch = {};
  for (const bar of bars) {
    const r = evaluateBar(s, bar, kind, nowMs);
    if (r.events.length || Object.keys(r.patch).length) {
      Object.assign(patch, r.patch);
      s = { ...s, ...r.patch };
      events.push(...r.events);
    }
    if (TERMINAL_STATUSES.includes(s.status)) break;
  }
  return { events, patch, state: s };
}

/** Pure time-based expiry (for when no new bar has arrived). */
export function expireIfDue(signal, kind, nowMs = Date.now()) {
  if (TERMINAL_STATUSES.includes(signal.status) || !signal.expires_at) return null;
  if (nowMs < ms(signal.expires_at)) return null;
  const at = new Date(nowMs).toISOString();
  if (signal.outcome === "win") return { events: [], patch: { status: "closed", closed_at: at } };
  if (kind === "recommended" && signal.status === "active") {
    return { events: [{ type: "expired", at, untriggered: true }], patch: { status: "expired", outcome: "expired_untriggered", closed_at: at } };
  }
  return { events: [{ type: "expired", at }], patch: { status: "expired", outcome: "expired_open", closed_at: at } };
}
