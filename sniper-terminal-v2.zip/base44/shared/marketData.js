// ─────────────────────────────────────────────────────────────────────────────
// OHLCV candle fetching with a provider fallback chain.
//
//   crypto:   Binance market-data-only REST (data-api.binance.vision) → Yahoo
//   fx/index/commodity: Yahoo Finance chart API
//
// Notes
// - data-api.binance.vision is Binance's documented public market-data host
//   (no API key). Binance geo-blocks some server regions with HTTP 451; if that
//   happens the Yahoo fallback is used and the asset records which source won.
// - Yahoo's chart endpoint is unofficial and can change without notice. It was
//   already the FX/index/commodity source in this codebase.
// ─────────────────────────────────────────────────────────────────────────────
import { binancePair, yahooSymbol } from "./symbols.js";

const BINANCE_REST = "https://data-api.binance.vision";
const HOUR_MS = 60 * 60 * 1000;

async function fetchJson(url, init = {}, timeoutMs = 12000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ctrl.signal });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      const err = new Error(`HTTP ${res.status} from ${new URL(url).host}${text ? `: ${text.slice(0, 160)}` : ""}`);
      err.status = res.status;
      throw err;
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchBinanceKlines(pair, { interval = "1h", limit = 500, endTime } = {}) {
  const qs = new URLSearchParams({ symbol: pair, interval, limit: String(Math.min(limit, 1000)) });
  if (endTime) qs.set("endTime", String(endTime));
  const rows = await fetchJson(`${BINANCE_REST}/api/v3/klines?${qs}`);
  if (!Array.isArray(rows) || rows.length === 0) throw new Error(`Binance returned no klines for ${pair}`);
  // [openTime, open, high, low, close, volume, closeTime, quoteAssetVolume, ...]
  return rows.map((r) => ({
    t: Number(r[0]),
    o: Number(r[1]),
    h: Number(r[2]),
    l: Number(r[3]),
    c: Number(r[4]),
    v: Number(r[7]), // quote-asset (USDT) volume — comparable across assets
  }));
}

export async function fetchYahooCandles(symbol, { interval = "1h", range = "60d" } = {}) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
  const data = await fetchJson(url, { headers: { Accept: "application/json", "User-Agent": "Mozilla/5.0" } });
  const result = data?.chart?.result?.[0];
  if (!result) throw new Error(`Yahoo returned no chart for ${symbol}`);
  const ts = result.timestamp || [];
  const q = result.indicators?.quote?.[0] || {};
  const out = [];
  for (let i = 0; i < ts.length; i++) {
    const o = q.open?.[i], h = q.high?.[i], l = q.low?.[i], c = q.close?.[i];
    if ([o, h, l, c].some((x) => x == null || Number.isNaN(x))) continue;
    out.push({ t: ts[i] * 1000, o, h, l, c, v: q.volume?.[i] ?? 0 });
  }
  if (out.length === 0) throw new Error(`Yahoo returned empty candles for ${symbol}`);
  return out;
}

/**
 * Fetch hourly candles for an asset, trying providers in order.
 * Returns { candles, source, symbol } or throws with every provider's error.
 */
export async function fetchCandlesForAsset(asset, { bars = 500 } = {}) {
  const errors = [];
  if (asset.market_type === "crypto") {
    const pair = binancePair(asset);
    if (pair) {
      try {
        return { candles: await fetchBinanceKlines(pair, { limit: bars }), source: "binance", symbol: pair };
      } catch (e) {
        errors.push(`binance(${pair}): ${e.message}`);
      }
    }
  }
  const ySym = yahooSymbol(asset);
  if (ySym) {
    // 60d of 1h bars ≈ 1,440 bars for 24/7 markets, ~1,000 for FX.
    const range = bars > 700 ? "180d" : "60d";
    try {
      const candles = await fetchYahooCandles(ySym, { interval: "1h", range });
      return { candles: candles.slice(-bars), source: "yahoo", symbol: ySym };
    } catch (e) {
      errors.push(`yahoo(${ySym}): ${e.message}`);
    }
  } else {
    errors.push("no yahoo mapping");
  }
  throw new Error(`No candle source succeeded — ${errors.join(" | ")}`);
}

/** Drop the still-forming last bar so signals only use CLOSED candles. */
export function closedCandles(candles, nowMs = Date.now(), barMs = HOUR_MS) {
  if (!candles.length) return candles;
  const last = candles[candles.length - 1];
  return last.t + barMs > nowMs ? candles.slice(0, -1) : candles;
}

export { HOUR_MS };
