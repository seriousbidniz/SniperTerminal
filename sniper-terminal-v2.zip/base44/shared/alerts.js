// Alert rules — one implementation used by refreshAll and generateAlerts.
// Signal-based alerts are global (audience "global"). Holding-based alerts are
// private to the holding's owner (audience "user" + user_email) so one user's
// positions are never visible to another.
import { LIVE_STATUSES } from "./lifecycle.js";

const STALE_MS = 4 * 60 * 60 * 1000;
const HIGH_OPP = 68;
const MED_OPP = 52;
const HIGH_RISK = 65;
const LOSS_TIERS = [
  { pct: -20, severity: "critical", action: "exit_hedge" },
  { pct: -10, severity: "high", action: "reduce_risk" },
];
const GAIN_PCT = 20;

const isStale = (ts, now) => !ts || now - new Date(ts).getTime() > STALE_MS;
const fmt = (p) => (p == null ? "" : ` at ${Number(p).toLocaleString("en-GB", { maximumFractionDigits: 6 })}`);

export function alertKey(a) {
  return [a.alert_type, a.asset_id || a.asset || "", a.holding_id || "", a.signal_id || "", a.dedupe_tag || ""].join("::");
}

export function buildAlerts({ recSignals, viralSignals, holdings, existingAlerts, assets, latestSnap, nowMs = Date.now() }) {
  const now = new Date(nowMs).toISOString();
  const assetById = {};
  const assetBySymbol = {};
  for (const a of assets) {
    assetById[a.id] = a;
    if (a.symbol) assetBySymbol[a.symbol.toUpperCase()] = a;
  }
  const seen = new Set(existingAlerts.map((a) => a.dedupe_key || alertKey(a)));
  const out = [];
  const add = (a) => {
    const key = alertKey(a);
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ ...a, dedupe_key: key, triggered_at: now, status: "active" });
  };

  for (const sig of recSignals) {
    if (!LIVE_STATUSES.includes(sig.status) || isStale(sig.updated_date || sig.timestamp, nowMs)) continue;
    const asset = assetById[sig.asset];
    const symbol = asset?.symbol || "Unknown";
    const name = asset?.name || symbol;
    const price = latestSnap[sig.asset]?.price ?? null;
    const opp = sig.opportunity_score ?? 0;
    const risk = sig.risk_score ?? 0;
    const dir = sig.direction || "bullish";
    const base = { audience: "global", asset: symbol, asset_id: sig.asset, signal_id: sig.id, display_name: name, market_type: asset?.market_type || "crypto", current_price: price };
    const levels = sig.entry_low != null ? ` Entry ${sig.entry_low}–${sig.entry_high}, invalidation ${sig.invalidation}, T1 ${sig.target_1}.` : "";

    if (opp >= HIGH_OPP && risk < 55 && sig.status === "active") {
      add({ ...base, alert_type: "opportunity_score", severity: opp >= 80 ? "high" : "medium", action_classification: "act_now",
        trigger_reason: `${symbol} ${dir} ${String(sig.setup_type || "").replace(/_/g, " ")} — score ${opp}, risk ${risk}${fmt(price)}`,
        summary: `${name} (${symbol}) has a ${dir} setup scored ${opp}.${levels} Validate independently before acting.` });
    } else if (opp >= MED_OPP && sig.status === "active") {
      add({ ...base, alert_type: "opportunity_score", severity: "low", action_classification: "prepare", dedupe_tag: "prepare",
        trigger_reason: `${symbol} ${dir} setup forming — score ${opp}${fmt(price)}`,
        summary: `${name} (${symbol}) has a developing ${dir} setup (score ${opp}). Wait for price to reach the entry zone.${levels}` });
    }
    if (risk >= HIGH_RISK) {
      add({ ...base, alert_type: "indicator", severity: risk >= 80 ? "critical" : "high", action_classification: "reduce_risk", dedupe_tag: "risk",
        trigger_reason: `${symbol} risk score elevated at ${risk}${fmt(price)}`,
        summary: `${name} (${symbol}) has a high risk score (${risk}) from elevated volatility and/or thin liquidity. Consider smaller size or tighter risk.` });
    }
  }

  for (const sig of viralSignals) {
    if (!LIVE_STATUSES.includes(sig.status) || isStale(sig.updated_date || sig.timestamp, nowMs)) continue;
    const asset = assetById[sig.asset];
    const symbol = asset?.symbol || "Unknown";
    const name = asset?.name || symbol;
    const price = latestSnap[sig.asset]?.price ?? null;
    const base = { audience: "global", asset: symbol, asset_id: sig.asset, signal_id: sig.id, display_name: name, market_type: asset?.market_type || "crypto", current_price: price };
    if (sig.ai_label === "avoid" || sig.ai_label === "caution") {
      add({ ...base, alert_type: "viral_score", severity: sig.ai_label === "avoid" ? "high" : "medium",
        action_classification: sig.ai_label === "avoid" ? "reduce_risk" : "watch",
        trigger_reason: `${symbol} unusual move labelled '${sig.ai_label}' — ${sig.move_state}, crowding ${sig.crowding_score}, exhaustion ${sig.exhaustion_score}${fmt(price)}`,
        summary: `${name} is moving unusually but is labelled '${sig.ai_label}' (${sig.move_state}). Activity is not the same as trade quality.` });
    }
  }

  for (const h of holdings) {
    const symbol = String(h.asset || "").toUpperCase();
    const entry = h.average_entry;
    const owner = h.created_by;
    if (!entry || !symbol || !owner) continue;
    const asset = assetBySymbol[symbol];
    const snap = asset ? latestSnap[asset.id] : null;
    let price = null;
    let stale = false;
    if (snap?.price != null) { price = snap.price; stale = isStale(snap.timestamp, nowMs); }
    else if (h.live_price != null) { price = h.live_price; stale = isStale(h.updated_date, nowMs); }
    if (price == null) continue;
    const isShort = (h.quantity ?? 0) < 0;
    const pnlPct = ((price - entry) / entry) * 100 * (isShort ? -1 : 1);
    const base = { audience: "user", user_email: owner, asset: symbol, asset_id: asset?.id || null, holding_id: h.id, display_name: asset?.name || symbol, market_type: asset?.market_type || "crypto", current_price: price, pnl_pct: pnlPct };
    const staleNote = stale ? " (price data is stale — verify independently)" : "";
    for (const tier of LOSS_TIERS) {
      if (pnlPct <= tier.pct) {
        add({ ...base, alert_type: "stop_loss", dedupe_tag: tier.severity,
          severity: stale ? (tier.severity === "critical" ? "high" : "medium") : tier.severity,
          action_classification: tier.action,
          trigger_reason: `${symbol} ${isShort ? "short" : "holding"} down ${pnlPct.toFixed(1)}% from entry ${entry}${stale ? " (stale price)" : ""}`,
          summary: `${base.display_name} position is down ${Math.abs(pnlPct).toFixed(1)}%${fmt(price)}.${staleNote} ${tier.action === "exit_hedge" ? "Review whether the original thesis still holds." : "Review your stop-loss level."}` });
        break;
      }
    }
    if (pnlPct >= GAIN_PCT) {
      add({ ...base, alert_type: "take_profit", severity: stale ? "low" : "medium", action_classification: "prepare",
        trigger_reason: `${symbol} ${isShort ? "short" : "holding"} up ${pnlPct.toFixed(1)}% from entry${stale ? " (stale price)" : ""}`,
        summary: `${base.display_name} has gained ${pnlPct.toFixed(1)}%${fmt(price)}.${staleNote} Consider reviewing take-profit targets.` });
    }
  }
  return out;
}
