// Notification fan-out. Base44 writes PushOutbox rows; the realtime worker
// delivers them with Web Push (VAPID). Lifecycle events detected BY the worker
// get their push jobs returned synchronously so delivery is immediate.
import { roundPrice } from "./symbols.js";

export const DEFAULT_PREFS = {
  push_enabled: true,
  push_new_signals_min_score: 75,
  push_lifecycle: "executed_only", // "all" | "executed_only" | "off"
  push_viral: false,
};

export async function loadPushAudience(svc) {
  const [subs, settings] = await Promise.all([
    svc.entities.PushSubscriptions.filter({ active: true }, "-created_date", 2000),
    svc.entities.UserSettings.list("-updated_date", 2000),
  ]);
  const settingsByUser = {};
  for (const s of settings) {
    const email = s.user_email || s.created_by;
    if (email && !settingsByUser[email]) settingsByUser[email] = s;
  }
  const subsByUser = {};
  for (const s of subs) (subsByUser[s.user_email] ||= []).push(s);
  return { users: Object.keys(subsByUser), subsByUser, settingsByUser };
}

export function prefsFor(aud, email) {
  return { ...DEFAULT_PREFS, ...(aud.settingsByUser[email] || {}) };
}

const sideWord = (dir) => (dir === "bullish" ? "long" : "short");
const px = (p, mt) => (p == null ? "—" : roundPrice(p, mt)?.toLocaleString("en-GB", { maximumFractionDigits: 8 }));

export function lifecycleMessage(kind, signal, asset, ev) {
  const sym = asset?.symbol || "Asset";
  const mt = asset?.market_type;
  const label = kind === "viral" ? "viral move" : `${sideWord(signal.direction)} signal`;
  const url = kind === "viral" ? "/viral" : "/recommended";
  switch (ev.type) {
    case "entry_triggered":
      return { title: `${sym}: entry zone reached`, body: `${sym} ${label} filled at ~${px(ev.price, mt)}. Invalidation ${px(signal.invalidation, mt)}, T1 ${px(signal.target_1, mt)}.`, severity: "warning", url };
    case "target_1_hit":
      return { title: `${sym}: Target 1 hit`, body: `${sym} ${label} reached T1 ${px(signal.target_1, mt)}${signal.target_2 ? `. T2 ${px(signal.target_2, mt)} still in play.` : "."}`, severity: "info", url };
    case "target_2_hit":
      return { title: `${sym}: Target 2 hit`, body: `${sym} ${label} reached T2 ${px(signal.target_2, mt)}. Signal closed.`, severity: "info", url };
    case "invalidated":
      return { title: `${sym}: signal invalidated`, body: `${sym} traded through ${px(signal.invalidation, mt)}${ev.before_entry ? " before entry — no trade." : ev.after_target_1 ? " after T1 — stop monitoring." : ". Thesis is void."}`, severity: "critical", url };
    case "expired":
      return { title: `${sym}: signal expired`, body: `${sym} ${label} ran out of time${ev.untriggered ? " without reaching the entry zone." : "."}`, severity: "info", url };
    default:
      return { title: `${sym}: ${ev.type}`, body: `${sym} ${label} update.`, severity: "info", url };
  }
}

export function newSignalMessage(kind, signal, asset) {
  const sym = asset?.symbol || "Asset";
  const mt = asset?.market_type;
  if (kind === "viral") {
    return { title: `${sym}: unusual move (${signal.ai_label})`, body: signal.summary?.slice(0, 180) || `${sym} viral score ${signal.viral_score}.`, severity: "info", url: "/viral" };
  }
  return {
    title: `${sym}: new ${sideWord(signal.direction)} setup (${signal.opportunity_score})`,
    body: `${String(signal.setup_type).replace(/_/g, " ")} — entry ${px(signal.entry_low, mt)}–${px(signal.entry_high, mt)}, invalidation ${px(signal.invalidation, mt)}, T1 ${px(signal.target_1, mt)}.`,
    severity: "warning",
    url: "/recommended",
  };
}

/**
 * Build outbox rows. `targets` is [{ email, message, signal_id, tag }].
 */
export async function enqueuePush(svc, targets) {
  if (!targets.length) return [];
  const now = new Date().toISOString();
  const rows = targets.map((t) => ({
    user_email: t.email,
    title: t.message.title,
    body: t.message.body,
    url: t.message.url,
    severity: t.message.severity,
    tag: t.tag,
    signal_id: t.signal_id || null,
    status: "pending",
    attempts: 0,
    created_at: now,
  }));
  const created = [];
  for (let i = 0; i < rows.length; i += 400) created.push(...(await svc.entities.PushOutbox.bulkCreate(rows.slice(i, i + 400))));
  return created;
}

/** Fan out lifecycle events: global alert + targeted push. */
export async function notifyLifecycle(svc, items, aud, assetsById) {
  if (!items.length) return [];
  const now = new Date().toISOString();
  const ids = items.map((i) => i.signal.id);
  const executions = await svc.entities.SignalExecutions.filter({ signal_id: { $in: ids } }, "-created_date", 2000);
  const executed = new Set(executions.map((e) => `${e.user_email}|${e.signal_id}`));
  // Idempotency: never announce the same lifecycle event for a signal twice
  // (worker and scheduled refresh can both observe it).
  const keys = items.flatMap(({ signal, events }) => events.map((ev) => `lifecycle::${signal.id}::${ev.type}`));
  const prior = keys.length ? await svc.entities.Alerts.filter({ dedupe_key: { $in: keys } }, "-triggered_at", keys.length) : [];
  const announced = new Set(prior.map((a) => a.dedupe_key));
  const alerts = [];
  const targets = [];
  for (const { kind, signal, events } of items) {
    const asset = assetsById[signal.asset];
    for (const ev of events) {
      const dedupeKey = `lifecycle::${signal.id}::${ev.type}`;
      if (announced.has(dedupeKey)) continue;
      announced.add(dedupeKey);
      const msg = lifecycleMessage(kind, signal, asset, ev);
      alerts.push({
        audience: "global", alert_type: "signal_lifecycle",
        severity: msg.severity === "critical" ? "high" : msg.severity === "warning" ? "medium" : "low",
        asset: asset?.symbol, asset_id: signal.asset, signal_id: signal.id, display_name: asset?.name,
        market_type: asset?.market_type, current_price: ev.price ?? null,
        trigger_reason: msg.title, summary: msg.body,
        action_classification: ev.type === "invalidated" ? "exit_hedge" : ev.type === "entry_triggered" ? "act_now" : "watch",
        dedupe_key: dedupeKey, triggered_at: now, status: "active",
      });
      for (const email of aud.users) {
        const p = prefsFor(aud, email);
        if (!p.push_enabled || p.push_lifecycle === "off") continue;
        if (p.push_lifecycle === "executed_only" && !executed.has(`${email}|${signal.id}`)) continue;
        targets.push({ email, message: msg, signal_id: signal.id, tag: `${signal.id}:${ev.type}` });
      }
    }
  }
  if (alerts.length) await svc.entities.Alerts.bulkCreate(alerts);
  return enqueuePush(svc, targets);
}

export async function notifyNewSignals(svc, items, aud, assetsById) {
  const targets = [];
  for (const { kind, signal } of items) {
    const asset = assetsById[signal.asset];
    const msg = newSignalMessage(kind, signal, asset);
    for (const email of aud.users) {
      const p = prefsFor(aud, email);
      if (!p.push_enabled) continue;
      if (kind === "recommended" && (signal.opportunity_score ?? 0) < p.push_new_signals_min_score) continue;
      if (kind === "viral" && (!p.push_viral || signal.ai_label !== "tradable")) continue;
      targets.push({ email, message: msg, signal_id: signal.id, tag: `${signal.id}:new` });
    }
  }
  return enqueuePush(svc, targets);
}

/** Turn outbox rows into deliverable jobs (one per device) and mark them dispatched. */
export async function claimPushJobs(svc, outboxRows, aud) {
  const jobs = [];
  const updates = [];
  for (const row of outboxRows) {
    const subs = aud.subsByUser[row.user_email] || [];
    if (!subs.length) {
      updates.push({ id: row.id, status: "failed", error: "no active subscription" });
      continue;
    }
    for (const s of subs) {
      jobs.push({
        outbox_id: row.id, subscription_id: s.id,
        subscription: { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        payload: { title: row.title, body: row.body, url: row.url, tag: row.tag, severity: row.severity },
      });
    }
    updates.push({ id: row.id, status: "dispatched", attempts: (row.attempts || 0) + 1 });
  }
  for (let i = 0; i < updates.length; i += 400) await svc.entities.PushOutbox.bulkUpdate(updates.slice(i, i + 400));
  return jobs;
}
