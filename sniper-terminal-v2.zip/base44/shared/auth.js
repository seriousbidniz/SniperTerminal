// Authorisation helpers for Base44 backend functions (Deno only).

export async function getUser(base44) {
  try {
    return (await base44.auth.me()) || null;
  } catch {
    return null;
  }
}

export function getSecret(name) {
  try {
    return Deno.env.get(name) || undefined;
  } catch {
    return undefined;
  }
}

export function json(data, status = 200) {
  return Response.json(data, { status });
}

/** Read / write small JSON values in the SystemState entity. */
export async function getState(svc, key) {
  const rows = await svc.entities.SystemState.filter({ key }, "-updated_date", 1);
  if (!rows.length) return null;
  try {
    return JSON.parse(rows[0].value);
  } catch {
    return null;
  }
}

export async function setState(svc, key, value) {
  await upsertBy(svc.entities.SystemState, [{ key, value: JSON.stringify(value), updated_at: new Date().toISOString() }], "key");
}

/**
 * Gate for heavy, app-wide jobs (refresh, recompute, calibration).
 *  - Signed-in admins: always allowed.
 *  - Signed-in non-admins: refused (these jobs rewrite global data).
 *  - No user (scheduled workflow or direct HTTP call): allowed at most once per
 *    `minIntervalMs`, so the public HTTP endpoint can't be used to hammer the
 *    data providers.
 */
export async function authorizeJob(base44, job, { minIntervalMs = 4 * 60_000, adminOnly = true } = {}) {
  const user = await getUser(base44);
  const svc = base44.asServiceRole;
  if (user) {
    if (adminOnly && user.role !== "admin") {
      return { ok: false, response: json({ error: "This action is restricted to admins." }, 403) };
    }
    await setState(svc, `job:${job}`, { last_run: Date.now(), by: user.email });
    return { ok: true, user, svc };
  }
  const last = await getState(svc, `job:${job}`);
  if (last?.last_run && Date.now() - last.last_run < minIntervalMs) {
    return { ok: false, response: json({ skipped: true, reason: "ran recently", last_run: last.last_run }, 429) };
  }
  await setState(svc, `job:${job}`, { last_run: Date.now(), by: "scheduler" });
  return { ok: true, user: null, svc };
}

/**
 * Insert-or-update by a natural key, using only filter / bulkCreate / bulkUpdate
 * (works on every SDK version; avoids depending on the newer `upsert` API).
 */
export async function upsertBy(handler, rows, key) {
  let created = 0;
  let updated = 0;
  for (let i = 0; i < rows.length; i += 200) {
    const chunk = rows.slice(i, i + 200);
    const keys = [...new Set(chunk.map((r) => r[key]))];
    const existing = await handler.filter({ [key]: { $in: keys } }, "-updated_date", keys.length * 2);
    const idByKey = {};
    for (const e of existing) if (!idByKey[e[key]]) idByKey[e[key]] = e.id;
    const last = {};
    for (const r of chunk) last[r[key]] = r; // last row per key wins
    const toUpdate = [];
    const toCreate = [];
    for (const r of Object.values(last)) (idByKey[r[key]] ? toUpdate.push({ id: idByKey[r[key]], ...r }) : toCreate.push(r));
    if (toUpdate.length) await handler.bulkUpdate(toUpdate);
    if (toCreate.length) await handler.bulkCreate(toCreate);
    created += toCreate.length;
    updated += toUpdate.length;
  }
  return { created, updated };
}
