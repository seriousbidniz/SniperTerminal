// ─────────────────────────────────────────────────────────────────────────────
// Walk-forward backtest of the signal engine + calibration blending.
//
// - The engine sees only candles[0..i] at step i (series are causal: every
//   indicator value at i depends on bars ≤ i), so there is no look-ahead.
// - Resolution uses the same lifecycle rules as live signals.
// - One open idea per (setup, direction) at a time — no overlapping duplicates.
// - Costs are an ASSUMPTION, expressed per side as a fraction of price, and are
//   subtracted from every triggered trade's R.
// ─────────────────────────────────────────────────────────────────────────────
import { computeSeries } from "./indicators.js";
import { analyzeAt, enrichSeries, calibrationKey, BAR_MS, MIN_CALIBRATION_SAMPLES } from "./signalEngine.js";
import { evaluateBar } from "./lifecycle.js";

export const DEFAULT_COST_PER_SIDE = { crypto: 0.001, fx: 0.0001, commodity: 0.0003, index: 0.0002 };
const WIN = "win";
const TRIGGERED_OUTCOMES = new Set(["win", "loss", "expired_profit", "expired_loss", "expired_flat", "expired_open"]);

export function backtestAsset(candles, asset, { warmup = 210, costPerSide } = {}) {
  const S = enrichSeries(computeSeries(candles));
  const cost = costPerSide ?? DEFAULT_COST_PER_SIDE[asset.market_type] ?? 0.001;
  const trades = [];
  const busyUntil = {};
  for (let i = warmup; i < candles.length - 1; i++) {
    const sig = analyzeAt(S, i, asset, {}); // uncalibrated: no feedback loop inside a backtest
    if (!sig) continue;
    const key = calibrationKey(sig.setup_type, sig.direction, asset.market_type);
    if (busyUntil[key] != null && i <= busyUntil[key]) continue;

    let st = { ...sig, status: "active", timestamp: new Date(candles[i].t + BAR_MS).toISOString() };
    let resolvedAt = null;
    for (let j = i + 1; j < candles.length; j++) {
      const bar = { ...candles[j], closeTime: candles[j].t + BAR_MS };
      const r = evaluateBar(st, bar, "recommended", Number.MAX_SAFE_INTEGER);
      st = { ...st, ...r.patch };
      if (st.outcome) { resolvedAt = j; break; }
    }
    if (resolvedAt == null) continue; // still open at end of data — not counted
    busyUntil[key] = resolvedAt;

    const triggered = TRIGGERED_OUTCOMES.has(st.outcome);
    let r = st.outcome_r;
    if (triggered && r != null && st.entry_price) {
      const riskPerUnit = Math.abs(st.entry_price - st.invalidation);
      if (riskPerUnit > 0) r = r - (2 * cost * st.entry_price) / riskPerUnit;
    }
    trades.push({
      key, setup_type: sig.setup_type, direction: sig.direction,
      outcome: st.outcome, triggered, win: st.outcome === WIN,
      r: triggered ? r : null, bars: resolvedAt - i, t: candles[i].t,
    });
  }
  return trades;
}

function median(arr) {
  if (!arr.length) return null;
  const s = [...arr].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

/** Aggregate trades into per-key stats { n_signals, n, wins, sum_r, bars[] }. */
export function aggregateTrades(trades) {
  const out = {};
  for (const t of trades) {
    const a = (out[t.key] ||= { n_signals: 0, n: 0, wins: 0, sum_r: 0, bars: [] });
    a.n_signals++;
    if (!t.triggered) continue;
    a.n++;
    if (t.win) a.wins++;
    a.sum_r += t.r ?? 0;
    a.bars.push(t.bars);
  }
  return out;
}

export function summarise(stats) {
  if (!stats || !stats.n) return { n: 0, n_signals: stats?.n_signals || 0, win_rate: null, expectancy_r: null, median_bars: null };
  return {
    n: stats.n,
    n_signals: stats.n_signals,
    win_rate: stats.wins / stats.n,
    expectancy_r: stats.sum_r / stats.n,
    median_bars: median(stats.bars),
  };
}

/**
 * Blend backtest evidence with live outcomes. The backtest acts as a prior
 * worth at most `maxPrior` samples, so real outcomes dominate as they accrue.
 */
export function blendCalibration(bt, live, { maxPrior = 50 } = {}) {
  const b = bt || { n: 0, wins: 0, sum_r: 0, bars: [] };
  const l = live || { n: 0, wins: 0, sum_r: 0, bars: [] };
  const w = b.n > 0 ? Math.min(1, maxPrior / b.n) : 0;
  const n = b.n * w + l.n;
  if (n <= 0) return { n_effective: 0, win_rate: null, expectancy_r: null, median_bars_to_resolution: null, source: "none" };
  const bars = l.n >= MIN_CALIBRATION_SAMPLES ? l.bars : [...b.bars, ...l.bars];
  return {
    n_effective: Math.round(n * 10) / 10,
    win_rate: (b.wins * w + l.wins) / n,
    expectancy_r: (b.sum_r * w + l.sum_r) / n,
    median_bars_to_resolution: median(bars),
    source: l.n === 0 ? "backtest" : b.n === 0 ? "live" : "blended",
  };
}
