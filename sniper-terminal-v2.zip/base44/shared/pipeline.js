// ─────────────────────────────────────────────────────────────────────────────
// Refresh pipeline (runs inside Base44 backend functions).
//
// For each tracked asset:
//   1. fetch 1h candles (Binance market-data → Yahoo fallback)
//   2. write a MarketSnapshot with REAL indicators (RSI, ATR-rank, EMAs…)
//   3. advance every live signal on that asset through its lifecycle using the
//      bars since it was last evaluated (covers markets the worker doesn't stream)
//   4. create, refresh-in-place, or supersede signals — signal ids are STABLE:
//      a signal keeps its id, levels and expiry until it resolves
//   5. alerts + push fan-out
// Respects Base44's 5-minute function limit with an internal deadline.
// ─────────────────────────────────────────────────────────────────────────────
import { computeSeries } from "./indicators.js";
import { fetchCandlesForAsset, closedCandles, HOUR_MS } from "./marketData.js";
import { analyzeAt, analyzeViral, enrichSeries, snapshotAt, ACTIVE_THRESHOLD } from "./signalEngine.js";
import { evaluateBars, expireIfDue, LIVE_STATUSES, TERMINAL_STATUSES } from "./lifecycle.js";
import { buildAlerts } from "./alerts.js";
import { loadPushAudience, notifyLifecycle, notifyNewSignals } from "./notify.js";
import { setState } from "./auth.js";

const SNAPSHOT_RETENTION_MS = 3 * 24 * HOUR_MS;
const SCORE_FIELDS_REC = [
  "opportunity_score", "risk_score", "conviction_score", "trend_score_input", "momentum_score_input",
  "liquidity_score", "why_now", "score_boost_factors", "score_penalty_factors", "confidence_note",
  "score_explanation", "calibration_source", "calibration_samples", "calibrated_win_rate", "expected_r",
];
const SCORE_FIELDS_VIRAL = [
  "viral_score", "attention_score", "volume_spike_score", "liquidity_quality_score", "crowding_score",
  "exhaustion_score", "move_state", "ai_label", "summary", "viral_boost_factors", "viral_penalty_factors",
  "score_explanation", "raw_inputs", "data_confidence",
];
const pick = (obj, keys) => Object.fromEntries(keys.filter((k) => obj[k] !== undefined).map((k) => [k, obj[k]]));

export async function loadCalibrations(svc) {
  const rows = await svc.entities.SetupCalibration.filter({ scope: "market" }, "-updated_at", 500);
  const map = {};
  for (const r of rows) map[r.key] = r;
  return map;
}

/** Re-read signals and apply patches only if the expected status still holds. */
export async function applyGuarded(svc, entity, items) {
  const accepted = [];
  for (const it of items) {
    let fresh;
    try { fresh = await svc.entities[entity].get(it.id); } catch { continue; }
    if (!fresh) continue;
    if (it.expect_status && fresh.status !== it.expect_status) continue;
    const patch = { ...it.patch };
    let events = it.events || [];
    if (fresh.target_1_hit_at) {
      delete patch.target_1_hit_at;
      events = events.filter((e) => e.type !== "target_1_hit");
    }
    if (fresh.entry_triggered_at) events = events.filter((e) => e.type !== "entry_triggered");
    if (TERMINAL_STATUSES.includes(fresh.status)) continue;
    await svc.entities[entity].update(it.id, patch);
    accepted.push({ signal: { ...fresh, ...patch }, events });
  }
  return accepted;
}

function barsSince(candles, sinceIso, nowMs) {
  const since = sinceIso ? new Date(sinceIso).getTime() : 0;
  return candles
    .filter((c) => c.t > since)
    .map((c) => ({ ...c, closeTime: Math.min(c.t + HOUR_MS, nowMs) }));
}

async function chunked(list, size, fn) {
  for (let i = 0; i < list.length; i += size) await fn(list.slice(i, i + size));
}

export async function runPipeline(svc, { assetIds = null, deadlineMs = 230_000, withAlerts = true, withPush = true } = {}) {
  const started = Date.now();
  const nowIso = () => new Date().toISOString();
  const summary = { assets: 0, failed: [], snapshots: 0, rec: { created: 0, refreshed: 0, superseded: 0 }, viral: { created: 0, refreshed: 0, superseded: 0 }, lifecycle_events: 0, alerts: 0, pushes: 0, timed_out: false };

  let assets = await svc.entities.Assets.filter({ active: true }, "-liquidity_score", 500);
  if (assetIds?.length) assets = assets.filter((a) => assetIds.includes(a.id));
  const assetsById = Object.fromEntries(assets.map((a) => [a.id, a]));

  const [calibrations, liveRec, liveViral] = await Promise.all([
    loadCalibrations(svc),
    svc.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-timestamp", 1000),
    svc.entities.ViralTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-timestamp", 1000),
  ]);
  const group = (rows) => rows.reduce((m, r) => ((m[r.asset] ||= []).push(r), m), {});
  const recByAsset = group(liveRec);
  const viralByAsset = group(liveViral);

  const snapshots = [];
  const assetUpdates = [];
  const lifecycleRec = [];
  const lifecycleViral = [];
  const createRec = [];
  const createViral = [];
  const refreshRec = [];
  const refreshViral = [];
  const processed = new Set();

  for (const asset of assets) {
    if (Date.now() - started > deadlineMs) { summary.timed_out = true; break; }
    const now = Date.now();
    let fetched;
    try {
      fetched = await fetchCandlesForAsset(asset, { bars: 300 });
    } catch (e) {
      summary.failed.push({ symbol: asset.symbol, error: e.message.slice(0, 200) });
      assetUpdates.push({ id: asset.id, data_status: "error", data_error: e.message.slice(0, 500) });
      continue;
    }
    processed.add(asset.id);
    summary.assets++;
    const all = fetched.candles;
    const closed = closedCandles(all, now);
    if (closed.length < 80) {
      assetUpdates.push({ id: asset.id, data_status: "error", data_error: `Only ${closed.length} closed 1h bars available` });
      continue;
    }
    const S = enrichSeries(computeSeries(closed));
    const i = closed.length - 1;
    const snap = snapshotAt(S, i);
    const livePrice = all[all.length - 1].c; // includes the forming bar
    const { atr: _atr, ...snapFields } = snap;
    snapshots.push({ asset: asset.id, timestamp: nowIso(), ...snapFields, price: livePrice });
    assetUpdates.push({ id: asset.id, status: "active", data_status: "ok", last_refresh_at: nowIso(), data_error: null, candle_source: fetched.source });
    const lastClosedIso = new Date(closed[i].t).toISOString();

    // ── Lifecycle for existing live signals ─────────────────────────────────
    const advance = (sig, kind, sink) => {
      const bars = barsSince(all, sig.last_eval_bar_time || sig.generated_bar_time, now);
      let { events, patch, state } = evaluateBars(sig, bars, kind, now);
      if (!TERMINAL_STATUSES.includes(state.status)) {
        const exp = expireIfDue(state, kind, now);
        if (exp) { events = [...events, ...exp.events]; patch = { ...patch, ...exp.patch }; state = { ...state, ...exp.patch }; }
      }
      patch.last_eval_bar_time = lastClosedIso;
      patch.last_price = livePrice;
      patch.last_price_at = nowIso();
      sink.push({ id: sig.id, expect_status: sig.status, patch, events });
      return state;
    };
    const recStates = (recByAsset[asset.id] || []).map((s) => advance(s, "recommended", lifecycleRec));
    const viralStates = (viralByAsset[asset.id] || []).map((s) => advance(s, "viral", lifecycleViral));

    // ── Recommended: create / refresh / supersede ────────────────────────────
    const analysis = analyzeAt(S, i, asset, calibrations);
    const live = recStates.find((s) => LIVE_STATUSES.includes(s.status));
    const qualifies = analysis && analysis.opportunity_score >= ACTIVE_THRESHOLD;
    if (live && live.status !== "active") {
      // trade in progress — never replace it
    } else if (live) {
      if (analysis && analysis.direction === live.direction && analysis.setup_type === live.setup_type) {
        refreshRec.push({ id: live.id, patch: { ...pick(analysis, SCORE_FIELDS_REC), last_confirmed_at: nowIso() } });
      } else if (qualifies && analysis.direction !== live.direction) {
        refreshRec.push({ id: live.id, patch: { status: "superseded", outcome: "superseded", closed_at: nowIso() } });
        createRec.push({ asset: asset.id, timestamp: nowIso(), status: "active", ...analysis });
        summary.rec.superseded++;
      }
    } else if (qualifies) {
      createRec.push({ asset: asset.id, timestamp: nowIso(), status: "active", ...analysis });
    }

    // ── Viral ────────────────────────────────────────────────────────────────
    const v = analyzeViral(snap, S, i, asset);
    const liveV = viralStates.find((s) => LIVE_STATUSES.includes(s.status));
    if (liveV) {
      if (v && v.direction === liveV.direction) {
        refreshViral.push({ id: liveV.id, patch: pick(v, SCORE_FIELDS_VIRAL) });
      } else if (v && v.direction !== liveV.direction) {
        refreshViral.push({ id: liveV.id, patch: { status: "superseded", outcome: "superseded", closed_at: nowIso() } });
        createViral.push({ asset: asset.id, timestamp: nowIso(), status: "active", entry_price: v.price_at_signal, ...v });
        summary.viral.superseded++;
      }
    } else if (v) {
      createViral.push({ asset: asset.id, timestamp: nowIso(), status: "active", entry_price: v.price_at_signal, ...v });
    }
  }

  // Signals on assets we didn't process (inactive, failed fetch) still expire on time.
  for (const [kind, rows, sink] of [["recommended", liveRec, lifecycleRec], ["viral", liveViral, lifecycleViral]]) {
    for (const sig of rows) {
      if (processed.has(sig.asset)) continue;
      const exp = expireIfDue(sig, kind, Date.now());
      if (exp) sink.push({ id: sig.id, expect_status: sig.status, patch: exp.patch, events: exp.events });
    }
  }

  // ── Writes ─────────────────────────────────────────────────────────────────
  await chunked(snapshots, 400, (b) => svc.entities.MarketSnapshots.bulkCreate(b));
  summary.snapshots = snapshots.length;
  await chunked(assetUpdates, 400, (b) => svc.entities.Assets.bulkUpdate(b));

  const recEventful = lifecycleRec.filter((x) => x.events.length);
  const viralEventful = lifecycleViral.filter((x) => x.events.length);
  const recQuiet = lifecycleRec.filter((x) => !x.events.length).map((x) => ({ id: x.id, ...x.patch }));
  const viralQuiet = lifecycleViral.filter((x) => !x.events.length).map((x) => ({ id: x.id, ...x.patch }));
  await chunked(recQuiet, 400, (b) => svc.entities.RecommendedTradeSignals.bulkUpdate(b));
  await chunked(viralQuiet, 400, (b) => svc.entities.ViralTradeSignals.bulkUpdate(b));
  const acceptedRec = await applyGuarded(svc, "RecommendedTradeSignals", recEventful);
  const acceptedViral = await applyGuarded(svc, "ViralTradeSignals", viralEventful);
  summary.lifecycle_events = [...acceptedRec, ...acceptedViral].reduce((n, x) => n + x.events.length, 0);

  await chunked(refreshRec.map((r) => ({ id: r.id, ...r.patch })), 400, (b) => svc.entities.RecommendedTradeSignals.bulkUpdate(b));
  await chunked(refreshViral.map((r) => ({ id: r.id, ...r.patch })), 400, (b) => svc.entities.ViralTradeSignals.bulkUpdate(b));
  summary.rec.refreshed = refreshRec.filter((r) => !r.patch.status).length;
  summary.viral.refreshed = refreshViral.filter((r) => !r.patch.status).length;

  const newRec = [];
  const newViral = [];
  await chunked(createRec, 200, async (b) => newRec.push(...(await svc.entities.RecommendedTradeSignals.bulkCreate(b))));
  await chunked(createViral, 200, async (b) => newViral.push(...(await svc.entities.ViralTradeSignals.bulkCreate(b))));
  summary.rec.created = newRec.length;
  summary.viral.created = newViral.length;

  // ── Alerts + push ──────────────────────────────────────────────────────────
  if (withPush) {
    const aud = await loadPushAudience(svc);
    const lifeItems = [
      ...acceptedRec.map((x) => ({ kind: "recommended", ...x })),
      ...acceptedViral.map((x) => ({ kind: "viral", ...x })),
    ];
    const a = await notifyLifecycle(svc, lifeItems, aud, assetsById);
    const b = await notifyNewSignals(svc, [
      ...newRec.map((signal) => ({ kind: "recommended", signal })),
      ...newViral.map((signal) => ({ kind: "viral", signal })),
    ], aud, assetsById);
    summary.pushes = a.length + b.length;
  }

  if (withAlerts) summary.alerts = await generateAlertsInto(svc);

  // ── Retention ──────────────────────────────────────────────────────────────
  const cutoff = new Date(Date.now() - SNAPSHOT_RETENTION_MS).toISOString();
  const old = await svc.entities.MarketSnapshots.filter({ timestamp: { $lt: cutoff } }, "timestamp", 300);
  for (const s of old) { try { await svc.entities.MarketSnapshots.delete(s.id); } catch { /* ignore */ } }
  summary.snapshots_pruned = old.length;

  summary.duration_ms = Date.now() - started;
  await setState(svc, "pipeline:last_run", { at: Date.now(), ...summary, failed: summary.failed.length });
  return summary;
}

export async function generateAlertsInto(svc) {
  const [recSignals, viralSignals, holdings, existingAlerts, assets, snaps] = await Promise.all([
    svc.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-opportunity_score", 300),
    svc.entities.ViralTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-viral_score", 300),
    svc.entities.Holdings.list("-created_date", 1000),
    svc.entities.Alerts.filter({ status: { $in: ["active", "snoozed", "read"] } }, "-triggered_at", 1000),
    svc.entities.Assets.filter({ active: true }, "-created_date", 500),
    svc.entities.MarketSnapshots.list("-timestamp", 600),
  ]);
  const latestSnap = {};
  for (const s of snaps) if (s.asset && s.price != null && !latestSnap[s.asset]) latestSnap[s.asset] = s;
  const toCreate = buildAlerts({ recSignals, viralSignals, holdings, existingAlerts, assets, latestSnap });
  await chunked(toCreate, 400, (b) => svc.entities.Alerts.bulkCreate(b));
  return toCreate.length;
}
