// ─────────────────────────────────────────────────────────────────────────────
// Gateway for the always-on realtime worker (see /realtime-worker).
// Every request must be HMAC-signed with WORKER_SHARED_SECRET (60s replay window).
//
// ops:
//   state          → live signals, broker connections to sync, pending push jobs
//   signal_events  → apply lifecycle transitions detected on live streams,
//                    returns push jobs for immediate delivery
//   push_results   → delivery receipts; dead subscriptions are deactivated
//   broker_status  → key-permission verification results
//   broker_fills   → new read-only fills; runs signal attribution
// ─────────────────────────────────────────────────────────────────────────────
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { getSecret, setState, json, upsertBy } from "../../shared/auth.js";
import { verifyBody, SIGNATURE_HEADER, TIMESTAMP_HEADER } from "../../shared/signing.js";
import { applyGuarded } from "../../shared/pipeline.js";
import { LIVE_STATUSES } from "../../shared/lifecycle.js";
import { loadPushAudience, notifyLifecycle, claimPushJobs } from "../../shared/notify.js";
import { attributeFills } from "../../shared/attribution.js";
import { binancePair } from "../../shared/symbols.js";

const SIGNAL_FIELDS = ["id", "asset", "status", "direction", "setup_type", "entry_low", "entry_high", "invalidation", "target_1", "target_2", "expires_at", "entry_window_hours", "timestamp", "generated_bar_time", "entry_price", "entry_triggered_at", "target_1_hit_at", "target_2_hit_at", "outcome", "price_at_signal"];
const pick = (o) => Object.fromEntries(SIGNAL_FIELDS.map((k) => [k, o[k] ?? null]));
const ENTITY = { recommended: "RecommendedTradeSignals", viral: "ViralTradeSignals" };

Deno.serve(async (req) => {
  try {
    const raw = await req.text();
    const secret = getSecret("WORKER_SHARED_SECRET");
    if (!secret) return json({ error: "WORKER_SHARED_SECRET not configured" }, 503);
    const ok = await verifyBody(secret, raw, req.headers.get(TIMESTAMP_HEADER), req.headers.get(SIGNATURE_HEADER));
    if (!ok) return json({ error: "Bad signature" }, 401);

    const body = JSON.parse(raw || "{}");
    const svc = createClientFromRequest(req).asServiceRole;

    switch (body.op) {
      case "state": return json(await opState(svc, body));
      case "signal_events": return json(await opSignalEvents(svc, body));
      case "push_results": return json(await opPushResults(svc, body));
      case "broker_status": return json(await opBrokerStatus(svc, body));
      case "broker_fills": return json(await opBrokerFills(svc, body));
      default: return json({ error: `Unknown op ${body.op}` }, 400);
    }
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});

async function opState(svc, body) {
  await setState(svc, "worker:heartbeat", { at: Date.now(), ...(body.stats || {}) });
  const [assets, rec, viral, conns, outbox] = await Promise.all([
    svc.entities.Assets.filter({ active: true }, "-liquidity_score", 500),
    svc.entities.RecommendedTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-timestamp", 1000),
    svc.entities.ViralTradeSignals.filter({ status: { $in: LIVE_STATUSES } }, "-timestamp", 1000),
    body.include_brokers ? svc.entities.BrokerConnections.filter({ status: { $in: ["pending_verification", "verified"] } }, "-created_date", 500) : [],
    svc.entities.PushOutbox.filter({ status: "pending" }, "created_at", 200),
  ]);
  const aud = outbox.length ? await loadPushAudience(svc) : null;
  const push_jobs = aud ? await claimPushJobs(svc, outbox, aud) : [];
  const assetOut = assets.map((a) => ({ id: a.id, symbol: a.symbol, market_type: a.market_type, binance_pair: binancePair(a), provider_symbol: a.provider_symbol }));
  return {
    server_time: Date.now(),
    assets: assetOut,
    signals: [
      ...rec.map((s) => ({ kind: "recommended", ...pick(s) })),
      ...viral.map((s) => ({ kind: "viral", ...pick(s) })),
    ],
    broker_connections: conns.map((c) => ({
      id: c.id, user_email: c.user_email, broker: c.broker, status: c.status,
      api_key_encrypted: c.api_key_encrypted, api_secret_encrypted: c.api_secret_encrypted,
      sync_cursor: c.sync_cursor, track_since: c.track_since,
    })),
    push_jobs,
  };
}

async function opSignalEvents(svc, body) {
  const items = body.items || [];
  const assets = await svc.entities.Assets.filter({ active: true }, "-created_date", 500);
  const assetsById = Object.fromEntries(assets.map((a) => [a.id, a]));
  const accepted: any[] = [];
  for (const kind of ["recommended", "viral"]) {
    const mine = items.filter((i) => i.kind === kind);
    if (!mine.length) continue;
    const res = await applyGuarded(svc, ENTITY[kind], mine);
    accepted.push(...res.map((r) => ({ kind, ...r })));
  }
  if (!accepted.length) return { accepted: 0, push_jobs: [] };
  const aud = await loadPushAudience(svc);
  const outbox = await notifyLifecycle(svc, accepted.filter((a) => a.events.length), aud, assetsById);
  const push_jobs = await claimPushJobs(svc, outbox, aud);
  return { accepted: accepted.length, events: accepted.reduce((n, a) => n + a.events.length, 0), push_jobs };
}

async function opPushResults(svc, body) {
  const results = body.results || [];
  const byOutbox: Record<string, any[]> = {};
  for (const r of results) (byOutbox[r.outbox_id] ||= []).push(r);
  const now = new Date().toISOString();
  const outboxUpdates = Object.entries(byOutbox).map(([id, rs]) => {
    const anyOk = rs.some((r) => r.ok);
    return { id, status: anyOk ? "sent" : "failed", sent_at: anyOk ? now : null, error: anyOk ? null : rs.map((r) => r.error).join("; ").slice(0, 500) };
  });
  if (outboxUpdates.length) await svc.entities.PushOutbox.bulkUpdate(outboxUpdates);
  for (const r of results) {
    if (!r.subscription_id) continue;
    if (r.ok) await svc.entities.PushSubscriptions.update(r.subscription_id, { last_success_at: now, failure_count: 0 });
    else if (r.status_code === 404 || r.status_code === 410) await svc.entities.PushSubscriptions.update(r.subscription_id, { active: false });
    else {
      const sub = await svc.entities.PushSubscriptions.get(r.subscription_id).catch(() => null);
      if (sub) await svc.entities.PushSubscriptions.update(sub.id, { failure_count: (sub.failure_count || 0) + 1, active: (sub.failure_count || 0) + 1 < 10 });
    }
  }
  return { updated: outboxUpdates.length };
}

async function opBrokerStatus(svc, body) {
  for (const u of body.updates || []) {
    const patch = { status: u.status, status_message: u.status_message || null, permissions: u.permissions ? JSON.stringify(u.permissions) : undefined };
    if (u.status === "rejected") Object.assign(patch, { api_key_encrypted: null, api_secret_encrypted: null }); // never keep unsafe keys
    await svc.entities.BrokerConnections.update(u.id, patch);
  }
  return { updated: (body.updates || []).length };
}

async function opBrokerFills(svc, body) {
  const { connection_id, user_email, fills = [], sync_cursor } = body;
  const conn = await svc.entities.BrokerConnections.get(connection_id).catch(() => null);
  if (!conn || conn.user_email !== user_email) return { error: "unknown connection" };

  const ids = fills.map((f) => f.external_trade_id);
  const existing = ids.length ? await svc.entities.BrokerFills.filter({ external_trade_id: { $in: ids } }, "-executed_at", ids.length) : [];
  const known = new Set(existing.map((f) => f.external_trade_id));
  const fresh = fills.filter((f) => !known.has(f.external_trade_id)).map((f) => ({ ...f, user_email, connection_id, broker: conn.broker }));

  let attributed = { fillPatches: [], executionCreates: [], executionUpdates: [] };
  if (fresh.length) {
    const bases: string[] = Array.from(new Set<string>(fresh.map((f: any) => String(f.base_asset))));
    const assets = await svc.entities.Assets.filter({ market_type: "crypto" }, "-created_date", 500);
    const assetByBase: Record<string, any> = {};
    for (const a of assets) {
      const pair = binancePair(a);
      if (pair) assetByBase[pair.replace(/USDT$/, "")] = a;
    }
    const assetIds = bases.map((b) => assetByBase[b]?.id).filter(Boolean);
    const earliest = fresh.reduce((m, f) => (f.executed_at < m ? f.executed_at : m), fresh[0].executed_at);
    const since = new Date(new Date(earliest).getTime() - 7 * 24 * 3600_000).toISOString();
    const [rec, viral, openEx] = await Promise.all([
      assetIds.length ? svc.entities.RecommendedTradeSignals.filter({ asset: { $in: assetIds }, timestamp: { $gte: since } }, "-timestamp", 1000) : [],
      assetIds.length ? svc.entities.ViralTradeSignals.filter({ asset: { $in: assetIds }, timestamp: { $gte: since } }, "-timestamp", 1000) : [],
      svc.entities.SignalExecutions.filter({ user_email, status: "open" }, "-opened_at", 500),
    ]);
    const baseByAssetId: Record<string, string> = Object.fromEntries(Object.entries(assetByBase).map(([b, a]: [string, any]) => [a.id, b]));
    const signalsByBase: Record<string, any[]> = {};
    for (const s of [...rec.map((x) => ({ ...x, kind: "recommended" })), ...viral.map((x) => ({ ...x, kind: "viral" }))]) {
      const b = baseByAssetId[s.asset];
      if (b) (signalsByBase[b] ||= []).push(s);
    }
    attributed = attributeFills(fresh, openEx, signalsByBase, user_email);
    const patchById = Object.fromEntries(attributed.fillPatches.map((p) => [p.external_trade_id, p]));
    const rows = fresh.map((f) => ({ ...f, ...(patchById[f.external_trade_id] || {}) }));
    await upsertBy(svc.entities.BrokerFills, rows, "external_trade_id");
    if (attributed.executionCreates.length) await svc.entities.SignalExecutions.bulkCreate(attributed.executionCreates);
    if (attributed.executionUpdates.length) await svc.entities.SignalExecutions.bulkUpdate(attributed.executionUpdates);
  }
  await svc.entities.BrokerConnections.update(connection_id, {
    last_sync_at: new Date().toISOString(),
    sync_cursor: sync_cursor ? JSON.stringify(sync_cursor) : conn.sync_cursor,
    status: "verified", status_message: null,
  });
  return {
    imported: fresh.length,
    matched: attributed.fillPatches.filter((p) => p.match_type !== "unmatched").length,
    executions_opened: attributed.executionCreates.length,
    executions_updated: attributed.executionUpdates.length,
  };
}
