// The signed-in user's verified performance (from read-only broker fills) and
// the platform's own signal track record (every resolved signal, not a sample).
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { getUser, json } from "../../shared/auth.js";
import { performanceStats } from "../../shared/attribution.js";

const TRIGGERED = new Set(["win", "loss", "expired_profit", "expired_loss", "expired_flat", "expired_open"]);

function platformStats(signals) {
  const triggered = signals.filter((s) => TRIGGERED.has(s.outcome));
  const decided = triggered.filter((s) => s.outcome === "win" || s.outcome === "loss");
  const wins = decided.filter((s) => s.outcome === "win").length;
  const rs = triggered.map((s) => s.outcome_r).filter((r) => r != null);
  const bySetup: Record<string, any> = {};
  for (const s of triggered) {
    const k = `${s.setup_type}|${s.direction}`;
    const b = (bySetup[k] ||= { setup_type: s.setup_type, direction: s.direction, n: 0, wins: 0, losses: 0, sum_r: 0 });
    b.n++; if (s.outcome === "win") b.wins++; if (s.outcome === "loss") b.losses++; b.sum_r += s.outcome_r ?? 0;
  }
  return {
    resolved: signals.length,
    triggered: triggered.length,
    untriggered: signals.filter((s) => s.outcome === "expired_untriggered" || s.outcome === "invalidated_untriggered").length,
    win_rate: decided.length ? wins / decided.length : null,
    avg_r: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : null,
    by_setup: Object.values(bySetup).map((b) => ({ ...b, win_rate: b.wins + b.losses ? b.wins / (b.wins + b.losses) : null, avg_r: b.n ? b.sum_r / b.n : null })),
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await getUser(base44);
    if (!user) return json({ error: "Unauthorized" }, 401);
    const svc = base44.asServiceRole;
    const { days = 90 } = await req.json().catch(() => ({}));
    const since = new Date(Date.now() - Math.min(365, Math.max(7, days)) * 24 * 3600_000).toISOString();

    const [executions, resolved, calibration, conns] = await Promise.all([
      svc.entities.SignalExecutions.filter({ user_email: user.email, opened_at: { $gte: since } }, "-opened_at", 2000),
      svc.entities.RecommendedTradeSignals.filter({ status: { $in: ["invalidated", "expired", "closed", "target_hit"] }, timestamp: { $gte: since } }, "-timestamp", 5000),
      svc.entities.SetupCalibration.filter({ scope: "market" }, "-n_effective", 200),
      svc.entities.BrokerConnections.filter({ user_email: user.email }, "-created_date", 10),
    ]);
    const assetIds = [...new Set(executions.map((e) => e.asset_id).filter(Boolean))];
    return json({
      window_days: days,
      has_broker: conns.some((c) => c.status === "verified"),
      user: performanceStats(executions),
      recent_executions: executions.slice(0, 50),
      platform: platformStats(resolved),
      calibration,
      asset_ids: assetIds,
    });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
