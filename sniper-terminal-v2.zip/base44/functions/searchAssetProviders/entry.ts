import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Search CoinGecko for crypto assets (no API key required)
async function searchCoinGecko(query) {
  try {
    const url = `https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(query)}`;
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.coins || []).slice(0, 8).map(c => ({
      provider: 'coingecko',
      provider_asset_id: c.id,
      provider_symbol: c.symbol?.toUpperCase(),
      symbol: c.symbol?.toUpperCase(),
      name: c.name,
      market_type: 'crypto',
      market_cap_rank: c.market_cap_rank,
      exchange: null,
      chain_id: null,
      token_address: null,
      pair_address: null,
    }));
  } catch {
    return [];
  }
}

// Search DEX Screener for on-chain / meme pairs (no API key required)
async function searchDexScreener(query) {
  try {
    const url = `https://api.dexscreener.com/latest/dex/search/?q=${encodeURIComponent(query)}`;
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.pairs || []).slice(0, 8).map(p => ({
      provider: 'dex_screener',
      provider_asset_id: p.pairAddress,
      provider_symbol: p.baseToken?.symbol?.toUpperCase(),
      symbol: p.baseToken?.symbol?.toUpperCase(),
      name: p.baseToken?.name,
      market_type: 'crypto',
      chain_id: p.chainId,
      token_address: p.baseToken?.address,
      pair_address: p.pairAddress,
      exchange: p.dexId,
      liquidity_usd: p.liquidity?.usd,
      volume_24h: p.volume?.h24,
      price_usd: p.priceUsd,
      market_cap_rank: null,
    }));
  } catch {
    return [];
  }
}

// Search Twelve Data for FX / commodity / index (requires TWELVE_DATA_API_KEY)
async function searchTwelveData(query, env) {
  const apiKey = env.TWELVE_DATA_API_KEY;
  if (!apiKey) {
    return { results: [], error: 'TWELVE_DATA_API_KEY not configured — add it to enable FX, commodity, and index search.' };
  }
  try {
    const url = `https://api.twelvedata.com/symbol_search?symbol=${encodeURIComponent(query)}&outputsize=8&apikey=${apiKey}`;
    const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
    if (!res.ok) return { results: [], error: `Twelve Data error: ${res.status}` };
    const data = await res.json();
    const results = (data.data || []).map(s => ({
      provider: 'twelve_data',
      provider_asset_id: s.symbol,
      provider_symbol: s.symbol,
      symbol: s.symbol,
      name: s.instrument_name,
      market_type: inferMarketType(s.instrument_type),
      exchange: s.exchange,
      currency: s.currency,
      chain_id: null,
      token_address: null,
      pair_address: null,
      market_cap_rank: null,
    }));
    return { results, error: null };
  } catch (e) {
    return { results: [], error: e.message };
  }
}

function inferMarketType(instrumentType) {
  if (!instrumentType) return 'index';
  const t = instrumentType.toLowerCase();
  if (t.includes('forex') || t.includes('fx') || t.includes('currency')) return 'fx';
  if (t.includes('commodity') || t.includes('metals') || t.includes('energy')) return 'commodity';
  return 'index';
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { query, market_type } = body;
    if (!query || query.trim().length < 1) {
      return Response.json({ error: 'Query is required' }, { status: 400 });
    }

    // Collect env vars at runtime inside the handler
    const env = {
      TWELVE_DATA_API_KEY: (() => { try { return Deno.env.get('TWELVE_DATA_API_KEY') || ''; } catch { return ''; } })(),
    };

    const q = query.trim();
    let results = [];
    let warnings = [];

    if (!market_type || market_type === 'crypto') {
      const [cg, dex] = await Promise.all([searchCoinGecko(q), searchDexScreener(q)]);
      results = [...cg, ...dex];
    } else {
      const { results: tdResults, error } = await searchTwelveData(q, env);
      results = tdResults;
      if (error) warnings.push(error);
    }

    // Deduplicate by provider+provider_asset_id
    const seen = new Set();
    const deduped = results.filter(r => {
      const key = `${r.provider}:${r.provider_asset_id}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    return Response.json({ results: deduped, warnings });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});