// Read-only broker connections for the signed-in user.
// ops: list | create | delete | resync
//
// Keys are encrypted (AES-256-GCM) before they are stored. The realtime worker
// verifies permissions with the broker and REJECTS (and wipes) any key that can
// trade or withdraw. This app never places orders.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { getUser, getSecret, json } from "../../shared/auth.js";
import { encryptSecret } from "../../shared/cryptoBox.js";

const MAX_CONNECTIONS = 3;
const PUBLIC_FIELDS = ["id", "broker", "label", "key_last4", "status", "status_message", "permissions", "last_sync_at", "track_since", "created_at"];
const publicView = (c) => Object.fromEntries(PUBLIC_FIELDS.map((k) => [k, c[k] ?? null]));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await getUser(base44);
    if (!user) return json({ error: "Unauthorized" }, 401);
    const svc = base44.asServiceRole;
    const body = await req.json().catch(() => ({}));
    const mine = () => svc.entities.BrokerConnections.filter({ user_email: user.email }, "-created_date", 20);

    if (body.op === "list") return json({ connections: (await mine()).map(publicView) });

    if (body.op === "create") {
      const { broker = "binance", label = "", api_key, api_secret, track_since } = body;
      if (broker !== "binance") return json({ error: "Only Binance is supported at the moment." }, 400);
      if (!/^[A-Za-z0-9]{32,128}$/.test(api_key || "") || !/^[A-Za-z0-9]{32,128}$/.test(api_secret || "")) {
        return json({ error: "That doesn't look like a Binance API key/secret pair." }, 400);
      }
      if ((await mine()).length >= MAX_CONNECTIONS) return json({ error: `Maximum of ${MAX_CONNECTIONS} connections.` }, 400);
      const encKey = getSecret("BROKER_ENCRYPTION_KEY");
      if (!encKey) return json({ error: "Broker sync is not configured on this server (BROKER_ENCRYPTION_KEY missing)." }, 503);
      const since = track_since ? new Date(track_since) : new Date(Date.now() - 30 * 24 * 3600_000);
      const row = await svc.entities.BrokerConnections.create({
        user_email: user.email, broker, label: String(label).slice(0, 60),
        api_key_encrypted: await encryptSecret(encKey, api_key),
        api_secret_encrypted: await encryptSecret(encKey, api_secret),
        key_last4: api_key.slice(-4), status: "pending_verification",
        status_message: "Waiting for the sync service to verify this key is read-only.",
        track_since: since.toISOString(), created_at: new Date().toISOString(),
      });
      return json({ connection: publicView(row) });
    }

    if (body.op === "delete" || body.op === "resync") {
      const conn = (await mine()).find((c) => c.id === body.id);
      if (!conn) return json({ error: "Not found" }, 404);
      if (body.op === "delete") {
        await svc.entities.BrokerConnections.delete(conn.id);
        if (body.purge_history) {
          const fills = await svc.entities.BrokerFills.filter({ connection_id: conn.id }, "-executed_at", 5000);
          for (const f of fills) await svc.entities.BrokerFills.delete(f.id);
        }
        return json({ success: true });
      }
      await svc.entities.BrokerConnections.update(conn.id, { sync_cursor: null, status_message: "Full resync requested." });
      return json({ success: true });
    }
    return json({ error: "Unknown op" }, 400);
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
