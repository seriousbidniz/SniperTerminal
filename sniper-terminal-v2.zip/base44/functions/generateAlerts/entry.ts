// Alert rules (shared with refreshAll). Scheduled by "Run Alert Rules" or run by an admin.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { authorizeJob, json } from "../../shared/auth.js";
import { generateAlertsInto } from "../../shared/pipeline.js";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const gate = await authorizeJob(base44, "generateAlerts", { minIntervalMs: 2 * 60_000, adminOnly: false });
    if (!gate.ok) return gate.response;
    const created = await generateAlertsInto(gate.svc);
    return json({ success: true, created });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
