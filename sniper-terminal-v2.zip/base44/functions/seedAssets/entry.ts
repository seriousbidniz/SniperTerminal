import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Seeds the Asset Universe with a curated list of 60+ liquid, high-coverage assets.
 * Skips assets that already exist (by symbol). Does NOT overwrite existing records.
 * Call this once to bootstrap coverage, then rely on refreshAll for data.
 */

const SEED_ASSETS = [
  // ── Crypto: Large cap ──────────────────────────────────────────────────────
  { symbol: "BTC", name: "Bitcoin",        market_type: "crypto", asset_class: "large_cap",  sector: "Store of Value",     liquidity_score: 98, data_provider: "coingecko", provider_asset_id: "bitcoin",       provider_symbol: "BTC" },
  { symbol: "ETH", name: "Ethereum",       market_type: "crypto", asset_class: "large_cap",  sector: "Layer 1",            liquidity_score: 96, data_provider: "coingecko", provider_asset_id: "ethereum",      provider_symbol: "ETH" },
  { symbol: "BNB", name: "BNB",            market_type: "crypto", asset_class: "large_cap",  sector: "Layer 1",            liquidity_score: 89, data_provider: "coingecko", provider_asset_id: "binancecoin",   provider_symbol: "BNB" },
  { symbol: "SOL", name: "Solana",         market_type: "crypto", asset_class: "large_cap",  sector: "Layer 1",            liquidity_score: 91, data_provider: "coingecko", provider_asset_id: "solana",        provider_symbol: "SOL" },
  { symbol: "XRP", name: "XRP",            market_type: "crypto", asset_class: "large_cap",  sector: "Payments",           liquidity_score: 90, data_provider: "coingecko", provider_asset_id: "ripple",        provider_symbol: "XRP" },
  { symbol: "ADA", name: "Cardano",        market_type: "crypto", asset_class: "large_cap",  sector: "Layer 1",            liquidity_score: 85, data_provider: "coingecko", provider_asset_id: "cardano",       provider_symbol: "ADA" },
  { symbol: "DOGE", name: "Dogecoin",      market_type: "crypto", asset_class: "large_cap",  sector: "Meme",               liquidity_score: 84, data_provider: "coingecko", provider_asset_id: "dogecoin",      provider_symbol: "DOGE" },
  { symbol: "AVAX", name: "Avalanche",     market_type: "crypto", asset_class: "large_cap",  sector: "Layer 1",            liquidity_score: 83, data_provider: "coingecko", provider_asset_id: "avalanche-2",   provider_symbol: "AVAX" },
  { symbol: "MATIC", name: "Polygon",      market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 2",            liquidity_score: 82, data_provider: "coingecko", provider_asset_id: "matic-network",  provider_symbol: "MATIC" },
  { symbol: "DOT", name: "Polkadot",       market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 0",            liquidity_score: 80, data_provider: "coingecko", provider_asset_id: "polkadot",      provider_symbol: "DOT" },
  { symbol: "LINK", name: "Chainlink",     market_type: "crypto", asset_class: "mid_cap",    sector: "Oracle",             liquidity_score: 82, data_provider: "coingecko", provider_asset_id: "chainlink",     provider_symbol: "LINK" },
  { symbol: "UNI",  name: "Uniswap",       market_type: "crypto", asset_class: "mid_cap",    sector: "DeFi",               liquidity_score: 78, data_provider: "coingecko", provider_asset_id: "uniswap",       provider_symbol: "UNI" },
  { symbol: "LTC",  name: "Litecoin",      market_type: "crypto", asset_class: "mid_cap",    sector: "Payments",           liquidity_score: 79, data_provider: "coingecko", provider_asset_id: "litecoin",      provider_symbol: "LTC" },
  { symbol: "ATOM", name: "Cosmos",        market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 0",            liquidity_score: 76, data_provider: "coingecko", provider_asset_id: "cosmos",        provider_symbol: "ATOM" },
  { symbol: "ICP",  name: "Internet Computer", market_type: "crypto", asset_class: "mid_cap", sector: "Layer 1",          liquidity_score: 72, data_provider: "coingecko", provider_asset_id: "internet-computer", provider_symbol: "ICP" },
  { symbol: "FIL",  name: "Filecoin",      market_type: "crypto", asset_class: "mid_cap",    sector: "Storage",            liquidity_score: 71, data_provider: "coingecko", provider_asset_id: "filecoin",      provider_symbol: "FIL" },
  { symbol: "APT",  name: "Aptos",         market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 1",            liquidity_score: 73, data_provider: "coingecko", provider_asset_id: "aptos",         provider_symbol: "APT" },
  { symbol: "ARB",  name: "Arbitrum",      market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 2",            liquidity_score: 75, data_provider: "coingecko", provider_asset_id: "arbitrum",      provider_symbol: "ARB" },
  { symbol: "OP",   name: "Optimism",      market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 2",            liquidity_score: 74, data_provider: "coingecko", provider_asset_id: "optimism",      provider_symbol: "OP" },
  { symbol: "SUI",  name: "Sui",           market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 1",            liquidity_score: 72, data_provider: "coingecko", provider_asset_id: "sui",           provider_symbol: "SUI" },
  { symbol: "INJ",  name: "Injective",     market_type: "crypto", asset_class: "mid_cap",    sector: "DeFi",               liquidity_score: 70, data_provider: "coingecko", provider_asset_id: "injective-protocol", provider_symbol: "INJ" },
  { symbol: "NEAR", name: "NEAR Protocol", market_type: "crypto", asset_class: "mid_cap",    sector: "Layer 1",            liquidity_score: 71, data_provider: "coingecko", provider_asset_id: "near",          provider_symbol: "NEAR" },
  { symbol: "TIA",  name: "Celestia",      market_type: "crypto", asset_class: "mid_cap",    sector: "Modular",            liquidity_score: 68, data_provider: "coingecko", provider_asset_id: "celestia",      provider_symbol: "TIA" },
  { symbol: "JUP",  name: "Jupiter",       market_type: "crypto", asset_class: "mid_cap",    sector: "DeFi",               liquidity_score: 67, data_provider: "coingecko", provider_asset_id: "jupiter-exchange-solana", provider_symbol: "JUP" },
  { symbol: "WIF",  name: "dogwifhat",     market_type: "crypto", asset_class: "small_cap",  sector: "Meme",               liquidity_score: 62, data_provider: "coingecko", provider_asset_id: "dogwifcoin",    provider_symbol: "WIF" },
  { symbol: "PEPE", name: "Pepe",          market_type: "crypto", asset_class: "small_cap",  sector: "Meme",               liquidity_score: 64, data_provider: "coingecko", provider_asset_id: "pepe",          provider_symbol: "PEPE" },
  { symbol: "BONK", name: "Bonk",          market_type: "crypto", asset_class: "small_cap",  sector: "Meme",               liquidity_score: 60, data_provider: "coingecko", provider_asset_id: "bonk",          provider_symbol: "BONK" },

  // ── FX: Major pairs ────────────────────────────────────────────────────────
  { symbol: "EUR/USD", name: "Euro / US Dollar",    market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 99, data_provider: "twelve_data", provider_asset_id: "EUR/USD", provider_symbol: "EUR/USD" },
  { symbol: "GBP/USD", name: "Pound / US Dollar",   market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 97, data_provider: "twelve_data", provider_asset_id: "GBP/USD", provider_symbol: "GBP/USD" },
  { symbol: "USD/JPY", name: "US Dollar / Yen",      market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 97, data_provider: "twelve_data", provider_asset_id: "USD/JPY", provider_symbol: "USD/JPY" },
  { symbol: "USD/CHF", name: "US Dollar / Franc",    market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 93, data_provider: "twelve_data", provider_asset_id: "USD/CHF", provider_symbol: "USD/CHF" },
  { symbol: "AUD/USD", name: "Australian / US Dollar", market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 92, data_provider: "twelve_data", provider_asset_id: "AUD/USD", provider_symbol: "AUD/USD" },
  { symbol: "USD/CAD", name: "US Dollar / Canadian",  market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 91, data_provider: "twelve_data", provider_asset_id: "USD/CAD", provider_symbol: "USD/CAD" },
  { symbol: "NZD/USD", name: "New Zealand / US Dollar", market_type: "fx", asset_class: "major_pair", sector: "Major FX", liquidity_score: 88, data_provider: "twelve_data", provider_asset_id: "NZD/USD", provider_symbol: "NZD/USD" },
  { symbol: "EUR/GBP", name: "Euro / Pound",          market_type: "fx", asset_class: "minor_pair", sector: "Minor FX", liquidity_score: 87, data_provider: "twelve_data", provider_asset_id: "EUR/GBP", provider_symbol: "EUR/GBP" },
  { symbol: "EUR/JPY", name: "Euro / Yen",             market_type: "fx", asset_class: "minor_pair", sector: "Minor FX", liquidity_score: 86, data_provider: "twelve_data", provider_asset_id: "EUR/JPY", provider_symbol: "EUR/JPY" },
  { symbol: "GBP/JPY", name: "Pound / Yen",            market_type: "fx", asset_class: "minor_pair", sector: "Minor FX", liquidity_score: 85, data_provider: "twelve_data", provider_asset_id: "GBP/JPY", provider_symbol: "GBP/JPY" },

  // ── Commodities ────────────────────────────────────────────────────────────
  { symbol: "XAUUSD", name: "Gold / USD",             market_type: "commodity", asset_class: "spot_commodity",    sector: "Precious Metals", liquidity_score: 95, data_provider: "twelve_data", provider_asset_id: "XAU/USD", provider_symbol: "XAU/USD" },
  { symbol: "XAGUSD", name: "Silver / USD",            market_type: "commodity", asset_class: "spot_commodity",    sector: "Precious Metals", liquidity_score: 88, data_provider: "twelve_data", provider_asset_id: "XAG/USD", provider_symbol: "XAG/USD" },
  { symbol: "WTIUSD", name: "WTI Crude Oil",           market_type: "commodity", asset_class: "futures_commodity", sector: "Energy",          liquidity_score: 91, data_provider: "twelve_data", provider_asset_id: "WTI/USD", provider_symbol: "WTI/USD" },
  { symbol: "BRENTUSD", name: "Brent Crude Oil",       market_type: "commodity", asset_class: "futures_commodity", sector: "Energy",          liquidity_score: 90, data_provider: "twelve_data", provider_asset_id: "BRENT/USD", provider_symbol: "BRENT/USD" },
  { symbol: "NATGAS", name: "Natural Gas",              market_type: "commodity", asset_class: "futures_commodity", sector: "Energy",          liquidity_score: 80, data_provider: "twelve_data", provider_asset_id: "NATGAS/USD", provider_symbol: "NATGAS/USD" },
  { symbol: "COPPER", name: "Copper",                   market_type: "commodity", asset_class: "futures_commodity", sector: "Base Metals",     liquidity_score: 78, data_provider: "twelve_data", provider_asset_id: "COPPER/USD", provider_symbol: "COPPER/USD" },

  // ── Indices ────────────────────────────────────────────────────────────────
  { symbol: "SPX", name: "S&P 500",                    market_type: "index", asset_class: "large_cap", sector: "US Equity",     liquidity_score: 99, data_provider: "twelve_data", provider_asset_id: "SPX", provider_symbol: "SPX" },
  { symbol: "NDX", name: "Nasdaq 100",                  market_type: "index", asset_class: "large_cap", sector: "US Tech",       liquidity_score: 98, data_provider: "twelve_data", provider_asset_id: "NDX", provider_symbol: "NDX" },
  { symbol: "DJI", name: "Dow Jones Industrial",        market_type: "index", asset_class: "large_cap", sector: "US Equity",     liquidity_score: 97, data_provider: "twelve_data", provider_asset_id: "DJI", provider_symbol: "DJI" },
  { symbol: "VIX", name: "CBOE Volatility Index",       market_type: "index", asset_class: "large_cap", sector: "Volatility",    liquidity_score: 93, data_provider: "twelve_data", provider_asset_id: "VIX", provider_symbol: "VIX" },
  { symbol: "FTSE", name: "FTSE 100",                   market_type: "index", asset_class: "large_cap", sector: "UK Equity",     liquidity_score: 91, data_provider: "twelve_data", provider_asset_id: "FTSE", provider_symbol: "FTSE" },
  { symbol: "DAX",  name: "DAX 40",                     market_type: "index", asset_class: "large_cap", sector: "EU Equity",     liquidity_score: 90, data_provider: "twelve_data", provider_asset_id: "DAX", provider_symbol: "DAX" },
  { symbol: "NKY",  name: "Nikkei 225",                 market_type: "index", asset_class: "large_cap", sector: "JP Equity",     liquidity_score: 89, data_provider: "twelve_data", provider_asset_id: "NKY", provider_symbol: "NKY" },
  { symbol: "HSI",  name: "Hang Seng Index",            market_type: "index", asset_class: "large_cap", sector: "HK Equity",     liquidity_score: 87, data_provider: "twelve_data", provider_asset_id: "HSI", provider_symbol: "HSI" },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Fetch existing assets to check for duplicates
    const existing = await base44.entities.Assets.list('-created_date', 500);
    const existingSymbols = new Set(existing.map(a => (a.symbol || '').toUpperCase()));

    const toCreate = SEED_ASSETS.filter(a => !existingSymbols.has(a.symbol.toUpperCase()));

    let created = 0;
    const errors = [];

    for (const asset of toCreate) {
      try {
        await base44.entities.Assets.create({
          ...asset,
          active: true,
          status: 'pending_data',
          data_status: 'pending',
          user_added: false,
        });
        created++;
      } catch (e) {
        errors.push({ symbol: asset.symbol, error: e.message });
      }
    }

    return Response.json({
      success: true,
      total_seed: SEED_ASSETS.length,
      already_existed: existingSymbols.size,
      created,
      skipped: SEED_ASSETS.length - toCreate.length,
      errors,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});