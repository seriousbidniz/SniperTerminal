import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// ─── Response cache (30 sec TTL per provider/symbol) ────────────────────────
const responseCache = new Map();

function cacheKey(provider, symbol) {
  return `${provider}::${symbol}`;
}

function getCached(provider, symbol) {
  const key = cacheKey(provider, symbol);
  const cached = responseCache.get(key);
  if (!cached) return null;
  if (Date.now() - cached.timestamp > 30_000) {
    responseCache.delete(key);
    return null;
  }
  return cached.data;
}

function setCached(provider, symbol, data) {
  const key = cacheKey(provider, symbol);
  responseCache.set(key, { data, timestamp: Date.now() });
}

// ─── Provider 1: CoinGecko (best for metadata, market cap rank) ──────────────

async function fetchCoinGecko(symbol, coinId) {
  if (!coinId) return { success: false, error: "No coin ID provided" };

  const cached = getCached("coingecko", symbol);
  if (cached) return cached;

  try {
    const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(coinId)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });

    if (res.status === 429) {
      return { success: false, error: "CoinGecko rate limit" };
    }
    if (!res.ok) return { success: false, error: `HTTP ${res.status}` };

    const data = await res.json();
    if (data.error) return { success: false, error: data.error };

    const md = data.market_data || {};
    const links = data.links || {};
    
    const result = {
      success: true,
      provider: "coingecko",
      symbol,
      fields: {
        price: md.current_price?.usd ?? null,
        volume_24h: md.total_volume?.usd ?? null,
        market_cap: md.market_cap?.usd ?? null,
        market_cap_rank: data.market_cap_rank ?? null,
        change_24h: md.price_change_percentage_24h ?? null,
      },
      // Extract research links from CoinGecko metadata
      links: {
        coingecko_profile_url: `https://www.coingecko.com/en/coins/${coinId}`,
        official_website_url: links.homepage?.[0] ?? null,
        docs_url: links.documentation_url?.[0] ?? null,
        where_to_buy_url: `https://www.coingecko.com/en/coins/${coinId}#markets`,
        explorer_url: links.blockchain_site?.[0] ?? null,
        x_url: links.twitter_screen_name ? `https://x.com/${links.twitter_screen_name}` : null,
        discord_url: links.chat_url?.[0] ?? null,
        github_url: links.repos_url?.github?.[0] ?? null,
      },
    };

    setCached("coingecko", symbol, result);
    return result;
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ─── Extract and apply link metadata to asset record ────────────────────────

async function applyResearchLinks(base44, assetId, provider, cgResult) {
  try {
    if (provider === "coingecko" && cgResult?.success && cgResult.links) {
      // Only update if we have new link data from CoinGecko
      const linkData = {};
      for (const [key, val] of Object.entries(cgResult.links)) {
        if (val) linkData[key] = val;
      }
      if (Object.keys(linkData).length > 0) {
        await base44.entities.Assets.update(assetId, linkData);
      }
    }
  } catch (e) {
    // Fail silently — link updates are non-critical
    console.warn(`Failed to update links for asset ${assetId}:`, e.message);
  }
}

// ─── Provider 2: Binance (best for price, volume, intraday data) ────────────

async function fetchBinance(symbol) {
  const cached = getCached("binance", symbol);
  if (cached) return cached;

  try {
    // Try as USDT pair first
    const pair = `${symbol.toUpperCase()}USDT`;
    const tickerUrl = `https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${encodeURIComponent(pair)}`;
    const res = await fetch(tickerUrl);

    if (res.status === 404) {
      return { success: false, error: `${pair} not found on Binance` };
    }
    if (!res.ok) return { success: false, error: `HTTP ${res.status}` };

    const data = await res.json();

    const result = {
      success: true,
      provider: "binance",
      symbol,
      fields: {
        price: parseFloat(data.lastPrice || "0") || null,
        volume_24h: parseFloat(data.quoteAssetVolume || "0") || null,
        change_24h: parseFloat(data.priceChangePercent || "0") || null,
        // Binance /klines endpoint needed for 1h/4h, but adds complexity
        // For now, mark as null to avoid fetching additional endpoints
      },
    };

    setCached("binance", symbol, result);
    return result;
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ─── Provider 3: CoinPaprika (backup, covers more assets) ────────────────────

async function fetchCoinPaprika(symbol, coinId) {
  if (!coinId) return { success: false, error: "No coin ID provided" };

  const cached = getCached("coinpaprika", symbol);
  if (cached) return cached;

  try {
    const url = `https://api.coinpaprika.com/v1/coins/${encodeURIComponent(coinId)}`;
    const res = await fetch(url);

    if (res.status === 404) {
      return { success: false, error: `Coin not found` };
    }
    if (!res.ok) return { success: false, error: `HTTP ${res.status}` };

    const data = await res.json();
    const quotes = data.quotes?.USD || {};

    const result = {
      success: true,
      provider: "coinpaprika",
      symbol,
      fields: {
        price: quotes.price ?? null,
        volume_24h: quotes.volume_24h ?? null,
        market_cap: quotes.market_cap ?? null,
        change_24h: quotes.percent_change_24h ?? null,
      },
    };

    setCached("coinpaprika", symbol, result);
    return result;
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ─── Field-level merger: pick best value from available sources ─────────────

function mergeFields(coinGeckoResult, binanceResult, paprikaResult, asset) {
  const providers = {};
  const merged = {
    price: null,
    volume_24h: null,
    market_cap: null,
    market_cap_rank: null,
    change_24h: null,
  };

  // Price hierarchy: Binance > CoinGecko > CoinPaprika
  if (binanceResult?.success && binanceResult.fields.price != null) {
    merged.price = binanceResult.fields.price;
    providers.price = "binance";
  } else if (coinGeckoResult?.success && coinGeckoResult.fields.price != null) {
    merged.price = coinGeckoResult.fields.price;
    providers.price = "coingecko";
  } else if (paprikaResult?.success && paprikaResult.fields.price != null) {
    merged.price = paprikaResult.fields.price;
    providers.price = "coinpaprika";
  }

  // Volume hierarchy: Binance > CoinGecko > CoinPaprika
  if (binanceResult?.success && binanceResult.fields.volume_24h != null) {
    merged.volume_24h = binanceResult.fields.volume_24h;
    providers.volume_24h = "binance";
  } else if (coinGeckoResult?.success && coinGeckoResult.fields.volume_24h != null) {
    merged.volume_24h = coinGeckoResult.fields.volume_24h;
    providers.volume_24h = "coingecko";
  } else if (paprikaResult?.success && paprikaResult.fields.volume_24h != null) {
    merged.volume_24h = paprikaResult.fields.volume_24h;
    providers.volume_24h = "coinpaprika";
  }

  // Market cap: CoinGecko preferred (most reliable)
  if (coinGeckoResult?.success && coinGeckoResult.fields.market_cap != null) {
    merged.market_cap = coinGeckoResult.fields.market_cap;
    providers.market_cap = "coingecko";
  } else if (paprikaResult?.success && paprikaResult.fields.market_cap != null) {
    merged.market_cap = paprikaResult.fields.market_cap;
    providers.market_cap = "coinpaprika";
  }

  // Market cap rank: CoinGecko only (most reliable)
  if (coinGeckoResult?.success && coinGeckoResult.fields.market_cap_rank != null) {
    merged.market_cap_rank = coinGeckoResult.fields.market_cap_rank;
    providers.market_cap_rank = "coingecko";
  }

  // 24h change: average of available sources for robustness
  const changeValues = [];
  if (coinGeckoResult?.success && coinGeckoResult.fields.change_24h != null) {
    changeValues.push(coinGeckoResult.fields.change_24h);
  }
  if (binanceResult?.success && binanceResult.fields.change_24h != null) {
    changeValues.push(binanceResult.fields.change_24h);
  }
  if (paprikaResult?.success && paprikaResult.fields.change_24h != null) {
    changeValues.push(paprikaResult.fields.change_24h);
  }
  if (changeValues.length > 0) {
    merged.change_24h = changeValues.reduce((a, b) => a + b, 0) / changeValues.length;
    providers.change_24h = changeValues.length > 1 ? "averaged" : (changeValues.length === 1 ? "coingecko" : "unknown");
  }

  return { merged, providers };
}

// ─── Data quality and completeness check ───────────────────────────────────

function assessSnapshot(merged) {
  const required = ["price"];
  const recommended = ["price", "volume_24h", "change_24h"];

  const missing = [];
  for (const field of required) {
    if (merged[field] == null) missing.push(field);
  }

  if (missing.length > 0) {
    return { quality: "failed", confidence: 0, missing };
  }

  const recommendedMissing = [];
  for (const field of recommended) {
    if (merged[field] == null) recommendedMissing.push(field);
  }

  if (recommendedMissing.length === 0) {
    return { quality: "complete", confidence: 90, missing: [] };
  }

  if (recommendedMissing.length <= 1) {
    return { quality: "complete", confidence: 75, missing: recommendedMissing };
  }

  return { quality: "partial", confidence: 50, missing: recommendedMissing };
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const now = new Date().toISOString();
    const allAssets = await base44.entities.Assets.filter({ active: true });
    const refreshable = allAssets.filter(a => a.data_provider && a.data_provider !== "manual");

    const results = [];
    const snapshots = [];
    let written = 0, failed = 0, partial = 0;

    // ── Fetch from multiple sources per asset ──────────────────────────────
    for (const asset of refreshable) {
      const symbol = asset.symbol;

      // Parallel fetch from all sources
      const [cgResult, binanceResult, paprikaResult] = await Promise.all([
        fetchCoinGecko(symbol, asset.provider_asset_id),
        fetchBinance(symbol),
        fetchCoinPaprika(symbol, asset.provider_asset_id),
      ]);

      // Field-level merge (not all-or-nothing)
      const { merged, providers } = mergeFields(cgResult, binanceResult, paprikaResult, asset);
      const quality = assessSnapshot(merged);

      // Skip if no price data
      if (quality.quality === "failed") {
        failed++;
        results.push({
          symbol,
          status: "failed",
          reason: `Missing critical fields: ${quality.missing.join(", ")}`,
        });
        continue;
      }

      // Track partial data
      if (quality.quality === "partial") partial++;

      // Create snapshot with explicit provider tracking
      const snap = {
        asset: asset.id,
        timestamp: now,
        price: merged.price,
        volume: merged.volume_24h, // Note: MarketSnapshots uses 'volume', not 'volume_24h'
        change_24h: merged.change_24h,
        // Set all other fields to null (explicit, not defaults)
        change_1h: null,
        change_4h: null,
        volatility: null,
        rsi: null,
        trend_score_input: null,
        momentum_score_input: null,
        catalyst_score_input: null,
        sentiment_score_input: null,
        attention_score_input: null,
        // Debug metadata
        _data_quality: quality.quality,
        _source_providers: providers,
        _missing_fields: quality.missing,
        _confidence: quality.confidence,
        _fetch_time: now,
      };

      snapshots.push({
        snap,
        assetId: asset.id,
        symbol,
        quality,
        providers,
        cgResult, // Pass CoinGecko result for link extraction
      });

      results.push({
        symbol,
        status: "fetched",
        quality: quality.quality,
        providers: Object.keys(providers).length > 0 ? providers : "no providers succeeded",
        missing: quality.missing,
      });
    }

    // ── Write snapshots and apply research links ───────────────────────────
    for (const { snap, assetId, symbol, quality, cgResult } of snapshots) {
      try {
        await base44.entities.MarketSnapshots.create(snap);

        // Update asset status
        const status = quality.quality === "complete" ? "active" : quality.quality === "partial" ? "pending_data" : "error";
        await base44.entities.Assets.update(assetId, {
          status,
          data_status: "ok",
          last_refresh_at: now,
          data_error: null,
        });

        // Apply research links from CoinGecko if available
        await applyResearchLinks(base44, assetId, "coingecko", cgResult);

        written++;
      } catch (e) {
        console.error(`Failed to write snapshot for ${symbol}:`, e.message);
        failed++;
      }
    }

    return Response.json({
      success: true,
      timestamp: now,
      summary: {
        total_assets: refreshable.length,
        fetched: snapshots.length,
        written,
        partial_quality: partial,
        failed,
      },
      details: results.slice(0, 50),
    });
  } catch (error) {
    console.error("fetchMultiSourceSnapshots error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});