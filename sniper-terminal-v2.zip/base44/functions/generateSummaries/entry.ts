import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// ─── Staleness check ──────────────────────────────────────────────────────────
const STALE_MS = 4 * 60 * 60 * 1000; // 4 hours

function isStale(timestamp) {
  if (!timestamp) return true;
  return Date.now() - new Date(timestamp).getTime() > STALE_MS;
}

// ─── Recommended trade summary ────────────────────────────────────────────────
// Only reads: direction, setup_type, opportunity_score, conviction_score,
// risk_score, entry_low, entry_high, invalidation, what_kills_it,
// score_boost_factors, score_penalty_factors, timestamp
function summariseRecommended(signal) {
  const dir = signal.direction || "neutral";
  const setup = signal.setup_type ? signal.setup_type.replace(/_/g, " ") : null;
  const opp = signal.opportunity_score ?? null;
  const conv = signal.conviction_score ?? null;
  const risk = signal.risk_score ?? null;
  const stale = isStale(signal.timestamp);
  const hasEntry = signal.entry_low != null || signal.entry_high != null;
  const hasInv = signal.invalidation != null;

  const parts = [];

  // Direction + setup
  if (setup) {
    parts.push(`${dir.charAt(0).toUpperCase() + dir.slice(1)} ${setup} setup.`);
  } else {
    parts.push(`${dir.charAt(0).toUpperCase() + dir.slice(1)} setup.`);
  }

  // Score summary — factual only
  if (opp != null && conv != null) {
    if (opp >= 70 && risk != null && risk < 45) {
      parts.push(`Scores: opportunity ${opp}, conviction ${conv}, risk ${risk} — strong alignment across factors.`);
    } else if (opp >= 55) {
      parts.push(`Scores: opportunity ${opp}, conviction ${conv}${risk != null ? `, risk ${risk}` : ""} — moderate alignment.`);
    } else {
      parts.push(`Scores: opportunity ${opp}, conviction ${conv}${risk != null ? `, risk ${risk}` : ""} — signal is at or near threshold.`);
    }
  }

  // Risk context
  if (risk != null && risk >= 65) {
    parts.push(`Elevated risk score (${risk}) — conditions are volatile, illiquid, or overextended.`);
  }

  // Key levels
  if (hasEntry && hasInv) {
    const entryStr = signal.entry_low != null && signal.entry_high != null
      ? `$${signal.entry_low.toLocaleString()} – $${signal.entry_high.toLocaleString()}`
      : signal.entry_low != null ? `$${signal.entry_low.toLocaleString()}` : `$${signal.entry_high.toLocaleString()}`;
    parts.push(`Entry zone: ${entryStr}. Invalidation at $${signal.invalidation.toLocaleString()}.`);
  } else if (hasInv) {
    parts.push(`Invalidation at $${signal.invalidation.toLocaleString()}.`);
  }

  // Boost/penalty if present
  if (signal.score_boost_factors) {
    parts.push(signal.score_boost_factors);
  }
  if (signal.score_penalty_factors && signal.score_penalty_factors !== "No significant penalties applied — all risk inputs are within acceptable ranges.") {
    parts.push(signal.score_penalty_factors);
  }

  // Stale warning
  if (stale) {
    parts.push("⚠ Data is more than 4 hours old — prices and levels may no longer reflect current market conditions. Verify independently before acting.");
  }

  parts.push("Not financial advice. Independent research required.");

  return parts.join(" ");
}

// ─── Viral trade summary ──────────────────────────────────────────────────────
// Only reads: viral_score, ai_label, move_state, attention_score,
// volume_spike_score, sentiment_spike_score, liquidity_quality_score,
// crowding_score, exhaustion_score, viral_boost_factors, viral_penalty_factors,
// timestamp
function summariseViral(signal) {
  const viral = signal.viral_score ?? null;
  const label = signal.ai_label || "caution";
  const state = signal.move_state || "building";
  const liq = signal.liquidity_quality_score ?? null;
  const crowding = signal.crowding_score ?? null;
  const exhaustion = signal.exhaustion_score ?? null;
  const stale = isStale(signal.timestamp);

  const parts = [];

  // Lead: virality is about attention, not quality
  if (viral != null) {
    parts.push(`Viral score: ${viral}/100 — this reflects market attention, not setup quality.`);
  }

  // Move state — be neutral
  if (state === "exhausted") {
    parts.push("Move state: exhausted. The spike appears to have run its course — late entries face high reversal risk.");
  } else if (state === "crowded") {
    parts.push("Move state: crowded. Significant crowd participation detected — new entries carry elevated reversal risk.");
  } else if (state === "building") {
    parts.push("Move state: building. Participation is increasing. Monitor for signs of crowding before committing.");
  } else if (state === "early") {
    parts.push("Move state: early. Limited crowd participation so far, but confirm the driver independently.");
  }

  // Label — specific and honest
  if (label === "tradable") {
    if (liq != null && liq < 50) {
      parts.push(`Labelled tradable, but liquidity quality is ${liq}/100 — position sizing should be limited.`);
    } else {
      parts.push("Labelled tradable: liquidity and exhaustion risk are within acceptable ranges for early entry.");
    }
  } else if (label === "caution") {
    const reasons = [];
    if (crowding != null && crowding >= 40) reasons.push(`crowding score ${crowding}`);
    if (liq != null && liq < 50) reasons.push(`low liquidity (${liq})`);
    if (exhaustion != null && exhaustion >= 45) reasons.push(`elevated exhaustion (${exhaustion})`);
    parts.push(`Labelled caution${reasons.length > 0 ? ": " + reasons.join(", ") : ""} — reduce sizing and tighten stops if entering.`);
  } else if (label === "avoid") {
    if (liq != null && liq < 30) {
      parts.push(`Labelled avoid: liquidity (${liq}/100) is too thin for safe execution.`);
    } else {
      parts.push("Labelled avoid: exhaustion or crowding risk is too high for new entries.");
    }
  }

  // Boost/penalty factors if set
  if (signal.viral_boost_factors) {
    parts.push(signal.viral_boost_factors);
  }
  if (signal.viral_penalty_factors && signal.viral_penalty_factors !== "No significant penalties — move shows acceptable risk profile for its viral score.") {
    parts.push(signal.viral_penalty_factors);
  }

  // Stale warning
  if (stale) {
    parts.push("⚠ Data is more than 4 hours old — viral momentum may have changed significantly. Do not act on this without refreshing.");
  }

  parts.push("Viral signals reflect attention, not fundamentals. Not financial advice.");

  return parts.join(" ");
}

// ─── Alert summary ────────────────────────────────────────────────────────────
// Only reads: alert_type, severity, trigger_reason, action_classification
function summariseAlert(alert) {
  const type = alert.alert_type || "indicator";
  const severity = alert.severity || "medium";
  const classification = alert.action_classification || "watch";
  const trigger = alert.trigger_reason || "";

  const parts = [];

  // Action framing
  const actionMap = {
    act_now: "Action required",
    reduce_risk: "Risk management required",
    exit_hedge: "Consider exit or hedge",
    prepare: "Prepare — monitor closely",
    watch: "Watch — no immediate action needed",
    ignore: "Informational only",
  };
  const actionLabel = actionMap[classification] || "Monitor";
  parts.push(`${actionLabel}.`);

  // Severity context
  if (severity === "critical") {
    parts.push("Severity: critical — conditions may require immediate attention.");
  } else if (severity === "high") {
    parts.push("Severity: high.");
  }

  // Trigger reason (already factual from the rule engine)
  if (trigger) {
    parts.push(trigger);
  }

  // Type-specific guidance — conservative
  if (type === "stop_loss" && classification === "exit_hedge") {
    parts.push("Review your stop-loss, assess whether the thesis remains valid, and decide on position size.");
  } else if (type === "take_profit" && classification === "prepare") {
    parts.push("Consider taking partial profits or raising your stop-loss to protect gains.");
  } else if (type === "opportunity_score") {
    parts.push("Review entry zone and risk level independently before acting.");
  } else if (type === "viral_score") {
    parts.push("Viral signals reflect attention only — verify with your own analysis.");
  } else if (type === "indicator" && classification === "reduce_risk") {
    parts.push("Check current position size and stop-loss placement.");
  }

  return parts.join(" ");
}

// ─── Main Handler ─────────────────────────────────────────────────────────────
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const mode = body.mode || "all"; // "recommended" | "viral" | "alerts" | "all"

    const counts = { recommended: 0, viral: 0, alerts: 0 };

    // ── Recommended ────────────────────────────────────────────────────────────
    if (mode === "all" || mode === "recommended") {
      const signals = await base44.entities.RecommendedTradeSignals.filter({ status: "active" }, "-opportunity_score", 200);
      for (const s of signals) {
        const summary = summariseRecommended(s);
        if (summary !== s.why_now) { // avoid no-op writes — use why_now as a proxy check
          await base44.entities.RecommendedTradeSignals.update(s.id, { why_now: summary });
          counts.recommended++;
        }
      }
    }

    // ── Viral ──────────────────────────────────────────────────────────────────
    if (mode === "all" || mode === "viral") {
      const signals = await base44.entities.ViralTradeSignals.filter({ status: "active" }, "-viral_score", 200);
      for (const s of signals) {
        const summary = summariseViral(s);
        if (summary !== s.summary) {
          await base44.entities.ViralTradeSignals.update(s.id, { summary });
          counts.viral++;
        }
      }
    }

    // ── Alerts ─────────────────────────────────────────────────────────────────
    if (mode === "all" || mode === "alerts") {
      const alerts = await base44.entities.Alerts.filter({ status: "active" }, "-triggered_at", 200);
      for (const a of alerts) {
        const summary = summariseAlert(a);
        if (summary !== a.summary) {
          await base44.entities.Alerts.update(a.id, { summary });
          counts.alerts++;
        }
      }
    }

    return Response.json({ success: true, updated: counts });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});