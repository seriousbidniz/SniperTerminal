// Legacy single-quote provider fetchers (CoinGecko / DEX Screener / Yahoo / Twelve Data).
// Kept so user-added assets that have no hourly candle history (e.g. DEX-only tokens)
// still get a price snapshot and a liquidity estimate. They no longer generate signals.
function clamp(v, lo = 0, hi = 100) { return Math.max(lo, Math.min(hi, v)); }
function norm(v) { return (v == null || isNaN(v)) ? 50 : clamp(v); }
// ─── Provider fetchers ────────────────────────────────────────────────────────

async function fetchCoinGecko(providerAssetId) {
  if (!providerAssetId) throw new Error("CoinGecko requires provider_asset_id (coin ID)");
  const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(providerAssetId)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (res.status === 429) throw new Error("CoinGecko rate limit hit — try again in a few minutes");
  if (!res.ok) throw new Error(`CoinGecko HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(`CoinGecko: ${data.error}`);
  const md = data.market_data || {};
  const price = md.current_price?.usd;
  if (!price) throw new Error("CoinGecko returned no price for this asset");

  const volume = md.total_volume?.usd ?? null;
  const marketCap = md.market_cap?.usd ?? null;
  const change1h = md.price_change_percentage_1h_in_currency?.usd ?? null;
  // CoinGecko free tier rarely returns 4h — derive from 1h and 24h as a proxy
  const change4hRaw = md.price_change_percentage_4h_in_currency?.usd ?? null;
  const change24h = md.price_change_percentage_24h ?? null;
  const change7d = md.price_change_percentage_7d ?? null;
  // If 4h not available, approximate: 4h ≈ 24h/4 + small adjustment from 1h signal
  const change4h = change4hRaw ?? (
    change24h != null && change1h != null
      ? clamp(change24h / 4 + change1h * 0.5, -50, 50)
      : change24h != null ? change24h / 4 : null
  );

  const rank = data.market_cap_rank || 500;
  const liquidity_score = clamp(Math.round(100 - (rank / 500) * 80), 5, 100);

  // Volume spike: compare 24h volume to rough expected (market_cap * typical daily turnover ~2%)
  let volume_change_percent = null;
  if (volume != null && marketCap != null && marketCap > 0) {
    const expectedVolume = marketCap * 0.02; // 2% daily turnover baseline
    volume_change_percent = clamp(((volume - expectedVolume) / expectedVolume) * 100, -100, 500);
  }

  // RSI proxy: use 24h change to estimate momentum direction
  const rsi = change24h != null ? clamp(50 + change24h * 1.8, 10, 90) : null;

  // Attention: combine rank tier + absolute price momentum
  const absChange = Math.abs(change24h || 0);
  const rankBase = rank <= 10 ? 75 : rank <= 50 ? 65 : rank <= 200 ? 50 : 35;
  const momentumBoost = clamp(absChange * 2, 0, 25); // big movers get attention boost
  const attention_score_input = clamp(rankBase + momentumBoost, 5, 95);

  // Sentiment: derive from direction and magnitude of 24h + 7d alignment
  let sentiment = 50;
  if (change24h != null) {
    sentiment += change24h * 2;
    if (change7d != null && Math.sign(change24h) === Math.sign(change7d)) {
      sentiment += 8; // aligned trend adds sentiment confidence
    }
  }
  const sentiment_score_input = clamp(Math.round(sentiment), 5, 95);

  // Trend: 7d direction combined with 24h confirmation
  let trend = 50;
  if (change7d != null) trend += change7d * 1.2;
  if (change24h != null) trend += change24h * 1.0;
  const trend_score_input = clamp(Math.round(trend), 5, 95);

  // Momentum: weighted toward short-term (1h heavily weighted)
  let momentum = 50;
  if (change1h != null) momentum += change1h * 6;
  if (change24h != null) momentum += change24h * 1.5;
  const momentum_score_input = clamp(Math.round(momentum), 5, 95);

  const volatility = clamp(Math.abs(change24h || 0) * 2.5 + Math.abs(change1h || 0) * 1.5, 0, 100);

  return {
    price, volume,
    change_1h: change1h,
    change_4h: change4h,
    change_24h: change24h,
    volume_change_percent,
    volatility,
    rsi,
    trend_score_input,
    momentum_score_input,
    catalyst_score_input: 50,
    sentiment_score_input,
    attention_score_input,
    liquidity_score,
  };
}

async function fetchDexScreener(chainId, pairAddress) {
  if (!chainId || !pairAddress) throw new Error("DEX Screener requires chain_id and pair_address");
  const url = `https://api.dexscreener.com/latest/dex/pairs/${encodeURIComponent(chainId)}/${encodeURIComponent(pairAddress)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`DEX Screener HTTP ${res.status}`);
  const data = await res.json();
  const pair = (data.pairs || [])[0];
  if (!pair) throw new Error("Pair not found on DEX Screener — may have been delisted or address changed");
  const price = parseFloat(pair.priceUsd || "0");
  if (!price) throw new Error("DEX Screener returned zero price");
  const volume = pair.volume?.h24 || 0;
  const change24h = pair.priceChange?.h24 || 0;
  const change1h = pair.priceChange?.h1 || 0;
  const change4h = pair.priceChange?.h6 ? pair.priceChange.h6 / 1.5 : null; // approx from h6
  const liquidity_usd = pair.liquidity?.usd || 0;
  const liquidity_score = clamp(Math.round((liquidity_usd / 1_000_000) * 30 + 10), 5, 100);
  return {
    price, volume,
    change_1h: change1h, change_4h: change4h, change_24h: change24h,
    volatility: clamp(Math.abs(change24h) * 2.5, 0, 100),
    rsi: clamp(50 + change24h * 1.5, 10, 90),
    trend_score_input: clamp(50 + change24h * 2, 5, 95),
    momentum_score_input: clamp(50 + change1h * 5, 5, 95),
    catalyst_score_input: 50,
    sentiment_score_input: 50,
    attention_score_input: liquidity_score > 50 ? 65 : 40,
    liquidity_score,
  };
}

// Map our internal symbols to Yahoo Finance tickers for fallback
const YAHOO_SYMBOL_MAP = {
  // Indices
  "SPX": "^GSPC", "SP500": "^GSPC",
  "NDX": "^NDX", "NASDAQ": "^IXIC",
  "DJI": "^DJI", "DOW": "^DJI",
  "FTSE": "^FTSE",
  "DAX": "^GDAXI",
  "NKY": "^N225",
  "HSI": "^HSI",
  "VIX": "^VIX",
  "CAC40": "^FCHI",
  "RUT": "^RUT",
  // Commodities
  "GOLD": "GC=F", "XAU": "GC=F", "XAU/USD": "GC=F",
  "SILVER": "SI=F", "XAG": "SI=F", "XAG/USD": "SI=F",
  "OIL": "CL=F", "WTI": "CL=F", "USOIL": "CL=F",
  "BRENT": "BZ=F", "UKOIL": "BZ=F", "BRENTUSD": "BZ=F", "BRENT/USD": "BZ=F",
  "NATGAS": "NG=F", "NATGAS/USD": "NG=F",
  "COPPER": "HG=F", "COPPER/USD": "HG=F",
  "PLATINUM": "PL=F", "XPT/USD": "PL=F",
  "PALLADIUM": "PA=F",
  "WHEAT": "ZW=F",
  "CORN": "ZC=F",
  // FX (Yahoo uses =X suffix)
  "EUR/USD": "EURUSD=X", "EURUSD": "EURUSD=X",
  "GBP/USD": "GBPUSD=X", "GBPUSD": "GBPUSD=X",
  "USD/JPY": "USDJPY=X", "USDJPY": "USDJPY=X",
  "USD/CHF": "USDCHF=X", "USDCHF": "USDCHF=X",
  "AUD/USD": "AUDUSD=X", "AUDUSD": "AUDUSD=X",
  "USD/CAD": "USDCAD=X", "USDCAD": "USDCAD=X",
  "NZD/USD": "NZDUSD=X", "NZDUSD": "NZDUSD=X",
  "USD/MXN": "USDMXN=X", "USDMXN": "USDMXN=X",
  "USD/SGD": "USDSGD=X",
  "USD/HKD": "USDHKD=X",
  "USD/CNY": "USDCNY=X",
  "USD/INR": "USDINR=X",
  "USD/BRL": "USDBRL=X",
  "USD/ZAR": "USDZAR=X",
  "USD/TRY": "USDTRY=X",
  "EUR/GBP": "EURGBP=X",
  "EUR/JPY": "EURJPY=X",
  "GBP/JPY": "GBPJPY=X",
};

function toYahooSymbol(symbol) {
  if (!symbol) return null;
  const upper = symbol.toUpperCase();
  if (YAHOO_SYMBOL_MAP[upper]) return YAHOO_SYMBOL_MAP[upper];
  // Auto-convert FX pairs: "EUR/USD" → "EURUSD=X"
  if (upper.includes("/") && upper.length <= 7) {
    return upper.replace("/", "") + "=X";
  }
  return null;
}

async function fetchYahooFinance(symbol) {
  const yahooSym = toYahooSymbol(symbol);
  if (!yahooSym) throw new Error(`No Yahoo Finance mapping for symbol: ${symbol}`);
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSym)}?interval=1d&range=5d`;
  const res = await fetch(url, {
    headers: { "Accept": "application/json", "User-Agent": "Mozilla/5.0" }
  });
  if (!res.ok) throw new Error(`Yahoo Finance HTTP ${res.status} for ${yahooSym}`);
  const data = await res.json();
  const result = data?.chart?.result?.[0];
  if (!result) throw new Error(`Yahoo Finance: no data returned for ${yahooSym}`);
  const meta = result.meta || {};
  const price = meta.regularMarketPrice || meta.previousClose;
  if (!price) throw new Error(`Yahoo Finance: no price for ${yahooSym}`);
  const prevClose = meta.previousClose || meta.chartPreviousClose;
  const change24h = prevClose && prevClose !== price ? ((price - prevClose) / prevClose) * 100 : 0;
  const volume = meta.regularMarketVolume || 0;
  // Use 5d closes to estimate week change
  const closes = result.indicators?.quote?.[0]?.close?.filter(v => v != null) || [];
  const change7d = closes.length >= 2 ? ((closes[closes.length - 1] - closes[0]) / closes[0]) * 100 : null;

  // Liquidity score: based on market type inferred from symbol
  let liquidity_score = 70;
  if (yahooSym.includes("=X")) liquidity_score = 80;        // FX
  else if (yahooSym.startsWith("^")) liquidity_score = 85;  // Index
  else if (yahooSym.endsWith("=F")) liquidity_score = 72;   // Futures/commodities

  let trend = 50;
  if (change7d != null) trend += change7d * 1.2;
  trend += change24h * 1.0;
  const trend_score_input = clamp(Math.round(trend), 5, 95);
  const momentum_score_input = clamp(Math.round(50 + change24h * 1.5), 5, 95);
  const sentiment_score_input = clamp(Math.round(50 + change24h * 2), 5, 95);

  return {
    price, volume,
    change_1h: null, change_4h: null, change_24h: change24h,
    volatility: clamp(Math.abs(change24h) * 1.5, 0, 100),
    rsi: null,
    trend_score_input,
    momentum_score_input,
    catalyst_score_input: 50,
    sentiment_score_input,
    attention_score_input: 50,
    liquidity_score,
  };
}

async function fetchTwelveData(providerSymbol) {
  if (!providerSymbol) throw new Error("Twelve Data requires provider_symbol");
  const apiKey = Deno.env.get("TWELVE_DATA_API_KEY") || "";

  // Always attempt Yahoo Finance first if we have a mapping — avoids burning API credits
  // on known-unsupported symbols (plan restrictions, invalid symbols, etc.)
  const yahooSym = toYahooSymbol(providerSymbol);
  if (yahooSym) {
    return fetchYahooFinance(providerSymbol);
  }

  // No Yahoo mapping — try Twelve Data (for any symbol not in our map)
  if (!apiKey) throw new Error("TWELVE_DATA_API_KEY is not configured — add it in Settings → Secrets");
  const url = `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(providerSymbol)}&apikey=${apiKey}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`Twelve Data HTTP ${res.status}`);
  const data = await res.json();
  if (data.status === "error") {
    throw new Error(`Twelve Data: ${data.message || "unknown error"} — consider adding this symbol to the Yahoo Finance map`);
  }
  const price = parseFloat(data.close || data.price || "0");
  if (!price) throw new Error("Twelve Data returned no price — symbol may be invalid or market closed");
  const change24h = parseFloat(data.percent_change || "0");
  const volume = parseFloat(data.volume || "0");
  return {
    price, volume,
    change_1h: null, change_4h: null, change_24h: change24h,
    volatility: clamp(Math.abs(change24h) * 1.5, 0, 100),
    rsi: null,
    trend_score_input: clamp(50 + change24h * 2, 5, 95),
    momentum_score_input: clamp(50 + change24h * 1.5, 5, 95),
    catalyst_score_input: 50,
    sentiment_score_input: 50,
    attention_score_input: 50,
    liquidity_score: 65,
  };
}

// ─── Route to correct provider ────────────────────────────────────────────────
async function fetchFromProvider(asset) {
  const p = asset.data_provider;
  if (p === "coingecko") {
    return fetchCoinGecko(asset.provider_asset_id);
  }
  if (p === "dex_screener") {
    return fetchDexScreener(asset.chain_id, asset.pair_address);
  }
  if (p === "twelve_data" || p === "alpha_vantage") {
    return fetchTwelveData(asset.provider_symbol || asset.provider_asset_id);
  }
  if (p === "manual" || !p) {
    throw new Error("This asset uses manual data entry — no provider to fetch from");
  }
  throw new Error(`Unknown data provider: ${p}`);
}

// ─── Score a single asset snapshot and write/supersede signals ────────────────

export { fetchFromProvider };
