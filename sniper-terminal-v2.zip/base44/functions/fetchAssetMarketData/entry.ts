// Refresh ONE asset on demand (used when a user adds an asset or taps refresh).
// Any signed-in user may call it; each asset is rate-limited to once per minute.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { getUser, getState, setState, json } from "../../shared/auth.js";
import { runPipeline } from "../../shared/pipeline.js";
import { fetchFromProvider } from "./legacyProviders.ts";

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  try {
    const user = await getUser(base44);
    if (!user) return json({ error: "Unauthorized" }, 401);
    const { asset_id: assetId } = await req.json();
    if (!assetId) return json({ error: "asset_id required" }, 400);
    const svc = base44.asServiceRole;
    const asset = await svc.entities.Assets.get(assetId).catch(() => null);
    if (!asset) return json({ error: "Asset not found" }, 404);

    const stateKey = `asset_refresh:${assetId}`;
    const last = await getState(svc, stateKey);
    if (last?.at && Date.now() - last.at < 60_000) {
      return json({ success: true, skipped: true, reason: "Refreshed less than a minute ago", symbol: asset.symbol });
    }
    await setState(svc, stateKey, { at: Date.now(), by: user.email });

    // Liquidity estimate + fallback quote from the asset's original provider.
    let quote = null;
    let quoteError = null;
    try {
      quote = await fetchFromProvider(asset);
      if (quote?.liquidity_score != null) {
        await svc.entities.Assets.update(assetId, { liquidity_score: quote.liquidity_score, active: true });
      }
    } catch (e) {
      quoteError = e.message;
    }

    const summary = await runPipeline(svc, { assetIds: [assetId], deadlineMs: 60_000, withAlerts: false });
    const failed = summary.failed.find((f) => f.symbol === asset.symbol);

    if (failed && quote?.price) {
      // No hourly candle history (typical for DEX-only tokens): store a price-only snapshot.
      const now = new Date().toISOString();
      await svc.entities.MarketSnapshots.create({
        asset: assetId, timestamp: now, price: quote.price,
        change_1h: quote.change_1h ?? null, change_24h: quote.change_24h ?? null,
        volume: quote.volume ?? null, volume_change_percent: quote.volume_change_percent ?? null,
      });
      await svc.entities.Assets.update(assetId, { status: "active", data_status: "ok", last_refresh_at: now, data_error: `Price only — ${failed.error}` });
      return json({ success: true, price_only: true, symbol: asset.symbol, price: quote.price, note: "No hourly candle history available, so no signals are generated for this asset." });
    }
    if (failed) {
      return json({ success: false, error: `${failed.error}${quoteError ? ` | provider: ${quoteError}` : ""}`, symbol: asset.symbol, asset_id: assetId }, 422);
    }
    return json({ success: true, symbol: asset.symbol, provider: asset.data_provider, price: quote?.price ?? null, liquidity_score: quote?.liquidity_score ?? asset.liquidity_score, summary });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
