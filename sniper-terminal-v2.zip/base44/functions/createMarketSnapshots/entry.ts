import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// ─── Fetch helpers (asset-specific, no sharing) ───────────────────────────────

async function fetchCoinGecko(symbol, providerAssetId) {
  if (!providerAssetId) throw new Error("CoinGecko requires provider_asset_id");
  const url = `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(providerAssetId)}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (res.status === 429) throw new Error(`CoinGecko: rate limit hit`);
  if (!res.ok) throw new Error(`CoinGecko HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(`CoinGecko: ${data.error}`);
  
  const md = data.market_data || {};
  const price = md.current_price?.usd;
  if (!price) throw new Error(`CoinGecko: no price returned for ${symbol}`);
  
  // Explicit null for missing fields — do NOT substitute defaults
  return {
    symbol,
    source: "coingecko",
    timestamp: new Date().toISOString(),
    price,
    volume: md.total_volume?.usd ?? null,
    change_1h: md.price_change_percentage_1h_in_currency?.usd ?? null,
    change_4h: md.price_change_percentage_4h_in_currency?.usd ?? null,
    change_24h: md.price_change_percentage_24h ?? null,
    volatility: null, // CoinGecko doesn't provide volatility
    rsi: null, // CoinGecko doesn't provide RSI
    trend_score_input: null, // Requires additional analysis
    momentum_score_input: null, // Requires additional analysis
    catalyst_score_input: null, // External catalyst source
    sentiment_score_input: null, // Requires external sentiment API
    attention_score_input: null, // Requires attention analysis
    liquidity_score: null, // Requires additional analysis
    missing_fields: ["volatility", "rsi", "trend", "momentum", "catalyst", "sentiment", "attention", "liquidity"],
    fetch_status: "partial_success",
  };
}

async function fetchDexScreener(symbol, chainId, pairAddress) {
  if (!chainId || !pairAddress) throw new Error("DEX Screener requires chain_id and pair_address");
  const url = `https://api.dexscreener.com/latest/dex/pairs/${encodeURIComponent(chainId)}/${encodeURIComponent(pairAddress)}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) throw new Error(`DEX Screener HTTP ${res.status}`);
  const data = await res.json();
  const pair = (data.pairs || [])[0];
  if (!pair) throw new Error(`DEX Screener: pair not found for ${symbol}`);
  
  const price = parseFloat(pair.priceUsd || "0");
  if (!price) throw new Error(`DEX Screener: zero price for ${symbol}`);
  
  return {
    symbol,
    source: "dex_screener",
    timestamp: new Date().toISOString(),
    price,
    volume: pair.volume?.h24 ?? null,
    change_1h: pair.priceChange?.h1 ?? null,
    change_4h: pair.priceChange?.h6 ? (pair.priceChange.h6 / 1.5) : null,
    change_24h: pair.priceChange?.h24 ?? null,
    volatility: null, // DEX Screener doesn't provide
    rsi: null,
    trend_score_input: null,
    momentum_score_input: null,
    catalyst_score_input: null,
    sentiment_score_input: null,
    attention_score_input: null,
    liquidity_score: null,
    missing_fields: ["volatility", "rsi", "trend", "momentum", "catalyst", "sentiment", "attention", "liquidity"],
    fetch_status: "partial_success",
  };
}

async function fetchTwelveData(symbol, providerSymbol) {
  if (!providerSymbol) throw new Error("Twelve Data requires provider_symbol");
  const apiKey = Deno.env.get("TWELVE_DATA_API_KEY") || "";
  if (!apiKey) throw new Error("TWELVE_DATA_API_KEY not configured");
  
  const url = `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(providerSymbol)}&apikey=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Twelve Data HTTP ${res.status}`);
  const data = await res.json();
  if (data.status === "error") throw new Error(`Twelve Data: ${data.message || "unknown error"}`);
  
  const price = parseFloat(data.close || data.price || "0");
  if (!price) throw new Error(`Twelve Data: no price for ${symbol}`);
  
  return {
    symbol,
    source: "twelve_data",
    timestamp: new Date().toISOString(),
    price,
    volume: parseFloat(data.volume || "0") || null,
    change_1h: null, // Twelve Data doesn't provide intraday
    change_4h: null,
    change_24h: parseFloat(data.percent_change || "0") || null,
    volatility: null,
    rsi: null,
    trend_score_input: null,
    momentum_score_input: null,
    catalyst_score_input: null,
    sentiment_score_input: null,
    attention_score_input: null,
    liquidity_score: null,
    missing_fields: ["change_1h", "change_4h", "volatility", "rsi", "trend", "momentum", "catalyst", "sentiment", "attention", "liquidity"],
    fetch_status: "partial_success",
  };
}

// ─── Per-asset fetch router ───────────────────────────────────────────────────

async function fetchAssetData(asset) {
  const { symbol, data_provider, provider_asset_id, provider_symbol, chain_id, pair_address } = asset;
  
  let raw;
  try {
    if (data_provider === "coingecko") {
      raw = await fetchCoinGecko(symbol, provider_asset_id);
    } else if (data_provider === "dex_screener") {
      raw = await fetchDexScreener(symbol, chain_id, pair_address);
    } else if (data_provider === "twelve_data") {
      raw = await fetchTwelveData(symbol, provider_symbol || provider_asset_id);
    } else {
      throw new Error(`Unknown provider: ${data_provider}`);
    }
  } catch (e) {
    return {
      symbol,
      success: false,
      error: e.message,
      fetch_status: "failed",
      missing_fields: ["all"],
    };
  }
  
  return raw;
}

// ─── Duplicate detection (at snapshot level) ──────────────────────────────────

function computeSignature(snap) {
  // Signature based on volatile metrics only (excludes price, volume)
  return JSON.stringify({
    change_1h: snap.change_1h,
    change_4h: snap.change_4h,
    change_24h: snap.change_24h,
    volatility: snap.volatility,
    rsi: snap.rsi,
    trend_score_input: snap.trend_score_input,
    momentum_score_input: snap.momentum_score_input,
    sentiment_score_input: snap.sentiment_score_input,
    attention_score_input: snap.attention_score_input,
  });
}

function detectDuplicates(snapshots) {
  const signatures = {};
  const duplicates = [];
  
  for (const snap of snapshots) {
    const sig = computeSignature(snap);
    if (!signatures[sig]) signatures[sig] = [];
    signatures[sig].push(snap.symbol);
  }
  
  for (const [sig, symbols] of Object.entries(signatures)) {
    if (symbols.length >= 3) {
      duplicates.push({
        count: symbols.length,
        symbols,
        signature: sig,
      });
    }
  }
  
  return duplicates;
}

// ─── Data quality assessment ──────────────────────────────────────────────────

function assessDataQuality(snap) {
  const criticalFields = [
    "price",
    "change_1h",
    "change_4h",
    "change_24h",
    "volume",
    "volatility",
    "rsi",
  ];
  
  const missing = criticalFields.filter(f => snap[f] == null);
  
  if (missing.length > 4) {
    return { quality: "incomplete", confidence: 20, missing };
  }
  if (missing.length > 2) {
    return { quality: "incomplete", confidence: 40, missing };
  }
  if (missing.length > 0) {
    return { quality: "partial", confidence: 65, missing };
  }
  
  return { quality: "complete", confidence: 90, missing: [] };
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
    
    const now = new Date().toISOString();
    const allAssets = await base44.entities.Assets.filter({ active: true });
    const refreshable = allAssets.filter(a => a.data_provider && a.data_provider !== "manual");
    
    // ── Step 1: Fetch data PER ASSET (no sharing) ──────────────────────────────
    const results = [];
    const snapshots = [];
    const errors = [];
    
    for (const asset of refreshable) {
      const raw = await fetchAssetData(asset);
      
      if (!raw.success) {
        errors.push({ symbol: asset.symbol, error: raw.error });
        results.push({ symbol: asset.symbol, status: "failed", error: raw.error });
        continue;
      }
      
      snapshots.push(raw);
      results.push({ symbol: asset.symbol, status: "fetched", source: raw.source });
    }
    
    // ── Step 2: Detect duplicate patterns ──────────────────────────────────────
    const duplicates = detectDuplicates(snapshots);
    
    if (duplicates.length > 0) {
      console.warn(`[DUPLICATE DETECTION] Found ${duplicates.length} pattern(s):`);
      duplicates.forEach((dup, idx) => {
        console.warn(`  Pattern ${idx + 1}: ${dup.symbols.join(", ")} (${dup.count} identical snapshots)`);
      });
    }
    
    // Extract asset IDs in duplicate patterns to suppress
    const suppressedSymbols = new Set();
    duplicates.forEach(dup => {
      dup.symbols.forEach(sym => suppressedSymbols.add(sym));
    });
    
    // ── Step 3: Write snapshots (skipping duplicates) ──────────────────────────
    let written = 0, suppressed = 0, incomplete = 0;
    
    for (const snap of snapshots) {
      // Skip if part of duplicate pattern
      if (suppressedSymbols.has(snap.symbol)) {
        suppressed++;
        results.find(r => r.symbol === snap.symbol).status = "suppressed_duplicate";
        continue;
      }
      
      // Find asset
      const asset = allAssets.find(a => a.symbol === snap.symbol);
      if (!asset) continue;
      
      // Assess data quality
      const quality = assessDataQuality(snap);
      
      // CRITICAL: Do NOT write incomplete snapshots as normal
      if (quality.quality === "incomplete" || snap.fetch_status === "failed") {
        incomplete++;
        results.find(r => r.symbol === snap.symbol).status = "incomplete_data";
        
        // Mark asset as error
        await base44.entities.Assets.update(asset.id, {
          data_status: "incomplete",
          data_error: `Missing critical fields: ${snap.missing_fields?.join(", ") || "unknown"}`,
        });
        continue;
      }
      
      // Write snapshot with raw values (no substitution)
      const snapDoc = {
        asset: asset.id,
        timestamp: snap.timestamp,
        price: snap.price,
        change_1h: snap.change_1h,
        change_4h: snap.change_4h,
        change_24h: snap.change_24h,
        volume: snap.volume,
        volatility: snap.volatility,
        rsi: snap.rsi,
        trend_score_input: snap.trend_score_input,
        momentum_score_input: snap.momentum_score_input,
        catalyst_score_input: snap.catalyst_score_input,
        sentiment_score_input: snap.sentiment_score_input,
        attention_score_input: snap.attention_score_input,
      };
      
      // Remove null fields to avoid storing empty data
      Object.keys(snapDoc).forEach(k => {
        if (snapDoc[k] == null) delete snapDoc[k];
      });
      
      // Store metadata
      snapDoc._fetch_source = snap.source;
      snapDoc._data_quality = quality.quality;
      snapDoc._missing_fields = snap.missing_fields || [];
      snapDoc._fetch_timestamp = snap.timestamp;
      
      await base44.entities.MarketSnapshots.create(snapDoc);
      
      // Update asset
      await base44.entities.Assets.update(asset.id, {
        status: quality.quality === "partial" ? "pending_data" : "active",
        active: true,
        data_status: "ok",
        last_refresh_at: now,
        data_error: null,
      });
      
      written++;
      results.find(r => r.symbol === snap.symbol).status = "written";
    }
    
    return Response.json({
      success: true,
      timestamp: now,
      summary: {
        total_assets: refreshable.length,
        fetched: snapshots.length,
        written,
        incomplete,
        suppressed,
        errors: errors.length,
      },
      duplicates: duplicates.length > 0 ? duplicates : null,
      details: results.slice(0, 50), // First 50 for debugging
      errors: errors.slice(0, 10),
    });
    
  } catch (error) {
    console.error("createMarketSnapshots error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});