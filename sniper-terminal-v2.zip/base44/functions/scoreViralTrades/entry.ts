// Kept for backwards compatibility with existing buttons and workflows.
// All scoring now lives in base44/shared (one engine, no drifting copies).
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { authorizeJob, json } from "../../shared/auth.js";
import { runPipeline } from "../../shared/pipeline.js";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const gate = await authorizeJob(base44, "refreshAll", { minIntervalMs: 4 * 60_000 });
    if (!gate.ok) return gate.response;
    const summary = await runPipeline(gate.svc);
    return json({ success: true, ...summary, created: summary.viral.created });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
