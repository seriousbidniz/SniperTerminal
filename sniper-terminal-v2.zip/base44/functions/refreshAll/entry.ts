// Full market refresh: candles → snapshots → signal lifecycle → signals → alerts → push.
// Triggered by the "Daily Signal Refresh" workflow (every 5 min) or an admin.
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { authorizeJob, json } from "../../shared/auth.js";
import { runPipeline } from "../../shared/pipeline.js";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const gate = await authorizeJob(base44, "refreshAll", { minIntervalMs: 4 * 60_000 });
    if (!gate.ok) return gate.response;
    const summary = await runPipeline(gate.svc);
    // `results` keeps the response shape the Portfolio page already reads.
    return json({
      success: true,
      timestamp: new Date().toISOString(),
      summary,
      results: {
        snapshots_created: summary.snapshots,
        recommended: summary.rec,
        viral: summary.viral,
        alerts: { created: summary.alerts },
      },
    });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
