// ─────────────────────────────────────────────────────────────────────────────
// Calibration: "learning" from historical price action and live outcomes.
//
// Each run backtests a rotating batch of assets (≈1,000 hourly bars each) with
// the exact live engine, stores per-asset stats, then rebuilds market-level
// calibration by blending backtest evidence (capped at 50 pseudo-samples) with
// the real resolved outcomes of live signals. The signal engine reads the
// market-level rows on every refresh.
// ─────────────────────────────────────────────────────────────────────────────
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { authorizeJob, getState, setState, json, upsertBy } from "../../shared/auth.js";
import { fetchCandlesForAsset, closedCandles } from "../../shared/marketData.js";
import { backtestAsset, aggregateTrades, blendCalibration, DEFAULT_COST_PER_SIDE } from "../../shared/backtest.js";
import { calibrationKey } from "../../shared/signalEngine.js";

const BATCH = 10;
const DEADLINE_MS = 220_000;
const LIVE_LOOKBACK_MS = 180 * 24 * 3600_000;
const TRIGGERED = new Set(["win", "loss", "expired_profit", "expired_loss", "expired_flat", "expired_open"]);

Deno.serve(async (req) => {
  const started = Date.now();
  try {
    const base44 = createClientFromRequest(req);
    const gate = await authorizeJob(base44, "calibrateSetups", { minIntervalMs: 45 * 60_000 });
    if (!gate.ok) return gate.response;
    const svc = gate.svc;

    const assets = (await svc.entities.Assets.filter({ active: true }, "created_date", 500)).filter((a) => a.data_status !== "error");
    const cursor = (await getState(svc, "calibration:cursor"))?.index ?? 0;
    const batch = [];
    for (let k = 0; k < Math.min(BATCH, assets.length); k++) batch.push(assets[(cursor + k) % assets.length]);
    await setState(svc, "calibration:cursor", { index: assets.length ? (cursor + batch.length) % assets.length : 0 });

    const perAsset = [];
    const errors = [];
    for (const asset of batch) {
      if (Date.now() - started > DEADLINE_MS) break;
      try {
        const { candles } = await fetchCandlesForAsset(asset, { bars: 1000 });
        const closed = closedCandles(candles);
        if (closed.length < 400) throw new Error(`only ${closed.length} bars`);
        const trades = backtestAsset(closed, asset);
        const agg = aggregateTrades(trades);
        for (const [key, s] of Object.entries(agg)) {
          const [setup, mt] = key.split("|");
          perAsset.push({
            key: `${asset.id}:${key}`, scope: "asset", asset_id: asset.id, setup_type: setup, market_type: mt,
            bt_n: s.n, bt_wins: s.wins, bt_sum_r: Math.round(s.sum_r * 1000) / 1000, bt_signals: s.n_signals,
            bt_bars: JSON.stringify(s.bars.slice(-300)),
            cost_assumption_per_side: DEFAULT_COST_PER_SIDE[asset.market_type] ?? 0.001,
            window_start: new Date(closed[0].t).toISOString(), window_end: new Date(closed[closed.length - 1].t).toISOString(),
            updated_at: new Date().toISOString(),
          });
        }
      } catch (e) {
        errors.push({ symbol: asset.symbol, error: e.message.slice(0, 200) });
      }
    }
    if (perAsset.length) await upsertBy(svc.entities.SetupCalibration, perAsset, "key");

    // ── Rebuild market-level calibration ──────────────────────────────────────
    const assetRows = await svc.entities.SetupCalibration.filter({ scope: "asset" }, "-updated_at", 5000);
    const bt: Record<string, any> = {};
    for (const r of assetRows) {
      const key = `${r.setup_type}|${r.market_type}`;
      const b = (bt[key] ||= { n: 0, wins: 0, sum_r: 0, bars: [], n_signals: 0 });
      b.n += r.bt_n || 0; b.wins += r.bt_wins || 0; b.sum_r += r.bt_sum_r || 0; b.n_signals += r.bt_signals || 0;
      try { b.bars.push(...JSON.parse(r.bt_bars || "[]")); } catch { /* ignore */ }
    }

    const assetsById = Object.fromEntries(assets.map((a) => [a.id, a]));
    const since = new Date(Date.now() - LIVE_LOOKBACK_MS).toISOString();
    const resolved = await svc.entities.RecommendedTradeSignals.filter(
      { status: { $in: ["invalidated", "expired", "closed", "target_hit"] }, timestamp: { $gte: since } }, "-timestamp", 5000);
    const live: Record<string, any> = {};
    for (const s of resolved) {
      if (!TRIGGERED.has(s.outcome) || !s.setup_type) continue;
      const mt = assetsById[s.asset]?.market_type || "crypto";
      const key = calibrationKey(s.setup_type, s.direction, mt);
      const l = (live[key] ||= { n: 0, wins: 0, sum_r: 0, bars: [] });
      l.n++;
      if (s.outcome === "win") l.wins++;
      l.sum_r += s.outcome_r ?? 0;
      const end = s.target_1_hit_at || s.invalidated_at || s.closed_at;
      if (end && s.timestamp) l.bars.push(Math.round((new Date(end).getTime() - new Date(s.timestamp).getTime()) / 3600_000));
    }

    const keys = new Set([...Object.keys(bt), ...Object.keys(live)]);
    const marketRows = [];
    for (const key of keys) {
      const [setup, mt] = key.split("|");
      const blend = blendCalibration(bt[key], live[key]);
      marketRows.push({
        key, scope: "market", setup_type: setup, market_type: mt,
        bt_n: bt[key]?.n || 0, bt_wins: bt[key]?.wins || 0, bt_sum_r: bt[key] ? Math.round(bt[key].sum_r * 1000) / 1000 : 0, bt_signals: bt[key]?.n_signals || 0,
        live_n: live[key]?.n || 0, live_wins: live[key]?.wins || 0, live_sum_r: live[key] ? Math.round(live[key].sum_r * 1000) / 1000 : 0,
        n_effective: blend.n_effective,
        win_rate: blend.win_rate == null ? null : Math.round(blend.win_rate * 10000) / 10000,
        expectancy_r: blend.expectancy_r == null ? null : Math.round(blend.expectancy_r * 1000) / 1000,
        median_bars_to_resolution: blend.median_bars_to_resolution,
        source: blend.source, updated_at: new Date().toISOString(),
      });
    }
    if (marketRows.length) await upsertBy(svc.entities.SetupCalibration, marketRows, "key");

    return json({ success: true, backtested: batch.map((a) => a.symbol), errors, asset_rows: perAsset.length, market_rows: marketRows.length, duration_ms: Date.now() - started });
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
