// Web Push subscription management for the signed-in user.
// ops: config | subscribe | unsubscribe | test
import { createClientFromRequest } from "npm:@base44/sdk@0.8.25";
import { getUser, getSecret, json, upsertBy } from "../../shared/auth.js";
import { enqueuePush } from "../../shared/notify.js";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await getUser(base44);
    if (!user) return json({ error: "Unauthorized" }, 401);
    const svc = base44.asServiceRole;
    const body = await req.json().catch(() => ({}));

    if (body.op === "config") {
      const key = getSecret("VAPID_PUBLIC_KEY");
      const hb = await svc.entities.SystemState.filter({ key: "worker:heartbeat" }, "-updated_date", 1);
      let workerAt = null;
      try { workerAt = hb[0] ? JSON.parse(hb[0].value).at : null; } catch { /* ignore */ }
      return json({ vapid_public_key: key || null, worker_last_seen: workerAt });
    }

    if (body.op === "subscribe") {
      const sub = body.subscription;
      if (!sub?.endpoint || !sub?.keys?.p256dh || !sub?.keys?.auth) return json({ error: "Invalid subscription" }, 400);
      if (!/^https:\/\//.test(sub.endpoint)) return json({ error: "Invalid endpoint" }, 400);
      await upsertBy(svc.entities.PushSubscriptions, [{
        user_email: user.email, endpoint: sub.endpoint, p256dh: sub.keys.p256dh, auth: sub.keys.auth,
        user_agent: String(body.user_agent || "").slice(0, 300), active: true, failure_count: 0,
        created_at: new Date().toISOString(),
      }], "endpoint");
      return json({ success: true });
    }

    if (body.op === "unsubscribe") {
      const rows = await svc.entities.PushSubscriptions.filter({ user_email: user.email, endpoint: body.endpoint }, "-created_date", 5);
      for (const r of rows) await svc.entities.PushSubscriptions.delete(r.id);
      return json({ success: true, removed: rows.length });
    }

    if (body.op === "test") {
      const rows = await enqueuePush(svc, [{ email: user.email, tag: `test:${Date.now()}`, message: { title: "Sniper Terminal", body: "Test notification — push delivery is working.", url: "/settings", severity: "info" } }]);
      return json({ success: true, queued: rows.length, note: "Delivered by the realtime worker within ~10 seconds if it is running." });
    }
    return json({ error: "Unknown op" }, 400);
  } catch (error) {
    return json({ error: error.message }, 500);
  }
});
